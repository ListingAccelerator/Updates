"""
ai_reply.py -- the Reply helper in Accelerator CRM.

Each buyer of the program chooses, in Accelerator CRM -> AI replies:
    "copy"    Copy for AI (no setup): the program builds the whole request --
              the buyer's message, the car, and the playbook -- and the
              salesman pastes it into whatever AI he already uses.
    "gemini"  His own free Google Gemini key: replies appear right in the
              program.
    "plan"    Included with a plan (reserved for when license keys arrive).

PRIVACY: before anything leaves the computer, the customer's name, phone
numbers, email addresses and street address are taken out of everything
sent. Only the message, the car's details and what you've told the program
about the deal go -- never who the customer is.

The key lives in program\\customers\\ai_settings.json, next to the customers,
which updates never touch.
"""
from __future__ import annotations

import json
import os
import re
import urllib.error
import urllib.request

import customers
import playbook

FILE = customers.BOOK / "ai_settings.json"
API = os.environ.get("LA_AI_API_TEST") or "https://generativelanguage.googleapis.com/v1beta"
# Google changes which models a new key may use, so the program asks the
# key which ones it has and picks the best fast one (see pick_model). These
# are only tried if that list can't be read.
FALLBACK_MODELS = ["gemini-flash-latest", "gemini-3.8-flash", "gemini-3.5-flash",
                   "gemini-3.5-flash-lite"]
MODES = ("copy", "gemini", "plan")


# ------------------------------------------------------------- settings
def settings() -> dict:
    try:
        d = json.loads(FILE.read_text(encoding="utf-8"))
        if isinstance(d, dict):
            return {"mode": d.get("mode") if d.get("mode") in MODES else "copy",
                    "key": str(d.get("key") or ""),
                    "model": str(d.get("model") or ""),
                    "tested": str(d.get("tested") or "")}
    except Exception:
        pass
    return {"mode": "copy", "key": "", "model": "", "tested": ""}


def public_settings() -> dict:
    """What the window may see -- never the whole key."""
    s = settings()
    k = s["key"]
    return {"mode": s["mode"], "model": s["model"], "tested": s["tested"],
            "has_key": bool(k), "key_hint": ("…" + k[-4:]) if len(k) > 8 else ""}


def save_settings(mode: str, key: str | None = None) -> dict:
    s = settings()
    if mode in MODES:
        s["mode"] = mode
    if key is not None:
        key = key.strip()
        if key != s["key"]:
            s["key"], s["model"], s["tested"] = key, "", ""
    customers.BOOK.mkdir(parents=True, exist_ok=True)
    FILE.write_text(json.dumps(s, indent=1), encoding="utf-8")
    return public_settings()


# ------------------------------------------------------------- privacy
def scrub(text: str, c: dict) -> str:
    """Take out who the customer is: name, phones, emails, street address."""
    t = str(text or "")
    t = customers.EMAIL.sub("[email]", t)
    t = customers.PHONE.sub("[phone]", t)
    t = re.sub(r"\b\d{2,6}\s+[A-Za-z0-9 .'-]{2,40}\b(?:St|Street|Rd|Road|Ave|Avenue|Dr|Drive|Ln|Lane|"
               r"Ct|Court|Blvd|Way|Hwy|Highway|Pike|Cir|Circle|Pl|Place)\b\.?", "[address]", t, flags=re.I)
    addr = str(c.get("address") or "").strip()
    if addr:
        t = t.replace(addr, "[address]")
    for part in sorted(str(c.get("name") or "").split(), key=len, reverse=True):
        if len(part) >= 2:
            t = re.sub(r"\b" + re.escape(part) + r"\b", "[customer]", t, flags=re.I)
    return t


# ------------------------------------------------------------- the request
def _store_settings(c: dict) -> dict:
    for st in customers.stores.all_stores():
        if st["key"] == c.get("store_key"):
            return st["settings"]
    allst = customers.stores.all_stores()
    return allst[0]["settings"] if allst else {}


def brief(c: dict, message: str, tweak: str = "") -> str:
    """Everything the AI needs about this deal -- with the customer taken out."""
    v = customers.view(c)
    st = _store_settings(c)
    L = []
    me = st.get("first_name") or ""
    store = st.get("store_name") or v.get("store") or ""
    if me or store:
        L.append(f"Salesperson: {me or 'the salesperson'}"
                 + (f" at {store}" + (f", {st.get('city')}" if st.get("city") else "") if store else ""))
    for car in v["cars"] or []:
        bits = [f"Vehicle: {car['stock']} {car['name']}".strip()]
        if isinstance(car.get("price"), (int, float)):
            bits.append(f"posted price ${car['price']:,}")
        if isinstance(car.get("miles"), (int, float)):
            bits.append(f"{car['miles']:,} miles")
        if car.get("on_lot") is True:
            bits.append("still on the website")
        elif car.get("on_lot") is False:
            bits.append("NO LONGER on the website (may have sold)")
        L.append(" · ".join(bits))
    if not v["cars"]:
        L.append("Vehicle: not picked yet")
    if c.get("wants"):
        L.append("They want: " + ", ".join(c["wants"]))
    L.append(f"Where it stands: {c.get('status') or 'New'}")
    if c.get("appointment"):
        L.append(f"Appointment: {v.get('appt_word')}")
    if c.get("trade"):
        L.append("Their trade: " + scrub(c["trade"], c))
    sent = [e["text"] for e in (c.get("sent") or [])][-5:]
    if sent:
        L.append("Already sent them: " + "; ".join(scrub(s, c) for s in sent))
    notes = [e["text"] for e in (c.get("notes") or [])][-3:]
    if notes:
        L.append("Salesperson's notes: " + " / ".join(scrub(n, c) for n in notes))
    chat = [e["text"] for e in (c.get("chat") or [])]
    if chat:
        earlier = scrub("\n".join(chat), c)[-1500:]
        L.append("Earlier in the chat:\n" + earlier)
    L.append("THEIR LATEST MESSAGE:\n" + scrub(message, c).strip())
    if tweak in playbook.TWEAKS:
        L.append("\n" + playbook.TWEAKS[tweak])
    return "\n".join(L)


def copy_text(c: dict, message: str) -> str:
    """The whole request, in plain English, ready to paste into any AI."""
    rules = playbook.RULES.split("OUTPUT")[0].rstrip()
    return (rules + "\n\nWRITE THREE REPLIES I can send, each 1 to 3 sentences:\n"
            "1. Keep them talking\n2. Set the appointment\n"
            "3. Answer what they asked, straight\n"
            "Under each one, name the rule it follows. Then tell me which one "
            "you'd send.\n\n---\n\n" + brief(c, message))


# ------------------------------------------------------------- Gemini
def _post(url: str, key: str, body: dict | None = None, timeout: int = 40):
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, method="POST" if data else "GET",
                                 headers={"x-goog-api-key": key,
                                          "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def _why(e: Exception) -> str:
    if isinstance(e, urllib.error.HTTPError):
        try:
            msg = json.loads(e.read().decode("utf-8")).get("error", {}).get("message", "")
        except Exception:
            msg = ""
        if e.code in (400, 401, 403) and ("key" in msg.lower() or e.code != 400):
            return "Google didn't accept that key. Copy it again from Google AI Studio and paste it in."
        if e.code == 429:
            return ("Google's free limit is used up for now. Try again in a minute, "
                    "or use Copy for AI.")
        if e.code == 404:
            return "That AI model isn't available to this key."
        return f"Google said: {msg or e.code}"
    if isinstance(e, urllib.error.URLError):
        return ("Couldn't reach Google from this computer. The network may block it "
                "(common on work computers) -- use Copy for AI instead.")
    return f"Something went wrong: {type(e).__name__}"


def _rank(name: str) -> tuple:
    nums = [int(x) for x in re.findall(r"\d+", name)[:2]] + [0, 0]
    return (nums[0], nums[1], "lite" not in name, "latest" in name)


def pick_model(key: str) -> list[str]:
    """Fast text models this key can use, best first."""
    try:
        d = _post(f"{API}/models?pageSize=200", key)
        names = []
        for m in d.get("models", []):
            n = str(m.get("name", "")).split("/")[-1]
            if "generateContent" not in (m.get("supportedGenerationMethods") or []):
                continue
            if "flash" not in n or re.search(r"image|tts|audio|live|embed|vision|thinking|exp", n):
                continue
            names.append(n)
        names.sort(key=_rank, reverse=True)
        stable = [n for n in names if "preview" not in n]
        return (stable + [n for n in names if n not in stable]) or FALLBACK_MODELS
    except urllib.error.HTTPError as e:
        if e.code in (400, 401, 403):
            raise
        return FALLBACK_MODELS
    except Exception:
        return FALLBACK_MODELS


def _ask(key: str, model: str, prompt: str) -> dict:
    body = {"systemInstruction": {"parts": [{"text": playbook.RULES}]},
            "contents": [{"role": "user", "parts": [{"text": prompt}]}],
            "generationConfig": {"temperature": 0.8,
                                 "responseMimeType": "application/json"}}
    d = _post(f"{API}/models/{model}:generateContent", key, body)
    parts = (((d.get("candidates") or [{}])[0].get("content") or {}).get("parts") or [])
    text = "".join(p.get("text", "") for p in parts).strip()
    m = re.search(r"\{.*\}", text, re.S)
    out = json.loads(m.group(0) if m else text)
    reps = [r for r in out.get("replies", []) if str(r.get("text", "")).strip()]
    if not reps:
        raise ValueError("no replies")
    return {"replies": reps[:3], "best": out.get("best") or ""}


def test_key(key: str | None = None) -> dict:
    s = settings()
    key = (key or s["key"]).strip()
    if not key:
        return {"ok": False, "message": "Paste your key first."}
    try:
        models = pick_model(key)
    except Exception as e:
        return {"ok": False, "message": _why(e)}
    last = None
    for m in models[:6]:
        try:
            _ask(key, m, "Vehicle: 2020 Honda CR-V EX · posted price $21,980\n"
                         "THEIR LATEST MESSAGE:\nIs this still available?")
            s.update(key=key, model=m, mode="gemini",
                     tested=customers.datetime.now().strftime("%Y-%m-%d %H:%M"))
            customers.BOOK.mkdir(parents=True, exist_ok=True)
            FILE.write_text(json.dumps(s, indent=1), encoding="utf-8")
            return {"ok": True, "model": m,
                    "message": "It works. AI replies are on."}
        except Exception as e:
            last = e
            if isinstance(e, urllib.error.HTTPError) and e.code != 404:
                break
            if isinstance(e, urllib.error.URLError) and not isinstance(e, urllib.error.HTTPError):
                break
    return {"ok": False, "message": _why(last) if last else "No AI model answered."}


def write(c: dict, message: str, tweak: str = "") -> dict:
    s = settings()
    if s["mode"] != "gemini" or not s["key"]:
        return {"ok": False, "off": True,
                "message": "AI replies aren't turned on. Use Copy for AI, or turn them on "
                           "in AI replies (free, about 2 minutes)."}
    if not str(message or "").strip():
        return {"ok": False, "message": "Paste what they said first."}
    prompt = brief(c, message, tweak)
    tried, last = [], None
    order = ([s["model"]] if s["model"] else []) + ["?pick"]
    while order:
        m = order.pop(0)
        if m == "?pick":
            order = [x for x in pick_model(s["key"])[:5] if x not in tried]
            continue
        tried.append(m)
        try:
            out = _ask(s["key"], m, prompt)
            if m != s["model"]:
                s["model"] = m
                FILE.write_text(json.dumps(s, indent=1), encoding="utf-8")
            return {"ok": True, **out}
        except urllib.error.HTTPError as e:
            last = e
            if e.code != 404:          # 404 = this model is gone; try the next
                break
        except (ValueError, KeyError) as e:
            last = e                  # an answer we couldn't read; try again
        except Exception as e:
            last = e
            break
    return {"ok": False, "message": _why(last) if last else "The AI didn't answer."}
