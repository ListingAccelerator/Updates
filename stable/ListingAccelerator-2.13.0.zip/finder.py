"""
finder.py -- find a car for a customer, across every store.

A customer says "a 2018 to 2022 SUV, Honda or Toyota, around $20,000, under
$400 a month, not too many miles." This searches every store in the program
for it -- the WHOLE used lot each store's website shows, not only the cars he
posts (his "What you work" filter only decides what he posts; every update
still reads every car on the site).

It reads what the last update saved (each store's out\\inventory.json), so
it is as fresh as that update. Nothing is sent anywhere.

Exact matches first, then close ones -- a car that misses by a little (a
year older, a few hundred over, a different model of the same kind) -- with
what's off spelled out, so he always has something to offer.

Payments are an estimate from the APR, term, down payment and tax he sets
on the search screen (kept in "finder.json" for next time).
"""
from __future__ import annotations

import csv
import json
import re
from datetime import datetime
from pathlib import Path

DEFAULTS = {"apr": 11.99, "term": 72, "down": 2000, "tax": 0.0, "trade": 0}

# A car is "close" when it misses by no more than this.
NEAR_YEARS = 1
NEAR_PRICE = 0.10          # 10% over the top (or under the bottom) of the range
NEAR_PRICE_MIN = 1500      # ...but always allow at least this many dollars
NEAR_PAY = 40              # dollars a month
NEAR_MILES = 0.15          # 15% over his miles limit
MAX_MISSES = 2

BODY_WORDS = {
    "suv": "SUV", "suvs": "SUV", "crossover": "SUV", "crossovers": "SUV",
    "truck": "Truck", "trucks": "Truck", "pickup": "Truck", "pickups": "Truck",
    "sedan": "Sedan", "sedans": "Sedan", "car": "Sedan", "cars": "Sedan",
    "coupe": "Coupe", "coupes": "Coupe",
    "van": "Van", "vans": "Van", "minivan": "Minivan", "minivans": "Minivan",
    "hatchback": "Hatchback", "hatchbacks": "Hatchback",
    "convertible": "Convertible", "convertibles": "Convertible",
    "wagon": "Wagon", "wagons": "Wagon",
}

# The options customers ask for, and how the websites word them.
OPTIONS = [
    ("awd", "4WD / AWD", r"\b(4wd|awd|4x4|all[- ]wheel|four[- ]wheel|4motion|quattro|xdrive|sh-awd)\b"),
    ("leather", "Leather", r"leather"),
    ("sunroof", "Sunroof / moonroof", r"sunroof|moonroof|panoramic|moon roof|sun roof"),
    ("third", "3rd row", r"3rd row|third row|third-row|3rd-row|7[- ]passenger|8[- ]passenger"),
    ("heated", "Heated seats", r"heated (front |driver |rear )?seat|heated seats|seat heat"),
    ("cooled", "Cooled seats", r"(ventilated|cooled) (front )?seat"),
    ("hwheel", "Heated steering wheel", r"heated steering"),
    ("nav", "Navigation", r"navigation|\bnav\b|\bgps\b"),
    ("carplay", "Apple CarPlay / Android Auto", r"carplay|android auto"),
    ("camera", "Backup camera", r"rear ?view camera|back-?up camera|rearview camera|parkview|360"),
    ("remote", "Remote start", r"remote (engine )?start"),
    ("blind", "Blind spot monitor", r"blind spot"),
    ("acc", "Adaptive cruise", r"adaptive cruise|dynamic radar cruise|smart cruise"),
    ("tow", "Towing package", r"\btow|trailer hitch|trailer sway|hitch"),
    ("liftgate", "Power liftgate", r"power (tailgate|liftgate|lift gate|rear door|hatch)|hands-free (lift|tail)gate"),
    ("bluetooth", "Bluetooth", r"bluetooth|wireless phone"),
    ("wifi", "Wi-Fi hotspot", r"wi-?fi|hotspot"),
    ("hybrid", "Hybrid / electric", r"hybrid|electric|\bev\b|plug-in"),
    ("diesel", "Diesel", r"diesel|duramax|cummins|powerstroke|power stroke|ecodiesel|\btdi\b"),
    ("v8", "V8", r"\bv-?8\b|8 cylinder|5\.7l|5\.3l|6\.2l|5\.0l|hemi"),
]
_OPT = {k: (label, re.compile(rx, re.I)) for k, label, rx in OPTIONS}


def option_list() -> list[dict]:
    return [{"key": k, "label": label} for k, label, _ in OPTIONS]


def _car_text(rec: dict) -> tuple[str, bool]:
    """Everything the website said about the car's equipment, and whether
    that includes its full option list (only cars whose own page was read)."""
    opts = rec.get("options") if isinstance(rec.get("options"), list) else []
    bits = [str(o) for o in opts]
    for k in ("model_trim", "model", "trim", "drivetrain", "engine", "engine_full",
              "fuel_type", "transmission", "body_style", "infotainment", "title"):
        if rec.get(k):
            bits.append(str(rec[k]))
    return " | ".join(bits), len(opts) >= 8


# Things a website states for every car even without opening its page, so
# "not listed" there really means "doesn't have it".
_ALWAYS_KNOWN = {"hybrid", "diesel"}


# Makes salesmen and customers say differently from the website.
MAKE_SAID = {"chevy": "chevrolet", "vw": "volkswagen", "benz": "mercedes",
             "mercedes-benz": "mercedes", "caddy": "cadillac", "olds": "oldsmobile"}


# ------------------------------------------------------------------ settings
def _file() -> Path:
    import config
    return Path(config.BASE) / "finder.json"


def settings() -> dict:
    s = dict(DEFAULTS)
    try:
        d = json.loads(_file().read_text(encoding="utf-8"))
        if isinstance(d, dict):
            for k in DEFAULTS:
                if k in d:
                    s[k] = d[k]
    except Exception:
        pass
    return _clean_money(s)


def _num(v, default=0.0) -> float:
    try:
        return float(str(v).replace("$", "").replace(",", "").replace("%", "").strip() or default)
    except (TypeError, ValueError):
        return default


def _clean_money(s: dict) -> dict:
    return {"apr": max(0.0, min(40.0, round(_num(s.get("apr"), DEFAULTS["apr"]), 2))),
            "term": int(max(12, min(96, _num(s.get("term"), DEFAULTS["term"])))),
            "down": int(max(0, _num(s.get("down"), 0))),
            "trade": int(max(0, _num(s.get("trade"), 0))),
            "tax": max(0.0, min(15.0, round(_num(s.get("tax"), 0), 3)))}


def save_settings(s: dict) -> dict:
    s = _clean_money(s or {})
    try:
        _file().write_text(json.dumps(s, indent=1), encoding="utf-8")
    except Exception:
        pass
    return s


# ------------------------------------------------------------------ payments
def payment(price: float, m: dict) -> int | None:
    """Monthly payment estimate: price plus tax, less down and trade, at APR for term."""
    if not price:
        return None
    financed = price * (1 + m["tax"] / 100) - m["down"] - m["trade"]
    if financed <= 0:
        return 0
    n = m["term"]
    r = m["apr"] / 1200
    if r == 0:
        return round(financed / n)
    return round(financed * r / (1 - (1 + r) ** -n))


def pay_on(financed: float, apr: float, term: int) -> int:
    """Payment on an amount financed."""
    if financed <= 0:
        return 0
    r = float(apr) / 1200
    n = int(term) or 72
    return round(financed / n) if r == 0 else round(financed * r / (1 - (1 + r) ** -n))


def price_for_payment(pay: float, m: dict) -> int:
    """The car price a payment buys -- payment() worked backwards."""
    n, r = m["term"], m["apr"] / 1200
    financed = pay * n if r == 0 else pay * (1 - (1 + r) ** -n) / r
    return int((financed + m["down"] + m["trade"]) / (1 + m["tax"] / 100))


# ------------------------------------------------------------------ the lots
def _posted(store_dir: Path) -> set[str]:
    f = store_dir / "out" / "posted.csv"
    out = set()
    try:
        with open(f, newline="", encoding="utf-8") as fh:
            for r in csv.DictReader(fh):
                if r.get("Stock") and r.get("Posted_Date") and r.get("Status") != "down":
                    out.add(r["Stock"].strip().upper())
    except Exception:
        pass
    return out


def lots() -> list[dict]:
    """Every store's saved lot: [{key, name, read, cars, posted}]."""
    import stores
    out = []
    for s in stores.all_stores():
        d = Path(s["dir"])
        f = d / "out" / "inventory.json"
        try:
            cars = json.loads(f.read_text(encoding="utf-8"))
            read = datetime.fromtimestamp(f.stat().st_mtime).isoformat(timespec="minutes")
        except Exception:
            cars, read = [], ""
        out.append({"key": s["key"], "name": s["name"], "read": read,
                    "cars": cars if isinstance(cars, list) else [], "posted": _posted(d),
                    "photo_drop": (s.get("settings") or {}).get("photo_drop") or str(d / "Photo Drop")})
    return out


# ------------------------------------------------------------------ the search
def _words(s) -> list[str]:
    if isinstance(s, list):
        s = ",".join(str(x) for x in s)
    return [w.strip().lower() for w in re.split(r"[,/;]|\bor\b|\band\b", str(s or "")) if w.strip()]


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(s or "").lower())


def _make_key(s: str) -> str:
    s = str(s or "").strip().lower()
    return _norm(MAKE_SAID.get(s, s))


def _range(lo, hi):
    lo, hi = _num(lo, 0), _num(hi, 0)
    if lo and hi and lo > hi:
        lo, hi = hi, lo
    return lo, hi


def _body(rec: dict) -> str:
    import track
    try:
        return track.body_of(rec) or ""
    except Exception:
        return str(rec.get("body_style") or "")


def _name(rec: dict) -> str:
    return " ".join(str(rec.get(k) or "").strip() for k in ("year", "make", "model", "trim")).strip() \
        or str(rec.get("model_trim") or rec.get("title") or rec.get("stock") or "")


def _color(rec: dict) -> str:
    c = str(rec.get("exterior_color") or "").strip()
    return "" if (not c or c.startswith("$") or re.fullmatch(r"[\d,.$ ]+", c)) else c


def _money(n) -> str:
    return f"${int(n):,}"


def search(q: dict, all_lots: list | None = None, remember: bool = True) -> dict:
    import track
    m = _clean_money({k: q.get(k, v) for k, v in settings().items()})
    if remember:
        save_settings(m)

    y_lo, y_hi = _range(q.get("year_from"), q.get("year_to"))
    p_lo, p_hi = _range(q.get("price_from"), q.get("price_to"))
    pay_lo, pay_hi = _range(q.get("pay_from"), q.get("pay_to"))
    miles_max = _num(q.get("miles_max"), 0)
    makes = [_make_key(w) for w in _words(q.get("makes"))]
    bodies, models = set(), []
    for w in _words(q.get("models")):
        if w in BODY_WORDS:
            bodies.add(BODY_WORDS[w])
        else:
            models.append(_norm(w))
    want_opts = [k for k in (q.get("options") or []) if k in _OPT]
    extra = [w for w in _words(q.get("other")) if len(w) > 1]
    want_stores = set(q.get("stores") or [])
    close_ok = q.get("close", True) is not False

    all_lots = all_lots if all_lots is not None else lots()
    # The kind of vehicle the customer's models are (CR-V -> SUV), read from
    # the lots themselves, so "close" can offer a RAV4 for a CR-V.
    model_bodies = set()
    if models:
        for lot in all_lots:
            for r in lot["cars"]:
                if any(mo and mo in _norm(f"{r.get('model','')} {r.get('trim','')}") for mo in models):
                    b = _body(r)
                    if b:
                        model_bodies.add(b)

    found, searched, per_store = [], 0, []
    for lot in all_lots:
        if want_stores and lot["key"] not in want_stores:
            continue
        n = 0
        for r in lot["cars"]:
            stock = str(r.get("stock") or "").strip()
            if not stock:
                continue
            try:
                if track.condition_of(r) != "used" or track.is_other_store(r):
                    continue
            except Exception:
                pass
            n += 1
            misses, exact_fail = [], False
            try:
                year = int(r.get("year") or 0)
            except (TypeError, ValueError):
                year = 0
            price = track.price_of(r) or 0
            miles = int(_num(r.get("mileage"), 0))
            pay = payment(price, m)
            body = _body(r)
            make = _make_key(r.get("make"))
            model_txt = _norm(f"{r.get('model','')} {r.get('trim','')} {r.get('model_trim','')}")

            # year
            if y_lo and year and year < y_lo:
                d = int(y_lo - year)
                (misses.append(f"{d} year{'s' if d > 1 else ''} older") if d <= NEAR_YEARS else None)
                exact_fail = exact_fail or d > NEAR_YEARS
            if y_hi and year and year > y_hi:
                d = int(year - y_hi)
                (misses.append(f"{d} year{'s' if d > 1 else ''} newer") if d <= NEAR_YEARS else None)
                exact_fail = exact_fail or d > NEAR_YEARS
            if (y_lo or y_hi) and not year:
                exact_fail = True

            # make / model / type
            if makes and not any(mk and (mk == make or mk in make or make in mk) for mk in makes):
                if (bodies or model_bodies) and body and body in (bodies | model_bodies):
                    misses.append("different make, same type")
                else:
                    exact_fail = True
            if models and not any(mo and mo in model_txt for mo in models):
                if body and body in model_bodies:
                    if "different make, same type" not in misses:
                        misses.append(f"different model, same type ({body})")
                else:
                    exact_fail = True
            if bodies and body not in bodies:
                exact_fail = True

            # price
            if (p_lo or p_hi) and not price:
                exact_fail = True
            elif price:
                if p_hi and price > p_hi:
                    over = price - p_hi
                    if over <= max(NEAR_PRICE * p_hi, NEAR_PRICE_MIN):
                        misses.append(f"{_money(over)} over price")
                    else:
                        exact_fail = True
                if p_lo and price < p_lo:
                    under = p_lo - price
                    if under <= max(NEAR_PRICE * p_lo, NEAR_PRICE_MIN):
                        misses.append(f"{_money(under)} under price")
                    else:
                        exact_fail = True

            # payment
            if (pay_lo or pay_hi) and pay is None:
                exact_fail = True
            elif pay is not None:
                if pay_hi and pay > pay_hi:
                    over = pay - pay_hi
                    (misses.append(f"${int(over)} over payment") if over <= NEAR_PAY else None)
                    exact_fail = exact_fail or over > NEAR_PAY
                if pay_lo and pay < pay_lo:
                    under = pay_lo - pay
                    (misses.append(f"${int(under)} under payment") if under <= NEAR_PAY else None)
                    exact_fail = exact_fail or under > NEAR_PAY

            # miles
            if miles_max and miles > miles_max:
                over = miles - miles_max
                if over <= NEAR_MILES * miles_max:
                    misses.append(f"{int(over):,} over miles")
                else:
                    exact_fail = True

            # options
            have, unknown = [], []
            if want_opts or extra:
                text, full = _car_text(r)
                for k in want_opts:
                    label, rx = _OPT[k]
                    if rx.search(text):
                        have.append(label)
                    elif full or k in _ALWAYS_KNOWN or (k == "awd" and r.get("drivetrain")):
                        exact_fail = True
                    else:
                        unknown.append(label)
                for w in extra:
                    if w in text.lower():
                        have.append(w)
                    elif full:
                        exact_fail = True
                    else:
                        unknown.append(w)
                if unknown:
                    misses.append("check for " + ", ".join(unknown) + " (not listed on the website)")

            if exact_fail or len(misses) > MAX_MISSES:
                continue
            if misses and not close_ok:
                continue
            # How far off, for sorting the close ones: fewer misses first, then
            # the price nearest the middle of what he asked for.
            mid = (p_lo + p_hi) / 2 if (p_lo and p_hi) else (p_hi or p_lo or 0)
            found.append({
                "store_key": lot["key"], "store": lot["name"], "stock": stock,
                "name": _name(r), "year": year, "make": str(r.get("make") or ""),
                "model": str(r.get("model") or ""), "trim": str(r.get("trim") or ""),
                "body": body, "color": _color(r),
                "price": price, "pay": pay, "miles": miles,
                "url": str(r.get("detail_url") or ""),
                "photo": (r.get("photos") or [""])[0] if isinstance(r.get("photos"), list) else "",
                "posted": stock.upper() in lot["posted"],
                "exact": not misses, "why": misses, "has": have,
                # a different make or model is a bigger stretch than a year or a few dollars
                "_sort": (sum(2 if w.startswith("different") else 1 for w in misses), abs(price - mid) if mid and price else 0, -year),
            })
        per_store.append({"key": lot["key"], "name": lot["name"], "read": lot["read"], "cars": n})
        searched += n

    found.sort(key=lambda x: x["_sort"])
    for x in found:
        x.pop("_sort", None)
    exact = sum(1 for x in found if x["exact"])
    return {"ok": True, "money": m, "results": found[:150], "total": len(found),
            "exact": exact, "close": len(found) - exact, "searched": searched, "stores": per_store,
            "options": option_list(),
            "pay_buys": price_for_payment(pay_hi, m) if pay_hi else None}


def text_for(car: dict, m: dict | None = None) -> str:
    """A short text to send the customer about one car."""
    m = m or settings()
    bits = [car.get("name") or "This one"]
    if car.get("miles"):
        bits.append(f"{int(car['miles']):,} miles")
    line = ", ".join(bits)
    if car.get("price"):
        line += f", {_money(car['price'])}"
    out = [f"I found one that fits what you're looking for: {line}."]
    if car.get("pay"):
        out.append(f"Around {_money(car['pay'])}/mo with {_money(m['down'])} down "
                   f"({m['term']} months at {m['apr']:g}% APR, with approved credit).")
    out.append(f"It's at {car.get('store')}, stock #{car.get('stock')}.")
    if car.get("url"):
        out.append(f"Pictures and details: {car['url']}")
    out.append("When can you come see it?")
    return " ".join(out)


# ------------------------------------------------------------------ saved searches
# A customer's search saved on their Accelerator CRM card. After every update
# the program runs each open customer's search again and tells him about any
# car that matches now and didn't before -- a new arrival, a price drop into
# their range, a car moved from another store.
SEARCH_KEYS = ("year_from", "year_to", "makes", "models", "price_from", "price_to",
               "pay_from", "pay_to", "miles_max", "options", "other", "stores", "close",
               "apr", "term", "down", "tax", "trade")


def clean_search(q: dict) -> dict:
    q = {k: q.get(k) for k in SEARCH_KEYS if q.get(k) not in (None, "", [])}
    q["options"] = [k for k in (q.get("options") or []) if k in _OPT]
    q["stores"] = [str(k) for k in (q.get("stores") or [])]
    q["close"] = q.get("close", True) is not False
    return q


def describe(q: dict) -> str:
    """'2018-2022 Honda, Toyota SUV · $15,000-$24,000 · under $425/mo · ...'"""
    if not q:
        return ""
    bits = []
    y = "-".join(str(int(_num(q[k]))) for k in ("year_from", "year_to") if q.get(k))
    car = " ".join(x for x in (y, str(q.get("makes") or ""), str(q.get("models") or "")) if x).strip()
    if car:
        bits.append(car)
    lo, hi = _num(q.get("price_from")), _num(q.get("price_to"))
    if lo and hi:
        bits.append(f"{_money(lo)}-{_money(hi)}")
    elif hi:
        bits.append(f"under {_money(hi)}")
    elif lo:
        bits.append(f"over {_money(lo)}")
    plo, phi = _num(q.get("pay_from")), _num(q.get("pay_to"))
    if phi:
        bits.append(f"{_money(plo)}-{_money(phi)}/mo" if plo else f"under {_money(phi)}/mo")
    if _num(q.get("miles_max")):
        bits.append(f"under {int(_num(q['miles_max'])):,} miles")
    labels = [_OPT[k][0] for k in q.get("options") or [] if k in _OPT]
    if q.get("other"):
        labels.append(str(q["other"]))
    if labels:
        bits.append(", ".join(labels))
    return " · ".join(bits) or "Any used car"


def _key(x: dict) -> str:
    return f"{x['store_key']}:{x['stock']}".upper()


def save_for_customer(cid: str, q: dict) -> dict:
    """Put this search on the customer's card. What matches today counts as
    already seen -- he's looking at it now -- so only later arrivals alert."""
    import customers
    c = customers.get(cid)
    if not c:
        return {"ok": False, "message": "That customer isn't in the CRM any more."}
    q = clean_search(q)
    r = search(q, remember=False)
    customers.set_fields(cid, search=q, search_seen=[_key(x) for x in r["results"]],
                         search_saved=datetime.now().isoformat(timespec="minutes"))
    return {"ok": True, "name": c.get("name") or "the customer", "now": r["total"],
            "described": describe(q)}


def alerts() -> dict:
    """New matches for every open customer with a saved search."""
    import customers
    all_lots = None
    out = []
    for c in customers.load():
        q = c.get("search")
        if not q or c.get("status") in customers.CLOSED:
            continue
        if all_lots is None:
            all_lots = lots()
        r = search(q, all_lots=all_lots, remember=False)
        seen = set(c.get("search_seen") or [])
        # a different make or model is fine to look through on screen, but too
        # loose to interrupt him about
        new = [x for x in r["results"] if _key(x) not in seen
               and not any(w.startswith("different") for w in x["why"])]
        if new:
            out.append({"id": c["id"], "name": c.get("name") or "(no name)",
                        "phone": c.get("phone") or "", "lang": c.get("lang") or "en",
                        "wants": describe(q), "money": r["money"], "cars": new[:10],
                        "more": max(0, len(new) - 10)})
    return {"ok": True, "customers": out, "cars": sum(len(x["cars"]) + x["more"] for x in out)}


def mark_seen(cid: str, keys: list[str] | None = None) -> bool:
    """He's seen these (or all of this customer's new matches). Cars no
    longer on any lot drop off the list so it doesn't grow forever."""
    import customers
    c = customers.get(cid)
    if not c or not c.get("search"):
        return False
    r = search(c["search"], remember=False)
    now = {_key(x) for x in r["results"]}
    seen = set(c.get("search_seen") or []) & now
    seen |= {str(k).upper() for k in keys} if keys else now
    customers.set_fields(cid, search_seen=sorted(seen))
    return True


def clear_for_customer(cid: str) -> bool:
    import customers
    return bool(customers.set_fields(cid, search={}, search_seen=[], search_saved=""))
