"""
Listing Accelerator -- application host.

The window itself is ui.html. This file is the engine behind it: it reads the
inventory, runs the morning update, and records what the salesman has done.

The window is a real desktop window (pywebview over the Edge WebView2 runtime
that ships with Windows), not a browser tab. No address bar, no tabs, its own
entry in the taskbar.

Everything store-specific comes from config.py in the same folder, so one copy
of this program runs any dealership.
"""
from __future__ import annotations

import json
import os
import queue
import re
import subprocess
import sys
import threading
import time
import traceback
import webbrowser
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import importlib       # noqa: E402
import netfix          # noqa: E402
netfix.fix()           # downloads trust what Windows trusts
import config          # noqa: E402
import track           # noqa: E402
import photo_watch     # noqa: E402
import stores          # noqa: E402
import customers       # noqa: E402
import ai_reply        # noqa: E402
import ai_engine       # noqa: E402
import walkaround      # noqa: E402
import sound           # noqa: E402
import backgrounds     # noqa: E402
import social          # noqa: E402
import crm_adf         # noqa: E402
import keycheck        # noqa: E402
import usage           # noqa: E402


def use_store(key):
    """
    Point the whole program at one store: its settings, its out folder, its
    photos. Every step of a run started after this inherits the same store.
    """
    global config, track, photo_watch
    if key and key != stores.HERE_KEY:
        os.environ["LA_STORE_DIR"] = str(stores.store_dir(key))
    else:
        os.environ.pop("LA_STORE_DIR", None)
    config = importlib.reload(config)
    track = importlib.reload(track)
    photo_watch = importlib.reload(photo_watch)

# Each step of the morning run, in the order it has to happen.
#
# The two numbers after each step are how long it tends to take: a fixed
# number of seconds, plus a number of seconds for every car on the lot.
# They are only used to show a sensible "about N minutes left" -- a big
# lot takes a lot longer than a small one and the salesman deserves to
# be told that up front rather than left watching a bar.
# Measured on a real 81-car lot, 15 Oct 2026: 20 minutes end to end.
# Do not "tidy" these downward without timing a real run first.
PIPELINE = [
    ("Reading the website",         "scrape_inventory.py",             25, 2.00),
    ("Collecting paint and engine", "scrape_details.py",                5, 7.00),
    ("Making photo folders",        "create_photo_drop_folders.py",     2, 0.01),
    ("Downloading photos",          "download_photos.py",               5, 0.90),
    ("Writing the ads",             "build_jt_listings.py",             3, 0.05),
    ("Building the posting helper", "build_listing_kit.py --personal",  3, 0.05),
    ("Working out what changed",    "whats_new.py",                     2, 0.02),
    # A car gone from the website a full week is sold: off the record, and
    # its photo folder to the Recycle Bin.
    ("Clearing out sold cars",      "track.py sweep",                   1, 0.00),
    # The one-page sheet behind the "Print report" button. Nothing built it
    # before, so the button always said "run today's update first".
    ("Making the printed report",   "make_report.py",                   1, 0.00),
    # Last, so everything for posting is ready first. Only new and changed
    # cars, and only when backgrounds are turned on for this store.
    ("Putting on backgrounds",      "backgrounds.py --auto",            1, 0.00),
]

# Steps 2 and 4 now do several vehicles at once, so their per-car figures
# above (measured one-at-a-time) need dividing by how many run together.
# Not the full factor -- some of the time is the computer's own work, which
# does not go away -- so three quarters of it, which errs on the long side.
PARALLEL = {1: ("DETAIL_WORKERS", 5), 3: ("PHOTO_WORKERS", 6)}

# The photo step is the one that moves when he changes the photo count, so
# its per-car figure above is PER PHOTO (about nine tenths of a second each,
# measured) and gets multiplied by however many he has asked for.
PHOTO_STEP = 3

# Until the website has been read we do not know how big the lot is.
# Assume a middling one so the first guess is not wild.
ASSUMED_LOT = 120


def photo_count():
    n = getattr(config, "MAX_PHOTOS_PER_VEHICLE", 16)
    return n if isinstance(n, int) and n > 0 else 16


def step_seconds(i, count):
    """How long step i (0-based) should take on a lot of `count` cars."""
    fixed, per_car = PIPELINE[i][2], PIPELINE[i][3]
    if i == PHOTO_STEP:
        per_car *= photo_count()
    if i in PARALLEL:
        name, default = PARALLEL[i]
        try:
            n = max(1, min(int(getattr(config, name, default)), 16))
        except (TypeError, ValueError):
            n = default
        if n > 1:
            per_car /= 1 + (n - 1) * 0.75
    return fixed + per_car * (count if count else ASSUMED_LOT)


def plain_minutes(secs):
    """Seconds -> something a person would actually say out loud."""
    if secs <= 45:
        return "nearly done"
    m = int(round(secs / 60.0))
    if m <= 1:
        return "about a minute left"
    return f"about {m} minutes left"

VERB = {
    "down":   "taken down",
    "drop":   "dropped",
    "post":   "posted",
    "synced": "matched",
    "photos": "photos updated",
}


def money(v):
    try:
        return "${:,}".format(int(v))
    except (TypeError, ValueError):
        return None


# Windows asks "Select an app to open this .html file" when no browser has
# been made the default -- which is common on a machine nobody has set up.
# A salesman pressing Posting helper should not be asked to pick a program,
# so find a browser ourselves and only fall back to Windows if we cannot.
# Chrome first, deliberately. The helper and the ads are things he copies
# from and pastes into Marketplace, and Facebook is almost always open in
# Chrome. Opening them in Edge means two browsers and no Facebook session in
# the one he is looking at. Edge is only the fallback because every Windows
# machine has it.
BROWSERS = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
]


def browser_exe():
    if sys.platform != "win32":
        return None
    for p in BROWSERS:
        p = os.path.expandvars(p)
        if "%" not in p and Path(p).exists():
            return p
    return None


def open_page(f: Path):
    """Open one of our own HTML pages, without Windows asking anything."""
    exe = browser_exe()
    if exe:
        try:
            subprocess.Popen([exe, f.as_uri()],
                             creationflags=getattr(subprocess,
                                                   "CREATE_NO_WINDOW", 0))
            return True
        except Exception:
            pass
    try:
        webbrowser.open(f.as_uri())
        return True
    except Exception:
        return False


def open_url(url: str):
    """Open a page of ours at a topic (Instructions.html#walkaround)."""
    exe = browser_exe()
    try:
        if exe:
            subprocess.Popen([exe, url], creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        else:
            webbrowser.open(url)
        return True
    except Exception:
        return False


def open_path(p: Path):
    try:
        if sys.platform == "win32":
            subprocess.Popen(["explorer", str(p)])
        else:
            subprocess.Popen(["xdg-open", str(p)])
    except Exception:
        pass


# ------------------------------------------------------------- clipboard
# The window's own right-click menu is off, and a local page can't read the
# clipboard without a permission prompt it never gets -- so Paste and Copy
# go through Windows directly.
def clip_get() -> str:
    if sys.platform == "win32":
        try:
            import ctypes
            u, k = ctypes.windll.user32, ctypes.windll.kernel32
            u.GetClipboardData.restype = ctypes.c_void_p
            k.GlobalLock.restype = ctypes.c_void_p
            k.GlobalLock.argtypes = [ctypes.c_void_p]
            k.GlobalUnlock.argtypes = [ctypes.c_void_p]
            if u.OpenClipboard(None):
                try:
                    h = u.GetClipboardData(13)          # CF_UNICODETEXT
                    if h:
                        ptr = k.GlobalLock(h)
                        try:
                            return ctypes.wstring_at(ptr) if ptr else ""
                        finally:
                            k.GlobalUnlock(h)
                finally:
                    u.CloseClipboard()
        except Exception:
            pass
    try:
        import tkinter
        r = tkinter.Tk(); r.withdraw()
        try:
            return str(r.clipboard_get())
        finally:
            r.destroy()
    except Exception:
        return ""


def clip_set(text: str) -> bool:
    text = str(text or "")
    if sys.platform == "win32":
        try:
            import ctypes
            u, k = ctypes.windll.user32, ctypes.windll.kernel32
            k.GlobalAlloc.restype = ctypes.c_void_p
            k.GlobalLock.restype = ctypes.c_void_p
            k.GlobalLock.argtypes = [ctypes.c_void_p]
            k.GlobalUnlock.argtypes = [ctypes.c_void_p]
            u.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]
            data = text.encode("utf-16-le") + b"\x00\x00"
            h = k.GlobalAlloc(0x0002, len(data))       # GMEM_MOVEABLE
            ptr = k.GlobalLock(h)
            ctypes.memmove(ptr, data, len(data))
            k.GlobalUnlock(h)
            if u.OpenClipboard(None):
                try:
                    u.EmptyClipboard()
                    return bool(u.SetClipboardData(13, h))
                finally:
                    u.CloseClipboard()
        except Exception:
            pass
    return False


# ------------------------------------------------------------- photos on screen
# The window can't always show a picture straight from a folder, so photos go
# to the screen as small copies inside the page itself.
def thumb_data(path, size: int = 360) -> str:
    import base64
    import io
    p = Path(path)
    try:
        from PIL import Image
        im = Image.open(p)
        if im.mode in ("RGBA", "LA", "P"):
            im = im.convert("RGBA")                 # a see-through logo: on white, not black
            bg = Image.new("RGBA", im.size, (255, 255, 255, 255))
            bg.alpha_composite(im)
            im = bg
        im = im.convert("RGB")
        im.thumbnail((size, size))
        buf = io.BytesIO()
        im.save(buf, "JPEG", quality=78)
        raw = buf.getvalue()
    except Exception:
        try:
            raw = p.read_bytes()
        except Exception:
            return ""
    kind = "png" if p.suffix.lower() == ".png" else "webp" if p.suffix.lower() == ".webp" else "jpeg"
    return f"data:image/{kind};base64," + base64.b64encode(raw).decode()


def _uri_to_path(uri: str):
    import urllib.parse
    import urllib.request
    if not uri.startswith("file:"):
        return None
    return Path(urllib.request.url2pathname(urllib.parse.urlparse(uri).path))


# ---------- Go post: the places he posts, one click each ----------
# (name, address, color, shown at first). Program-wide -- they're his
# accounts, not the store's. Kept in "my links.json".
POST_SITES = [
    ("Facebook Marketplace", "https://www.facebook.com/marketplace/create/vehicle", "#1877F2", True),
    ("Facebook", "https://www.facebook.com/", "#1877F2", True),
    ("Meta Business Suite", "https://business.facebook.com/latest/home", "#0866FF", True),
    ("Instagram", "https://www.instagram.com/", "#D62976", True),
    ("TikTok", "https://www.tiktok.com/tiktokstudio/upload", "#111111", True),
    ("YouTube", "https://studio.youtube.com/", "#E62117", True),
    ("LinkedIn", "https://www.linkedin.com/feed/", "#0A66C2", True),
    ("X (Twitter)", "https://x.com/compose/post", "#111111", True),
    ("Threads", "https://www.threads.net/", "#111111", True),
    ("Google Business Profile", "https://business.google.com/", "#1A73E8", True),
    ("Pinterest", "https://www.pinterest.com/pin-creation-tool/", "#E60023", True),
    ("Nextdoor", "https://nextdoor.com/", "#3B8D1E", True),
    ("Snapchat", "https://www.snapchat.com/", "#C9B400", False),
    ("Craigslist", "https://post.craigslist.org/", "#5A2D82", False),
    ("OfferUp", "https://offerup.com/", "#00AB80", False),
    ("Sendible", "https://app.sendible.com/", "#E8562A", True),
]


def _links_file() -> Path:
    return Path(config.BASE) / "my links.json"


def _links() -> list[dict]:
    try:
        saved = json.loads(_links_file().read_text(encoding="utf-8"))
        items = saved.get("items") if isinstance(saved, dict) else None
    except Exception:
        items = None
    have = {i.get("name") for i in items or []}
    out = list(items or [])
    for n, u, c, on in POST_SITES:          # new built-in sites show up too
        if n not in have:
            out.append({"name": n, "url": u, "color": c, "on": on, "own": False})
    return out


def _good_link(u: str) -> str:
    u = str(u or "").strip()
    if u and not re.match(r"^https?://", u, re.I):
        u = "https://" + u
    return u if re.match(r"^https?://[^\s/]+\.[^\s]+", u, re.I) else ""


class Api:
    """Everything the window is allowed to ask for."""

    def __init__(self):
        self.lock = threading.Lock()
        self.run_state = {
            "running": False,
            "step": 0,
            "total": len(PIPELINE),
            "label": "",
            "finished": False,
            "error": "",
            "lines": [],
            "count": 0,          # cars on the lot, once we know
            "started": 0.0,      # when the current step began
        }

    # --- all stores ---------------------------------------------------------
    store_key = None            # the store the window is on; None = home

    def _store_summary(self, s):
        """The one line per store on the home screen."""
        use_store(s["key"])
        row = {"key": s["key"], "name": s["name"], "read": None,
               "vehicles": None, "live": None, "todo": 0, "new": 0,
               "down": 0, "prices": 0, "photos": 0, "post": 0,
               "set_up": True}
        try:
            inv = config.INVENTORY_JSON
            if Path(inv).exists():
                t = datetime.fromtimestamp(Path(inv).stat().st_mtime)
                row["read"] = t.strftime("%a %I:%M %p").replace(" 0", " ")
            if row["read"] is None:
                return row            # never read: "Not read yet", not "All caught up"
            d = track.todo_data()
            row.update(vehicles=d["vehicles"], live=d["live"],
                       down=len(d["take_down"]),
                       prices=len(d["mismatched"]) + len(d["drop_today"]),
                       post=len(d["not_posted"]))
            try:
                pend = photo_watch.load_pending()
                row["photos"] = len(pend)
            except Exception:
                pass
            row["todo"] = row["down"] + row["prices"] + row["post"] + row["photos"]
        except Exception:
            pass
        return row

    def home(self):
        """Every store at a glance -- or, on a single-store copy, just that."""
        multi = stores.multi()
        if self.is_running():
            # never switch stores under a running update -- show the last
            # summaries and say which one is updating
            rows = getattr(self, "_home_cache", None) or \
                [{"key": s["key"], "name": s["name"]} for s in stores.all_stores()]
        else:
            keep = self.store_key
            rows = [self._store_summary(s) for s in stores.all_stores()]
            use_store(keep if keep else (stores.HERE_KEY if not multi else None))
            self._home_cache = rows
        with self.lock:
            run = {"running": self.run_state["running"],
                   "store": self.run_state.get("store_name", "")}
        return {"multi": multi, "stores": rows, "run": run,
                "current": self.store_key,
                "date": datetime.now().strftime("%A, %B %d").replace(" 0", " ")}

    def open_store(self, key):
        if self.is_running() and key != self.run_state.get("store_key"):
            return {"ok": False, "message": "A store is updating right now. "
                    "You can look at that one, or wait for it to finish."}
        if key not in {s["key"] for s in stores.all_stores()}:
            return {"ok": False, "message": "That store isn't set up."}
        self.store_key = key
        use_store(key)
        return {"ok": True, "data": self.bootstrap()}

    def go_home(self):
        if not self.is_running():
            self.store_key = None
        return self.home()

    def add_store_from_copy(self):
        """Bring in a store from an older copy of the program."""
        if self.is_running():
            return {"ok": False, "message": "Wait for the update to finish."}
        try:
            import webview
            picked = self._window.create_file_dialog(webview.FOLDER_DIALOG)
        except Exception:
            picked = None
        if not picked:
            return {"ok": False, "message": "No folder picked."}
        folder = picked[0] if isinstance(picked, (list, tuple)) else picked
        first = stores.adopt_here()
        if first and not first.get("ok"):
            return first
        res = stores.import_copy(folder)
        if res.get("ok") and first and first.get("ok"):
            res["message"] = (f"Both stores are in: {first['name']} and "
                              f"{res['name']}. Photos stay where they are.")
        return res

    def add_store_new(self):
        """Set up a brand-new store with the setup screen."""
        if self.is_running():
            return {"ok": False, "message": "Wait for the update to finish."}
        first = stores.adopt_here()
        if first and not first.get("ok"):
            return first
        d = stores.new_store_dir("new store")
        return self.open_setup(env=stores.environ_for(d.name))

    def store_icon(self, key):
        """A desktop icon that opens straight to this store."""
        names = {s["key"]: s["name"] for s in stores.all_stores()}
        if key not in names:
            return {"ok": False, "message": "That store isn't set up."}
        try:
            import wizard
            ok = wizard.make_desktop_shortcut(names[key], args=f"--store {key}")
        except Exception:
            ok = False
        return ({"ok": True, "message": f"Desktop icon made: \"Listing Accelerator - "
                 f"{names[key]}\". It opens straight to that store."} if ok else
                {"ok": False, "message": "Couldn't make the icon on this computer."})

    def remove_store(self, key):
        if self.is_running():
            return {"ok": False, "message": "Wait for the update to finish."}
        if key == self.store_key:
            self.store_key = None
        return stores.remove(key)

    # --- what the sheet shows ---------------------------------------------
    def bootstrap(self):
        store = getattr(config, "STORE_FULL", "Inventory")
        now = datetime.now()
        out = {
            "store": store,
            "date": now.strftime("%A, %B %d").replace(" 0", " "),
            "read": None,
            "vehicles": None,
            "live": None,
            "cap": None,
            "sections": [],
            "footnotes": [],
            "error": None,
            "multi": stores.multi(),
            "store_key": self.store_key,
        }

        inv = getattr(config, "INVENTORY_JSON", None)
        if inv and Path(inv).exists():
            t = datetime.fromtimestamp(Path(inv).stat().st_mtime)
            out["read"] = t.strftime("%I:%M %p").lstrip("0")
            # an old read shows its day, so "read 9:50 PM" can't pass for today
            if t.date() != datetime.now().date():
                out["read"] = t.strftime("%a %b %d").replace(" 0", " ") + \
                    ", " + out["read"]

        try:
            d = track.todo_data()
        except Exception as e:
            out["error"] = str(e)
            return out

        out["vehicles"] = d["vehicles"]
        out["live"] = d["live"]
        out["cap"] = money(d["cap"]) if d["cap"] else None

        def rows(items, fn):
            return [fn(r) for r in items]

        if d["take_down"]:
            out["sections"].append({
                "key": "down", "tone": "sold",
                "title": "Sold — take these down",
                "note": "Delete these on Marketplace, then record them here.",
                "verb": VERB["down"],
                "rows": rows(d["take_down"], lambda r: {
                    "stock": r["stock"], "name": r["name"], "detail": None}),
            })

        if d["mismatched"]:
            out["sections"].append({
                "key": "synced", "tone": "reprice",
                "title": "The store changed the price",
                "note": "Your listing is out of date. Correct it, then record it.",
                "verb": VERB["synced"],
                "rows": rows(d["mismatched"], lambda r: {
                    "stock": r["stock"],
                    "name": "Listing says " + (money(r["yours"]) or "—"),
                    "detail": "change to " + (money(r["should"]) or "—")}),
            })

        if d["drop_today"]:
            def drop_row(r):
                was, now_ = money(r["was"]), money(r["now"])
                detail = f"{was} → {now_}" if was and now_ else None
                age = "up 1 day" if r["days"] == 1 else f"up {r['days']} days"
                return {"stock": r["stock"], "name": r["name"],
                        "detail": detail or age, "age": age}
            out["sections"].append({
                "key": "drop", "tone": "drop",
                "title": "Drop the price",
                "note": "Lower these on Marketplace, then record them.",
                "verb": VERB["drop"],
                "rows": rows(d["drop_today"], drop_row),
            })

        # Cars he has up whose pictures changed on the website -- usually the
        # real photos replacing the stock ones. Kept until he says done.
        try:
            pend = photo_watch.load_pending()
            rows_l = track.load()
            inv_now = track.inventory()
            live_now = {s for s, r in rows_l.items()
                        if r.get("Status") != "down"}
            pend = {s: v for s, v in pend.items()
                    if s in live_now and s in inv_now}
        except Exception:
            pend = {}
        if pend:
            out["sections"].append({
                "key": "photos", "tone": "reprice",
                "title": "New photos on the website",
                "note": "Your ad is up with the old pictures. Swap in the new "
                        "ones from the Photos folder, then record them.",
                "verb": VERB["photos"],
                "rows": [{"stock": s, "name": v.get("name", ""),
                          "detail": v.get("what")}
                         for s, v in sorted(pend.items())],
            })

        def stock_note(stock):
            try:
                rec_ = inv_all.get(stock) or {}
                info = photo_watch.summary(rec_.get("photos"), rec_.get("vin"))
            except Exception:
                return ""
            return " · stock photos only" if (info["stock"] and
                                              not info["real"]) else ""

        try:
            inv_all = track.inventory()
        except Exception:
            inv_all = {}

        if d["not_posted"]:
            title = "Not posted yet"
            if d["cap"]:
                title += " — under " + money(d["cap"])
            out["sections"].append({
                "key": "post", "tone": "new",
                "title": title,
                "note": "Put these up, then record them.",
                "verb": VERB["post"],
                "rows": rows(d["not_posted"], lambda r: {
                    "stock": r["stock"], "name": r["name"],
                    "detail": (money(r["price"]) or "")
                    + stock_note(r["stock"])}),
            })

        if d["waiting"]:
            out["footnotes"].append(
                "Posted today, drop tomorrow: "
                + ", ".join(r["stock"] for r in d["waiting"]))
        if d["over_cap"] or d["no_price"]:
            bits = []
            if d["over_cap"]:
                bits.append(f"{d['over_cap']} priced over {money(d['cap'])}")
            if d["no_price"]:
                bits.append(f"{d['no_price']} the store hasn't priced yet")
            out["footnotes"].append(
                "Not shown: " + ", ".join(bits)
                + ". Still read, still watched for price changes.")

        return out

    # --- recording work ----------------------------------------------------
    def record(self, action, stocks):
        if action not in VERB:
            return {"ok": False, "message": "Unknown action."}
        stocks = [s for s in (stocks or []) if s]
        if not stocks:
            return {"ok": False, "message": "Nothing selected."}
        fn = {"down": track.cmd_down, "drop": track.cmd_drop,
              "post": track.cmd_post, "synced": track.cmd_synced,
              "photos": photo_watch.clear_pending}[action]
        try:
            fn(stocks)
        except Exception:
            return {"ok": False,
                    "message": "Nothing was saved.",
                    "detail": traceback.format_exc()}
        n = len(stocks)
        if action == "post":
            usage.bump("posted", n)
        return {"ok": True,
                "message": f"Recorded {n} as {VERB[action]}."}

    # --- the morning run ---------------------------------------------------
    def run_update(self):
        key = self.store_key or (None if stores.multi() else stores.HERE_KEY)
        if not key:
            return {"ok": False, "message": "Pick a store first."}
        return self._start_runs([key])

    def run_all(self):
        """Update every store, one after the other."""
        keys = [s["key"] for s in stores.all_stores()]
        if not keys:
            return {"ok": False, "message": "No stores are set up yet."}
        return self._start_runs(keys)

    def _start_runs(self, keys):
        with self.lock:
            if self.run_state["running"]:
                return {"ok": False, "message": "An update is already running."}
            self.run_state = {
                "running": True, "step": 0, "total": len(PIPELINE),
                "label": "Starting", "finished": False, "error": "",
                "lines": [], "count": 0, "started": time.time(),
                "queue": list(keys), "store_key": keys[0], "store_name": "",
                "store_no": 1, "store_count": len(keys), "done_stores": [],
            }
        threading.Thread(target=self._run_queue, daemon=True).start()
        return {"ok": True}

    def _run_queue(self):
        keys = list(self.run_state["queue"])
        names = {s["key"]: s["name"] for s in stores.all_stores()}
        for n, key in enumerate(keys, 1):
            use_store(key)
            with self.lock:
                self.run_state.update(
                    store_key=key, store_name=names.get(key, key), store_no=n,
                    out=str(config.OUT),
                    step=0, label="Starting", count=self._lot_size(),
                    started=time.time(), finished=False, error="", blocked=False,
                    lines=[], all_lines=[])
            if len(keys) > 1:
                self._push(f"\n===== {names.get(key, key)} ({n} of {len(keys)}) =====")
            self._worker(final=(n == len(keys)), env=stores.environ_for(key))
            usage.bump("runs")
            if self.run_state.get("error") or self.run_state.get("blocked"):
                usage.bump("run_problems")
            try:                     # the manager dashboard, if he shares
                import team
                r = team.share(key)
                if r.get("ok"):
                    self._push("Shared your numbers with your manager's dashboard.")
                elif r.get("message"):
                    self._push("Manager dashboard: " + r["message"])
            except Exception:
                pass
            with self.lock:
                self.run_state["done_stores"].append(
                    {"key": key, "name": names.get(key, key),
                     "error": self.run_state.get("error", ""),
                     "blocked": bool(self.run_state.get("blocked"))})
        # back to whichever store the window is showing
        use_store(self.store_key if self.store_key else
                  (None if stores.multi() else stores.HERE_KEY))
        with self.lock:
            self.run_state.update(running=False, finished=True,
                                  step=len(PIPELINE))

    def _save_log(self):
        """
        Drop the whole run log into a file next to the output.

        When a run fails the detail is the only thing that says why, and it
        should not depend on the salesman knowing to scroll down a window.
        A file he can open, or send to whoever sold him the program.
        """
        try:
            Path(self.run_state.get("out") or config.OUT).mkdir(parents=True, exist_ok=True)
            with self.lock:
                lines = list(self.run_state.get("all_lines")
                             or self.run_state["lines"])
            head = [
                "Listing Accelerator -- what happened on the last run",
                datetime.now().strftime("%A, %d %B %Y at %I:%M %p"),
                f"store    : {getattr(config, 'STORE_FULL', '')}",
                f"inventory: {getattr(config, 'INVENTORY_URL', '')}",
                "-" * 64, "",
            ]
            out_dir = Path(self.run_state.get("out") or config.OUT)
            (out_dir / "last run detail.txt").write_text(
                "\r\n".join(head + lines), encoding="utf-8-sig", newline="")
        except Exception:
            pass

    def open_log(self):
        f = config.OUT / "last run detail.txt"
        if f.exists():
            open_path(f)
            return {"ok": True, "message": "Opened the detail from the last run."}
        return {"ok": False, "message": "There's no run detail saved yet."}

    def _push(self, line):
        with self.lock:
            self.run_state["lines"].append(line.rstrip("\n"))
            # the saved log keeps everything -- the start of a run is where
            # the photo pages and anything that failed get reported
            full = self.run_state.setdefault("all_lines", [])
            if len(full) < 50000:
                full.append(line.rstrip("\n"))
            # keep the panel light; nobody scrolls back a thousand lines
            if len(self.run_state["lines"]) > 400:
                del self.run_state["lines"][:200]

    def open_setup(self, env=None):
        """Reopen the setup screen -- new phone number, moved stores, etc."""
        if env is None:
            env = stores.environ_for(self.store_key or stores.HERE_KEY)
        try:
            exe = sys.executable
            if sys.platform == "win32":
                w = Path(exe).with_name("pythonw.exe")
                if w.exists():
                    exe = str(w)
            subprocess.Popen([exe, str(HERE / "wizard.py")], cwd=str(HERE),
                             env=env,
                             creationflags=getattr(subprocess,
                                                   "CREATE_NO_WINDOW", 0))
        except Exception:
            return {"ok": False,
                    "message": "Couldn't open the setup screen.",
                    "detail": traceback.format_exc()}
        return {"ok": True,
                "message": "Setup is opening. This window will close when "
                           "you save."}

    def open_instructions(self, topic=None):
        # the copy inside program\ arrives with every update, so it is
        # always the current one; the one next to it may be older
        for f in [HERE / "Instructions.html"] + [
                HERE.parent / n for n in ("Instructions.html",
                                          "Instructions.pdf",
                                          "Read me first.txt")]:
            if f.exists():
                if topic and f.suffix == ".html":
                    open_url(f.as_uri() + "#" + str(topic))
                else:
                    open_page(f)
                return {"ok": True,
                        "message": "Instructions open. Ctrl+P to print them."}
        return {"ok": False, "message": "The instructions file is missing."}

    # --- settings ----------------------------------------------------------
    def get_settings(self):
        """What the Settings panel shows, with the time cost worked out."""
        cars = self._lot_size()
        now = photo_count()
        choices = []
        for n, blurb in ((10, "Quickest"),
                         (16, "Recommended"),
                         (20, "Everything Facebook allows")):
            secs = PIPELINE[PHOTO_STEP][2] + \
                PIPELINE[PHOTO_STEP][3] * n * (cars or ASSUMED_LOT)
            mins = max(1, int(round(secs / 60.0)))
            choices.append({
                "n": n,
                "blurb": blurb,
                "cost": f"about {mins} minute{'s' if mins != 1 else ''} "
                        f"of downloading" + (f" for {cars} cars" if cars else ""),
            })
        return {"max_photos": now, "choices": choices, "cars": cars}

    def focus_options(self):
        """
        What the "what you work" panel shows.

        The makes and body styles are read off HIS OWN LOT rather than a
        fixed list, so he ticks what is actually out there -- with a count
        beside each, which is the quickest way to see what a choice costs.
        """
        makes, bodies, years, prices = {}, {}, [], []
        n_certified = n_specials = 0
        n_new = n_used = 0
        try:
            with open(config.INVENTORY_JSON, encoding="utf-8") as fh:
                recs = json.load(fh)
        except Exception:
            recs = []

        for r in recs:
            if track.is_certified(r):
                n_certified += 1
            if track.is_special(r):
                n_specials += 1
            if track.condition_of(r) == "new":
                n_new += 1
            else:
                n_used += 1
            mk = str(r.get("make", "")).strip()
            if mk:
                makes[mk] = makes.get(mk, 0) + 1
            b = track.body_of(r)
            if b:
                nice = track.pretty_body(b)
                bodies[nice] = bodies.get(nice, 0) + 1
            try:
                y = int(r.get("year") or 0)
                if 1950 < y < 2100:
                    years.append(y)
            except (TypeError, ValueError):
                pass
            p = track.price_of(r)
            if p:
                prices.append(p)

        f = track.focus()
        return {
            "makes": [{"name": k, "n": v} for k, v in
                      sorted(makes.items(), key=lambda kv: (-kv[1], kv[0]))],
            "bodies": [{"name": k, "n": v} for k, v in
                       sorted(bodies.items(), key=lambda kv: (-kv[1], kv[0]))],
            "year_lo": min(years) if years else 0,
            "year_hi": max(years) if years else 0,
            "price_hi": max(prices) if prices else 0,
            "total": len(recs),
            # How many of his own cars are in each group, so the switch shows
            # what it costs before he flips it. A store with no certified
            # inventory shows zero and the panel greys the switch out.
            "n_certified": n_certified,
            "read": bool(recs),
            "n_specials": n_specials,
            "n_new": n_new,
            "n_used": n_used,
            # Only offered when the lot actually splits into stores, which is
            # the one case where this matters.
            "prefixes": track.stock_prefixes(recs),
            "current": {
                "min_price": f["min_price"], "max_price": f["max_price"],
                "min_year": f["min_year"], "max_year": f["max_year"],
                "makes": [m for m in getattr(config, "FOCUS_MAKES", [])],
                "bodies": [b for b in getattr(config, "FOCUS_BODIES", [])],
                "models": ", ".join(getattr(config, "FOCUS_MODELS", [])),
                "stock": getattr(config, "FOCUS_STOCK_PREFIX", ""),
                "certified": f["certified"],
                "specials": f["specials"],
                "condition": f["condition"],
            },
            "wording": track.focus_wording(),
        }

    def preview_focus(self, focus):
        """How many of his cars a set of choices would leave him."""
        try:
            with open(config.INVENTORY_JSON, encoding="utf-8") as fh:
                recs = json.load(fh)
        except Exception:
            return {"ok": False, "n": 0, "total": 0}

        saved = {k: getattr(config, k, None) for k in
                 ("FOCUS_MIN_PRICE", "FOCUS_MAX_PRICE", "FOCUS_YEAR_MIN",
                  "FOCUS_YEAR_MAX", "FOCUS_MAKES", "FOCUS_MODELS",
                  "FOCUS_BODIES", "FOCUS_STOCK_PREFIX",
                  "FOCUS_CERTIFIED_ONLY", "FOCUS_SPECIALS_ONLY",
                  "FOCUS_CONDITION")}
        try:
            self._apply_focus(focus or {})
            n = sum(1 for r in recs
                    if track.price_of(r) and track.in_focus(r))
            wording = track.focus_wording()
        finally:
            for k, v in saved.items():
                setattr(config, k, v)
        return {"ok": True, "n": n, "total": len(recs), "wording": wording}

    @staticmethod
    def _apply_focus(d):
        def num(key):
            try:
                return max(0, int(d.get(key) or 0))
            except (TypeError, ValueError):
                return 0

        def words(key):
            v = d.get(key) or []
            if isinstance(v, str):
                v = v.replace(",", "\n").split("\n")
            return [str(x).strip() for x in v if str(x).strip()][:60]

        config.FOCUS_MIN_PRICE = num("min_price")
        config.FOCUS_MAX_PRICE = num("max_price")
        config.FOCUS_YEAR_MIN = num("min_year")
        config.FOCUS_YEAR_MAX = num("max_year")
        config.FOCUS_MAKES = words("makes")
        config.FOCUS_BODIES = words("bodies")
        config.FOCUS_MODELS = words("models")
        config.FOCUS_STOCK_PREFIX = str(d.get("stock") or "").strip()
        config.FOCUS_CERTIFIED_ONLY = bool(d.get("certified"))
        config.FOCUS_SPECIALS_ONLY = bool(d.get("specials"))
        c = str(d.get("condition") or "used").lower()
        config.FOCUS_CONDITION = c if c in ("used", "new", "all") else "used"

    def save_focus(self, focus):
        d = focus or {}
        try:
            saved = {}
            if config.SETTINGS_FILE.exists():
                with open(config.SETTINGS_FILE, encoding="utf-8") as fh:
                    loaded = json.load(fh)
                if isinstance(loaded, dict):
                    saved = loaded

            self._apply_focus(d)
            saved["focus_min_price"] = config.FOCUS_MIN_PRICE
            saved["focus_max_price"] = config.FOCUS_MAX_PRICE
            saved["focus_year_min"] = config.FOCUS_YEAR_MIN
            saved["focus_year_max"] = config.FOCUS_YEAR_MAX
            saved["focus_makes"] = config.FOCUS_MAKES
            saved["focus_bodies"] = config.FOCUS_BODIES
            saved["focus_models"] = config.FOCUS_MODELS
            saved["focus_stock_prefix"] = config.FOCUS_STOCK_PREFIX
            saved["focus_certified_only"] = config.FOCUS_CERTIFIED_ONLY
            saved["focus_specials_only"] = config.FOCUS_SPECIALS_ONLY
            saved["focus_condition"] = config.FOCUS_CONDITION

            with open(config.SETTINGS_FILE, "w", encoding="utf-8") as fh:
                json.dump(saved, fh, indent=2)
        except Exception:
            return {"ok": False, "message": "Couldn't save that.",
                    "detail": traceback.format_exc()}

        where = track.focus_wording()
        return {"ok": True,
                "message": ("Saved. You're working " + where + "."
                            if where else "Saved. You're working the whole lot.")}

    def save_settings(self, max_photos):
        try:
            n = int(max_photos)
        except (TypeError, ValueError):
            return {"ok": False, "message": "That isn't a number."}
        if not 1 <= n <= 20:
            return {"ok": False,
                    "message": "Facebook allows up to 20 photos on a vehicle."}
        try:
            saved = {}
            if config.SETTINGS_FILE.exists():
                with open(config.SETTINGS_FILE, encoding="utf-8") as fh:
                    loaded = json.load(fh)
                if isinstance(loaded, dict):
                    saved = loaded
            saved["max_photos"] = n
            with open(config.SETTINGS_FILE, "w", encoding="utf-8") as fh:
                json.dump(saved, fh, indent=2)
        except Exception:
            return {"ok": False,
                    "message": "Couldn't save that.",
                    "detail": traceback.format_exc()}
        # Take effect now, so the estimate on screen updates immediately.
        config.MAX_PHOTOS_PER_VEHICLE = n
        return {"ok": True,
                "message": f"Saved. {n} photos per vehicle from the next "
                           f"update on."}

    def is_running(self):
        with self.lock:
            return bool(self.run_state["running"])

    def _lot_size(self):
        """
        How many cars the next run will actually WORK. Zero before the first.

        Not the size of the lot. On a dealer-group website the inventory holds
        the whole group, and the slow steps only touch the cars he works -- so
        counting all of them put "228 vehicles" and an hours-long estimate on
        screen for a job that is twenty cars. That is what made the program
        look like it was still doing everything.
        """
        try:
            with open(config.INVENTORY_JSON, encoding="utf-8") as f:
                recs = json.load(f)
        except Exception:
            return 0
        try:
            f = track.focus()
            if track.focus_is_on(f):
                return sum(1 for r in recs if track.in_focus(r, f))
            return sum(1 for r in recs if not track.is_other_store(r))
        except Exception:
            return len(recs)

    def _worker(self, final=True, env=None):
        for i, step in enumerate(PIPELINE, start=1):
            label, cmd = step[0], step[1]
            with self.lock:
                self.run_state["step"] = i
                self.run_state["label"] = label
                self.run_state["started"] = time.time()
            self._push(f"\n--- {label} ---")
            try:
                proc = subprocess.Popen(
                    [sys.executable, "-u"] + cmd.split(), cwd=str(HERE),
                    env=env,
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    text=True, bufsize=1,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            except Exception as e:
                self._push(f"could not start {cmd}: {e}")
                self._save_log()
                continue
            for line in proc.stdout:
                self._push(line)
            if proc.wait() != 0:
                self._push(f"{cmd} stopped with an error.")
                # A bad inventory read poisons everything after it.
                if "scrape_inventory" in cmd:
                    self._save_log()
                    text = "\n".join(self.run_state.get("all_lines") or self.run_state.get("lines") or [])
                    if "TURNS AWAY PROGRAMS" in text or "WAITING FOR THE CHROME HELPER" in text:
                        with self.lock:
                            self.run_state.update(
                                blocked=True,
                                error=("This store's website turns programs away, so nothing was changed. "
                                       "Read it with the Chrome helper, load a file, or use a feed.")
                                if "TURNS AWAY" in text else
                                ("Waiting for the Chrome helper: open the store's inventory in Chrome, "
                                 "click the Listing Accelerator button, read the pages, press Done."))
                        return
                    with self.lock:
                        self.run_state.update(
                            error="The website didn't read properly, so "
                                  "nothing was changed. Nothing is broken — "
                                  "it stopped rather than give you a wrong "
                                  "list. The detail is below, and saved to "
                                  "\"last run detail.txt\" in your out "
                                  "folder.")
                    return
            # The website read is what tells us how big this lot is. From
            # here on the time left is a real number, not a guess.
            if "scrape_inventory" in cmd:
                n = self._lot_size()
                if n:
                    with self.lock:
                        self.run_state["count"] = n
        self._save_log()

    def status(self):
        with self.lock:
            s = dict(self.run_state)
            s.pop("all_lines", None)        # the window only shows the tail
            s["lines"] = "\n".join(s["lines"][-220:])
            count, step, started = s["count"], s["step"], s["started"]

        # How far along, and how much longer -- worked out from the size of
        # the lot rather than from which step number we happen to be on, so
        # the bar crawls through the long steps instead of sitting still.
        costs = [step_seconds(i, count) for i in range(len(PIPELINE))]
        total = sum(costs) or 1
        if step <= 0:
            done, left = 0.0, total
        else:
            before = sum(costs[:step - 1])
            here = costs[step - 1]
            inside = min(max(time.time() - started, 0.0), here)
            done = before + inside
            left = max(total - done, 0.0)
        s["frac"] = min(done / total, 0.995) if s["running"] else 1.0
        s["left"] = plain_minutes(left) if s["running"] else ""
        s["cars"] = count
        return s

    # --- buttons -----------------------------------------------------------
    def open_helper(self):
        f = config.OUT / "listing_kit" / "post_helper.html"
        if f.exists():
            open_page(f)
            return {"ok": True, "message": "Posting helper open. Click any line to copy it."}
        return {"ok": False, "message": "Run today's update first — the helper isn't built yet."}

    def open_ads(self):
        # The folder of ads, one file per car named by its stock number --
        # the way he works Teays Valley: open the folder, click the car, copy
        # the ad. "ALL ADS.txt" is still in there for anyone who wants every
        # ad in one file.
        f = config.OUT / "jt_listings"
        if f.exists():
            open_path(f)
            return {"ok": True,
                    "message": "Ads folder open -- one file per car, named "
                               "by stock number."}
        return {"ok": False,
                "message": "Run today's update first — the ads aren't written yet."}

    def open_photos(self):
        f = getattr(config, "PHOTO_DROP", None)
        if f and Path(f).exists():
            open_path(Path(f))
            return {"ok": True, "message": "Photo folders open."}
        return {"ok": False, "message": "Run today's update first — there are no photos yet."}

    # ------------------------------------------------------ customer book
    # Everything stays on this computer, in program\customers\.
    def book(self):
        try:
            return {"ok": True, **customers.book()}
        except Exception as e:
            return {"ok": False, "message": f"Couldn't open Accelerator CRM: {e}"}

    # --- Quick answers ---------------------------------------------------------
    def qa_answers(self, stock, store_key="", cid="", lang="", sold=""):
        try:
            import quick_answers
            c = customers.get(cid) if cid else None
            return quick_answers.answers(store_key or "", stock, (c or {}).get("name", ""),
                                         lang or (c or {}).get("lang") or "en", sold or "")
        except Exception as e:
            return {"ok": False, "message": f"Couldn't make the answers: {e}"}

    def qa_templates(self):
        import quick_answers
        return {"ok": True, "items": quick_answers.templates(), "fields": quick_answers.FIELDS}

    def qa_save(self, items):
        try:
            import quick_answers
            return quick_answers.save(items)
        except Exception as e:
            return {"ok": False, "message": f"Couldn't save your answers: {e}"}

    def vin_decode(self, vin):
        """A trade's year, make, model, trim and details from its VIN."""
        try:
            import vin_decode
            return vin_decode.decode(vin)
        except Exception as e:
            return {"ok": False, "message": f"Couldn't decode that VIN: {e}"}

    def desk_set(self, on, pin="", new_pin=""):
        try:
            return customers.desk_set(bool(on), pin, new_pin)
        except Exception as e:
            return {"ok": False, "message": f"Couldn't change the deal desk: {e}"}

    def book_customer(self, cid):
        c = customers.get(cid)
        if not c:
            return {"ok": False, "message": "That customer isn't in Accelerator CRM any more."}
        return {"ok": True, "customer": self._cview(c), "desk": customers.desk_public()}

    def _cview(self, c):
        v = customers.view(c)
        for car in v.get("cars") or []:
            t = car.get("thumb") or ""
            if t.startswith("https://"):
                continue                     # the dealer website's own photo
            path = _uri_to_path(t)
            car["thumb"] = thumb_data(path, 320) if path else ""
        return v

    def book_save(self, data):
        try:
            data = dict(data or {})
            if not str(data.get("name") or "").strip():
                return {"ok": False, "message": "Put in their name first."}
            if not (str(data.get("phone") or "").strip()
                    or str(data.get("email") or "").strip()):
                return {"ok": False, "message": "Put in a phone number or an "
                        "email, so you can reach them."}
            c = customers.save(data)
            usage.bump("customers_saved")
            return {"ok": True, "customer": self._cview(c),
                    "message": f"Saved {c['name']}."}
        except Exception as e:
            return {"ok": False, "message": f"Couldn't save: {e}"}

    def book_add_entry(self, cid, kind, text):
        c = customers.add_entry(cid, kind, text)
        if not c:
            return {"ok": False, "message": "That customer isn't in Accelerator CRM any more."}
        return {"ok": True, "customer": self._cview(c)}

    def book_remove_entry(self, cid, kind, when, text):
        c = customers.remove_entry(cid, kind, when, text)
        if not c:
            return {"ok": False, "message": "That customer isn't in Accelerator CRM any more."}
        return {"ok": True, "customer": self._cview(c)}

    def book_delete(self, cid):
        ok = customers.delete(cid)
        return {"ok": ok, "message": "Deleted from Accelerator CRM." if ok
                else "That customer wasn't in Accelerator CRM."}

    def book_parse(self, text):
        return customers.parse_chat(text)

    def book_search(self, q):
        return customers.search(q)

    def book_vin_text(self, cid):
        return customers.vin_text(cid)

    # --- dealer CRM leads (ADF email) ---
    def _adf_for(self, cid):
        c = customers.get(cid)
        if not c:
            return None, None, None
        invs = customers.inventories()
        v = customers.view(c, invs)
        for car in v["cars"]:
            car["rec"] = (invs.get(car.get("store_key")) or {}).get("cars", {}).get(car["stock"]) or {}
        key = c.get("store_key") or (v["cars"][0]["store_key"] if v["cars"] else None)
        st = crm_adf.store_settings(key)
        return c, crm_adf.adf(c, v, st), st

    def book_crm_adf(self, cid):
        """The ADF lead text, to look at or copy."""
        c, xml, st = self._adf_for(cid)
        if not c:
            return {"ok": False, "message": "That customer isn't in Accelerator CRM any more."}
        return {"ok": True, "xml": xml, "to": st.get("crm_lead_email", ""), "store": st.get("store_name", "")}

    def book_crm_send(self, cid):
        """Open an email to the store's dealer CRM lead address with the ADF
        lead in it. He presses Send in his own email program."""
        c, xml, st = self._adf_for(cid)
        if not c:
            return {"ok": False, "message": "That customer isn't in Accelerator CRM any more."}
        to = str(st.get("crm_lead_email") or "").strip()
        if not crm_adf.valid_email(to):
            return {"ok": False, "need_setup": True,
                    "message": f"Put in {st.get('store_name') or 'this store'}'s dealer CRM lead address first "
                               "(Integrations, along the top)."}
        car = ""
        v = customers.view(c)
        if v["cars"]:
            car = " - " + (v["cars"][0].get("name") or v["cars"][0]["stock"])
        subject = f"Lead: {c.get('name', '')}{car}"
        clip_set(xml)                     # in case the email program cuts the body short
        link = crm_adf.mail_link(to, subject, xml)
        long_ = len(link) > 1900          # Windows cuts long email links short
        if long_:
            link = crm_adf.mail_link(to, subject, "")
        try:
            if sys.platform == "win32":
                os.startfile(link)
            else:
                webbrowser.open(link)
        except Exception as e:
            return {"ok": False, "message": f"Couldn't open your email program ({e}). The lead is copied: "
                    f"paste it into a new email to {to}."}
        customers.add_entry(cid, "sent", f"Sent to dealer CRM (lead email to {to})")
        c = customers.save({"id": cid, "vin_entered": True})
        return {"ok": True, "customer": self._cview(c), "paste": long_,
                "message": (f"Your email is open to {to}. Click in the message, press Ctrl+V to "
                            "paste the lead, then Send." if long_ else
                            f"Your email is open with the lead to {to} -- press Send. (It's also "
                            "copied, if the email comes up empty: paste it in.)")}

    def crm_state(self):
        s = self._settings_raw()
        return {"email": s.get("crm_lead_email", ""), "source": s.get("crm_source", "")}

    def crm_save(self, email, source=""):
        email = str(email or "").strip()
        if email and not crm_adf.valid_email(email):
            return {"ok": False, "message": "That doesn't look like an email address."}
        s = self._settings_raw()
        if email:
            s["crm_lead_email"] = email
            s["crm_source"] = str(source or "").strip()
        else:
            s.pop("crm_lead_email", None)
            s.pop("crm_source", None)
        try:
            Path(config.SETTINGS_FILE).write_text(json.dumps(s, indent=2), encoding="utf-8")
        except OSError as e:
            return {"ok": False, "message": f"Couldn't save: {e}"}
        return {"ok": True, "message": "Saved. \"Send to dealer CRM\" is ready on customer cards."
                if email else "Dealer CRM lead address removed."}

    def book_followup(self, days):
        from datetime import date as _d
        return customers.next_workday(_d.today(), int(days)).isoformat()

    def book_days_off(self, days):
        return customers.set_days_off(days or [])

    def book_open_photos(self, stock, store_key):
        try:
            inv = customers.inventories().get(store_key) or {}
            base = inv.get("photos")
            f = Path(base) / str(stock).upper() if base else None
            if f and f.exists():
                open_path(f)
                return {"ok": True, "message": f"Photos for {stock} open."}
            # a car he doesn't post (no photo folder): its page on the website
            rec = (inv.get("cars") or {}).get(str(stock).upper()) or {}
            if str(rec.get("detail_url") or "").startswith("http"):
                open_url(rec["detail_url"])
                return {"ok": True, "message": f"{stock} has no photo folder, so its web page is open."}
            return {"ok": False, "message": f"No photo folder for {stock} yet."}
        except Exception as e:
            return {"ok": False, "message": f"Couldn't open the photos: {e}"}

    def clip_get(self):
        return clip_get()

    def clip_set(self, text):
        return clip_set(text)

    # ------------------------------------------------------ walkaround videos
    _wa = {"busy": False, "frac": 0.0, "message": "", "done": False, "ok": False,
           "out": "", "stock": ""}

    def _wa_rec(self, stock):
        try:
            recs = json.loads(Path(config.INVENTORY_JSON).read_text(encoding="utf-8"))
        except Exception:
            return None
        stock = str(stock or "").strip().upper()
        return next((r for r in recs if str(r.get("stock", "")).upper() == stock), None)

    def wa_ready(self):
        s = ai_reply.settings()
        return {"ready": walkaround.ready(),
                "ai": ai_engine.on(),
                "busy": self._wa["busy"]}

    def wa_cars(self, q=""):
        try:
            recs = json.loads(Path(config.INVENTORY_JSON).read_text(encoding="utf-8"))
        except Exception:
            return []
        words = [w for w in str(q or "").lower().split() if w]
        out = []
        for r in recs:
            name = " ".join(str(r.get(k) or "") for k in ("year", "make", "model", "trim")).strip()
            hay = f"{r.get('stock', '')} {name}".lower()
            if words and not all(w in hay for w in words):
                continue
            folder = Path(config.PHOTO_DROP) / str(r.get("stock", ""))
            n = len(walkaround.photos_for(folder))
            if not n:
                continue
            out.append({"stock": r.get("stock"), "name": name,
                        "price": r.get("final_price") or r.get("moses_price"),
                        "miles": r.get("mileage"), "photos": n,
                        "video": (folder / f"{r.get('stock')} walkaround.mp4").exists()})
            if len(out) >= 40:
                break
        return out

    def wa_load(self, stock):
        rec = self._wa_rec(stock)
        if not rec:
            return {"ok": False, "message": "That stock number isn't in today's inventory."}
        folder = Path(config.PHOTO_DROP) / str(rec["stock"])
        pics = walkaround.photos_for(folder)[:walkaround.MAX_PHOTOS]
        if not pics:
            return {"ok": False, "message": "No photos in that car's folder yet. Run today's update first."}
        n_use = min(len(pics), walkaround.DEFAULT_PHOTOS)
        caps = walkaround.suggest(rec, len(pics))
        name = " ".join(str(rec.get(k) or "") for k in ("year", "make", "model", "trim")).strip()
        price = rec.get("final_price") or rec.get("moses_price")
        return {"ok": True, "stock": rec["stock"], "name": name,
                "price": f"${price:,}" if isinstance(price, (int, float)) else "",
                "miles": rec.get("mileage"),
                # each photo: its background version too, when there is one --
                # used by default (he made them to use them); switchable per photo
                "photos": [{"name": p.name, "uri": thumb_data(p), "use": i < n_use,
                            "caption": caps[i] if i < len(caps) else "",
                            "bg_uri": thumb_data(folder / backgrounds.bg_name(p))
                            if (folder / backgrounds.bg_name(p)).exists() else "",
                            "bg": (folder / backgrounds.bg_name(p)).exists()}
                           for i, p in enumerate(pics)],
                "choices": walkaround.all_choices(rec),
                "seller": config.SELLER_NAME or "", "phone": config.DEALER_PHONE or "",
                "store": config.STORE_FULL or "",
                "company_on": social.settings().get("company_on") == "yes",
                "company": self._wa_who(True),
                **self._cert_info(rec),
                "video": (folder / f"{rec['stock']} walkaround.mp4").exists(),
                "with_bg": sum((folder / backgrounds.bg_name(p)).exists() for p in pics)}

    def wa_ai(self, stock, names):
        rec = self._wa_rec(stock)
        if not rec:
            return {"ok": False, "message": "That car isn't in today's inventory."}
        folder = Path(config.PHOTO_DROP) / str(rec["stock"])
        pics = [folder / n for n in names if (folder / n).exists()]
        try:
            return walkaround.ai_match(rec, pics, walkaround.ai_choices(rec))
        except Exception as e:
            return {"ok": False, "message": f"Couldn't match captions: {e}"}

    def wa_sound(self):
        """The sound choices, and the Windows voices on this computer."""
        c = sound.choices()
        v = sound.voices()
        if c["voice"] not in v:
            c["voice"] = v[0] if v else ""
        own = Path(c["own"]) if c["own"] else None
        return {**c, "voices": v, "own_name": own.name if own and own.exists() else "",
                "musics": [[k, l] for k, l in sound.MUSIC.items() if k not in ("none",)]}

    def wa_music_preview(self, kind):
        """A few seconds of a free music style for the ▶ button."""
        import music_gen
        try:
            f = sound.music_file(str(kind or ""))
        except Exception as e:
            return {"ok": False, "message": f"Couldn't make the music: {e}"}
        if not f:
            return {"ok": False, "message": "No music to play for that choice."}
        return {"ok": True, "uri": music_gen.preview_uri(f)}

    def wa_sound_save(self, d):
        return sound.save_choices(d or {})

    def wa_pick_music(self):
        try:
            import webview
            r = self._window.create_file_dialog(
                webview.OPEN_DIALOG, allow_multiple=False,
                file_types=("Music (*.mp3;*.wav;*.m4a;*.aac;*.ogg)", "All files (*.*)"))
        except Exception as e:
            return {"ok": False, "message": f"Couldn't open the file picker: {e}"}
        if not r:
            return {"ok": False, "message": ""}
        p = Path(r[0] if isinstance(r, (list, tuple)) else r)
        sound.save_choices({"music": "own", "own": str(p)})
        return {"ok": True, "name": p.name}

    def wa_install(self):
        if self._wa["busy"]:
            return {"ok": False, "message": "Already working on it."}
        self._wa.update(busy=True, frac=0.05, done=False, ok=False,
                        message="Getting the video maker ready -- one time, about a minute.")

        def go():
            r = walkaround.install_parts()
            self._wa.update(busy=False, done=True, ok=r["ok"], frac=1.0, message=r["message"])
        threading.Thread(target=go, daemon=True).start()
        return {"ok": True}

    def _wa_who(self, company=False):
        """Who the video is from: him (name, cell) or the store's company page
        (store name, store phone, website -- never his name or cell)."""
        if company and social.settings().get("company_on") == "yes":
            s = social.settings()
            return {"company": True, "seller": config.STORE_FULL or "",
                    "phone": (s.get("store_phone") or "").strip(), "store": config.STORE_FULL or "",
                    "web": social.store_web(s)}
        return {"seller": config.SELLER_NAME or "", "phone": config.DEALER_PHONE or "",
                "store": config.STORE_FULL or ""}

    def wa_make(self, stock, items, opts=None):
        if self._wa["busy"]:
            return {"ok": False, "message": "A video is already being made."}
        if not walkaround.ready():
            return {"ok": False, "need_parts": True,
                    "message": "The video maker needs to be set up first (one time)."}
        rec = self._wa_rec(stock)
        if not rec:
            return {"ok": False, "message": "That car isn't in today's inventory."}
        folder = Path(config.PHOTO_DROP) / str(rec["stock"])
        allowed = set(walkaround.all_choices(rec))
        with_bg = (opts or {}).get("photos") == "bg"
        use = []
        for it in items or []:
            p = folder / str(it.get("name", ""))
            if not p.exists():
                continue
            if (with_bg or it.get("bg")) and (folder / backgrounds.bg_name(p)).exists():
                p = folder / backgrounds.bg_name(p)
            cap = str(it.get("caption") or "")
            use.append({"path": p, "caption": cap if cap in allowed else ""})
        if not use:
            return {"ok": False, "message": "Check at least one photo."}
        name = " ".join(str(rec.get(k) or "") for k in ("year", "make", "model", "trim")).strip()
        price = rec.get("final_price") or rec.get("moses_price")
        car = {"title": name, "price": f"${price:,}" if isinstance(price, (int, float)) else "",
               **self._wa_who(bool((opts or {}).get("company")))}
        if (opts or {}).get("cert", True):
            car["certified"] = track.is_certified(rec)
        try:
            sv = social.facts(rec)["save"]
            if sv and (opts or {}).get("hook", True):
                car["hook"] = f"Save ${sv:,} off retail"
        except Exception:
            pass
        out = folder / f"{rec['stock']} walkaround{' company' if car.get('company') else ''}.mp4"
        self._wa.update(busy=True, frac=0.0, done=False, ok=False, out=str(out),
                        stock=rec["stock"], message="Making the video…")

        def go():
            try:
                o = dict(opts or {})
                mode = o.get("sound") or "both"
                so = {"music": o.get("music") if mode in ("both", "music") else "none",
                      "own": o.get("own") or sound.choices().get("own", ""),
                      "voice": o.get("voice") if mode in ("both", "voice") else ""}
                if mode == "none":
                    so = None
                elif so["voice"]:
                    self._wa.update(message="Recording the voice…")
                walkaround.render(car, use, out, progress=lambda f: self._wa.update(
                    frac=f, message="Making the video…"), sound_opts=so)
                self._wa.update(busy=False, done=True, ok=True, frac=1.0,
                                message=f"Done -- saved as {out.name} in the car's photo folder.")
            except Exception as e:
                self._wa.update(busy=False, done=True, ok=False, message=f"The video couldn't be made: {e}")
        threading.Thread(target=go, daemon=True).start()
        return {"ok": True}

    def wa_pick_video(self):
        """Your own walkaround video, shot on your phone and copied to this computer."""
        if not walkaround.ready():
            return {"ok": False, "need_parts": True,
                    "message": "The video maker needs to be set up first (one time)."}
        try:
            import webview
            r = self._window.create_file_dialog(
                webview.OPEN_DIALOG, allow_multiple=False,
                file_types=("Videos (*.mp4;*.mov;*.m4v;*.avi;*.wmv;*.mkv;*.3gp;*.webm)", "All files (*.*)"))
        except Exception as e:
            return {"ok": False, "message": f"Couldn't open the file picker: {e}"}
        if not r:
            return {"ok": False, "message": ""}
        p = Path(r[0] if isinstance(r, (list, tuple)) else r)
        try:
            info = walkaround.probe(p)
        except Exception as e:
            return {"ok": False, "message": str(e)}
        import base64
        jpg = walkaround.video_thumb(p, min(1.0, info["seconds"] / 3))
        return {"ok": True, "path": str(p), "name": p.name, **info,
                "thumb": ("data:image/jpeg;base64," + base64.b64encode(jpg).decode()) if jpg else ""}

    def wa_video_info(self, path):
        """A video that came from the phone: same details as choosing one."""
        if not walkaround.ready():
            return {"ok": False, "need_parts": True,
                    "message": "The video maker needs to be set up first (one time)."}
        p = Path(str(path or ""))
        if not p.exists():
            return {"ok": False, "message": "That video isn't there."}
        try:
            info = walkaround.probe(p)
        except Exception as e:
            return {"ok": False, "message": str(e)}
        import base64
        jpg = walkaround.video_thumb(p, min(1.0, info["seconds"] / 3))
        return {"ok": True, "path": str(p), "name": p.name, **info,
                "thumb": ("data:image/jpeg;base64," + base64.b64encode(jpg).decode()) if jpg else ""}

    def wa_make_own(self, stock, path, opts=None):
        if self._wa["busy"]:
            return {"ok": False, "message": "A video is already being made."}
        if not walkaround.ready():
            return {"ok": False, "need_parts": True,
                    "message": "The video maker needs to be set up first (one time)."}
        rec = self._wa_rec(stock)
        if not rec:
            return {"ok": False, "message": "That car isn't in today's inventory."}
        video = Path(str(path or ""))
        if not video.exists():
            return {"ok": False, "message": "Choose your video first."}
        o = dict(opts or {})
        folder = Path(config.PHOTO_DROP) / str(rec["stock"])
        name = " ".join(str(rec.get(k) or "") for k in ("year", "make", "model", "trim")).strip()
        price = rec.get("final_price") or rec.get("moses_price")
        car = {"title": name, "price": f"${price:,}" if isinstance(price, (int, float)) else "",
               **self._wa_who(bool((opts or {}).get("company")))}
        if (opts or {}).get("cert", True):
            car["certified"] = track.is_certified(rec)
        try:
            sv = social.facts(rec)["save"]
            if sv:
                car["hook"] = f"Save ${sv:,} off retail"
        except Exception:
            pass
        out = folder / f"{rec['stock']} walkaround{' company' if car.get('company') else ''}.mp4"
        mode = o.get("sound") or "keep_music"
        self._wa.update(busy=True, frac=0.0, done=False, ok=False, out=str(out),
                        stock=rec["stock"], message="Making the video from yours…")

        def go():
            try:
                music = None
                if mode in ("keep_music", "music"):
                    music = sound.music_file(o.get("music") or "country",
                                             o.get("own") or sound.choices().get("own", ""))
                walkaround.render_own(car, video, out, float(o.get("start") or 0),
                                      float(o.get("end") or 0), mode in ("keep", "keep_music"),
                                      music, progress=lambda f: self._wa.update(
                                          frac=f, message="Making the video from yours…"))
                self._wa.update(busy=False, done=True, ok=True, frac=1.0,
                                message=f"Done -- saved as {out.name} in the car's photo folder.")
            except Exception as e:
                self._wa.update(busy=False, done=True, ok=False, message=f"The video couldn't be made: {e}")
        threading.Thread(target=go, daemon=True).start()
        return {"ok": True}

    def wa_status(self):
        return dict(self._wa)

    def wa_open(self, stock):
        f = Path(config.PHOTO_DROP) / str(stock)
        if f.exists():
            open_path(f)
            return {"ok": True, "message": "Photo folder open -- the video is in there."}
        return {"ok": False, "message": "That car's folder isn't there."}

    # ------------------------------------------------------ inventory feed
    def _settings_raw(self):
        try:
            d = json.loads(Path(config.SETTINGS_FILE).read_text(encoding="utf-8"))
            return d if isinstance(d, dict) else {}
        except Exception:
            return {}

    # --- a website that turns programs away: three ways in ------------------
    def _store_settings_file(self, key):
        return stores.store_dir(key or self.store_key or stores.HERE_KEY) / "settings.json"

    def source_state(self, key=""):
        key = key or self.store_key or (stores.HERE_KEY if not stores.multi() else "")
        try:
            s = json.loads(self._store_settings_file(key).read_text(encoding="utf-8"))
        except Exception:
            s = {}
        name = next((x["name"] for x in stores.all_stores() if x["key"] == key), "")
        try:
            import chrome_helper
            hp = bool(chrome_helper.installed_version())
        except Exception:
            hp = False
        return {"ok": True, "key": key, "name": name, "website": s.get("inventory_url", ""),
                "feed": s.get("feed_source", ""), "helper": bool(s.get("read_by_helper")), "helper_files": hp}

    def source_set(self, key, how, value=""):
        """How this store's cars come in: "website", "helper", or "file"/"feed" (value = path or link)."""
        if self.is_running():
            return {"ok": False, "message": "Wait for the update to finish."}
        f = self._store_settings_file(key)
        try:
            s = json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            return {"ok": False, "message": "Couldn't read that store's settings."}
        if how in ("file", "feed"):
            import feed_import
            try:
                recs, rep = feed_import.records(str(value or ""), int(s.get("feed_add_fee") or 0))
            except Exception as e:
                return {"ok": False, "message": f"Couldn't read it: {e}"}
            if not recs:
                return {"ok": False, "message": "It opened, but no used cars with a stock number or VIN were in it."}
            s["feed_source"] = str(value)
            s.pop("read_by_helper", None)
            msg = f"Saved. {rep['count']} used cars in it ({rep['priced']} priced, {rep['photos']} with photos). Press Run today's update."
        elif how == "helper":
            s["read_by_helper"] = True
            s.pop("feed_source", None)
            msg = ("Saved. Each day: open the store's used inventory in Chrome, click the Listing Accelerator "
                   "button in the toolbar, press Read on each page, then Done. The update runs by itself.")
        else:
            s.pop("read_by_helper", None)
            s.pop("feed_source", None)
            msg = "Saved. This store reads its website again."
        f.write_text(json.dumps(s, indent=2), encoding="utf-8")
        if key == self.store_key:
            use_store(self.store_key)
        return {"ok": True, "message": msg}

    def feed_state(self):
        s = self._settings_raw()
        return {"source": s.get("feed_source", ""), "fee": int(s.get("feed_add_fee") or 0),
                "website": s.get("inventory_url", ""), "store": config.STORE_FULL or "",
                "seller": config.SELLER_NAME or ""}

    def feed_pick(self, kind="file"):
        try:
            import webview
            if kind == "folder":
                r = self._window.create_file_dialog(webview.FOLDER_DIALOG)
            else:
                r = self._window.create_file_dialog(
                    webview.OPEN_DIALOG, allow_multiple=False,
                    file_types=("Inventory files (*.csv;*.txt;*.tsv;*.xml;*.json;*.xlsx)", "All files (*.*)"))
        except Exception as e:
            return {"ok": False, "message": f"Couldn't open the picker: {e}"}
        if not r:
            return {"ok": False, "message": ""}
        return {"ok": True, "path": str(r[0] if isinstance(r, (list, tuple)) else r)}

    def feed_test(self, source, fee=0):
        import feed_import
        try:
            recs, rep = feed_import.records(str(source or ""), int(fee or 0))
        except Exception as e:
            return {"ok": False, "message": f"Couldn't read it: {e}"}
        if not recs:
            return {"ok": False, "message": "It opened, but no vehicles with a stock number or VIN "
                    "were found in it. Send the file to Claude and it can be taught this layout."}
        return {"ok": True, **rep}

    def feed_save(self, source, fee=0):
        if self.is_running():
            return {"ok": False, "message": "Wait for the update to finish."}
        s = self._settings_raw()
        source = str(source or "").strip()
        if source:
            s["feed_source"] = source
            s["feed_add_fee"] = max(0, int(fee or 0))
        else:
            s.pop("feed_source", None)
            s.pop("feed_add_fee", None)
        try:
            Path(config.SETTINGS_FILE).write_text(json.dumps(s, indent=2), encoding="utf-8")
        except OSError as e:
            return {"ok": False, "message": f"Couldn't save: {e}"}
        use_store(self.store_key)
        return {"ok": True, "message": ("Saved. This store's cars now come from the feed -- press "
                                        "Run today's update.") if source else
                "Saved. This store reads its website again."}

    # ------------------------------------------------------ your own photos
    def add_photos(self, stock):
        """Photos you took yourself, added to the car's folder as my_01.jpg,
        my_02.jpg... The morning run never touches them; every screen uses them."""
        rec = self._wa_rec(stock)
        folder = Path(config.PHOTO_DROP) / str(rec["stock"] if rec else stock)
        if not str(stock or "").strip():
            return {"ok": False, "message": "Pick a car first."}
        try:
            import webview
            r = self._window.create_file_dialog(
                webview.OPEN_DIALOG, allow_multiple=True,
                file_types=("Photos (*.jpg;*.jpeg;*.png;*.webp;*.heic;*.heif)", "All files (*.*)"))
        except Exception as e:
            return {"ok": False, "message": f"Couldn't open the file picker: {e}"}
        if not r:
            return {"ok": False, "message": ""}
        files = [Path(x) for x in (r if isinstance(r, (list, tuple)) else [r])]
        try:
            from PIL import Image, ImageOps
        except Exception:
            return {"ok": False, "message": "Set up the video maker first (Walkaround video) -- it brings the picture tools."}
        if any(f.suffix.lower() in (".heic", ".heif") for f in files):
            try:
                import pillow_heif
            except Exception:
                subprocess.run([sys.executable, "-m", "pip", "install", "pillow-heif"],
                               capture_output=True, timeout=600,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                import importlib
                importlib.invalidate_caches()
            try:
                import pillow_heif
                pillow_heif.register_heif_opener()
            except Exception:
                pass
        folder.mkdir(parents=True, exist_ok=True)
        import re as _re
        nums = [int(m.group(1)) for p in folder.glob("my_*.jpg")
                if (m := _re.match(r"my_(\d+)", p.stem))]
        n = max(nums or [0])
        added, bad = 0, []
        for f in files:
            try:
                im = ImageOps.exif_transpose(Image.open(f)).convert("RGB")
                im.thumbnail((2400, 2400))
                n += 1
                im.save(folder / f"my_{n:02d}.jpg", "JPEG", quality=92)
                added += 1
            except Exception:
                bad.append(f.name)
        msg = f"Added {added} photo{'s' if added != 1 else ''} to {folder.name} (my_01, my_02…)."
        if bad:
            msg += f" Couldn't read: {', '.join(bad[:3])}."
        return {"ok": bool(added), "added": added, "message": msg}

    def remove_photo(self, stock, name):
        """Only your own photos (my_...) -- to the Recycle Bin."""
        name = Path(str(name or "")).name
        if not name.lower().startswith("my_"):
            return {"ok": False, "message": "Only your own photos (my_…) can be removed here."}
        f = Path(config.PHOTO_DROP) / str(stock) / name
        if not f.exists():
            return {"ok": False, "message": "That photo isn't there."}
        ok = False
        if sys.platform == "win32":
            ps = ("Add-Type -AssemblyName Microsoft.VisualBasic; "
                  "[Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile("
                  f"'{str(f).replace(chr(39), chr(39) * 2)}', 'OnlyErrorDialogs', 'SendToRecycleBin')")
            try:
                subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
                               capture_output=True, timeout=60,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            except Exception:
                pass
            ok = not f.exists()
        else:
            f.unlink(missing_ok=True)
            ok = True
        bgp = f.with_name(backgrounds.bg_name(f))
        if ok and bgp.exists():
            bgp.unlink(missing_ok=True)
        return {"ok": ok, "message": f"{name} moved to the Recycle Bin." if ok else "Couldn't remove it (is it open?)."}

    # ------------------------------------------------------ backgrounds
    _bg = {"busy": False, "frac": 0.0, "message": "", "done": False, "ok": False,
           "made": [], "stock": "", "notes": []}

    def bg_state(self):
        s = backgrounds.settings()
        own = Path(s["own"]) if s["own"] else None
        return {"ready": backgrounds.ready(), "missing": backgrounds.missing(),
                "settings": {k: v for k, v in s.items() if k != "cars"},
                "picked": sorted(s["cars"]), "choices": backgrounds.choices(),
                "own_name": own.name if own and own.exists() else "",
                "ai": bool(backgrounds.ai_key()), "season": backgrounds.season_now(),
                "busy": self._bg["busy"]}

    def bg_thumbs(self):
        """A small picture of each background, made once and kept."""
        out = {}
        tdir = backgrounds.MEDIA / "thumbs"
        for c in backgrounds.CATALOG:
            t = tdir / f"{c['key']}.jpg"
            try:
                if not t.exists():
                    tdir.mkdir(parents=True, exist_ok=True)
                    if c.get("drawn"):
                        im = backgrounds.scene(c["key"], (480, 360), 230, 240)
                    else:
                        src = backgrounds.PIC_DIR / f"{c['key']}.jpg"
                        if not src.exists():
                            continue
                        from PIL import Image
                        im = Image.open(src).convert("RGB")
                    im.thumbnail((240, 180))
                    im.save(t, "JPEG", quality=80)
                out[c["key"]] = thumb_data(t, 240)
            except Exception:
                continue
        return out

    def bg_save(self, d):
        return backgrounds.save_settings(d or {})

    def bg_pick_own(self):
        try:
            import webview
            r = self._window.create_file_dialog(
                webview.OPEN_DIALOG, allow_multiple=False,
                file_types=("Pictures (*.jpg;*.jpeg;*.png;*.webp)", "All files (*.*)"))
        except Exception as e:
            return {"ok": False, "message": f"Couldn't open the file picker: {e}"}
        if not r:
            return {"ok": False, "message": ""}
        src = Path(r[0] if isinstance(r, (list, tuple)) else r)
        try:
            from PIL import Image
            im = Image.open(src).convert("RGB")
            if im.width < 800:
                return {"ok": False, "message": "That picture is too small -- use one at least 800 pixels wide."}
            im.thumbnail((2400, 2400))
            dest = Path(config.STORE_DIR) / "my background.jpg"
            im.save(dest, "JPEG", quality=90)
        except Exception as e:
            return {"ok": False, "message": f"Couldn't use that picture: {e}"}
        backgrounds.save_settings({"own": str(dest)})
        try:
            (backgrounds.MEDIA / "thumbs" / "own.jpg").unlink(missing_ok=True)
        except OSError:
            pass
        return {"ok": True, "name": src.name, "uri": thumb_data(dest, 240)}

    def bg_setup(self):
        if self._bg["busy"]:
            return {"ok": False, "message": "Already working on it."}
        self._bg.update(busy=True, frac=0.02, done=False, ok=False, made=[], notes=[],
                        message="Getting backgrounds ready -- one time.")

        def go():
            r = backgrounds.setup(lambda f, m: self._bg.update(frac=f, message=m))
            self._bg.update(busy=False, done=True, ok=r["ok"], frac=1.0, message=r["message"])
        threading.Thread(target=go, daemon=True).start()
        return {"ok": True}

    def bg_cars(self, q=""):
        try:
            recs = json.loads(Path(config.INVENTORY_JSON).read_text(encoding="utf-8"))
        except Exception:
            return []
        picked = backgrounds.settings()["cars"]
        words = [w for w in str(q or "").lower().split() if w]
        out = []
        for r in recs:
            name = " ".join(str(r.get(k) or "") for k in ("year", "make", "model", "trim")).strip()
            if words and not all(w in f"{r.get('stock', '')} {name}".lower() for w in words):
                continue
            folder = Path(config.PHOTO_DROP) / str(r.get("stock", ""))
            n = len(backgrounds.originals(folder))
            if not n:
                continue
            st = str(r.get("stock", "")).upper()
            out.append({"stock": r.get("stock"), "name": name, "photos": n,
                        "made": len(backgrounds.made_for(folder)),
                        "picked": backgrounds.BY_KEY.get(picked.get(st, ""), {}).get("label", "")})
            if len(out) >= 40:
                break
        return out

    def bg_load(self, stock):
        rec = self._wa_rec(stock)
        if not rec:
            return {"ok": False, "message": "That stock number isn't in today's inventory."}
        folder = Path(config.PHOTO_DROP) / str(rec["stock"])
        pics = backgrounds.originals(folder)
        if not pics:
            return {"ok": False, "message": "No photos in that car's folder yet. Run today's update first."}
        s = backgrounds.settings()
        name = " ".join(str(rec.get(k) or "") for k in ("year", "make", "model", "trim")).strip()
        out = []
        for i, p in enumerate(pics):
            bgp = folder / backgrounds.bg_name(p)
            out.append({"name": p.name, "uri": thumb_data(p, 220),
                        "bg": thumb_data(bgp, 220) if bgp.exists() else "",
                        # dealer sets go outside shots first: start with those checked
                        "use": p.name.lower().startswith("web_") and i < 8})
        return {"ok": True, "stock": rec["stock"], "name": name, "photos": out,
                "car_bg": s["cars"].get(str(rec["stock"]).upper(), ""),
                "store_bg": s["bg"], "pick": backgrounds.pick_for(rec["stock"], s)}

    # --- license plates ------------------------------------------------------
    def _refresh_post(self, stock):
        """A posting set made before the blur is out of date: make it again."""
        try:
            folder = Path(config.PHOTO_DROP) / str(stock)
            if (folder / "post").is_dir():
                backgrounds.posting_set(folder)
        except Exception:
            pass

    def plates_load(self, stock):
        import plates
        rec = self._wa_rec(stock)
        if not rec:
            return {"ok": False, "message": "That stock number isn't in today's inventory."}
        folder = Path(config.PHOTO_DROP) / str(rec["stock"])
        pics = backgrounds.originals(folder)
        if not pics:
            return {"ok": False, "message": "No photos in that car's folder yet."}
        keep = folder / plates.KEEP
        boxes = plates.saved_boxes(rec["stock"])
        return {"ok": True, "stock": rec["stock"], "ai": ai_engine.on(),
                "photos": [{"name": p.name,
                            "uri": thumb_data(keep / p.name if (keep / p.name).exists() else p, 900),
                            "boxes": boxes.get(p.name, [])} for p in pics[:24]],
                "blurred": plates.blurred(rec["stock"])}

    def plates_find(self, stock, names):
        import plates
        try:
            return plates.ai_find(str(stock), list(names or []))
        except Exception as e:
            return {"ok": False, "message": f"Couldn't look for plates: {e}"}

    def plates_apply(self, stock, boxes):
        import plates
        try:
            r = plates.apply(str(stock), boxes or {})
        except Exception as e:
            return {"ok": False, "message": f"Couldn't blur: {e}"}
        n = len(r["done"])
        if not n:
            return {"ok": False, "message": "Draw a box over a plate first."}
        self._refresh_post(stock)
        return {"ok": True, "done": r["done"],
                "message": f"Blurred the plate on {n} photo{'s' if n != 1 else ''}. The untouched photos are kept -- Undo puts them back."}

    def plates_undo(self, stock):
        import plates
        n = plates.undo(str(stock))
        self._refresh_post(stock)
        return {"ok": True, "message": f"Put back {n} untouched photo{'s' if n != 1 else ''}." if n else "Nothing to undo."}

    def bg_preview(self, stock, name, key):
        """One photo on one background, small and quick, to see before making."""
        folder = Path(config.PHOTO_DROP) / str(stock)
        p = folder / str(name)
        if not p.exists():
            return {"ok": False, "message": "That photo isn't there."}
        if not backgrounds.ready():
            return {"ok": False, "need_setup": True, "message": "Set up backgrounds first."}
        try:
            from PIL import Image
            tmp = backgrounds.MEDIA / "tmp"
            tmp.mkdir(parents=True, exist_ok=True)
            small = tmp / "preview_src.jpg"
            im = Image.open(p).convert("RGB")
            im.thumbnail((900, 900))
            im.save(small, "JPEG", quality=92)
            r = backgrounds.make_one(small, key, tmp / "preview.jpg",
                                     backgrounds.settings()["own"])
            if r.get("skipped"):
                return {"ok": False, "message": "That one looks like an inside shot or a "
                        "close-up -- those stay as they are. Pick an outside photo."}
            return {"ok": True, "uri": thumb_data(tmp / "preview.jpg", 900)}
        except Exception as e:
            return {"ok": False, "message": f"Couldn't make the preview: {e}"}

    def bg_make(self, stock, names, key, remember=True):
        if self._bg["busy"]:
            return {"ok": False, "message": "Backgrounds are already being made."}
        if not backgrounds.ready():
            return {"ok": False, "need_setup": True, "message": "Set up backgrounds first (one time)."}
        if key == backgrounds.OWN and not Path(backgrounds.settings()["own"] or "x").exists():
            return {"ok": False, "message": "Choose your own picture first."}
        if key not in backgrounds.BY_KEY and key != backgrounds.OWN:
            return {"ok": False, "message": "Pick a background."}
        folder = Path(config.PHOTO_DROP) / str(stock)
        if not names:
            return {"ok": False, "message": "Check at least one photo."}
        s = backgrounds.settings()
        if remember:
            backgrounds.save_settings({"car": {"stock": stock, "bg": key}})
        look = backgrounds.ai_key()
        finish = look if s["ai_finish"] else ""
        self._bg.update(busy=True, frac=0.0, done=False, ok=False, made=[], notes=[],
                        stock=str(stock), message="Making the background photos…")

        def go():
            try:
                r = backgrounds.make_car(folder, list(names), key, s["own"], finish,
                                         progress=lambda f, m: self._bg.update(
                                             frac=f, message="Working on " + m),
                                         look_key=look)
                n = len(r["made"])
                msg = (f"Done -- {n} bg_ photo{'s' if n != 1 else ''} in the car's folder, and a "
                       "ready-to-post set in its \"post\" folder."
                       if n else "No outside shots in the ones you checked -- nothing to change.")
                if r["skipped"]:
                    msg += f" {len(r['skipped'])} inside or close-up shot{'s' if len(r['skipped']) != 1 else ''} left as they are."
                self._bg.update(busy=False, done=True, ok=bool(n), frac=1.0, message=msg,
                                made=r["made"], notes=r["notes"])
            except Exception as e:
                self._bg.update(busy=False, done=True, ok=False,
                                message=f"The background photos couldn't be made: {e}")
        threading.Thread(target=go, daemon=True).start()
        return {"ok": True}

    def bg_open_post(self, stock):
        folder = Path(config.PHOTO_DROP) / str(stock)
        if not backgrounds.made_for(folder):
            return {"ok": False, "message": "Make bg_ photos for this car first."}
        backgrounds.posting_set(folder)
        open_path(folder / "post")
        return {"ok": True, "message": "Posting set open -- select all (Ctrl+A) and drag them into Marketplace."}

    def bg_status(self):
        return dict(self._bg)

    def bg_remove_one(self, stock, name):
        """Take one bad bg_ photo away; the original is used in its place."""
        folder = Path(config.PHOTO_DROP) / str(stock)
        src = folder / Path(str(name)).name
        bgp = folder / backgrounds.bg_name(src)
        try:
            bgp.unlink()
        except FileNotFoundError:
            pass
        except OSError as e:
            return {"ok": False, "message": f"Couldn't remove it: {e}"}
        # and remember: don't make one for this photo again
        try:
            import json as _j
            cache = folder / ".bgcheck.json"
            known = _j.loads(cache.read_text(encoding="utf-8")) if cache.exists() else {}
            known[f"{src.name}:{int(src.stat().st_mtime)}"] = False
            cache.write_text(_j.dumps(known), encoding="utf-8")
        except Exception:
            pass
        if (folder / "post").is_dir():
            try:
                backgrounds.posting_set(folder)
            except Exception:
                pass
        return {"ok": True, "message": f"Removed the background from {src.name}. The original photo is used."}

    def bg_clear(self, stock):
        """Take this car's bg_ photos away and stop making them for it."""
        folder = Path(config.PHOTO_DROP) / str(stock)
        n = 0
        for f in backgrounds.made_for(folder):
            try:
                f.unlink()
                n += 1
            except OSError:
                pass
        import shutil
        shutil.rmtree(folder / "post", ignore_errors=True)
        backgrounds.save_settings({"car": {"stock": stock, "bg": "off"}})
        return {"ok": True, "message": f"Removed {n} bg_ photo{'s' if n != 1 else ''}. "
                "This car keeps its original photos from now on."}

    # ------------------------------------------------------ social kit
    def _recs(self):
        try:
            return json.loads(Path(config.INVENTORY_JSON).read_text(encoding="utf-8"))
        except Exception:
            return []

    # --- My results ---------------------------------------------------------------
    def my_results(self):
        import results
        try:
            rows = track.load()
            return {"ok": True, "store": config.STORE_FULL or "", "listings": results.listing_results(rows),
                    "crm": results.crm_results(getattr(self, "store_key", None))}
        except Exception as e:
            return {"ok": False, "message": f"Couldn't count your results: {e}"}

    # --- Find a car for a customer ---------------------------------------------
    # Searches every store's whole used lot (what the last update read), and
    # watches customers' saved searches for new arrivals.
    def finder_state(self, cid=""):
        import finder
        try:
            out = {"ok": True, "money": finder.settings(), "options": finder.option_list(),
                   "stores": [{"key": l["key"], "name": l["name"], "read": l["read"], "cars": len(l["cars"])}
                              for l in finder.lots()],
                   "customers": [{"id": c["id"], "name": c.get("name") or "(no name)", "phone": c.get("phone") or ""}
                                 for c in sorted(customers.load(), key=lambda c: (c.get("name") or "").lower())
                                 if c.get("status") not in customers.CLOSED]}
            if cid:
                c = customers.get(cid)
                if c:
                    out["customer"] = {"id": c["id"], "name": c.get("name") or "", "search": c.get("search") or {}}
            return out
        except Exception as e:
            return {"ok": False, "message": f"Couldn't open the car finder: {e}"}

    def finder_search(self, q):
        import finder
        try:
            return finder.search(dict(q or {}))
        except Exception as e:
            return {"ok": False, "message": f"Couldn't search: {e}"}

    def finder_text(self, car, cid=""):
        import finder
        t = finder.text_for(dict(car or {}))
        c = customers.get(cid) if cid else None
        if c and c.get("name"):
            t = f"Hi {c['name'].split()[0]}! " + t
        return t

    def finder_open(self, url):
        if str(url or "").startswith(("http://", "https://")):
            open_url(url)
            return True
        return False

    def finder_save_customer(self, cid, q, name="", phone=""):
        import finder
        try:
            if not cid:
                name, phone = str(name or "").strip(), str(phone or "").strip()
                if not name:
                    return {"ok": False, "message": "Pick a customer, or put in a new customer's name and phone."}
                if not phone:
                    return {"ok": False, "message": "Put in a phone number for the new customer."}
                c = customers.save({"name": name, "phone": phone, "wants": ["Buying"], "looking_for": "Used",
                                    "store_key": getattr(self, "store_key", "") or ""})
                cid = c["id"]
            r = finder.save_for_customer(cid, dict(q or {}))
            if r.get("ok"):
                r["id"] = cid
                r["message"] = (f"Saved on {r['name']}'s card. After every update you'll be told about any new car "
                                f"that matches ({r['now']} match right now).")
            return r
        except Exception as e:
            return {"ok": False, "message": f"Couldn't save the search: {e}"}

    def finder_add_car(self, cid, car, name="", phone=""):
        """Put a car the search found on a customer's card, to work the deal."""
        import finder
        try:
            car = dict(car or {})
            stock, key = str(car.get("stock") or "").strip(), str(car.get("store_key") or "")
            if not stock:
                return {"ok": False, "message": "No stock number on that car."}
            if not cid:
                name, phone = str(name or "").strip(), str(phone or "").strip()
                if not name:
                    return {"ok": False, "message": "Pick a customer, or put in a new customer's name and phone."}
                if not phone:
                    return {"ok": False, "message": "Put in a phone number for the new customer."}
                c = customers.save({"name": name, "phone": phone, "wants": ["Buying"], "looking_for": "Used",
                                    "store_key": key})
            else:
                c = customers.get(cid)
                if not c:
                    return {"ok": False, "message": "That customer isn't in Accelerator CRM any more."}
            vehicles = [v for v in c.get("vehicles") or [] if str(v.get("stock") or "").upper() != stock.upper()]
            vehicles.append({"stock": stock, "store_key": key, "label": car.get("name") or stock})
            patch = {"id": c["id"], "vehicles": vehicles}
            if not c.get("store_key"):
                patch["store_key"] = key
            if c.get("status") in customers.CLOSED:
                patch["status"] = "Talking"
            c = customers.save(patch)
            try:
                if c.get("search"):
                    finder.mark_seen(c["id"], [f"{key}:{stock}"])
            except Exception:
                pass
            first = (c.get("name") or "the customer").split()[0]
            return {"ok": True, "id": c["id"], "name": c.get("name") or "",
                    "message": f"{car.get('name') or stock} is on {first}'s card. Work the deal from there."}
        except Exception as e:
            return {"ok": False, "message": f"Couldn't add the car: {e}"}

    def book_print(self, cid):
        """The customer's deal sheet, opened in the browser to print."""
        try:
            if not customers.desk()["on"]:
                return {"ok": False, "message": "The deal sheet is turned off. A manager can turn it on (Accelerator CRM → Deal desk)."}
            import profile_sheet
            customers.ensure_deal_no(cid)
            f = profile_sheet.build(cid)
            open_page(f)
            try:
                customers.add_quote(cid, "printed")
            except Exception:
                pass
            return {"ok": True, "message": "Deal sheet open in your browser. The print window comes up by itself.",
                    "file": str(f)}
        except Exception as e:
            return {"ok": False, "message": f"Couldn't make the deal sheet: {e}"}

    def book_quote_text(self, cid):
        """Text the deal as it stands: copy-ready words, and the quote saved on the card."""
        try:
            if not customers.desk()["on"]:
                return {"ok": False, "message": "Quotes are turned off. A manager can turn them on (Accelerator CRM → Deal desk)."}
            q = customers.add_quote(cid, "texted")
            if not q:
                return {"ok": False, "message": "Add a vehicle or a selling price first."}
            c = customers.get(cid)
            t = customers.quote_text(c, q)
            customers.add_entry(cid, "sent", f"Payment quote: {q['vehicle']} · ${q['payment']:,}/mo, "
                                f"${q['down']:,} down, {q['term']} mo at {q['apr']:g}%")
            return {"ok": True, "text": t, "customer": self._cview(customers.get(cid))}
        except Exception as e:
            return {"ok": False, "message": f"Couldn't make the quote: {e}"}

    # --- Add to my cars: work one car outside the filter, right now ---------
    _wc = {"busy": False, "stock": "", "store_key": "", "step": "", "lines": [], "done": False,
           "ok": False, "message": "", "photos": 0}

    def work_car(self, store_key, stock):
        import threading
        stock = str(stock or "").strip().upper()
        if not stock:
            return {"ok": False, "message": "Type the car's stock number."}
        if not store_key:
            # just a stock number: find which store has it
            import finder
            hits = [l for l in finder.lots()
                    if any(str(r.get("stock") or "").strip().upper() == stock for r in l["cars"])]
            if not hits:
                return {"ok": False, "message": f"{stock} isn't on any of your stores' websites (as of the last update)."}
            store_key = hits[0]["key"]
        if self._wc["busy"]:
            return {"ok": False, "message": f"Still getting {self._wc['stock']}. One car at a time."}
        if self.run_state.get("running"):
            return {"ok": False, "message": "The update is running. Try again when it finishes."}
        self._wc.update(busy=True, stock=stock, store_key=store_key, step="Starting", lines=[], done=False,
                        ok=False, message="", photos=0)

        def go():
            try:
                proc = subprocess.Popen([sys.executable, "-u", "work_car.py", stock], cwd=str(HERE),
                                        env=stores.environ_for(store_key), stdout=subprocess.PIPE,
                                        stderr=subprocess.STDOUT, text=True, bufsize=1,
                                        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                for line in proc.stdout:
                    line = line.rstrip()
                    if not line:
                        continue
                    self._wc["lines"] = (self._wc["lines"] + [line])[-200:]
                    if line.startswith("STEP "):
                        self._wc["step"] = line[5:]
                    if line.startswith("DONE "):
                        try:
                            self._wc["photos"] = int(line.split()[-1])
                        except ValueError:
                            pass
                rc = proc.wait()
                ok = rc == 0
                msg = (f"{stock} is one of your cars now: {self._wc['photos']} photos, its ad and the posting helper are ready."
                       if ok else (self._wc["lines"][-1] if self._wc["lines"] else "It didn't finish."))
                self._wc.update(ok=ok, message=msg)
            except Exception as e:
                self._wc.update(ok=False, message=f"Couldn't get that car: {e}")
            finally:
                self._wc.update(busy=False, done=True)
        threading.Thread(target=go, daemon=True).start()
        return {"ok": True, "message": f"Getting {stock}...", "store_key": store_key}

    def carfax_get(self, cid):
        """
        The CarFax link for this customer's car. Already read with the car,
        or read now from the car's page on the store's website (a few seconds).
        """
        c = customers.get(cid)
        if not c:
            return {"ok": False, "message": "Couldn't find that customer."}
        cars = customers.view(c).get("cars") or []
        if not cars:
            return {"ok": False, "message": "Add the car to this customer first, or paste the CarFax link in the box and press + CarFax."}
        for car in cars:
            if car.get("carfax"):
                return {"ok": True, "url": car["carfax"], "car": car.get("name") or car["stock"]}
        if self.run_state.get("running"):
            return {"ok": False, "message": "The update is running. Try + CarFax again when it finishes."}
        car = next((x for x in cars if x.get("on_lot")), None)
        if not car:
            return {"ok": False, "message": "That car isn't on the store's website anymore, so there's no CarFax link to get."}
        said = ""
        try:
            said = subprocess.run([sys.executable, "-u", "scrape_details.py", "--stock", car["stock"], "--force"],
                                  cwd=str(HERE), env=stores.environ_for(car["store_key"]), timeout=120,
                                  capture_output=True, text=True,
                                  creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)).stdout or ""
        except Exception:
            pass
        if "read by the Chrome helper" in said:
            return {"ok": False, "message": "This store's website is read with the Chrome helper, so the program can't open "
                    "the car's page. Copy the CarFax link from the car's page, paste it in the box and press + CarFax."}
        c = customers.get(cid)
        for x in customers.view(c).get("cars") or []:
            if x.get("carfax"):
                return {"ok": True, "url": x["carfax"], "car": x.get("name") or x["stock"]}
        return {"ok": False, "message": f"The store's page for {car.get('name') or car['stock']} doesn't show a CarFax link "
                f"the program can read. Copy it from the car's page, paste it in the box and press + CarFax."}

    def work_car_status(self):
        w = dict(self._wc)
        w["lines"] = w["lines"][-12:]
        return w

    def work_car_remove(self, store_key, stock):
        """Take a hand-added car back out (its photos stay until it sells)."""
        try:
            f = stores.store_dir(store_key) / "extra cars.json"
            try:
                cur = json.loads(f.read_text(encoding="utf-8")).get("stocks") or []
            except Exception:
                cur = []
            cur = [x for x in cur if str(x).strip().upper() != str(stock).strip().upper()]
            f.write_text(json.dumps({"stocks": cur}, indent=1), encoding="utf-8")
            return {"ok": True, "message": f"{stock} is off your cars. The next update leaves it out."}
        except Exception as e:
            return {"ok": False, "message": f"Couldn't change that: {e}"}

    def finder_alerts(self):
        import finder
        try:
            return finder.alerts()
        except Exception as e:
            return {"ok": False, "customers": [], "cars": 0, "message": str(e)}

    def finder_seen(self, cid, keys=None):
        import finder
        return finder.mark_seen(cid, keys or None)

    def finder_clear(self, cid):
        import finder
        return finder.clear_for_customer(cid)

    # --- Facebook groups -------------------------------------------------------
    # His buy/sell groups (program-wide: they're his) and when each car was
    # last shared to each one (per store), so he doesn't post the same car to
    # the same group over and over -- groups remove people for that.
    def _groups_file(self):
        return Path(config.BASE) / "my groups.json"

    def _glog_file(self):
        return Path(config.STORE_DIR) / "groups_log.json"

    def groups_state(self, stock=""):
        try:
            items = json.loads(self._groups_file().read_text(encoding="utf-8")).get("items") or []
        except Exception:
            items = []
        try:
            log = json.loads(self._glog_file().read_text(encoding="utf-8"))
        except Exception:
            log = {}
        mine = (log.get(str(stock).upper()) or {}) if stock else {}
        from datetime import date as _d
        out = []
        for g in items:
            last = mine.get(g.get("url", ""), "")
            days = None
            try:
                days = (_d.today() - _d.fromisoformat(last)).days if last else None
            except ValueError:
                pass
            out.append({"name": g.get("name", ""), "url": g.get("url", ""), "last": last, "days": days})
        return {"items": out}

    def groups_save(self, items):
        out = []
        for g in items or []:
            name = str(g.get("name") or "").strip()[:60]
            url = _good_link(g.get("url"))
            if name and url:
                out.append({"name": name, "url": url})
        try:
            self._groups_file().write_text(json.dumps({"items": out}, indent=1), encoding="utf-8")
        except Exception as e:
            return {"ok": False, "message": f"Couldn't save: {e}"}
        return {"ok": True, "message": f"Saved {len(out)} group{'s' if len(out) != 1 else ''}."}

    def group_open(self, stock, url):
        u = _good_link(url)
        if not u:
            return {"ok": False, "message": "That group's address isn't right. Fix it under Change my groups."}
        ok = open_url(u)
        if ok and stock:
            try:
                log = json.loads(self._glog_file().read_text(encoding="utf-8"))
            except Exception:
                log = {}
            from datetime import date as _d
            log.setdefault(str(stock).upper(), {})[u] = _d.today().isoformat()
            try:
                self._glog_file().write_text(json.dumps(log, indent=1), encoding="utf-8")
            except Exception:
                pass
        return ({"ok": True, "message": "Group opening — the ad is copied. Click Write something…, press Ctrl+V, add the photos, Post."}
                if ok else {"ok": False, "message": "Couldn't open your browser."})

    # --- manager dashboard --------------------------------------------------------
    def team_state(self):
        import team
        return {"ok": True, **team.public_settings()}

    # --- manager access to salespeople's customers ---------------------------------
    def mgr_on(self, pin, name=""):
        import team
        s = team.settings()
        return team.manager_on(s["watch"] or s["folder"], pin, name or config.SELLER_NAME or "Manager")

    def mgr_off(self, pin):
        import team
        return team.manager_off(pin)

    def mgr_unlock(self, pin):
        import team
        return team.manager_unlock(pin)

    def mgr_person(self, me_id):
        import team
        s = team.settings()
        return team.open_person(s["watch"] or s["folder"], me_id)

    def mgr_change(self, me_id, pub, cid, op, value):
        import team
        s = team.settings()
        try:
            return team.manager_change(s["watch"] or s["folder"], me_id, pub, cid, op, value)
        except Exception as e:
            return {"ok": False, "message": f"Couldn't save it: {e}"}

    def team_pick_folder(self, which="folder"):
        import team
        if which != "watch" and team.settings()["managed"] and team.manager_info():
            return {"ok": False, "message": "Your manager turned on manager access, so the shared folder can't be changed here. Ask your manager."}
        try:
            import webview
            r = self._window.create_file_dialog(webview.FOLDER_DIALOG)
        except Exception as e:
            return {"ok": False, "message": f"Couldn't open the folder picker: {e}"}
        if not r:
            return {"ok": False, "message": ""}
        path = r[0] if isinstance(r, (list, tuple)) else r
        team.save_settings(**{("watch" if which == "watch" else "folder"): str(path)})
        return {"ok": True, "path": str(path), **team.settings()}

    def team_save(self, share):
        import team
        if not share and team.settings()["managed"] and team.manager_info():
            return {"ok": False, "message": "Your manager turned on manager access, so sharing stays on. Only your manager can turn it off."}
        s = team.save_settings(share=bool(share))
        if share and not s["folder"]:
            return {"ok": False, "message": "Pick the shared folder first."}
        return {"ok": True, **s}

    def team_share_now(self):
        """Share every store's numbers now (not just after an update)."""
        import team
        if self.is_running():
            return {"ok": False, "message": "Wait for the update to finish -- it shares by itself at the end."}
        s = team.settings()
        if not s["folder"]:
            return {"ok": False, "message": "Pick the shared folder first."}
        if not s["share"]:
            team.save_settings(share=True)
        keep = self.store_key
        done, err = 0, ""
        for st in stores.all_stores():
            use_store(st["key"])
            try:
                r = team.share(st["key"])
                done += 1 if r.get("ok") else 0
                err = err or r.get("message", "")
            except Exception as e:
                err = str(e)
        use_store(keep if keep else (stores.HERE_KEY if not stores.multi() else None))
        return ({"ok": True, "message": f"Shared {done} store{'s' if done != 1 else ''} with the dashboard."}
                if done else {"ok": False, "message": err or "Nothing was shared."})

    def team_dashboard(self, folder=""):
        import team
        f = folder or team.settings()["watch"] or team.settings()["folder"]
        try:
            return team.dashboard(f)
        except Exception as e:
            return {"ok": False, "message": f"Couldn't read the folder: {e}"}

    # --- the Chrome helper --------------------------------------------------------
    def helper_state(self):
        import chrome_helper
        return {"ok": True, "port": chrome_helper.running_port(),
                "folder": str(chrome_helper.FOLDER), "written": chrome_helper.FOLDER.exists(),
                "version": chrome_helper.VERSION}

    def helper_setup(self, which="chrome"):
        """Write the helper's files, open its folder, and open the browser's
        extensions page -- the three things he needs side by side."""
        import chrome_helper
        try:
            f = chrome_helper.write_extension()
        except Exception as e:
            return {"ok": False, "message": f"Couldn't write the helper's files: {e}"}
        open_path(f)
        page = "edge://extensions" if which == "edge" else "chrome://extensions"
        exe = None
        if sys.platform == "win32":
            for p in (BROWSERS if which != "edge" else [b for b in BROWSERS if "msedge" in b.lower()]):
                p = os.path.expandvars(p)
                if "%" not in p and Path(p).exists() and (which == "edge" or "chrome" in p.lower()):
                    exe = p
                    break
        opened = False
        if exe:
            try:
                subprocess.Popen([exe, page], creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                opened = True
            except Exception:
                pass
        copied = clip_set(str(f))      # so "Load unpacked" is just Ctrl+V
        return {"ok": True, "folder": str(f), "opened": opened, "page": page, "copied": copied,
                "message": ("The helper's folder address is copied. On the Extensions page press "
                            "Load unpacked, click in the Folder box at the bottom, press Ctrl+V, "
                            "then Select Folder." if copied else "The helper's folder is open.")
                           + ("" if opened else f" Open {page} in your browser.")}

    # --- Go post -------------------------------------------------------------
    def links_state(self):
        return {"items": _links()}

    def links_save(self, items):
        out = []
        builtin = {n: (u, c) for n, u, c, _ in POST_SITES}
        for i in items or []:
            name = str(i.get("name") or "").strip()[:40]
            url = _good_link(i.get("url"))
            if not name or not url:
                continue
            own = name not in builtin or bool(i.get("own"))
            color = i.get("color") or (builtin.get(name, ("", "#00305F"))[1])
            out.append({"name": name, "url": url, "color": color,
                        "on": bool(i.get("on", True)), "own": own})
        try:
            _links_file().write_text(json.dumps({"items": out}, indent=1), encoding="utf-8")
        except Exception as e:
            return {"ok": False, "message": f"Couldn't save: {e}"}
        return {"ok": True, "items": _links(), "message": "Saved."}

    def links_reset(self):
        try:
            _links_file().unlink()
        except FileNotFoundError:
            pass
        return {"ok": True, "items": _links(), "message": "Back to the standard list."}

    # --- From my phone -----------------------------------------------------
    def phone_start(self, kind, ref="", accept="both"):
        """A QR code the phone scans to send photos/videos straight here."""
        import phone_drop
        t = self._phone_target(kind, ref, accept)
        if not t.get("kind"):
            return t
        r = phone_drop.start(t)
        # the other way, through OneDrive / iCloud / Google Drive, shown on the same screen
        r["folder"] = phone_drop.folder_saved()
        if not r.get("ok"):
            r["wifi_message"] = r.get("message", "")
            r["ok_folder"] = True
        return r

    def phone_folder_state(self, accept="both"):
        import phone_drop
        f = phone_drop.folder_saved()
        recent = phone_drop.folder_recent(f) if f else []
        if accept == "photos":
            recent = [x for x in recent if not x["video"]]
        elif accept == "video":
            recent = [x for x in recent if x["video"]]
        return {"ok": True, "folder": f, "candidates": [] if f else phone_drop.folder_candidates(),
                "recent": recent}

    def phone_folder_set(self, path=""):
        import phone_drop
        if path == "pick":
            try:
                import webview
                r = self._window.create_file_dialog(webview.FOLDER_DIALOG)
            except Exception as e:
                return {"ok": False, "message": f"Couldn't open the picker: {e}"}
            if not r:
                return {"ok": False, "message": ""}
            path = str(r[0] if isinstance(r, (list, tuple)) else r)
        return phone_drop.folder_set(path)

    def phone_folder_take(self, kind, ref, paths, accept="both"):
        import phone_drop
        t = self._phone_target(kind, ref, accept)
        if not t.get("kind"):
            return t
        r = phone_drop.take(t, list(paths or []))
        n = len(r["received"])
        r["message"] = (f"Brought in {n} from your phone folder." if n else "Nothing was brought in.") + \
                       (f" Couldn't read: {', '.join(r['bad'][:3])}." if r["bad"] else "")
        return r

    def _phone_target(self, kind, ref="", accept="both"):
        kind = str(kind or "car")
        if kind == "car":
            rec = self._wa_rec(ref)
            stock = str(rec["stock"] if rec else ref or "").strip().upper()
            if not stock:
                return {"ok": False, "message": "Pick a car first."}
            name = " ".join(str((rec or {}).get(k) or "") for k in ("year", "make", "model", "trim")).strip()
            target = {"kind": "car", "folder": str(Path(config.PHOTO_DROP) / stock), "stock": stock,
                      "label": f"{stock} · {name}" if name else stock, "accept": accept}
        elif kind == "trade":
            c = customers.get(ref)
            if not c:
                return {"ok": False, "message": "Couldn't find that customer."}
            t = c.get("trade_info") or {}
            car = " ".join(str(t.get(k) or "") for k in ("year", "make", "model")).strip()
            target = {"kind": "trade", "cid": c["id"], "folder": str(customers.trade_folder(c["id"])),
                      "label": f"{c.get('name') or 'Customer'}'s trade" + (f" · {car}" if car else ""),
                      "accept": "both"}
        elif kind == "headshot":
            target = {"kind": "headshot", "label": "Your headshot for social posts", "accept": "photos"}
        elif kind == "logo":
            target = {"kind": "logo", "label": "Your store's logo for social posts", "accept": "photos",
                      "store_dir": str(config.STORE_DIR)}
        elif kind == "bgown":
            target = {"kind": "bgown", "label": "Your own background picture", "accept": "photos",
                      "store_dir": str(config.STORE_DIR)}
        elif kind == "sold":
            target = {"kind": "sold", "label": "Your customer's delivery photo", "accept": "photos",
                      "folder": str(Path(config.BASE) / "phone inbox" / "sold")}
        else:
            return {"ok": False, "message": "Not something the phone can send to."}
        return target

    def phone_status(self, tok):
        import phone_drop
        return phone_drop.status(str(tok or ""))

    def phone_stop(self, tok):
        import phone_drop
        phone_drop.stop(str(tok or ""))
        return {"ok": True}

    def trade_photo_remove(self, cid, name):
        f = customers.trade_folder(cid) / Path(str(name)).name
        if not f.exists():
            return {"ok": False, "message": "That photo isn't there."}
        if sys.platform == "win32":
            ps = ("Add-Type -AssemblyName Microsoft.VisualBasic; "
                  "[Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile("
                  f"'{str(f).replace(chr(39), chr(39) * 2)}', 'OnlyErrorDialogs', 'SendToRecycleBin')")
            try:
                subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
                               capture_output=True, timeout=60,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            except Exception:
                pass
        else:
            f.unlink(missing_ok=True)
        if f.exists():
            return {"ok": False, "message": "Couldn't remove it (is it open?)."}
        return {"ok": True, "message": f"{f.name} moved to the Recycle Bin.", "customer": self._cview(customers.get(cid))}

    def trade_photo_open(self, cid):
        f = customers.trade_folder(cid)
        f.mkdir(parents=True, exist_ok=True)
        open_path(f)
        return {"ok": True}

    # --- Support ----------------------------------------------------------
    def support_open(self):
        """Screenshot first (before the Support box covers anything), then who they are."""
        import support
        shot = support.capture()
        return {"ok": True, "me": support.me(), "shot": shot if shot.get("ok") else None,
                "direct": bool(support.send_url()), "email": support.SUPPORT_EMAIL}

    def support_pick(self):
        import support
        try:
            import webview
            r = self._window.create_file_dialog(
                webview.OPEN_DIALOG, allow_multiple=False,
                file_types=("Pictures (*.png;*.jpg;*.jpeg;*.webp;*.bmp;*.gif)", "All files (*.*)"))
        except Exception as e:
            return {"ok": False, "message": f"Couldn't open the picker: {e}"}
        if not r:
            return {"ok": False, "message": ""}
        return support.picture(str(r[0] if isinstance(r, (list, tuple)) else r))

    def support_live(self):
        import support
        return support.quick_assist()

    def support_details(self):
        import support
        return {"ok": True, "text": support.details()}

    def support_send(self, message, name="", email="", phone="", pictures=None, include_details=True):
        import support
        try:
            r = support.send(message, name, email, phone, pictures or [], bool(include_details))
        except Exception as e:
            return {"ok": False, "message": f"Couldn't send it: {e}"}
        if r.get("how") == "email" and not r.get("opened") and r.get("copy"):
            clip_set(r["copy"])
        return r

    def link_open(self, url):
        u = _good_link(url)
        if not u:
            return {"ok": False, "message": "That isn't a web address."}
        return ({"ok": True, "message": "Opening in your browser…"} if open_url(u)
                else {"ok": False, "message": "Couldn't open your browser."})

    def soc_state(self):
        s = social.settings()
        hs = Path(s["headshot"]) if s["headshot"] else None
        lg = Path(s["logo"]) if s["logo"] else None
        return {"settings": s, "styles": social.STYLES,
                "addins": social.ADDINS, "colors": {k: "#%02X%02X%02X" % v for k, v in social.THEME_COLORS.items()},
                "holidays": list(social.HOLIDAYS),
                "headshot": thumb_data(hs, 200) if hs and hs.exists() else "",
                "logo": thumb_data(lg, 200) if lg and lg.exists() else "",
                "ai": ai_engine.on(), "cut": backgrounds.ready(),
                "season": social.season_word()[0],
                "company": social.company(s), "mypage": social.mypage(s), "web": social.store_web(s),
                "store": config.STORE_FULL or ""}

    def soc_save(self, d):
        return social.save_settings(d or {})

    def soc_pick(self, kind):
        """Your headshot or your store's logo, kept in this store's folder."""
        try:
            import webview
            r = self._window.create_file_dialog(
                webview.OPEN_DIALOG, allow_multiple=False,
                file_types=("Pictures (*.jpg;*.jpeg;*.png;*.webp)", "All files (*.*)"))
        except Exception as e:
            return {"ok": False, "message": f"Couldn't open the file picker: {e}"}
        if not r:
            return {"ok": False, "message": ""}
        src = Path(r[0] if isinstance(r, (list, tuple)) else r)
        try:
            from PIL import Image, ImageOps
            im = ImageOps.exif_transpose(Image.open(src))
            im.thumbnail((1600, 1600))
            if kind == "logo":
                dest = Path(config.STORE_DIR) / "my logo.png"
                im.convert("RGBA").save(dest, "PNG")
            else:
                dest = Path(config.BASE) / "my headshot.jpg"     # one for every store
                im.convert("RGB").save(dest, "JPEG", quality=92)
        except Exception as e:
            return {"ok": False, "message": f"Couldn't use that picture: {e}"}
        social.save_settings({"logo" if kind == "logo" else "headshot": str(dest)})
        warn = social.head_room(str(dest)) if kind != "logo" else ""
        return {"ok": True, "uri": thumb_data(dest, 200), "warn": warn}

    def _cert_info(self, rec):
        hand = str(rec.get("stock") or "").upper() in track.certified_by_hand()
        web = track.is_certified({k: v for k, v in rec.items() if k != "stock"})
        return {"certified": web or hand, "cert_web": web, "cert_hand": hand and not web}

    def cert_set(self, stock, on):
        """He knows it's Certified even though the website doesn't say so."""
        track.set_certified(stock, bool(on))
        return {"ok": True}

    def soc_forget(self, kind):
        social.save_settings({"logo" if kind == "logo" else "headshot": ""})
        return {"ok": True}

    def soc_load(self, stock):
        rec = self._wa_rec(stock)
        if not rec:
            return {"ok": False, "message": "That stock number isn't in today's inventory."}
        f = social.facts(rec)
        folder = Path(config.PHOTO_DROP) / str(rec["stock"])
        styles = {}
        for k, label in social.STYLES.items():
            ok, why = social.style_ok(k, f)
            styles[k] = {"label": label, "ok": ok, "why": why}
        made = sorted((folder / "social").glob("*.jpg")) if (folder / "social").is_dir() else []
        return {"ok": True, "stock": rec["stock"], "facts": f, "price": social.money(f["price"]),
                "save": social.money(f["save"]), "styles": styles,
                "captions": social.captions(rec),
                "has_bg": bool(backgrounds.made_for(folder)),
                **self._cert_info(rec),
                "photos": [{"name": p.name,
                            "uri": thumb_data(folder / backgrounds.bg_name(p)
                                              if (folder / backgrounds.bg_name(p)).exists() else p, 160)}
                           for p in backgrounds.originals(folder)[:20]],
                "photo": thumb_data(social.best_photo(rec["stock"]), 300) if social.best_photo(rec["stock"]) else "",
                "made": [{"name": p.name, "uri": thumb_data(p, 300)} for p in made[-12:]]}

    def soc_make(self, stock, styles, sizes, me=False, prefer_bg=True, main=""):
        rec = self._wa_rec(stock)
        if not rec:
            return {"ok": False, "message": "That car isn't in today's inventory."}
        if social.company():
            me = False
        if me and not social.settings()["headshot"]:
            return {"ok": False, "message": "Add your photo first (My photo, on the right)."}
        out, skipped = [], []
        if "own" in (styles or []):
            s0 = social.settings()
            h = (s0.get("own_head") or "").strip()
            if h:
                saved = [x for x in (s0.get("own_saved") or "").split("|") if x and x.upper() != h.upper()]
                social.save_settings({"own_saved": "|".join([h] + saved[:7])})
        for st in styles or []:
            for sz in sizes or ["square"]:
                try:
                    p = social.ad_picture(rec, st, sz, bool(me), bool(prefer_bg), main=main or "")
                    out.append({"name": p.name, "uri": thumb_data(p, 360)})
                except ValueError as e:
                    skipped.append(f"{social.STYLES.get(st, st)}: {e}")
                except Exception as e:
                    return {"ok": False, "message": f"Couldn't make the picture: {e}"}
        if not out:
            return {"ok": False, "message": "; ".join(skipped) or "Pick a style and a size."}
        social.note("made", rec["stock"])
        return {"ok": True, "made": out, "skipped": skipped,
                "message": f"Made {len(out)} picture{'s' if len(out) != 1 else ''} -- in the car's folder, under social."}

    def soc_carousel(self, stock, prefer_bg=True):
        rec = self._wa_rec(stock)
        if not rec:
            return {"ok": False, "message": "That car isn't in today's inventory."}
        try:
            ps = social.carousel(rec, bool(prefer_bg))
            social.note("made", rec["stock"])
        except Exception as e:
            return {"ok": False, "message": f"Couldn't make the carousel: {e}"}
        return {"ok": True, "made": [{"name": p.name, "uri": thumb_data(p, 240)} for p in ps],
                "message": f"{len(ps)} slides in the car's folder, under social\\carousel. Post them in order."}

    def soc_store(self, kind, size="square", prefer_bg=True):
        """Store-wide pictures: today's deals, or the 'I've got it' ad."""
        recs = self._recs()
        try:
            p = (social.deals_picture(recs, size, 4, bool(prefer_bg)) if kind == "deals"
                 else social.this_or_that(recs, size, bool(prefer_bg)) if kind == "tot"
                 else social.brand_picture(recs, size, bool(prefer_bg)))
            cap = social.store_caption(kind, recs)
        except ValueError as e:
            return {"ok": False, "message": str(e)}
        except Exception as e:
            return {"ok": False, "message": f"Couldn't make the picture: {e}"}
        social.note(kind if kind in ("deals", "tot") else "brand")
        return {"ok": True, "made": [{"name": p.name, "uri": thumb_data(p, 360)}], "caption": cap,
                "message": f"Saved as {p.name} in {p.parent.relative_to(Path(config.OUT).parent) if Path(config.OUT).parent in p.parents else p.parent}."}

    def soc_plan(self):
        try:
            return {"ok": True, **social.plan(self._recs())}
        except Exception as e:
            return {"ok": False, "message": f"Couldn't work out today's plan: {e}"}

    def soc_renewed(self, stocks):
        for s in stocks or []:
            social.note("renewed", s)
        return {"ok": True, "message": f"Marked {len(stocks or [])} as renewed -- they come back in a week."}

    def soc_sold(self, first_name, stock, vehicle, release_ok, size="square", photo_path=""):
        if not release_ok:
            return {"ok": False, "message": "Check that the customer signed the photo release first."}
        if photo_path and Path(str(photo_path)).exists():
            photo = str(photo_path)                     # sent from the phone
        else:
            try:
                import webview
                r = self._window.create_file_dialog(
                    webview.OPEN_DIALOG, allow_multiple=False,
                    file_types=("Pictures (*.jpg;*.jpeg;*.png;*.webp;*.heic)", "All files (*.*)"))
            except Exception as e:
                return {"ok": False, "message": f"Couldn't open the file picker: {e}"}
            if not r:
                return {"ok": False, "message": ""}
            photo = r[0] if isinstance(r, (list, tuple)) else r
        rec = self._wa_rec(stock) if stock else None
        car = vehicle or (social.facts(rec)["name"] if rec else "")
        try:
            p = social.sold_picture(photo, first_name, rec, car, size)
        except Exception as e:
            return {"ok": False, "message": f"Couldn't make the picture: {e}"}
        return {"ok": True, "made": [{"name": p.name, "uri": thumb_data(p, 360)}],
                "caption": social.sold_caption(first_name, car or "new ride"),
                "message": f"Saved as {p.name} in out\\social."}

    def soc_rewrite(self, text, platform):
        try:
            return social.ai_rewrite(str(text or ""), str(platform or ""))
        except Exception as e:
            return {"ok": False, "message": f"The AI couldn't rewrite it: {e}"}

    def soc_open(self, stock=""):
        if stock:
            f = Path(config.PHOTO_DROP) / str(stock) / "social"
        else:
            f = social._out_dir()
        f.mkdir(parents=True, exist_ok=True)
        open_path(f)
        return {"ok": True, "message": "Folder open."}

    def soc_sold_cars(self):
        """Cars gone from the website lately -- for the sold post's car list."""
        try:
            import track
            rows = track.load()
            inv = {str(r.get("stock") or "").upper() for r in self._recs()}
            return [{"stock": s, "name": r.get("Vehicle", "")} for s, r in rows.items()
                    if s not in inv and r.get("Vehicle")][:30]
        except Exception:
            return []

    # ------------------------------------------------------ AI replies
    def ai_settings(self):
        return ai_reply.public_settings()

    def ai_save(self, mode, key=None, copy_site=None):
        return ai_reply.save_settings(mode, key, copy_site)

    def ai_test(self, key=None, provider=None):
        return ai_reply.test_key(key, provider)

    def ai_open_google(self):
        return self.ai_open("gemini_key")

    def ai_open(self, kind):
        """Get-a-key pages and the AI chat sites -- links come from the
        update site when it can be reached (see ai_engine.links)."""
        lk = ai_engine.links()
        url = lk.get(kind)
        if not url:
            return {"ok": False, "message": "Unknown link."}
        ok = open_url(url)
        names = {"gemini_key": "Google AI Studio", "openai_key": "OpenAI", "claude_key": "Anthropic",
                 "chatgpt": "ChatGPT", "claude": "Claude", "gemini": "Gemini", "copilot": "Copilot"}
        return ({"ok": True, "message": f"{names.get(kind, 'It')} is opening in your browser."} if ok
                else {"ok": False, "message": f"Open {url} in your browser."})

    def ai_write(self, cid, message, tweak=""):
        c = customers.get(cid)
        if not c:
            return {"ok": False, "message": "That customer isn't in Accelerator CRM any more."}
        try:
            return ai_reply.write(c, message, tweak or "")
        except Exception as e:
            return {"ok": False, "message": f"Couldn't write replies: {e}"}

    def ai_copy(self, cid, message):
        c = customers.get(cid)
        if not c:
            return ""
        return ai_reply.copy_text(c, message)

    def ai_log(self, cid, message, label, text):
        """He sent one: keep their message in the chat and log the reply."""
        c = customers.get(cid)
        if not c:
            return {"ok": False, "message": "That customer isn't in Accelerator CRM any more."}
        msg = str(message or "").strip()
        chat = c.get("chat") or []
        if msg and not (chat and chat[-1].get("text", "").endswith(msg)):
            customers.add_entry(cid, "chat", msg)
        c = customers.add_entry(cid, "sent", f"Reply ({label}): {text}")
        return {"ok": True, "customer": self._cview(c)}

    def open_report(self):
        for name in ("MORNING_REPORT.html", "MORNING_REPORT.txt"):
            f = config.OUT / name
            if f.exists():
                open_page(f)
                return {"ok": True, "message": "Report open. Press Ctrl+P to print."}
        return {"ok": False, "message": "Run today's update first — there's no report yet."}

    # ---------------------------------------------------------- updates
    def update_check(self):
        try:
            import updater
            if not updater.enabled():
                return {"available": False, "current": updater.current_version()}
            f = updater.check()
            self._update_found = f
            return {"available": f.get("available", False),
                    "current": f.get("current"), "version": f.get("version"),
                    "notes": f.get("notes", []), "critical": f.get("critical", False),
                    "snoozed": updater.snoozed(f.get("version", "")),
                    "error": f.get("error", "")}
        except Exception as e:
            return {"available": False, "error": str(e)}

    def update_later(self):
        try:
            import updater
            f = getattr(self, "_update_found", {}) or {}
            updater.snooze(f.get("version", ""),
                           hours=4 if f.get("critical") else 20)
        except Exception:
            pass
        return {"ok": True}

    def update_install(self):
        if self.is_running():
            return {"ok": False, "message": "Today's run is still going. "
                    "Update when it finishes."}
        f = getattr(self, "_update_found", None)
        if not f or not f.get("available"):
            return {"ok": False, "message": "No update to install."}
        self._upd = {"lines": [], "done": False, "result": None}

        def work():
            import updater
            res = updater.install(f, progress=lambda m: self._upd["lines"].append(m))
            self._upd.update(done=True, result=res)
        threading.Thread(target=work, daemon=True).start()
        return {"ok": True}

    def update_status(self):
        u = getattr(self, "_upd", None) or {"lines": [], "done": False, "result": None}
        return {"lines": list(u["lines"]), "done": u["done"], "result": u["result"]}

    def update_rollback(self):
        import updater
        return updater.rollback()

    # ---------------------------------------------------------- the key
    def key_status(self):
        s = keycheck.status()
        s["sends"] = usage.what_is_sent()
        return s

    def key_enter(self, text):
        r = keycheck.enter(text)
        if r.get("ok"):
            r["status"]["sends"] = usage.what_is_sent()
        return r

    def key_later(self):
        keycheck.snooze()
        return {"ok": True}

    def key_buy(self):
        open_url(keycheck.BUY_URL)
        return {"ok": True}

    def version(self):
        try:
            import updater
            return updater.current_version()
        except Exception:
            return ""

    def restart(self):
        """Start the program again from its (new) files and close this window."""
        import subprocess
        exe = sys.executable
        if exe.lower().endswith("python.exe"):
            w = Path(exe).with_name("pythonw.exe")
            if w.exists():
                exe = str(w)
        try:
            subprocess.Popen([exe, str(HERE / "app.py")], cwd=str(HERE))
        except Exception as e:
            return {"ok": False, "message": f"Close and reopen the program ({e})."}
        try:
            self._window.destroy()
        except Exception:
            os._exit(0)
        return {"ok": True}


# What pauses when the key has run out (or before one is entered). Reading,
# looking up, exporting and opening what was already made keep working.
_PAUSED_WITHOUT_KEY = {
    "run_update": None, "run_all": None, "_start_runs": None,
    "wa_make": "videos", "wa_make_own": "videos",
    "soc_make": "social", "soc_carousel": "social", "soc_store": "social",
    "soc_sold": "social", "soc_rewrite": None,
    "bg_make": "backgrounds", "ai_write": "replies",
}
# Only a manager's key (or Jeff's own) opens the manager side.
_MANAGER_ONLY = ("mgr_on", "mgr_off", "mgr_unlock", "mgr_person", "mgr_change",
                 "team_dashboard")


def _gate(name, fn, kind):
    def wrapped(self, *a, **k):
        if not keycheck.allowed():
            return {"ok": False, "key": True, "message": keycheck.blocked_message()}
        r = fn(self, *a, **k)
        if kind and isinstance(r, dict) and r.get("ok") is not False:
            usage.bump(kind)
        return r
    wrapped.__name__ = name
    wrapped.__doc__ = fn.__doc__
    return wrapped


def _mgr(name, fn):
    def wrapped(self, *a, **k):
        if not keycheck.is_manager():
            return {"ok": False, "key": True,
                    "message": "The manager side opens with a manager's key."}
        return fn(self, *a, **k)
    wrapped.__name__ = name
    wrapped.__doc__ = fn.__doc__
    return wrapped


for _n, _kind in _PAUSED_WITHOUT_KEY.items():
    setattr(Api, _n, _gate(_n, getattr(Api, _n), _kind))
for _n in _MANAGER_ONLY:
    setattr(Api, _n, _mgr(_n, getattr(Api, _n)))

_qa = Api.qa_answers


def _qa_counted(self, *a, **k):
    r = _qa(self, *a, **k)
    usage.bump("replies")
    return r


Api.qa_answers = _qa_counted


def main():
    try:
        import webview
    except ImportError:
        print("The window library isn't installed. Run MARKETPLACE.bat.")
        return 1

    # Older desktop icons open the .bat file, which makes Windows ask "Do
    # you want to run this file?" every morning. Repoint them, once, in the
    # background so the window isn't held up.
    if sys.platform == "win32":
        try:
            import wizard
            threading.Thread(target=wizard.fix_old_icons, daemon=True).start()
        except Exception:
            pass

    # The start file lives beside the program folder, where updates don't
    # reach. Updates carry a copy (start_file.txt); put it in place.
    try:
        src, dst = HERE / "start_file.txt", HERE.parent / "Start Listing Accelerator.bat"
        if src.exists() and dst.exists() and src.read_bytes() != dst.read_bytes():
            dst.write_bytes(src.read_bytes())
    except Exception:
        pass
    api = Api()
    usage.bump("opened")
    # The beta's daily count (counts only), sent in the background.
    def _count_loop():
        while True:             # the program stays open all day: try every few hours
            try:
                usage.send_waiting()
            except Exception:
                pass
            time.sleep(4 * 3600)
    threading.Thread(target=_count_loop, daemon=True).start()
    # The team folder: "last in the program" for the manager, and -- when the
    # manager has turned on manager access -- the locked customer copy and his
    # changes, every few minutes while the program is open.
    def _team_loop():
        import team
        team.opened_now()
        try:
            team.auto_join()          # a team key and the team folder in OneDrive: join it
        except Exception:
            pass
        first = True
        while True:
            try:
                s = team.settings()
                if s["share"] and s["folder"] and not api.is_running():
                    team.share(api.store_key)
            except Exception:
                pass
            time.sleep(20 if first else 240)
            first = False
    threading.Thread(target=_team_loop, daemon=True).start()
    # The Chrome helper talks to the program on this computer only.
    try:
        import chrome_helper
        chrome_helper.HOOKS.update(work_car=api.work_car, work_car_status=api.work_car_status,
                                   run_store=lambda key: api._start_runs([key]))
        chrome_helper.start()
        if chrome_helper.FOLDER.exists():
            chrome_helper.write_extension()      # keep the helper's files current, every start
    except Exception:
        pass
    # A desktop icon can open straight to one store: app.py --store <name>
    if "--store" in sys.argv:
        try:
            want = sys.argv[sys.argv.index("--store") + 1]
            if want in {s["key"] for s in stores.all_stores()}:
                api.store_key = want
                use_store(want)
        except IndexError:
            pass
    elif not stores.multi():
        api.store_key = stores.HERE_KEY
    store = "all your stores" if stores.multi() and not api.store_key \
        else getattr(config, "STORE_FULL", "Inventory")
    win = webview.create_window(
        f"Listing Accelerator — {store}",
        str(HERE / "ui.html"),
        js_api=api,
        width=1180, height=860, min_size=(960, 640),
        background_color="#EEF1F4",
        text_select=True,       # any words on screen can be highlighted and copied
    )
    api._window = win

    # A salesman starts the update, a customer walks on the lot, and the
    # window gets closed out of habit -- which kills the run partway. Catch
    # that and tell him he can just leave it alone instead.
    def on_closing():
        if not api.is_running():
            return True
        try:
            return bool(win.create_confirmation_dialog(
                "Still working",
                "Today's update is still running.\n\n"
                "You do not have to sit here. Leave this window open, go work "
                "your customer, and come back when you have a minute -- it "
                "keeps going on its own.\n\n"
                "Close it now and the update stops partway. Nothing is "
                "damaged; you would just start it again later.\n\n"
                "Close anyway?"))
        except Exception:
            # Never trap him in a window he cannot shut.
            return True

    try:
        win.events.closing += on_closing
    except Exception:
        pass

    # Give the taskbar its own icon rather than a generic Python one.
    ico = HERE / "app.ico"
    try:
        if ico.exists():
            webview.start(icon=str(ico))
        else:
            webview.start()
    except TypeError:
        # Older pywebview has no icon argument; not worth failing over.
        webview.start()
    return 0


if __name__ == "__main__":
    sys.exit(main())
