"""
team.py -- the manager dashboard.

No server and no accounts. Each salesperson's program writes a small
summary file into one shared folder the store already has (a OneDrive,
SharePoint, Google Drive or network folder) after every update, and the
manager's program reads every file in that folder.

What's in a summary: the salesperson's name and store, when it was last
updated, their Marketplace numbers (posted, live, posted this week, sold
and taken down, price drops, days up), what's waiting for them (not posted
yet, price drops due, sold cars still listed), their Accelerator CRM counts
(customers, appointments, shows, sold) and the stock numbers they have
listed. Never a customer's name, phone, email or address.

Manager access (the manager turns it on; a salesperson can't turn it off):
the manager's program puts "_manager.json" (his public key) in the folder.
From then on each salesperson's program also leaves a LOCKED copy of its
customers there ("<name> (id) - customers.crm"), which only the manager's
program, with his PIN, can open. What the manager does on a customer
(a note, what was sent, status, follow-up, appointment) goes back as a locked
change file that only that salesperson's program can open; it is applied
there and marked "Manager". Nothing goes to any outside server.
"""
from __future__ import annotations

import json
import re
from datetime import date, datetime, timedelta
from pathlib import Path

KIND = "listing-accelerator-team"


# ------------------------------------------------------------------ settings
def _file() -> Path:
    import config
    return Path(config.BASE) / "team.json"


def settings() -> dict:
    keys = ("share", "folder", "watch", "last_shared", "me_id", "me_pub", "me_priv", "last_opened",
            "managed", "manager_name", "applied")
    d = {}
    try:
        d = json.loads(_file().read_text(encoding="utf-8"))
        if not isinstance(d, dict):
            d = {}
    except Exception:
        d = {}
    out = {"share": bool(d.get("share")), "folder": str(d.get("folder") or ""),
           "watch": str(d.get("watch") or ""), "last_shared": str(d.get("last_shared") or ""),
           "me_id": str(d.get("me_id") or ""), "me_pub": str(d.get("me_pub") or ""),
           "me_priv": str(d.get("me_priv") or ""), "last_opened": str(d.get("last_opened") or ""),
           "managed": bool(d.get("managed")), "manager_name": str(d.get("manager_name") or ""),
           "applied": list(d.get("applied") or [])[-500:]}
    return {k: out[k] for k in keys}


def save_settings(**kw) -> dict:
    s = settings()
    for k in s:
        if k in kw and kw[k] is not None:
            s[k] = kw[k]
    _file().write_text(json.dumps(s, indent=1), encoding="utf-8")
    return s


def public_settings() -> dict:
    s = settings()
    s.pop("me_priv", None)
    s.pop("applied", None)
    mk = manager_key()
    s["is_manager"] = bool(mk)
    s["manager_on"] = bool(mk and mk.get("on"))
    return s


def me() -> dict:
    """This computer's own id and key pair (made once)."""
    s = settings()
    if not s["me_id"] or not s["me_priv"]:
        import uuid
        import teamlock
        priv, pub = teamlock.new_keys()
        s = save_settings(me_id=uuid.uuid4().hex[:10], me_priv=priv, me_pub=pub)
    return s


def opened_now() -> None:
    """The program was opened: the manager sees "last in the program"."""
    try:
        save_settings(last_opened=datetime.now().isoformat(timespec="minutes"))
    except Exception:
        pass


def _safe(t: str) -> str:
    return re.sub(r"[^A-Za-z0-9 ()&.-]+", " ", str(t or "")).strip()[:60] or "Salesperson"


# ------------------------------------------------------------------ one summary
def summary(store_key: str | None = None) -> dict:
    """This salesperson at the store the program is pointed at right now."""
    import config
    import track
    import results
    rows = track.load()
    d = track.todo_data()
    inv = track.inventory()
    today = date.today()
    week = (today - timedelta(days=7)).isoformat()
    month = (today - timedelta(days=30)).isoformat()
    lst = results.listing_results(rows)
    live = []
    for s, r in rows.items():
        if r.get("Status") == "down" or not r.get("Posted_Date"):
            continue
        v = inv.get(s)
        days = None
        try:
            days = (today - date.fromisoformat(r["Posted_Date"][:10])).days
        except ValueError:
            pass
        live.append({"stock": s, "name": r.get("Vehicle") or (track.name_of(inv, s, rows) if v else s),
                     "posted": r.get("Posted_Date", ""), "price": r.get("Posted_Price", ""),
                     "dropped": bool(r.get("Dropped_Date")), "days": days, "on_lot": s in inv})
    crm30 = {"leads": 0, "appts": 0, "shows": 0, "sold": 0}
    try:
        import customers
        for c in customers.load():
            if store_key and c.get("store_key") and c.get("store_key") != store_key:
                continue
            if str(c.get("added") or "")[:10] < month:
                continue
            st = c.get("status") or ""
            crm30["leads"] += 1
            if c.get("appointment") or st in ("Appointment set", "Showed", "Sold"):
                crm30["appts"] += 1
            if st in ("Showed", "Sold"):
                crm30["shows"] += 1
            if st == "Sold":
                crm30["sold"] += 1
    except Exception:
        pass
    act = activity(store_key)
    # posts to his own Facebook business page (Social -> Posting for: My own page)
    page_mode, page_week = False, 0
    try:
        import social
        page_mode = social.mypage(social.settings())
        pf = Path(config.STORE_DIR) / "social_log_page.json"
        lg = json.loads(pf.read_text(encoding="utf-8")) if pf.exists() else {}
        page_week = sum(1 for v in (lg.get("made") or {}).values() if str(v) >= week)
        page_week += sum(1 for k, v in lg.items()
                         if k not in ("made", "renewed") and isinstance(v, str) and v >= week)
    except Exception:
        pass
    read = ""
    try:
        read = datetime.fromtimestamp(Path(config.INVENTORY_JSON).stat().st_mtime).isoformat(timespec="minutes")
    except Exception:
        pass
    try:
        version = (Path(config.BASE) / "version.txt").read_text(encoding="utf-8").strip()
    except Exception:
        version = ""
    return {
        "kind": KIND, "v": 1,
        "salesperson": getattr(config, "SELLER_NAME", "") or "Salesperson",
        "store": getattr(config, "STORE_FULL", "") or "Store",
        "updated": datetime.now().isoformat(timespec="minutes"),
        "lot_read": read, "version": version,
        "lot": len(inv),
        "live": len(live),
        "posted_week": sum(1 for r in rows.values() if str(r.get("Posted_Date") or "") >= week),
        "not_posted": len(d["not_posted"]),
        "drops_due": len(d["drop_today"]) + len(d["mismatched"]),
        "sold_still_listed": [x["stock"] for x in d["take_down"]],
        "sold_taken_down": lst["sold"], "avg_days": lst["avg_days"], "drops_made": lst["drops"],
        "crm30": crm30,
        "page_mode": page_mode, "page_week": page_week,
        "act": act,
        "posted_today": sum(1 for r in rows.values() if str(r.get("Posted_Date") or "")[:10] == today.isoformat()),
        "last_opened": settings()["last_opened"],
        "me_id": me()["me_id"], "pub": me()["me_pub"],
        "crm_file": crm_name() if manager_info() else "",
        "listings": sorted(live, key=lambda x: x["posted"]),
        "lot_stocks": [{"stock": s, "name": " ".join(str(v.get(k) or "") for k in ("year", "make", "model")).strip(),
                        "price": track.price_of(v)} for s, v in sorted(inv.items())],
    }


def activity(store_key: str | None = None) -> dict:
    """This week in Accelerator CRM, counts only: what he did and what's waiting."""
    out = {"new_week": 0, "sent_week": 0, "notes_week": 0, "followups_late": 0, "followups_today": 0,
           "appts_week": 0, "sold_week": 0, "no_contact_3d": 0, "open": 0}
    try:
        import customers
        today = date.today()
        week = (today - timedelta(days=7)).isoformat()
        for c in customers.load():
            if store_key and c.get("store_key") and c.get("store_key") != store_key:
                continue
            st = c.get("status") or ""
            closed = st in ("Sold", "Lost")
            if str(c.get("added") or "")[:10] >= week:
                out["new_week"] += 1
            out["sent_week"] += sum(1 for e in c.get("sent") or [] if str(e.get("when") or "")[:10] >= week)
            out["notes_week"] += sum(1 for e in c.get("notes") or [] if str(e.get("when") or "")[:10] >= week)
            fu = str(c.get("followup") or "")[:10]
            if fu and not closed:
                if fu < today.isoformat():
                    out["followups_late"] += 1
                elif fu == today.isoformat():
                    out["followups_today"] += 1
            ap = str(c.get("appointment") or "")[:10]
            if ap and week <= ap <= (today + timedelta(days=7)).isoformat():
                out["appts_week"] += 1
            if st == "Sold" and str(c.get("last_contact") or "")[:10] >= week:
                out["sold_week"] += 1
            if not closed:
                out["open"] += 1
                lc = str(c.get("last_contact") or "")[:10]
                if lc and lc < (today - timedelta(days=3)).isoformat():
                    out["no_contact_3d"] += 1
    except Exception:
        pass
    return out


def share(store_key: str | None = None) -> dict:
    """Write this store's summary into the shared folder, if sharing is on."""
    s = settings()
    if not s["share"] or not s["folder"]:
        return {"ok": False, "off": True}
    folder = Path(s["folder"])
    if not folder.is_dir():
        return {"ok": False, "message": f"The shared folder isn't there any more: {folder}"}
    data = summary(store_key)
    name = f"{_safe(data['salesperson'])} - {_safe(data['store'])}.json"
    tmp = folder / (name + ".tmp")
    tmp.write_text(json.dumps(data, indent=1), encoding="utf-8")
    tmp.replace(folder / name)
    save_settings(last_shared=datetime.now().isoformat(timespec="minutes"))
    try:
        sync_customers()
    except Exception:
        pass
    return {"ok": True, "file": str(folder / name)}


# ------------------------------------------------------------------ manager access: the salesperson's side
MANAGER_FILE = "_manager.json"


def _write_atomic(path: Path, data: bytes) -> None:
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_bytes(data)
    tmp.replace(path)


def manager_info(folder: str | None = None) -> dict | None:
    """The manager's notice in the shared folder, when manager access is on."""
    f = Path(folder or settings()["folder"] or "")
    if not str(f) or not f.is_dir():
        return None
    try:
        d = json.loads((f / MANAGER_FILE).read_text(encoding="utf-8"))
        return d if d.get("kind") == "la-manager" and d.get("on") and d.get("pub") else None
    except Exception:
        return None


def crm_name(who: dict | None = None) -> str:
    who = who or me()
    import config
    nm = getattr(config, "SELLER_NAME", "") or "Salesperson"
    return f"{_safe(nm)} ({who['me_id'][:4]}) - customers.crm"


def sync_customers() -> dict:
    """Leave the locked copy of my customers for the manager, and take in his changes."""
    s = settings()
    if not s["share"] or not s["folder"]:
        return {"ok": False, "off": True}
    folder = Path(s["folder"])
    mi = manager_info()
    who = me()
    mine = folder / crm_name(who)
    if not mi:
        # manager access is off: no copy of my customers stays in the folder
        if mine.exists():
            try:
                mine.unlink()
            except Exception:
                pass
        if s["managed"]:
            save_settings(managed=False, manager_name="")
        return {"ok": True, "managed": False}
    if not s["managed"] or s["manager_name"] != mi.get("name", ""):
        save_settings(managed=True, manager_name=str(mi.get("name") or "Manager"), share=True)
    applied = apply_changes(folder, who, mi)
    import customers
    import teamlock
    import config
    blob = teamlock.seal({"kind": "la-crm", "me_id": who["me_id"], "pub": who["me_pub"],
                          "salesperson": getattr(config, "SELLER_NAME", "") or "Salesperson",
                          "saved": datetime.now().isoformat(timespec="minutes"),
                          "applied": settings()["applied"], "customers": _for_manager(customers)}, mi["pub"])
    _write_atomic(mine, blob)
    return {"ok": True, "managed": True, "applied": applied}


def _for_manager(customers) -> list[dict]:
    """His customers, with each car's name and price filled in for the manager's screen."""
    try:
        invs = customers.inventories()
    except Exception:
        invs = {}
    out = []
    for c in customers.load():
        c = dict(c)
        cars = []
        for v in c.get("vehicles") or []:
            try:
                i = customers._vehicle_info(v, invs)
                cars.append({k: i.get(k) for k in ("stock", "name", "store", "price", "on_lot")})
            except Exception:
                cars.append({"stock": v.get("stock"), "name": v.get("label") or ""})
        c["vehicles"] = cars
        out.append(c)
    return out


def apply_changes(folder: Path, who: dict, mi: dict) -> int:
    """The manager's change files for me: open, apply, mark "Manager", remove."""
    import customers
    import teamlock
    n = 0
    done = settings()["applied"]
    files = list(folder.glob(f"*({who['me_id'][:4]}) - change *.chg"))
    for f in sorted(files, key=lambda x: x.stat().st_mtime):
        try:
            d = teamlock.unseal(f.read_bytes(), who["me_priv"])
        except Exception:
            continue                       # not for me (a name clash) or still syncing
        if d.get("kind") != "la-change" or d.get("to") != who["me_id"]:
            continue
        by = str(d.get("by") or mi.get("name") or "Manager")
        for op in d.get("ops") or []:
            if op.get("id") in done:
                continue
            try:
                _apply_one(customers, op, by)
                n += 1
            except Exception:
                pass
            done.append(op.get("id"))
        try:
            f.unlink()
        except Exception:
            pass
    if n:
        save_settings(applied=done[-500:])
    return n


def _apply_one(customers, op: dict, by: str) -> None:
    cid, kind, val = op.get("cid"), op.get("op"), op.get("value")
    if not customers.get(cid):
        return
    tag = f"👔 {by}: "
    if kind in ("note", "sent"):
        customers.add_entry(cid, "notes" if kind == "note" else "sent", tag + str(val or ""))
    elif kind == "status" and val in customers.STATUSES:
        customers.save({"id": cid, "status": val})
        customers.add_entry(cid, "notes", tag + f"status changed to {val}")
    elif kind == "followup":
        customers.save({"id": cid, "followup": str(val or "")[:10]})
        customers.add_entry(cid, "notes", tag + (f"follow-up set for {val}" if val else "follow-up cleared"))
    elif kind == "appointment":
        customers.save({"id": cid, "appointment": str(val or "")[:16],
                        **({"status": "Appointment set"} if val else {})})
        customers.add_entry(cid, "notes", tag + (f"appointment set for {str(val).replace('T', ' ')}" if val else "appointment cleared"))


# ------------------------------------------------------------------ manager access: the manager's side
def _mkey_file() -> Path:
    import config
    return Path(config.BASE) / "manager key.json"


def manager_key() -> dict | None:
    try:
        d = json.loads(_mkey_file().read_text(encoding="utf-8"))
        return d if d.get("pub") and d.get("locked") else None
    except Exception:
        return None


_UNLOCKED: dict = {}


def manager_on(folder: str, pin: str, name: str = "", old_pin: str = "") -> dict:
    """Turn on manager access for this folder (sets the PIN the first time)."""
    import teamlock
    f = Path(folder or "")
    if not folder or not f.is_dir():
        return {"ok": False, "message": "Pick the shared folder first."}
    pin = str(pin or "").strip()
    mk = manager_key()
    if mk:
        priv = teamlock.open_with_pin(mk["locked"], pin)
        if not priv:
            return {"ok": False, "message": "That manager PIN isn't right."}
    else:
        if not re.fullmatch(r"\d{4,8}", pin):
            return {"ok": False, "message": "Pick a manager PIN of 4 to 8 numbers."}
        priv, pub = teamlock.new_keys()
        mk = {"pub": pub, "locked": teamlock.lock_with_pin(priv, pin)}
    mk.update(on=True, folder=str(f), name=str(name or mk.get("name") or "Manager").strip()[:40])
    _mkey_file().write_text(json.dumps(mk, indent=1), encoding="utf-8")
    (f / MANAGER_FILE).write_text(json.dumps({"kind": "la-manager", "on": True, "pub": mk["pub"],
                                              "name": mk["name"], "since": date.today().isoformat()},
                                             indent=1), encoding="utf-8")
    _UNLOCKED["priv"] = priv
    return {"ok": True, "message": "Manager access is on. Each salesperson's customers show up after their program next shares (within a few minutes while it's open)."}


def manager_off(pin: str) -> dict:
    import teamlock
    mk = manager_key()
    if not mk:
        return {"ok": False, "message": "Manager access isn't set up on this computer."}
    if not teamlock.open_with_pin(mk["locked"], str(pin or "").strip()):
        return {"ok": False, "message": "That manager PIN isn't right."}
    f = Path(mk.get("folder") or "")
    try:
        (f / MANAGER_FILE).write_text(json.dumps({"kind": "la-manager", "on": False}), encoding="utf-8")
    except Exception:
        pass
    mk["on"] = False
    _mkey_file().write_text(json.dumps(mk, indent=1), encoding="utf-8")
    _UNLOCKED.clear()
    return {"ok": True, "message": "Manager access is off. Each salesperson's program removes its customer copy from the folder the next time it shares."}


def manager_unlock(pin: str) -> dict:
    import teamlock
    mk = manager_key()
    if not mk:
        return {"ok": False, "message": "Turn on manager access first."}
    priv = teamlock.open_with_pin(mk["locked"], str(pin or "").strip())
    if not priv:
        return {"ok": False, "message": "That manager PIN isn't right."}
    _UNLOCKED["priv"] = priv
    return {"ok": True}


def _people_crm_files(folder: Path) -> list[Path]:
    return sorted(folder.glob("* - customers.crm"))


def open_person(folder: str, me_id: str) -> dict:
    """A salesperson's customers, for the manager (needs the PIN this session)."""
    import teamlock
    if "priv" not in _UNLOCKED:
        return {"ok": False, "locked": True, "message": "Type your manager PIN."}
    f = Path(folder or "")
    for p in _people_crm_files(f):
        if f"({me_id[:4]})" not in p.name:
            continue
        try:
            d = teamlock.unseal(p.read_bytes(), _UNLOCKED["priv"])
        except Exception:
            continue
        if d.get("me_id") != me_id:
            continue
        # changes he made that the salesperson's program hasn't taken in yet
        pend = _pending(me_id, d.get("applied") or [])
        custs = d.get("customers") or []
        for op in pend:
            c = next((x for x in custs if x.get("id") == op.get("cid")), None)
            if c:
                _overlay(c, op)
        return {"ok": True, "salesperson": d.get("salesperson"), "saved": d.get("saved"),
                "pending": len(pend), "customers": custs}
    return {"ok": False, "message": "That salesperson's customers aren't in the folder yet. Their program shares them within a few minutes of being open."}


def _pend_file() -> Path:
    import config
    return Path(config.BASE) / "manager changes waiting.json"


def _pending(me_id: str, applied: list) -> list:
    try:
        d = json.loads(_pend_file().read_text(encoding="utf-8"))
    except Exception:
        d = {}
    keep = [op for op in d.get(me_id, []) if op.get("id") not in set(applied)]
    if len(keep) != len(d.get(me_id, [])):
        d[me_id] = keep
        _pend_file().write_text(json.dumps(d, indent=1), encoding="utf-8")
    return keep


def _overlay(c: dict, op: dict) -> None:
    kind, val, when = op.get("op"), op.get("value"), op.get("when", "")
    if kind in ("note", "sent"):
        c.setdefault("notes" if kind == "note" else "sent", []).append(
            {"when": when, "text": "👔 Manager: " + str(val or ""), "waiting": True})
    elif kind == "status":
        c["status"] = val
    elif kind == "followup":
        c["followup"] = val
    elif kind == "appointment":
        c["appointment"] = val
        if val:
            c["status"] = "Appointment set"


def manager_change(folder: str, me_id: str, pub: str, cid: str, op: str, value) -> dict:
    """One thing the manager did on a salesperson's customer: locked for that salesperson."""
    import uuid
    import teamlock
    if "priv" not in _UNLOCKED:
        return {"ok": False, "locked": True, "message": "Type your manager PIN."}
    if op not in ("note", "sent", "status", "followup", "appointment"):
        return {"ok": False, "message": "That can't be changed from here."}
    if op in ("note", "sent") and not str(value or "").strip():
        return {"ok": False, "message": "Type something first."}
    mk = manager_key() or {}
    f = Path(folder or "")
    one = {"id": uuid.uuid4().hex[:12], "cid": cid, "op": op, "value": value,
           "when": datetime.now().strftime("%Y-%m-%d %H:%M")}
    blob = teamlock.seal({"kind": "la-change", "to": me_id, "by": mk.get("name") or "Manager", "ops": [one]}, pub)
    _write_atomic(f / f"Manager ({me_id[:4]}) - change {one['id']}.chg", blob)
    try:
        d = json.loads(_pend_file().read_text(encoding="utf-8"))
    except Exception:
        d = {}
    d.setdefault(me_id, []).append(one)
    _pend_file().write_text(json.dumps(d, indent=1), encoding="utf-8")
    return {"ok": True, "message": "Saved. It shows on their screen within a few minutes, marked Manager."}


# ------------------------------------------------------------------ the dashboard
def _age_hours(iso: str):
    try:
        return round((datetime.now() - datetime.fromisoformat(iso)).total_seconds() / 3600, 1)
    except Exception:
        return None


def flags(d: dict) -> list[str]:
    """What the manager should look at, in plain words."""
    out = []
    oh = d.get("opened_hours")
    if oh is not None and oh >= 48:
        out.append(f"Hasn't opened it in {int(oh // 24)} days")
    elif d.get("age_hours") is not None and d["age_hours"] > 36:
        out.append(f"No update in {int(d['age_hours'] // 24)} day{'s' if d['age_hours'] >= 48 else ''}")
    if d.get("page_mode") and not d.get("live"):
        # posts to his own business page instead of Marketplace: judge him on that
        if not d.get("page_week"):
            out.append("No page posts this week")
    elif d.get("not_posted", 0) >= 10:
        out.append(f"{d['not_posted']} cars not posted")
    if d.get("drops_due", 0) >= 3:
        out.append(f"{d['drops_due']} price drops waiting")
    if d.get("sold_still_listed"):
        n = len(d["sold_still_listed"])
        out.append(f"{n} sold car{'s' if n > 1 else ''} still up")
    a = d.get("act") or {}
    if a.get("followups_late"):
        out.append(f"{a['followups_late']} follow-up{'s' if a['followups_late'] > 1 else ''} late")
    if a.get("no_contact_3d", 0) >= 3:
        out.append(f"{a['no_contact_3d']} customers not contacted in 3+ days")
    return out


def dashboard(folder: str) -> dict:
    f = Path(folder or "")
    if not folder or not f.is_dir():
        return {"ok": False, "message": "Pick the shared folder first."}
    people = []
    for p in sorted(f.glob("*.json")):
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            continue
        if d.get("kind") != KIND:
            continue
        d["age_hours"] = _age_hours(d.get("updated", ""))
        c = d.get("crm30") or {}
        d["closing"] = round(100 * c.get("sold", 0) / c["leads"]) if c.get("leads") else None
        d["opened_hours"] = _age_hours(d.get("last_opened", "")) if d.get("last_opened") else None
        d["has_crm"] = bool(d.get("crm_file") and (f / d["crm_file"]).exists())
        d["flags"] = flags(d)
        d.pop("pub", None) if not d["has_crm"] else None
        people.append(d)
    # each store: what's on the lot (newest read), and what nobody has listed
    stores = {}
    for d in people:
        k = d.get("store", "").strip().lower()
        st = stores.setdefault(k, {"store": d.get("store", ""), "people": 0, "lot": [], "lot_read": "",
                                   "listed": set()})
        st["people"] += 1
        if d.get("lot_read", "") >= st["lot_read"]:
            st["lot_read"] = d.get("lot_read", "")
            st["lot"] = d.get("lot_stocks") or []
        st["listed"] |= {x["stock"] for x in d.get("listings") or []}
    store_rows = []
    for st in stores.values():
        nobody = [x for x in st["lot"] if x["stock"] not in st["listed"]]
        store_rows.append({"store": st["store"], "people": st["people"], "lot": len(st["lot"]),
                           "listed": len([x for x in st["lot"] if x["stock"] in st["listed"]]),
                           "nobody": sorted(nobody, key=lambda x: x.get("price") or 0)})
    people.sort(key=lambda d: (d.get("store", ""), d.get("salesperson", "")))
    for d in people:
        d.pop("lot_stocks", None)       # the store rows carry the lot
    return {"ok": True, "folder": str(f), "people": people,
            "stores": sorted(store_rows, key=lambda x: x["store"])}


# ------------------------------------------------------------ finding the team folder
TEAM_FOLDER_NAME = "Listing Accelerator Team"


def find_team_folder() -> str:
    """The manager's shared folder, if it's in this person's OneDrive (his
    own, or the shortcut a salesman adds with "Add shortcut to My files")."""
    import os
    home = Path(os.environ.get("USERPROFILE") or Path.home())
    roots = [Path(os.environ[v]) for v in ("OneDriveCommercial", "OneDrive", "OneDriveConsumer")
             if os.environ.get(v)]
    try:
        roots += [p for p in home.iterdir() if p.is_dir() and p.name.lower().startswith("onedrive")]
    except Exception:
        pass
    seen = []
    for r in roots:
        for cand in (r / TEAM_FOLDER_NAME,):
            try:
                if cand.is_dir() and str(cand) not in seen:
                    seen.append(str(cand))
            except Exception:
                pass
    return seen[0] if len(seen) == 1 else ""


def auto_join() -> str:
    """Someone with a team key and no folder picked yet: if the team folder is
    in his OneDrive, use it and start sharing -- nothing to browse for."""
    try:
        import keycheck
        k = keycheck.status()
    except Exception:
        return ""
    if not (k.get("ok") and k.get("team")):
        return ""
    s = settings()
    if s["folder"]:
        return ""
    f = find_team_folder()
    if f:
        save_settings(folder=f, share=True)
    return f
