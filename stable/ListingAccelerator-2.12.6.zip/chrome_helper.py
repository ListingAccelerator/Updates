"""
chrome_helper.py -- the Chrome (or Edge) helper that fills in Facebook's
Marketplace vehicle form.

Two halves:

1. A small web server inside the program, on this computer only
   (127.0.0.1, port 8765). It hands the helper the cars that aren't posted
   yet -- the same words and photos the Posting helper has -- and records a
   car as posted when he says so. Nothing outside this computer can reach it,
   and web pages can't use it either: every request has to carry the helper's
   own header, which a web page isn't allowed to send.

2. The helper itself, a browser extension. The program writes its files into
   "Chrome helper" next to the program, and the salesperson loads that folder
   once in chrome://extensions (or edge://extensions).

On facebook.com/marketplace/create/vehicle the helper shows a panel: pick a
car, press Fill. It types the year, make, model, miles, price, colours, body,
condition, fuel, transmission and description, and adds the photos. It never
presses Next or Publish -- he looks it over and publishes it himself, the way
the program has always worked. Anything it couldn't fill is listed so he
can do that one box by hand. The VIN box is always left empty.

The extension's files live in this file (not a folder) so the one-click
updater, which ships the program's top-level files, keeps them current.
"""
from __future__ import annotations

import csv
import json
import mimetypes
import threading
import urllib.parse
from datetime import date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).resolve().parent
FOLDER = HERE / "Chrome helper"
PORTS = (8765, 8766, 8767)
HEADER = "X-Listing-Accelerator"
VERSION = "1.0.5"
_server = {"port": None}


# ------------------------------------------------------------------ data
def _stores() -> list[dict]:
    import stores
    out = []
    for s in stores.all_stores():
        d = Path(s["dir"])
        out.append({"key": s["key"], "name": s["name"], "dir": d, "out": d / "out"})
    return out


def _posted(out_dir: Path) -> dict:
    p = out_dir / "posted.csv"
    if not p.exists():
        return {}
    with open(p, newline="", encoding="utf-8") as f:
        return {r["Stock"].upper(): r for r in csv.DictReader(f) if r.get("Stock")}


def _kit(out_dir: Path) -> dict:
    try:
        return json.loads((out_dir / "listing_kit" / "cars.json").read_text(encoding="utf-8"))
    except Exception:
        return {"cars": []}


def _photos(folder: Path) -> list[str]:
    """The posting set if there is one (background versions where made),
    otherwise the car's own photos -- up to 20, Facebook's limit."""
    post = folder / "post"
    if post.is_dir():
        pics = sorted(p.name for p in post.iterdir() if p.suffix.lower() in (".jpg", ".jpeg", ".png"))
        if pics:
            return ["post/" + n for n in pics][:20]
    try:
        import backgrounds
        return [p.name for p in backgrounds.originals(folder)][:20]
    except Exception:
        return sorted(p.name for p in folder.glob("*.jpg"))[:20] if folder.is_dir() else []


def cars(store_key: str = "") -> dict:
    out = []
    for s in _stores():
        if store_key and s["key"] != store_key:
            continue
        kit = _kit(s["out"])
        posted = _posted(s["out"])
        for c in kit.get("cars", []):
            r = posted.get(str(c.get("stock", "")).upper())
            live = bool(r and r.get("Status") != "down" and r.get("Posted_Date"))
            out.append({"store": s["key"], "store_name": s["name"], "stock": c.get("stock"),
                        "title": c.get("title"), "photos": c.get("photos", 0),
                        "posted": live, "posted_date": (r or {}).get("Posted_Date", "")})
    return {"ok": True, "version": VERSION,
            "stores": [{"key": s["key"], "name": s["name"],
                        "ready": (s["out"] / "listing_kit" / "cars.json").exists()} for s in _stores()],
            "cars": out}


def _find(store_key: str, stock: str):
    for s in _stores():
        if s["key"] != store_key:
            continue
        for c in _kit(s["out"]).get("cars", []):
            if str(c.get("stock", "")).upper() == str(stock).upper():
                return s, c
    return None, None


def car(store_key: str, stock: str) -> dict:
    s, c = _find(store_key, stock)
    if not c:
        return {"ok": False, "message": "That car isn't in the Posting helper. Run today's update."}
    folder = Path(c.get("folder") or "")
    pics = _photos(folder)
    q = urllib.parse.quote
    return {"ok": True, "stock": c["stock"], "title": c.get("title"), "fb": c.get("fb", {}),
            "photos": [{"name": n.split("/")[-1],
                        "url": f"/la/photo?store={q(store_key)}&stock={q(c['stock'])}&name={q(n)}"}
                       for n in pics]}


def photo_path(store_key: str, stock: str, name: str):
    s, c = _find(store_key, stock)
    if not c:
        return None
    folder = Path(c.get("folder") or "").resolve()
    allowed = set(_photos(folder))
    if name not in allowed:            # only the car's own listed photos
        return None
    p = (folder / name).resolve()
    if folder not in p.parents or not p.is_file():
        return None
    return p


def mark_posted(store_key: str, stock: str) -> dict:
    import track
    s, c = _find(store_key, stock)
    if not s:
        return {"ok": False, "message": "That car isn't in the Posting helper."}
    out_dir = s["out"]
    rows = _posted(out_dir)
    try:
        inv = {str(r.get("stock", "")).upper(): r for r in
               json.loads((out_dir / "inventory.json").read_text(encoding="utf-8"))}
    except Exception:
        inv = {}
    st = str(stock).upper()
    r = rows.get(st, {"Stock": st})
    r["Posted_Date"] = date.today().isoformat()
    r["Status"] = "live"
    r["Dropped_Date"] = ""
    r["Dropped_Price"] = ""
    v = inv.get(st)
    if v:
        r["Posted_Price"] = track.post_price(v) or ""
        r["Vehicle"] = " ".join(str(v.get(k) or "") for k in ("year", "make", "model", "trim")).strip()
    rows[st] = r
    out_dir.mkdir(parents=True, exist_ok=True)
    with open(out_dir / "posted.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=track.COLS, extrasaction="ignore")
        w.writeheader()
        for k in sorted(rows):
            row = {c2: "" for c2 in track.COLS}
            row.update(rows[k])
            w.writerow(row)
    return {"ok": True, "message": f"{st} recorded as posted."}


# ------------------------------------------------------------------ server
class _H(BaseHTTPRequestHandler):
    server_version = "ListingAccelerator"

    def log_message(self, *a):
        pass

    def _ok_origin(self) -> bool:
        # Only the helper: it sends our header (a web page can't, without a
        # permission this server never gives) and only from this computer.
        return self.headers.get(HEADER) == "1" and self.client_address[0] in ("127.0.0.1", "::1")

    def _json(self, code, obj):
        b = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(b)

    def do_OPTIONS(self):
        self.send_response(403)        # no permission for web pages, ever
        self.end_headers()

    def do_GET(self):
        if not self._ok_origin():
            return self._json(403, {"ok": False})
        u = urllib.parse.urlparse(self.path)
        q = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
        try:
            if u.path == "/la/ping":
                return self._json(200, {"ok": True, "version": VERSION, "app": "Listing Accelerator"})
            if u.path == "/la/cars":
                return self._json(200, cars(q.get("store", "")))
            if u.path == "/la/car":
                return self._json(200, car(q.get("store", ""), q.get("stock", "")))
            if u.path == "/la/photo":
                p = photo_path(q.get("store", ""), q.get("stock", ""), q.get("name", ""))
                if not p:
                    return self._json(404, {"ok": False})
                data = p.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", mimetypes.guess_type(p.name)[0] or "image/jpeg")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return
        except Exception as e:
            return self._json(500, {"ok": False, "message": str(e)})
        return self._json(404, {"ok": False})

    def do_POST(self):
        if not self._ok_origin():
            return self._json(403, {"ok": False})
        u = urllib.parse.urlparse(self.path)
        try:
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(n) or b"{}") if n else {}
            if u.path == "/la/posted":
                return self._json(200, mark_posted(str(body.get("store", "")), str(body.get("stock", ""))))
        except Exception as e:
            return self._json(500, {"ok": False, "message": str(e)})
        return self._json(404, {"ok": False})


def start() -> int | None:
    """Start the server in the background. Quietly does nothing if another
    copy of the program already has the port."""
    if _server["port"]:
        return _server["port"]
    for port in PORTS:
        try:
            srv = ThreadingHTTPServer(("127.0.0.1", port), _H)
        except OSError:
            continue
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        _server["port"] = port
        return port
    return None


def running_port():
    return _server["port"]


# ------------------------------------------------------------------ the extension
MANIFEST = {
    "manifest_version": 3,
    "name": "Listing Accelerator – Marketplace Helper",
    "version": VERSION,
    "description": "Fills in Facebook Marketplace's vehicle form from Listing Accelerator. You review it and press Publish yourself.",
    "permissions": [],
    "host_permissions": ["http://127.0.0.1/*"],
    "background": {"service_worker": "background.js"},
    "content_scripts": [{
        # Every Facebook page: Facebook moves between pages without reloading,
        # so a helper that only loaded on Marketplace pages never showed up
        # when he clicked his way there. It only shows itself on Marketplace.
        "matches": ["https://www.facebook.com/*", "https://web.facebook.com/*"],
        "js": ["content.js"],
        "run_at": "document_idle",
    }],
    "icons": {"128": "icon128.png"},
}

BACKGROUND_JS = r"""
// Talks to Listing Accelerator on this computer. Only the helper can: the
// program answers requests that carry this header, which web pages can't send.
const PORTS = [8765, 8766, 8767];
let base = null;
async function findApp(){
  if (base) {
    try { const r = await fetch(base + "/la/ping", {headers: {"X-Listing-Accelerator": "1"}}); if (r.ok) return base; } catch (e) {}
    base = null;
  }
  for (const p of PORTS){
    try {
      const u = "http://127.0.0.1:" + p;
      const r = await fetch(u + "/la/ping", {headers: {"X-Listing-Accelerator": "1"}});
      if (r.ok){ const j = await r.json(); if (j.app === "Listing Accelerator"){ base = u; return base; } }
    } catch (e) {}
  }
  return null;
}
async function call(path, opts){
  const b = await findApp();
  if (!b) return {ok: false, noapp: true, message: "Open Listing Accelerator on this computer first."};
  const r = await fetch(b + path, Object.assign({headers: {"X-Listing-Accelerator": "1", "Content-Type": "application/json"}}, opts || {}));
  return r.json();
}
async function photoData(path){
  const b = await findApp();
  if (!b) return null;
  const r = await fetch(b + path, {headers: {"X-Listing-Accelerator": "1"}});
  if (!r.ok) return null;
  const blob = await r.blob();
  const buf = new Uint8Array(await blob.arrayBuffer());
  let s = ""; for (let i = 0; i < buf.length; i += 32768) s += String.fromCharCode.apply(null, buf.subarray(i, i + 32768));
  return {type: blob.type || "image/jpeg", b64: btoa(s)};
}
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  (async () => {
    try {
      if (msg.t === "cars") return reply(await call("/la/cars"));
      if (msg.t === "car") return reply(await call("/la/car?store=" + encodeURIComponent(msg.store) + "&stock=" + encodeURIComponent(msg.stock)));
      if (msg.t === "photo") return reply(await photoData(msg.url));
      if (msg.t === "posted") return reply(await call("/la/posted", {method: "POST", body: JSON.stringify({store: msg.store, stock: msg.stock})}));
      reply({ok: false});
    } catch (e) { reply({ok: false, message: String(e)}); }
  })();
  return true;
});
"""

CONTENT_JS = r"""
// Listing Accelerator – Marketplace Helper
// Fills Facebook's vehicle form. Never presses Next or Publish: you check
// everything and publish it yourself. The VIN box is always left empty.
(() => {
  if (window.__laHelper) return; window.__laHelper = true;
  const send = m => new Promise(res => chrome.runtime.sendMessage(m, r => res(r)));
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const norm = t => (t || "").replace(/\s+/g, " ").trim().toLowerCase();

  // Facebook's pages refuse innerHTML ("Trusted Types"), so the panel is
  // built from its own small, fixed templates with this little reader
  // instead -- no innerHTML anywhere.
  const ENT = {"&amp;": "&", "&lt;": "<", "&gt;": ">", "&quot;": '"', "&#39;": "'", "&nbsp;": "\u00a0"};
  const dec = t => t.replace(/&(amp|lt|gt|quot|#39|nbsp);/g, m => ENT[m]);
  const VOID = new Set(["input", "br", "img", "hr"]);
  function setHTML(el, str){
    const top = document.createDocumentFragment();
    const stack = [top];
    const re = /<\/([a-zA-Z0-9]+)\s*>|<([a-zA-Z0-9]+)((?:\s+[\w-]+(?:="[^"]*")?)*)\s*\/?>|([^<]+)/g;
    let m;
    while ((m = re.exec(str))){
      const cur = stack[stack.length - 1];
      if (m[1]){ if (stack.length > 1) stack.pop(); continue; }
      if (m[2]){
        const node = document.createElement(m[2]);
        const ar = /([\w-]+)(?:="([^"]*)")?/g; let a;
        while ((a = ar.exec(m[3] || ""))) node.setAttribute(a[1], a[2] === undefined ? "" : dec(a[2]));
        cur.appendChild(node);
        if (!VOID.has(m[2].toLowerCase())) stack.push(node);
        continue;
      }
      if (m[4]) cur.appendChild(document.createTextNode(dec(m[4])));
    }
    el.replaceChildren(top);
  }

  // ---------- the panel ----------
  const host = document.createElement("div");
  host.style.cssText = "position:fixed;right:16px;bottom:16px;z-index:2147483647";
  const root = host.attachShadow({mode: "open"});
  setHTML(root, `<style>
    .p{width:330px;max-height:70vh;display:flex;flex-direction:column;background:#fff;color:#14181D;border-radius:12px;
       box-shadow:0 12px 40px rgba(0,0,0,.28);font:14px/1.45 "Segoe UI",Arial,sans-serif;overflow:hidden;border:1px solid #D9DEE5}
    .h{background:#00305F;color:#fff;padding:10px 12px;display:flex;align-items:center;gap:8px;cursor:move}
    .h b{flex:1;font-size:14px} .h button{background:none;border:0;color:#fff;font-size:16px;cursor:pointer}
    .b{padding:10px 12px;overflow:auto}
    input,select{width:100%;box-sizing:border-box;padding:7px 9px;border:1px solid #D9DEE5;border-radius:7px;font:inherit;margin:4px 0}
    .car{padding:7px 8px;border-radius:7px;cursor:pointer;border:1px solid transparent}
    .car:hover{background:#E4EBF3} .car.on{border-color:#00305F;background:#E4EBF3}
    .car small{color:#5C6671;display:block}
    .go{background:#00305F;color:#fff;border:0;border-radius:8px;padding:9px 12px;font:inherit;font-weight:700;cursor:pointer;width:100%;margin-top:8px}
    .go:disabled{opacity:.5}
    .ghost{background:#fff;color:#00305F;border:1px solid #D9DEE5;border-radius:8px;padding:8px 12px;font:inherit;cursor:pointer;width:100%;margin-top:6px}
    .note{font-size:12.5px;color:#5C6671;margin:6px 0}
    .warn{background:#FFF8E6;border:1px solid #E0A400;border-radius:7px;padding:7px 9px;font-size:12.5px;margin-top:8px}
    ul{margin:6px 0;padding-left:18px;font-size:13px} li.ok{color:#0A6E3D} li.no{color:#B3261E}
    .p.min .b{display:none} .p.min{width:200px}
  </style>
  <div class="p"><div class="h"><b>Listing Accelerator <span style="font-weight:400;opacity:.7;font-size:11px">helper ${chrome.runtime.getManifest().version}</span></b><button id="min" title="Shrink">–</button></div><div class="b" id="b"></div></div>`);
  document.documentElement.appendChild(host);
  const $ = s => root.querySelector(s);
  $("#min").onclick = () => { const p = root.querySelector(".p"); p.classList.toggle("min"); $("#min").textContent = p.classList.contains("min") ? "+" : "–"; };
  // drag the panel
  (() => { const h = root.querySelector(".h"); let sx, sy, ox, oy;
    h.addEventListener("mousedown", e => { if (e.target.tagName === "BUTTON") return; sx = e.clientX; sy = e.clientY;
      const r = host.getBoundingClientRect(); ox = r.left; oy = r.top;
      const mv = ev => { host.style.left = (ox + ev.clientX - sx) + "px"; host.style.top = (oy + ev.clientY - sy) + "px"; host.style.right = "auto"; host.style.bottom = "auto"; };
      const up = () => { document.removeEventListener("mousemove", mv); document.removeEventListener("mouseup", up); };
      document.addEventListener("mousemove", mv); document.addEventListener("mouseup", up); }); })();

  let S = {cars: [], store: "", pick: null, filter: "", report: null, car: null};
  const esc = t => String(t ?? "").replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
  const onVehicleForm = () => /\/marketplace\/create\/vehicle/.test(location.pathname);

  async function load(){
    const r = await send({t: "cars"});
    if (!r || !r.ok){ draw(r && r.noapp ? "noapp" : "err", r && r.message); return; }
    S.cars = r.cars; S.stores = r.stores;
    // the program has a newer helper than the one Chrome is running
    S.old = r.version && r.version !== chrome.runtime.getManifest().version;
    if (!S.store && r.stores.length) S.store = r.stores[0].key;
    draw();
  }
  function draw(state, msg){
    const b = $("#b");
    if (state === "noapp"){ setHTML(b, `<p>Open <b>Listing Accelerator</b> on this computer, then press Try again.</p><button class="go" id="again">Try again</button>`); $("#again").onclick = load; return; }
    if (state === "err"){ setHTML(b, `<p>${esc(msg || "Something went wrong.")}</p><button class="go" id="again">Try again</button>`); $("#again").onclick = load; return; }
    if (!onVehicleForm()){
      setHTML(b, `<p class="note">Open the vehicle listing form and the helper fills it in for you.</p>
        <button class="go" id="tov">Create vehicle listing</button>`);
      $("#tov").onclick = () => location.href = "https://www.facebook.com/marketplace/create/vehicle";
      return;
    }
    const mine = S.cars.filter(c => c.store === S.store);
    const match = c => !S.filter || norm(c.title + " " + c.stock).includes(norm(S.filter));
    // searching shows already-posted cars too (to post one again); the plain list is what's left to post
    const list = mine.filter(c => (S.filter ? true : !c.posted) && match(c));
    const left = mine.filter(c => !c.posted).length;
    const stInfo = (S.stores || []).find(x => x.key === S.store) || {};
    const empty = stInfo.ready === false ? "This store's list isn't built yet. In Listing Accelerator, press <b>Run today's update</b>, then press F5 here."
      : S.filter ? "No car matches that. It may be outside <b>What you work</b>, or not on the website today."
      : "Everything is posted. New cars show up here after the next update.";
    setHTML(b, `${S.old ? `<div class="warn" style="margin:0 0 8px;border-color:#B3261E;background:#FDECEA">This helper is out of date. Open <b>chrome://extensions</b>, press the round arrow on <b>Listing Accelerator – Marketplace Helper</b>, then press F5 here.</div>` : ""}${S.stores.length > 1 ? `<select id="st">${S.stores.map(s => `<option value="${esc(s.key)}" ${s.key === S.store ? "selected" : ""}>${esc(s.name)}</option>`).join("")}</select>` : ""}
      <input id="q" placeholder="Stock number, year or model" value="${esc(S.filter)}">
      <div class="note">${left} not posted yet${S.filter ? ` · ${list.length} match` : ""}</div>
      <div id="list">${list.slice(0, 40).map(c => `<div class="car ${S.pick && S.pick.stock === c.stock ? "on" : ""}" data-s="${esc(c.stock)}">${esc(c.title)}<small>${esc(c.stock)} · ${c.photos} photos${c.posted ? " · already posted " + esc(c.posted_date) : ""}</small></div>`).join("") || `<p class="note">${empty}</p>`}</div>
      ${S.pick ? `<button class="go" id="fill">Fill the form: ${esc(S.pick.stock)}</button>` : ""}
      <div id="rep">${S.report || ""}</div>
      ${S.car ? `<button class="ghost" id="done">I published it — record it as posted</button>` : ""}
      <div class="warn">Check every box, then press <b>Next</b> and <b>Publish</b> yourself. Leave the <b>VIN</b> box empty.</div>`);
    const st = $("#st"); if (st) st.onchange = () => { S.store = st.value; S.pick = null; draw(); };
    const q = $("#q"); q.oninput = () => { S.filter = q.value; const pos = q.selectionStart; draw(); const q2 = $("#q"); q2.focus(); q2.setSelectionRange(pos, pos); };
    root.querySelectorAll("[data-s]").forEach(el => el.onclick = () => { S.pick = S.cars.find(c => c.stock === el.dataset.s && c.store === S.store); S.report = null; S.car = null; draw(); });
    const f = $("#fill"); if (f) f.onclick = fill;
    const d = $("#done"); if (d) d.onclick = async () => {
      const r = await send({t: "posted", store: S.store, stock: S.car.stock});
      S.report = r && r.ok ? `<p class="note" style="color:#0A6E3D">✓ ${esc(r.message)}</p>` : `<p class="note" style="color:#B3261E">${esc((r && r.message) || "Couldn't record it.")}</p>`;
      if (r && r.ok){ const c = S.cars.find(x => x.stock === S.car.stock && x.store === S.store); if (c) c.posted = true; S.pick = null; S.car = null; }
      draw();
    };
  }

  // ---------- finding Facebook's boxes ----------
  // Facebook labels each box with its name ("Year", "Mileage"...). Find the
  // smallest visible element whose own text is exactly that name, then the
  // control that goes with it.
  // Every visible element whose own text is exactly the box's name. The
  // same words can appear elsewhere on the page (the preview shows "Price",
  // a heading says "Description"), so each one is tried until one has a box.
  function labelHosts(name){
    const want = norm(name);
    return [...document.querySelectorAll("label span, label div, span, div, h2, h3")].filter(e => {
      if (!e.offsetParent || e.children.length) return false;
      return norm(e.textContent) === want;
    }).map(s => s.closest("label") || s.closest("[role=combobox]") || s.parentElement).filter(Boolean);
  }
  function labelEl(name){ return labelHosts(name)[0] || null; }
  const TEXTBOX = "input:not([type=file]):not([type=checkbox]):not([type=radio]), textarea, [contenteditable=true], [role=textbox]";
  function inputFor(name){
    for (const l of labelHosts(name)){
      const c = l.matches && l.matches(TEXTBOX) ? l : l.querySelector(TEXTBOX) ||
                (l.id && document.querySelector(`[aria-labelledby~="${l.id}"]`));
      if (c) return c;
    }
    // last try: a box that names itself
    const want = norm(name);
    return [...document.querySelectorAll(TEXTBOX)].find(e => e.offsetParent &&
      (norm(e.getAttribute("aria-label")) === want || norm(e.getAttribute("placeholder")) === want)) || null;
  }
  function comboFor(name){
    const hosts = labelHosts(name);
    for (const l of hosts){
      if (l.getAttribute("role") === "combobox" || l.getAttribute("aria-haspopup")) return l;
      const c = l.querySelector("[role=combobox],[aria-haspopup]") || l.closest("[role=combobox],[aria-haspopup]");
      if (c) return c;
    }
    return hosts[0] || null;
  }
  function setNative(el, value){
    const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
    el.focus();
    setter.call(el, value);
    el.dispatchEvent(new Event("input", {bubbles: true}));
    el.dispatchEvent(new Event("change", {bubbles: true}));
    el.blur();
  }
  async function typeInto(name, value){
    if (!value) return null;
    const el = inputFor(name);
    if (!el) return false;
    if (!/^(INPUT|TEXTAREA)$/.test(el.tagName)){
      // a rich text box: select what's there and type over it
      el.focus();
      document.execCommand("selectAll", false, null);
      document.execCommand("insertText", false, value);
      await sleep(200);
      return norm(el.textContent).length > 0;
    }
    setNative(el, value);
    await sleep(150);
    return norm(el.value) === norm(value) || norm(el.value).replace(/[^0-9]/g, "") === norm(value).replace(/[^0-9]/g, "");
  }
  function clickEl(el){
    for (const t of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"])
      el.dispatchEvent(new MouseEvent(t, {bubbles: true, cancelable: true, view: window}));
  }
  async function pick(name, value, also){
    if (!value) return null;
    const cb = comboFor(name);
    if (!cb) return false;
    cb.scrollIntoView({block: "center"});
    clickEl(cb);
    let opts = [];
    for (let i = 0; i < 20 && !opts.length; i++){ await sleep(120); opts = [...document.querySelectorAll("[role=option]")].filter(o => o.offsetParent); }
    // a typeahead (Make on some forms): type to narrow the list
    const inner = cb.querySelector("input") || (document.activeElement && document.activeElement.tagName === "INPUT" ? document.activeElement : null);
    if (!opts.length && inner){ setNative(inner, value); for (let i = 0; i < 15 && !opts.length; i++){ await sleep(150); opts = [...document.querySelectorAll("[role=option]")].filter(o => o.offsetParent); } }
    const wants = [value, ...(also || [])].map(norm);
    let hit = null;
    for (const w of wants){ hit = opts.find(o => norm(o.textContent) === w); if (hit) break; }
    if (!hit) for (const w of wants){ hit = opts.find(o => norm(o.textContent).startsWith(w)); if (hit) break; }
    if (!hit){ document.dispatchEvent(new KeyboardEvent("keydown", {key: "Escape", bubbles: true})); clickEl(document.body); await sleep(150); return false; }
    hit.scrollIntoView({block: "center"});
    clickEl(hit);
    await sleep(350);
    return true;
  }
  async function addPhotos(car){
    const input = [...document.querySelectorAll("input[type=file]")].find(i => /image/.test(i.accept || "image"));
    if (!input) return false;
    const dt = new DataTransfer();
    for (const p of car.photos.slice(0, 20)){
      const d = await send({t: "photo", url: p.url});
      if (!d) continue;
      const bin = atob(d.b64); const arr = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
      dt.items.add(new File([arr], p.name, {type: d.type}));
    }
    if (!dt.files.length) return false;
    input.files = dt.files;
    input.dispatchEvent(new Event("input", {bubbles: true}));
    input.dispatchEvent(new Event("change", {bubbles: true}));
    await sleep(1200);
    return dt.files.length;
  }

  async function fill(){
    const btn = $("#fill"); if (btn){ btn.disabled = true; btn.textContent = "Filling…"; }
    const r = await send({t: "car", store: S.store, stock: S.pick.stock});
    if (!r || !r.ok){ S.report = `<p class="note" style="color:#B3261E">${esc((r && r.message) || "Couldn't get that car.")}</p>`; return draw(); }
    const f = r.fb || {};
    const done = [], missed = [];
    const step = async (label, res) => { if (res === null) return; (res ? done : missed).push(label); };
    await step("Vehicle type", await pick("Vehicle type", f.vehicle_type, ["Car/Truck", "Car/truck"]));
    await sleep(600);    // the rest of the form appears after the type is picked
    const n = await addPhotos(r); (n ? done : missed).push(n ? `Photos (${n})` : "Photos");
    await step("Year", await pick("Year", f.year));
    await step("Make", await pick("Make", f.make));
    await step("Model", await typeInto("Model", f.model));
    await step("Mileage", await typeInto("Mileage", f.mileage));
    await step("Price", await typeInto("Price", f.price));
    await step("Body style", await pick("Body style", f.body_style));
    await step("Exterior color", await pick("Exterior color", f.exterior_color));
    await step("Interior color", await pick("Interior color", f.interior_color));
    await step("Vehicle condition", await pick("Vehicle condition", f.condition));
    await step("Fuel type", await pick("Fuel type", f.fuel));
    await step("Transmission", await pick("Transmission", f.transmission));
    await step("Description", await typeInto("Description", f.description));
    S.car = r;
    S.report = `<ul>${done.map(x => `<li class="ok">✓ ${esc(x)}</li>`).join("")}${missed.map(x => `<li class="no">✗ ${esc(x)} — fill this one yourself</li>`).join("")}</ul>
      <p class="note">Price ${esc(f.price ? "$" + Number(f.price).toLocaleString() : "")} · Clean title: tick it yourself only if it's true.</p>`;
    draw();
  }

  // Facebook changes pages without reloading: keep the panel in step.
  let last = location.pathname;
  const onMarket = () => location.pathname.startsWith("/marketplace");
  let loaded = false;
  const show = () => {
    host.style.display = onMarket() ? "" : "none";
    if (onMarket() && !loaded){ loaded = true; load(); }
  };
  setInterval(() => {
    if (location.pathname !== last){ last = location.pathname; S.report = null; S.car = null; if (loaded) draw(); }
    show();
  }, 800);
  show();
})();
"""


def _icon_png() -> bytes:
    """A 128px icon: the program's navy tag."""
    try:
        from PIL import Image, ImageDraw
        import io
        im = Image.new("RGBA", (128, 128), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        d.rounded_rectangle([4, 4, 124, 124], 26, fill=(0, 48, 95, 255))
        d.polygon([(30, 40), (78, 40), (100, 64), (78, 88), (30, 88)], fill=(255, 255, 255, 255))
        d.ellipse([40, 57, 54, 71], fill=(0, 48, 95, 255))
        b = io.BytesIO()
        im.save(b, "PNG")
        return b.getvalue()
    except Exception:
        return b""


def write_extension() -> Path:
    """Put the helper's files in "Chrome helper" (again, if they're old)."""
    FOLDER.mkdir(parents=True, exist_ok=True)
    (FOLDER / "manifest.json").write_text(json.dumps(MANIFEST, indent=1), encoding="utf-8")
    (FOLDER / "background.js").write_text(BACKGROUND_JS.strip() + "\n", encoding="utf-8")
    (FOLDER / "content.js").write_text(CONTENT_JS.strip() + "\n", encoding="utf-8")
    ico = _icon_png()
    if ico:
        (FOLDER / "icon128.png").write_bytes(ico)
    (FOLDER / "READ ME.txt").write_text(
        "Listing Accelerator - Marketplace Helper\n\n"
        "Load this folder once in Chrome (or Edge):\n"
        "  1. Open chrome://extensions  (Edge: edge://extensions)\n"
        "  2. Turn on Developer mode (top right; Edge: left side)\n"
        "  3. Press Load unpacked and pick this folder\n\n"
        "Then open Facebook Marketplace -> Create new listing -> Vehicle for sale.\n"
        "The helper fills the form; you check it and press Publish yourself.\n"
        "Keep Listing Accelerator open while you post.\n", encoding="utf-8")
    return FOLDER


def installed_version() -> str:
    try:
        return json.loads((FOLDER / "manifest.json").read_text(encoding="utf-8")).get("version", "")
    except Exception:
        return ""
