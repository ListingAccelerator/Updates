"""
Support: a salesperson having trouble sends a message and a screenshot to
support@automotivesalesaccelerator.com without leaving the program.

Two ways out, tried in order:
  1. Straight from the program, through a small Google Apps Script web app
     that runs on the Automotive Sales Accelerator Google account and emails
     support@ with the pictures attached. (SEND_URL below.)
  2. If that isn't set up or can't be reached: the message is put together
     in their own email program (To, Subject and the words filled in) and the
     folder with the screenshot opens beside it so they can drag it in.

What goes: their message, their name / email / phone, the screenshot(s) they
chose, and -- if they leave the box ticked -- program details: version,
Windows, each store's name and how it's read, and the end of the last
update's log. Never customers, chats, deals or the Gemini key.
"""
from __future__ import annotations

import base64
import io
import json
import platform
import re
import subprocess
import sys
import time
import urllib.parse
import urllib.request
from pathlib import Path

import config

SUPPORT_EMAIL = "support@automotivesalesaccelerator.com"
# The Apps Script web app's address ("Deploy -> Web app" URL). Empty until
# it's set up; the email way is used until then.
SEND_URL = ""
TOKEN = "la-support-7Qm2xV9pK4"     # must match the script; stops stray posts

BASE = Path(config.BASE)
FOLDER = BASE / "support"


def _saved() -> dict:
    try:
        return json.loads((BASE / "support.json").read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save(d: dict) -> None:
    try:
        cur = _saved()
        cur.update(d)
        (BASE / "support.json").write_text(json.dumps(cur, indent=1), encoding="utf-8")
    except Exception:
        pass


def send_url() -> str:
    return str(_saved().get("url") or SEND_URL or "").strip()


def version() -> str:
    try:
        return (BASE / "version.txt").read_text(encoding="utf-8").strip()
    except Exception:
        return "?"


# --- who's asking -----------------------------------------------------------
def me() -> dict:
    """Name / email / phone, from what they typed last time or their store setup."""
    s = _saved()
    name, phone = s.get("name", ""), s.get("phone", "")
    if not name or not phone:
        try:
            import stores
            for st in stores.all_stores():
                cfg = st.get("settings") or {}
                name = name or cfg.get("full_name") or cfg.get("first_name") or ""
                phone = phone or cfg.get("phone") or ""
                if name and phone:
                    break
        except Exception:
            pass
    return {"name": name, "email": s.get("email", ""), "phone": phone}


# --- screenshot -------------------------------------------------------------
def capture() -> dict:
    """A picture of the screen right now (taken before the Support box opens)."""
    try:
        from PIL import ImageGrab
        img = ImageGrab.grab(all_screens=True)
    except Exception:
        try:
            from PIL import ImageGrab
            img = ImageGrab.grab()
        except Exception as e:
            return {"ok": False, "message": f"Couldn't take a screenshot ({e})."}
    FOLDER.mkdir(parents=True, exist_ok=True)
    f = FOLDER / time.strftime("Screenshot %Y-%m-%d %H%M%S.png")
    img.save(f)
    _tidy()
    return {"ok": True, "path": str(f), "preview": _preview(img)}


def picture(path: str) -> dict:
    """A picture they picked (a phone photo, a screenshot they took themselves)."""
    try:
        from PIL import Image
        img = Image.open(path)
        img.load()
    except Exception:
        return {"ok": False, "message": "That file isn't a picture the program can open (use PNG or JPG)."}
    return {"ok": True, "path": str(path), "preview": _preview(img)}


def _preview(img) -> str:
    im = img.convert("RGB")
    im.thumbnail((520, 320))
    b = io.BytesIO()
    im.save(b, "JPEG", quality=80)
    return "data:image/jpeg;base64," + base64.b64encode(b.getvalue()).decode()


def _for_mail(path: str) -> dict | None:
    """A picture made small enough to email: JPEG, at most 1920 wide."""
    try:
        from PIL import Image
        im = Image.open(path).convert("RGB")
        im.thumbnail((1920, 1920))
        b = io.BytesIO()
        im.save(b, "JPEG", quality=82)
        return {"name": Path(path).stem + ".jpg", "type": "image/jpeg",
                "b64": base64.b64encode(b.getvalue()).decode()}
    except Exception:
        return None


def _tidy(keep_days: int = 14) -> None:
    """Old screenshots go; they're only needed until the message is sent."""
    try:
        cut = time.time() - keep_days * 86400
        for f in FOLDER.glob("Screenshot *.png"):
            if f.stat().st_mtime < cut:
                f.unlink()
    except Exception:
        pass


# --- program details --------------------------------------------------------
_SECRET = re.compile(r"(AIza[\w-]{20,}|sk-[\w-]{20,}|sk-ant-[\w-]{20,})")


def details() -> str:
    lines = [f"Listing Accelerator {version()}",
             f"Windows: {platform.platform()}",
             f"Python: {sys.version.split()[0]}"]
    try:
        import stores
        for st in stores.all_stores():
            cfg = st.get("settings") or {}
            how = ("Chrome helper" if cfg.get("read_by_helper") else
                   ("file/feed: " + str(cfg.get("feed_source"))) if cfg.get("feed_source") else
                   "website: " + str(cfg.get("inventory_url") or "?"))
            lines.append(f"Store: {st['name']}  ({how})")
            log = Path(st["dir"]) / "out" / "last run detail.txt"
            if log.exists():
                tail = log.read_text(encoding="utf-8-sig", errors="replace").splitlines()[-40:]
                lines.append(f"  Last update log ({time.strftime('%b %d %I:%M %p', time.localtime(log.stat().st_mtime))}), last lines:")
                lines += ["    " + t for t in tail]
    except Exception as e:
        lines.append(f"(couldn't read the stores: {e})")
    return _SECRET.sub("[key removed]", "\n".join(lines))


# --- sending ----------------------------------------------------------------
def send(message: str, name: str = "", email: str = "", phone: str = "",
         pictures: list[str] | None = None, include_details: bool = True) -> dict:
    message = str(message or "").strip()
    if not message and not pictures:
        return {"ok": False, "message": "Tell us what's going on, or add a screenshot."}
    name, email, phone = (str(x or "").strip() for x in (name, email, phone))
    if not email and not phone:
        return {"ok": False, "message": "Put in your email or phone so we can answer you."}
    _save({"name": name, "email": email, "phone": phone})
    pictures = [p for p in (pictures or []) if p and Path(p).exists()]
    info = details() if include_details else ""
    summary = (message.splitlines()[0] if message else "Screenshot")[:70]

    url = send_url()
    if url:
        pics = [x for x in (_for_mail(p) for p in pictures[:5]) if x]
        body = json.dumps({"token": TOKEN, "name": name, "email": email, "phone": phone,
                           "message": message, "summary": summary, "version": version(),
                           "details": info, "pictures": pics}).encode()
        try:
            req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=45) as r:
                ans = json.loads(r.read().decode("utf-8", "replace") or "{}")
            if ans.get("ok"):
                return {"ok": True, "how": "sent",
                        "message": "Sent to Listing Accelerator support. You'll get an answer at "
                                   + (email or phone) + "."}
        except Exception:
            pass        # fall through to their email program

    return _by_email(message, name, email, phone, pictures, info, summary)


def _by_email(message, name, email, phone, pictures, info, summary) -> dict:
    """Their own email program, filled in, with the screenshot folder open."""
    who = " · ".join(x for x in (name, phone, email) if x)
    short_info = "\n".join(info.splitlines()[:8]) if info else ""
    body = (f"{message}\n\nFrom: {who}\n"
            + (f"\n--- Program details ---\n{short_info}\n" if short_info else "")
            + ("\n(Screenshot attached)" if pictures else ""))
    # The whole details go in a file too; email links get cut off when long.
    FOLDER.mkdir(parents=True, exist_ok=True)
    if info:
        try:
            (FOLDER / "Program details.txt").write_text(info, encoding="utf-8")
        except Exception:
            pass
    link = ("mailto:" + SUPPORT_EMAIL + "?subject="
            + urllib.parse.quote("Listing Accelerator support: " + summary)
            + "&body=" + urllib.parse.quote(body[:1500]))
    opened = False
    try:
        if sys.platform == "win32":
            import os
            os.startfile(link)
        else:
            import webbrowser
            webbrowser.open(link)
        opened = True
    except Exception:
        pass
    if pictures:
        try:
            if sys.platform == "win32":
                subprocess.Popen(["explorer", "/select,", str(pictures[0])])
        except Exception:
            pass
    return {"ok": True, "how": "email", "opened": opened, "email": SUPPORT_EMAIL,
            "copy": body,
            "message": ("Your email is open with the message filled in. "
                        + ("Drag the screenshot from the folder that opened into the email, then press Send."
                           if pictures else "Press Send.") if opened else
                        f"Couldn't open your email program. Email {SUPPORT_EMAIL} -- the message is copied, "
                        "just paste it" + (" and attach the screenshot from the folder that opened." if pictures else "."))}
