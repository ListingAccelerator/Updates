"""
Accelerator on your phone: the parts of Listing Accelerator a salesperson
needs on the lot -- his customers, quick answers for a car, Find a car, and
adding a customer from a Marketplace chat -- on his iPhone or Android, saved
to the home screen like an app.

How it works: the program on his computer serves a small page on the store's
Wi-Fi only. He connects a phone once by scanning a QR code; that phone gets
its own key (in the address), which he can remove from Integrations any time.
Nothing goes to the internet and nothing is stored on a server: the customers
stay on his computer, and the phone only shows them while it's on the same
Wi-Fi and the program is open.
"""
from __future__ import annotations

import json
import secrets
import threading
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import config

PORTS = range(8780, 8790)
HERE = Path(__file__).resolve().parent

# What the phone may ask the program for. Nothing else is reachable.
ALLOWED = {
    "book", "book_customer", "book_save", "book_add_entry", "book_parse",
    "book_search", "qa_answers", "finder_search", "finder_text",
}

_lock = threading.RLock()
_server = None
_port = 0
API = None           # the program's Api, set by start()


# --- connected phones ------------------------------------------------------------
def _file() -> Path:
    return Path(getattr(config, "BASE", HERE)) / "phones.json"


def _load() -> dict:
    try:
        d = json.loads(_file().read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save(d: dict) -> None:
    try:
        _file().write_text(json.dumps(d, indent=1), encoding="utf-8")
    except OSError:
        pass


def phones() -> list[dict]:
    return [{"id": k[:6], "name": v.get("name") or "Phone", "made": v.get("made", ""),
             "seen": v.get("seen", "")} for k, v in _load().items()]


def remove(short_id: str) -> dict:
    d = _load()
    for k in list(d):
        if k[:6] == short_id:
            d.pop(k)
    _save(d)
    return {"ok": True, "message": "That phone can't open your customers any more."}


# --- the server ------------------------------------------------------------------
def start(api=None) -> int:
    """Start serving (once). Called at program start when a phone is connected,
    and when he connects one."""
    global _server, _port, API
    if api is not None:
        API = api
    with _lock:
        if _server:
            return _port
        last = None
        for p in PORTS:
            try:
                srv = ThreadingHTTPServer(("0.0.0.0", p), _Handler)
                srv.daemon_threads = True
                threading.Thread(target=srv.serve_forever, daemon=True).start()
                _server, _port = srv, p
                return p
            except OSError as e:
                last = e
        raise OSError(f"No free port for the phone page ({last})")


def connect(name: str = "") -> dict:
    """A new phone: a key of its own, and the QR code that opens it."""
    import phone_drop
    import qr
    ip = phone_drop.lan_ip()
    if not ip:
        return {"ok": False, "message": "This computer isn't on a Wi-Fi or network right now. "
                "Connect it to the same Wi-Fi as your phone."}
    try:
        port = start()
    except OSError as e:
        return {"ok": False, "message": str(e)}
    tok = secrets.token_urlsafe(18).replace("-", "x").replace("_", "y")
    d = _load()
    d[tok] = {"name": (name or "My phone").strip()[:30],
              "made": datetime.now().isoformat(timespec="minutes"), "seen": ""}
    _save(d)
    url = f"http://{ip}:{port}/m/{tok}"
    return {"ok": True, "url": url, "qr": qr.png_data_uri(url, 7)}


def state() -> dict:
    import phone_drop
    return {"ok": True, "phones": phones(), "running": bool(_server), "port": _port,
            "ip": phone_drop.lan_ip()}


def _known(tok: str) -> bool:
    d = _load()
    if tok not in d:
        return False
    now = datetime.now().isoformat(timespec="minutes")
    if d[tok].get("seen", "")[:15] != now[:15]:        # write at most every ~10 minutes
        d[tok]["seen"] = now
        _save(d)
    return True


class _Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="text/html; charset=utf-8", cache=False):
        b = body if isinstance(body, bytes) else body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "max-age=86400" if cache else "no-store")
        self.end_headers()
        self.wfile.write(b)

    def _parts(self):
        bits = [b for b in self.path.split("?")[0].split("/") if b]
        if len(bits) >= 2 and bits[0] == "m" and _known(bits[1]):
            return bits[1], bits[2:]
        return None, None

    def do_GET(self):
        tok, rest = self._parts()
        if not tok:
            return self._send(404, _GONE)
        if not rest:
            page = (HERE / "phone_app.html").read_text(encoding="utf-8")
            seller = getattr(config, "SELLER_NAME", "") or ""
            return self._send(200, page.replace("__SELLER__", json.dumps(seller)))
        if rest == ["icon.png"]:
            return self._send(200, _icon(), "image/png", cache=True)
        if rest == ["manifest.json"]:
            m = {"name": "Accelerator", "short_name": "Accelerator", "display": "standalone",
                 "start_url": f"/m/{tok}", "background_color": "#0B2A57", "theme_color": "#0B2A57",
                 "icons": [{"src": f"/m/{tok}/icon.png", "sizes": "180x180", "type": "image/png"}]}
            return self._send(200, json.dumps(m), "application/manifest+json")
        return self._send(404, _GONE)

    def do_POST(self):
        tok, rest = self._parts()
        if not tok or len(rest) != 2 or rest[0] != "api":
            return self._send(404, json.dumps({"ok": False, "message": "This phone isn't connected."}),
                              "application/json")
        name = rest[1]
        if name not in ALLOWED or API is None:
            return self._send(403, json.dumps({"ok": False, "message": "Not available on the phone."}),
                              "application/json")
        try:
            n = int(self.headers.get("Content-Length") or 0)
            args = json.loads(self.rfile.read(min(n, 2_000_000)) or b"[]")
            if not isinstance(args, list):
                args = [args]
            out = getattr(API, name)(*args)
        except Exception as e:
            out = {"ok": False, "message": f"Something went wrong: {e}"}
        return self._send(200, json.dumps(out, default=str), "application/json")


_ICON = None


def _icon() -> bytes:
    global _ICON
    if _ICON is None:
        import io
        from PIL import Image
        try:
            im = Image.open(HERE / "app.ico")
            im = im.convert("RGBA").resize((180, 180))
        except Exception:
            im = Image.new("RGBA", (180, 180), (11, 42, 87, 255))
        bg = Image.new("RGBA", (180, 180), (11, 42, 87, 255))
        bg.alpha_composite(im)
        b = io.BytesIO()
        bg.convert("RGB").save(b, "PNG")
        _ICON = b.getvalue()
    return _ICON


_GONE = """<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Accelerator</title></head><body style="font-family:-apple-system,Segoe UI,sans-serif;padding:28px;color:#0B2A57">
<h2>This phone isn't connected</h2><p>On your computer, open Listing Accelerator → Integrations →
<b>Accelerator on your phone</b> → <b>Connect a phone</b>, and scan the new code.</p></body></html>"""
