"""
netfix.py -- downloads trust what Windows trusts.

Company networks often check secure connections with their own certificate,
which Windows trusts but a freshly installed Python doesn't, so downloads
fail with "CERTIFICATE_VERIFY_FAILED". pip gets around this by asking Windows
itself (the "truststore" library); this makes the rest of the program do the
same. Nothing is turned off -- connections are still fully checked.
"""
_done = False


def fix() -> bool:
    global _done
    if _done:
        return True
    ts = None
    try:
        import truststore as ts            # if it's installed on its own
    except Exception:
        try:
            from pip._vendor import truststore as ts   # the copy pip carries
        except Exception:
            ts = None
    if ts is None:
        return False
    try:
        ts.inject_into_ssl()
        _done = True
    except Exception:
        return False
    return True
