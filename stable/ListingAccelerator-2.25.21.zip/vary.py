"""
vary.py -- so five salespeople at one store posting the same car don't post
the same ad.

Every ad is written the same way, then given its own look for the salesperson
who posts it: the emojis are swapped for others that mean the same thing, the
feature lines inside each section are put in a different order, and the
title's emojis change. Nothing is added or removed -- every fact, price and
feature stays exactly as written.

It is steady: the same salesperson gets the same look for the same car every
run, so a re-run or a price drop doesn't rewrite an ad he already posted.
Jeff's own copy (the owner key) keeps the original look.
"""
from __future__ import annotations

import hashlib
import random

# Each line: the emoji the writer uses, then others that say the same thing.
SAME = [
    ["\U0001F525", "⭐", "\U0001F4A5", "✨", "\U0001F31F", "\U0001F3C1"],   # title / headline
    ["✅", "✔️", "☑️", "\U0001F449", "\U0001F538", "\U0001F7E2"],          # highlights
    ["✨", "\U0001F31F", "⭐", "\U0001F4AB"],
    ["\U0001F539", "\U0001F538", "▪️", "➡️", "✔️"],                        # why-buy bullets
    ["\U0001F3A8", "\U0001F58C️", "\U0001F308"],                           # color
    ["\U0001F4BA", "\U0001F6CB️", "\U0001FA91"],                           # seats / interior
    ["\U0001F451", "\U0001F6CB️", "\U0001F48E", "\U0001F3C6"],             # comfort header
    ["\U0001F4F6", "\U0001F4F1", "\U0001F4BB", "\U0001F50C"],              # tech header
    ["\U0001F6E1️", "\U0001F6A6", "\U0001F512", "\U0001F9BA"],              # safety header
    ["⚡", "\U0001F4AA", "\U0001F527"],                                     # capability header
    ["\U0001F48E", "\U0001F3C6", "\U0001F947"],                             # trim
    ["\U0001F4AF", "\U0001F64C", "\U0001F44D"],
    ["\U0001F91D", "\U0001F64B", "\U0001F4AC"],                             # why buy from
    ["\U0001F4A5", "\U0001F6A8", "\U0001F4E3", "⏰"],                        # closer
    ["\U0001F4DE", "☎️", "\U0001F4F2"],                                     # phone
    ["\U0001F3E2", "\U0001F3EC", "\U0001F5FA️"],                            # address
]

# Lines that start a section. Feature lines between two of these may be
# reordered; the header itself and contact lines never move.
_NEVER_MOVE = ("\U0001F4CD", "\U0001F3E2", "\U0001F464", "\U0001F4DE", "At ",
               "•", "[[")


def _seed(stock: str) -> int | None:
    try:
        import keycheck
        if keycheck.status().get("role") == "owner":
            return None                  # Jeff's copy: the original look
    except Exception:
        pass
    try:
        import config
        who = f"{getattr(config, 'SELLER_NAME', '')}|{getattr(config, 'DEALER_PHONE', '')}"
    except Exception:
        who = ""
    if not who.strip("|"):
        return None
    h = hashlib.sha256(f"{who}|{str(stock).upper()}".encode("utf-8")).digest()
    return int.from_bytes(h[:8], "big")


def _swaps(rng: random.Random) -> dict[str, str]:
    out = {}
    for group in SAME:
        head = group[0]
        if head in out:
            continue
        out[head] = rng.choice(group)
    return out


def _swap(text: str, table: dict[str, str]) -> str:
    # one pass, longest first, so an emoji isn't swapped twice
    keys = sorted(table, key=len, reverse=True)
    out, i = [], 0
    while i < len(text):
        for k in keys:
            if text.startswith(k, i):
                out.append(table[k])
                i += len(k)
                break
        else:
            out.append(text[i])
            i += 1
    return "".join(out)


def _reorder(lines: list[str], rng: random.Random) -> list[str]:
    """Shuffle runs of plain feature lines; headers, blanks, bullets and
    contact lines stay put (and a bullet stays under the line above it)."""
    out, run = [], []

    def flush():
        if len(run) > 2:
            rng.shuffle(run)
        out.extend(run)
        run.clear()

    for i, ln in enumerate(lines):
        nxt = lines[i + 1] if i + 1 < len(lines) else ""
        movable = (ln.strip() and " – " in ln and not ln.startswith(_NEVER_MOVE)
                   and not nxt.startswith("•"))
        if movable:
            run.append(ln)
        else:
            flush()
            out.append(ln)
    flush()
    return out


def ad(text: str, title: str, stock: str) -> tuple[str, str]:
    seed = _seed(stock)
    if seed is None:
        return text, title
    rng = random.Random(seed)
    table = _swaps(rng)
    lines = _reorder(text.split("\n"), rng)
    return _swap("\n".join(lines), table), _swap(title, table)
