"""
pricecheck.py -- a price that can't be the car's price never reaches an ad.

Some sites print a discount ("Save $4,126") or a payment in the price box,
and it gets read as the price: a 2024 RAM at $4,126. When the read price is
far under the car's own listed price, the listed price is used instead (and
the log names the cars so they can be checked). A tiny price with nothing to
compare it to is held back as "no price yet".
"""
from __future__ import annotations


def tidy(text):
    # Stray quote marks some sites leave in names, e.g. a cargo van whose
    # trim reads   rwd 2500 155 followed by three quote marks.
    if not isinstance(text, str) or '"' not in text:
        return text
    t = text.replace('""', '"')
    import re
    t = re.sub(r'(^|\s)"(?=\w)', r"\1", t)          # an opening quote before a word
    t = re.sub(r'(?<=[A-Za-z])"(\s|$)', r"\1", t)    # a closing quote after letters
    t = re.sub(r'\s+', " ", t).strip().strip('"').strip()
    return t


def fix(records: list[dict]) -> list[str]:
    fixed = []
    for r in records:
        for k in ("model", "trim", "name", "title", "body_style"):
            if k in r:
                r[k] = tidy(r[k])
        try:
            fp = int(r.get("final_price") or 0)
            rp = int(r.get("retail_price") or 0)
        except (TypeError, ValueError):
            continue
        if fp and rp >= 3000 and fp < rp * 0.6:
            r["price_read_as"] = fp
            r["final_price"] = rp
            fixed.append(str(r.get("stock", "?")))
        elif fp and fp < 1000 and not rp:
            r["price_read_as"] = fp
            r["final_price"] = None
            fixed.append(str(r.get("stock", "?")))
    return fixed


def report(fixed: list[str]) -> None:
    if fixed:
        print(f"  {len(fixed)} price(s) on the website looked like a discount or "
              f"payment, not the car's price -- used the car's listed price "
              f"instead. Check these on the website: {', '.join(fixed[:12])}"
              + (" ..." if len(fixed) > 12 else ""))
