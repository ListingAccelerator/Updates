"""
keycheck.py -- the key that turns the program on.

A key is made only by Jeff's Key maker (a private GitHub workflow that holds
the signing secret). It carries who it is for and when it ends, signed with
Ed25519, so:

  * changing one letter breaks it -- nobody can give themselves more days,
    a higher level, or someone else's team;
  * it is checked right here, with the internet off;
  * the program remembers the latest date it has seen, so setting the
    computer's clock back does not buy more days.

Key text:  LA1.<payload, base64url>.<signature, base64url>
Payload:   {"v":1,"k":7,"n":"Mike Smith","e":"mike@...","l":"Elite",
            "r":"salesperson","t":"Moses Teays Valley","s":"2026-11-01",
            "x":"2026-12-01"}        x = "" means it never ends.

When a key runs out the program goes read-only: everything already made can
be opened, looked up and exported; the morning run, new ads, Social posts,
videos and AI writing pause until a new key is entered. Nothing is deleted.
"""
from __future__ import annotations

import base64
import json
from datetime import date, datetime, timedelta
from pathlib import Path

HERE = Path(__file__).resolve().parent
KEY_FILE = HERE / "my key.txt"
STATE_FILE = HERE / "key state.json"

# The Key maker's public key (the matching secret lives only in GitHub).
PUBLIC_KEY_HEX = "c099487efe5f3b6fb04b3afcaf5bfea79baf25c3b2be94e380bcbdcc0bfca192"

LEVELS = ("Starter", "Pro", "Elite", "Dealer Team 5", "Dealer Team 10")
ROLES = ("salesperson", "manager", "owner")
REMIND_DAYS = 5

BUY_URL = "https://automotivesalesaccelerator.com"


# ------------------------------------------------------------------ reading
def _unb64(s: str) -> bytes:
    s = s.strip()
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def parse(text: str) -> dict:
    """The key's contents if the signature is good, else raise ValueError."""
    t = "".join(str(text or "").split())          # pasted with line breaks? fine
    parts = t.split(".")
    if len(parts) != 3 or parts[0] != "LA1":
        raise ValueError("That isn't a Listing Accelerator key. Copy the whole "
                         "key from the email -- it starts with LA1.")
    try:
        body, sig = _unb64(parts[1]), _unb64(parts[2])
    except Exception:
        raise ValueError("Part of the key is missing. Copy the whole key again.")
    import updater
    if (len(sig) != 64 or PUBLIC_KEY_HEX.startswith("__") or
            not updater.verify(bytes.fromhex(PUBLIC_KEY_HEX), b"LA1." + body, sig)):
        raise ValueError("This key doesn't check out. Copy it again from the "
                         "email, exactly as it was sent.")
    d = json.loads(body.decode("utf-8"))
    if d.get("v") != 1:
        raise ValueError("This key is for a newer version. Update the program first.")
    return d


def _today() -> date:
    """Today -- but never earlier than a day the program has already seen."""
    real = date.today()
    st = _state()
    seen = st.get("seen", "")
    try:
        seen_d = date.fromisoformat(seen) if seen else real
    except ValueError:
        seen_d = real
    use = max(real, seen_d)
    if use.isoformat() != seen:
        st["seen"] = use.isoformat()
        _save_state(st)
    return use


def _state() -> dict:
    try:
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_state(d: dict) -> None:
    try:
        STATE_FILE.write_text(json.dumps(d, indent=1), encoding="utf-8")
    except Exception:
        pass


def _nice(d: date) -> str:
    return d.strftime("%b %d, %Y").replace(" 0", " ")


# ------------------------------------------------------------------ status
def status() -> dict:
    """What the window shows and what the program allows."""
    out = {"has_key": False, "ok": False, "read_only": True, "name": "",
           "level": "", "role": "", "team": "", "number": 0, "ends": "",
           "days_left": None, "remind": False, "never_ends": False,
           "message": "", "buy_url": BUY_URL}
    try:
        text = KEY_FILE.read_text(encoding="utf-8")
    except Exception:
        out["message"] = "Enter your key to turn the program on."
        return out
    try:
        k = parse(text)
    except ValueError as e:
        out["message"] = str(e)
        return out
    out.update(has_key=True, name=k.get("n", ""), level=k.get("l", ""),
               role=k.get("r", "salesperson"), team=k.get("t", ""),
               number=k.get("k", 0))
    end = k.get("x") or ""
    if not end:
        out.update(ok=True, read_only=False, never_ends=True)
        return out
    end_d = date.fromisoformat(end)
    today = _today()
    left = (end_d - today).days
    out["ends"] = _nice(end_d)
    out["days_left"] = max(left, 0)
    if left <= 0:
        out["message"] = (f"Your key ended {_nice(end_d)}. Everything you made "
                          "is still here -- enter a new key and it all turns back on.")
        return out
    out.update(ok=True, read_only=False)
    out["remind"] = left <= REMIND_DAYS and _state().get("snooze") != today.isoformat()
    return out


def enter(text: str) -> dict:
    try:
        k = parse(text)
    except ValueError as e:
        return {"ok": False, "message": str(e)}
    end = k.get("x") or ""
    if end and date.fromisoformat(end) <= _today():
        return {"ok": False, "message": f"This key ended {_nice(date.fromisoformat(end))}. "
                "Ask for a new one at support@automotivesalesaccelerator.com."}
    t = "".join(str(text).split())
    if KEY_FILE.exists():                       # keep the old one, just in case
        try:
            (HERE / "my key (before).txt").write_text(
                KEY_FILE.read_text(encoding="utf-8"), encoding="utf-8")
        except Exception:
            pass
    KEY_FILE.write_text(t + "\n", encoding="utf-8")
    st = status()
    who = (k.get("n") or "").split(" ")[0]
    return {"ok": True, "status": st,
            "message": f"Welcome, {who}. Your key is good." if who else "Your key is good."}


def snooze() -> None:
    st = _state()
    st["snooze"] = _today().isoformat()
    _save_state(st)


def allowed() -> bool:
    return not status()["read_only"]


def is_manager() -> bool:
    s = status()
    return s["ok"] and s["role"] in ("manager", "owner")


PAUSED = ("The beta key has ended, so this is paused. Everything you made is "
          "still here. Enter a new key to turn it back on.")
NO_KEY = "Enter your key first — click \"Enter your key\" at the top right."


def blocked_message() -> str:
    s = status()
    return NO_KEY if not s["has_key"] else PAUSED
