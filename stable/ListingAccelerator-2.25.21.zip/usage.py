"""
usage.py -- the beta's daily count, so Jeff can see what is working.

COUNTS ONLY. What is sent once a day: the key number and the name on the key,
the program version, and how many times each thing was done that day (runs,
runs that stopped with a problem, cars recorded as posted, reply suggestions,
videos, Social pictures, backgrounds, customers saved). Never a customer
name, a message, a phone number, a price or a stock number.

Where it goes is read from the update channel (stable/counts.json), so the
address can be set or turned off without a new version. No address there,
or no internet: nothing is sent, and the counts wait for the next day.
Owner copies (Jeff's own) never send.
"""
from __future__ import annotations

import json
import threading
import urllib.request
from datetime import date
from pathlib import Path

HERE = Path(__file__).resolve().parent
FILE = HERE / "usage counts.json"
_LOCK = threading.Lock()

KINDS = ("runs", "run_problems", "posted", "replies", "videos", "social",
         "backgrounds", "customers_saved", "opened",
         "answers", "searches", "fills", "quotes")


def _load() -> dict:
    try:
        return json.loads(FILE.read_text(encoding="utf-8"))
    except Exception:
        return {"days": {}, "sent": []}


def _save(d: dict) -> None:
    try:
        FILE.write_text(json.dumps(d, indent=1), encoding="utf-8")
    except Exception:
        pass


def bump(kind: str, n: int = 1) -> None:
    if kind not in KINDS or n <= 0:
        return
    with _LOCK:
        d = _load()
        day = d["days"].setdefault(date.today().isoformat(), {})
        day[kind] = day.get(kind, 0) + int(n)
        _save(d)


def _address() -> str:
    try:
        import updater
        raw = updater._get(updater.UPDATE_BASE.rstrip("/") + "/counts.json", timeout=15)
        return str(json.loads(raw.decode("utf-8")).get("url", "")).strip()
    except Exception:
        return ""


def send_waiting() -> int:
    """Send every finished day not sent yet (today waits until tomorrow)."""
    try:
        import keycheck
        k = keycheck.status()
    except Exception:
        return 0
    if not k.get("has_key") or k.get("role") == "owner":
        return 0
    with _LOCK:
        d = _load()
    today = date.today().isoformat()
    todo = sorted(x for x in d["days"] if x < today and x not in d.get("sent", []))
    if not todo:
        return 0
    url = _address()
    if not url.startswith("https://"):
        return 0
    try:
        import updater
        ver = updater.current_version()
    except Exception:
        ver = ""
    sent = 0
    for day in todo:
        row = {"day": day, "key": k.get("number", 0), "name": k.get("name", ""),
               "team": k.get("team", ""), "role": k.get("role", ""),
               "level": k.get("level", ""), "version": ver}
        for kind in KINDS:
            row[kind] = int(d["days"][day].get(kind, 0))
        try:
            req = urllib.request.Request(url, data=json.dumps(row).encode("utf-8"),
                                         headers={"Content-Type": "application/json"})
            urllib.request.urlopen(req, timeout=20).read()
        except Exception:
            break
        sent += 1
        with _LOCK:
            d2 = _load()
            d2.setdefault("sent", []).append(day)
            # keep 60 days of history at most
            for old in sorted(d2["days"])[:-60]:
                d2["days"].pop(old, None)
            d2["sent"] = [x for x in d2["sent"] if x in d2["days"]]
            _save(d2)
    return sent


def what_is_sent() -> str:
    return ("Once a day the program sends a count only: how many runs, posts, "
            "replies, videos and Social pictures you made. Never a customer "
            "name, a message, a phone number or a price.")
