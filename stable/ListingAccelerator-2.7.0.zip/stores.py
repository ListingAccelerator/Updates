"""
stores.py -- every store (rooftop) in one program.

    program\\stores\\<store>\\settings.json   that store's setup and choices
    program\\stores\\<store>\\out\\            its ads, posting record, reports
    program\\stores\\<store>\\Photo Drop\\     its photos (unless it kept them
                                            in an older copy -- see import_copy)

A copy with no stores folder is a single store, the way the program has
always worked: settings.json, out\\ and Photo Drop\\ sit next to app.py.
"""
from __future__ import annotations

import json
import os
import re
import shutil
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
STORES = HERE / "stores"
HERE_KEY = "_here"            # the single-store layout, used before any import


def slug(name: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", str(name).lower()).strip("-")
    return s[:48] or "store"


def _read(p: Path) -> dict:
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def multi() -> bool:
    """Has this copy been set up for several stores?"""
    return any(not f.parent.name.startswith("_")
               for f in STORES.glob("*/settings.json"))


def store_dir(key: str) -> Path:
    return HERE if key == HERE_KEY else STORES / key


def all_stores() -> list[dict]:
    """[{key, dir, name, short, settings}] in the order he set them up."""
    out = []
    if multi():
        dirs = [d for d in STORES.iterdir()
                if d.is_dir() and not d.name.startswith("_")
                and (d / "settings.json").exists()]
        order = _read(STORES / "order.json").get("order") or []
        dirs.sort(key=lambda d: (order.index(d.name) if d.name in order
                                 else len(order), d.name))
        for d in dirs:
            st = _read(d / "settings.json")
            out.append({"key": d.name, "dir": str(d),
                        "name": st.get("store_name") or d.name,
                        "settings": st})
    elif (HERE / "settings.json").exists():
        st = _read(HERE / "settings.json")
        out.append({"key": HERE_KEY, "dir": str(HERE),
                    "name": st.get("store_name") or "My store",
                    "settings": st})
    return out


def _remember_order(key: str):
    f = STORES / "order.json"
    order = _read(f).get("order") or []
    if key not in order:
        order.append(key)
    f.write_text(json.dumps({"order": order}, indent=1), encoding="utf-8")


def new_store_dir(name: str) -> Path:
    STORES.mkdir(parents=True, exist_ok=True)
    base = slug(name)
    key, n = base, 2
    while (STORES / key).exists():
        key, n = f"{base}-{n}", n + 1
    d = STORES / key
    d.mkdir(parents=True)
    _remember_order(key)
    return d


def find_copy(folder: str | Path) -> Path | None:
    """
    Where the settings live in an older copy he points at. He may pick the
    copy's own folder ("Listing Accelerator - Teays Valley") or the program
    folder inside it -- either is fine.
    """
    f = Path(folder).expanduser().resolve()
    for cand in (f, f / "program"):
        if (cand / "settings.json").exists():
            return cand
    return None


def import_copy(folder: str | Path) -> dict:
    """
    Bring a store in from an older single-store copy.

    COPIES its settings and out\\ folder (ads, posting record, history) --
    the old copy is left exactly as it was and still works. The photos are
    NOT copied: the store keeps using the old copy's Photo Drop where it is,
    which saves gigabytes and keeps every folder he already knows.
    """
    src = find_copy(folder)
    if not src:
        return {"ok": False, "message": "That folder doesn't have a store set "
                "up in it. Pick the folder of the old program (the one with "
                "\"Start Listing Accelerator\" in it)."}
    st = _read(src / "settings.json")
    name = st.get("store_name") or src.parent.name
    for s in all_stores():
        if s["key"] != HERE_KEY and \
                (s["settings"].get("inventory_url") or "").strip().lower() == \
                (st.get("inventory_url") or "").strip().lower() and \
                st.get("inventory_url"):
            return {"ok": False, "message": f"{s['name']} is already in the "
                    f"program -- same website."}

    dest = new_store_dir(name)
    try:
        if (src / "out").exists():
            shutil.copytree(src / "out", dest / "out",
                            ignore=shutil.ignore_patterns("xhr", "debug_*"))
        photos = st.get("photo_drop") or str(src / "Photo Drop")
        st["photo_drop"] = photos
        st["imported_from"] = str(src)
        st["imported_on"] = datetime.now().strftime("%Y-%m-%d %H:%M")
        (dest / "settings.json").write_text(json.dumps(st, indent=2),
                                            encoding="utf-8")
    except Exception as e:
        shutil.rmtree(dest, ignore_errors=True)
        return {"ok": False, "message": f"Couldn't bring that store in: {e}"}
    return {"ok": True, "key": dest.name, "name": name,
            "message": f"{name} is in. Its photos stay where they are."}


def adopt_here() -> dict | None:
    """
    The first time a single-store copy becomes several stores, the store
    that was already here moves in as the first of them -- by import, so
    nothing next to app.py is touched.
    """
    if multi() or not (HERE / "settings.json").exists():
        return None
    return import_copy(HERE)


def remove(key: str) -> dict:
    """
    Take a store out of the program with everything in it -- its settings,
    ads, posting record, customers' notes for it, and its photos -- into the
    Windows Recycle Bin, so a mistake can still be put back from there.
    A photo folder kept somewhere else (shared with another store) is left.
    """
    d = STORES / key
    if not d.is_dir() or key.startswith("_"):
        return {"ok": False, "message": "No such store."}
    import track
    elsewhere = ""
    try:
        s = _read(d / "settings.json")
        pd = s.get("photo_drop") or s.get("PHOTO_DROP") or ""
        if pd and Path(pd).exists() and d not in Path(pd).resolve().parents:
            elsewhere = str(pd)
    except Exception:
        pass
    if not track._to_recycle_bin(d):
        return {"ok": False, "message": "Couldn't remove it -- close any of its files or "
                "folders that are open (and let OneDrive finish syncing), then try again."}
    try:
        f = STORES / "order.json"
        o = _read(f)
        if key in (o.get("order") or []):
            o["order"] = [k for k in o["order"] if k != key]
            f.write_text(json.dumps(o, indent=1), encoding="utf-8")
    except Exception:
        pass
    msg = "Removed, with all its files -- they're in the Recycle Bin if you ever need them back."
    if elsewhere:
        msg += f" Its photos folder is somewhere else ({elsewhere}) and was left alone."
    return {"ok": True, "message": msg}


def environ_for(key: str) -> dict:
    env = dict(os.environ)
    if key == HERE_KEY:
        env.pop("LA_STORE_DIR", None)
    else:
        env["LA_STORE_DIR"] = str(store_dir(key))
    return env
