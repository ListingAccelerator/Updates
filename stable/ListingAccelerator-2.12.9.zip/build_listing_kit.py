"""
build_listing_kit.py -- paste-ready listing content for manual Marketplace posting.

Posting by hand is the part nobody can automate for you without risking the
account. This makes the hand-posting fast: every Marketplace field is
pre-filled and one click from your clipboard, and each vehicle points at its
Photo Drop folder so you know exactly which photos to attach.

Outputs (in out/listing_kit/):
    post_helper.html   open in a browser; click any field to copy it
    <STOCK>.txt        same content as plain text, one file per vehicle
    index.csv          one row per vehicle for tracking what you have posted

Usage:
    python build_listing_kit.py
"""
from __future__ import annotations

import argparse
import csv
import html
import json
import sys

import config
from build_fb_catalog import MODEL_TO_BODY, build_description


# Marketplace's own labels, so you can paste straight into its dropdowns.
BODY_DISPLAY = {
    "SUV": "SUV", "TRUCK": "Truck", "VAN": "Van", "MINIVAN": "Minivan",
    "SEDAN": "Sedan", "COUPE": "Coupe", "HATCHBACK": "Hatchback",
    "CONVERTIBLE": "Convertible", "WAGON": "Wagon",
}


def vehicle_type(body: str) -> str:
    if body == "TRUCK":
        return "Truck"
    if body in ("VAN", "MINIVAN"):
        return "Van"
    if body == "MOTORCYCLE":
        return "Motorcycle"
    return "Car"


def seller_first_name() -> str:
    """
    Your first name for the first-person copy.

    Set SELLER_FIRST_NAME in config.py to control it. If it isn't there we work
    it out from SELLER_NAME ("Jeff Turley (JT)" -> "Jeff") so this never stops
    the run over a missing setting.
    """
    name = getattr(config, "SELLER_FIRST_NAME", "")
    if name:
        return name
    return (getattr(config, "SELLER_NAME", "") or "").split()[0] or "I"


def contact_verb() -> str:
    """
    The verb the closing line is built on: "Call or text me if you want to..."

    Deliberately NOT config.SELLER_CONTACT -- that one is a label the dealer ads
    print as "Call or Text Me Directly: 704-998-7280", and dropping it into a
    sentence gives you "Call or Text Me Directly me and I'll get you the
    details." Separate setting, separate job.
    """
    return getattr(config, "SELLER_CONTACT_VERB", "call or text")


# Marketplace's own dropdown wording, so what you copy matches what you pick.
def fuel_display(raw: str) -> str:
    t = (raw or "").lower()
    if not t:
        return ""
    if "plug" in t or "phev" in t:
        return "Plug-in hybrid"
    if "hybrid" in t:
        return "Hybrid"
    if "electric" in t or t == "ev":
        return "Electric"
    if "diesel" in t:
        return "Diesel"
    if "flex" in t or "e85" in t:
        return "Flex"
    if "gas" in t or "petrol" in t or "unleaded" in t:
        return "Gasoline"
    return "Other"


def transmission_display(raw: str) -> str:
    t = (raw or "").lower()
    if not t:
        return ""
    # CVT, DCT, dual-clutch and every n-speed auto are "Automatic" to Facebook.
    if "manual" in t and "automanual" not in t:
        return "Manual transmission"
    return "Automatic transmission"


SPORTY = {"Corvette", "Camaro", "Mustang", "Challenger", "Charger", "BRZ",
          "WRX", "SQ5", "SQ5 Sportback", "Q60", "Supra", "GR86"}

THREE_ROW = {"Grand Cherokee L", "Highlander", "Highlander Hybrid", "Pilot",
             "Telluride", "Palisade", "Traverse", "Suburban", "Tahoe", "Yukon",
             "Yukon XL", "Expedition", "Expedition Max", "Pathfinder",
             "Ascent", "CX-90", "Durango", "Wagoneer", "Grand Wagoneer",
             "QX80", "QX60", "Sequoia", "Atlas", "Acadia", "Escalade",
             "Escalade ESV", "Navigator", "Navigator L", "Aviator", "MDX",
             "Carnival", "Odyssey", "Sienna", "Pacifica", "Pacifica Hybrid",
             "Grand Caravan", "Voyager", "TX 350"}


def _angle(rec: dict, body: str, pick) -> str:
    """One line about who this particular vehicle suits."""
    model = rec.get("model", "")
    trim = (rec.get("trim") or "").lower()
    miles = rec.get("mileage") or 0
    price = rec.get("final_price") or rec.get("moses_price") or 0
    feats = " ".join(rec.get("features") or []).lower()
    awd = "4wd" in feats or "awd" in feats

    if model in SPORTY or any(k in trim for k in ("srt", "rubicon", "gt-line",
                                                  "pro-4x", "z71", "trail boss",
                                                  "ecoboost premium")):
        return pick([
            "This one's just fun to drive.",
            "If you've been holding out for the right one, this is it.",
            "A lot of car for the money on this one.",
        ])
    if model in THREE_ROW or "3rd row" in feats:
        return pick([
            "Third row, so it actually works for a full family.",
            "Good family hauler — third row and room for everybody.",
            "If you need the third row, this one has it.",
        ])
    if body in ("TRUCK", "VAN"):
        return pick([
            "Set up to work, not just haul kids around.",
            "If you need something that earns its keep, this'll do it.",
            "Good work vehicle that still cleans up nice.",
        ])
    if miles and miles < 20000:
        return pick([
            "Basically new without the new-car price.",
            "Still feels new at a used-car number.",
            "Barely broken in.",
        ])
    if (miles and miles > 110000) or (price and price < 15000):
        return pick([
            "Higher miles and priced for it — solid transportation if you "
            "want to keep the payment down.",
            "If you're watching the payment, this is a lot of vehicle for "
            "the money.",
            "Good honest miles, priced to move.",
        ])
    if awd:
        return pick([
            "All-wheel drive, which matters around here come January.",
            "Four-wheel drive — handy on our hills when the weather turns.",
            "AWD, so our winters aren't a problem.",
        ])
    if body in ("SEDAN", "HATCHBACK"):
        return pick([
            "Easy on gas for the daily commute.",
            "Good daily driver that won't nickel you to death.",
            "Solid commuter car.",
        ])
    return pick([
        "Clean one, worth a look.",
        "Nice vehicle, won't sit long.",
        "Good shape inside and out.",
    ])


def equipment_lines(rec: dict, limit: int = 6) -> list[str]:
    """
    This car's equipment, one line each, written as a benefit.

    Only what the dealership's own page lists for this vehicle. Nothing is
    inferred from the trim badge -- if the site does not say it has heated
    seats, the ad does not say it either.

    Safety and capability come first: those are what people actually buy on
    in this part of the country, and a 4WD line does more work than a USB
    port. Within a group the site's own order is kept.
    """
    try:
        from build_jt_listings import FEATURES, match_features
    except Exception:
        return []

    feats = [f.strip() for f in (rec.get("features") or []) if f and f.strip()]
    if not feats:
        return []

    try:
        grouped = match_features(feats)
    except Exception:
        return []

    order = ("capability", "safety", "comfort", "tech")
    style = getattr(config, "EMOJI_STYLE", "light")

    # Take one from each group in turn rather than draining them in order.
    # Straight priority order lets five comfort items push CarPlay off the
    # end, and a buyer who wants CarPlay wants it badly.
    buckets = [list(grouped.get(s, [])) for s in order]
    interleaved = []
    while any(buckets):
        for b in buckets:
            if b:
                interleaved.append(b.pop(0))

    out, seen = [], set()
    for line in interleaved:
        # match_features hands back "<emoji> <benefit>". At the light setting
        # the per-feature emoji are dropped -- six of them in a row is the
        # bulk-dealer look, which is the whole thing we are avoiding on a
        # personal account.
        text = line
        if style != "heavy":
            parts = line.split(" ", 1)
            if len(parts) == 2 and not parts[0][:1].isalnum():
                text = parts[1]
        key = text.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(text)
        if len(out) >= limit:
            break
    return out


def personal_description(rec: dict) -> str:
    """
    Copy for posting from your OWN Marketplace account.

    Three things make this read like a person instead of a feed:
      * your name is in it, and it says you sell at the store. That disclosure
        is deliberate -- Meta looks for dealer inventory posted as though it
        were private-party, and a listing that says what it is stays up.
      * the opening, the angle and the closer all rotate, so 88 listings don't
        share one sentence.
      * the angle depends on the actual vehicle: a third row gets a family
        line, a truck gets a work line, 4WD gets a West Virginia winter line.

    Variation is seeded on the stock number, so a given vehicle always gets
    the same copy. Re-running does not reshuffle what you already posted.
    """
    year = rec.get("year", "")
    name = " ".join(x for x in (rec.get("make"), rec.get("model"),
                                rec.get("trim")) if x)
    veh = f"{year} {name}".strip()
    miles = f"{rec['mileage']:,}" if rec.get("mileage") else ""
    price = rec.get("final_price") or rec.get("moses_price")
    pstr = f"${price:,}" if price else ""
    body = MODEL_TO_BODY.get(rec.get("model", ""), "")
    stock = rec.get("stock", "")

    seed = sum(ord(c) for c in stock) if stock else 0
    def pick(opts): return opts[seed % len(opts)]

    opener = pick([
        f"{veh} — {miles} miles, {pstr}.",
        f"Got a {veh} here. {miles} miles, {pstr}.",
        f"{pstr}, {veh} with {miles} miles.",
        f"{veh}, {miles} miles. Asking {pstr}.",
        f"Here's a {veh} — {pstr}, {miles} miles.",
    ])

    # The equipment, written as what it does for the buyer rather than as a
    # spec list, one per line. Everything here comes off this car's own page
    # on the dealership website -- nothing is assumed from the trim name.
    feat_lines = equipment_lines(rec, limit=6)
    featline = ""          # kept for the no-equipment case below

    me = seller_first_name()
    who = pick([
        f"I'm {me}, I sell at {config.STORE_SHORT}.",
        f"I'm {me} — one of the sales consultants at {config.STORE_SHORT}.",
        f"{me} here, I'm over at {config.STORE_SHORT}.",
    ])

    # Your cell goes in the body. You work out of Teays Valley but sell off any
    # Moses lot, so a buyer looking at a Saint Albans car needs to reach YOU --
    # not that store's switchboard, where the lead goes to whoever answers.
    verb = contact_verb()
    phone = getattr(config, "DEALER_PHONE", "").strip()
    at = f" at {phone}" if phone else ""
    closer = pick([
        f"{verb.capitalize()} me{at} and I'll get you the details or set up a drive.",
        f"{verb.capitalize()} me{at} if you want to come take a look at it.",
        f"{verb.capitalize()} me{at} — happy to answer questions or get you "
        "behind the wheel.",
    ])

    style = getattr(config, "EMOJI_STYLE", "light")
    if style == "heavy":
        # Scannable, but this is the look buyers associate with bulk dealer
        # and spam listings -- the opposite of the personal read you want
        # from a personal account.
        if pstr:
            opener = f"\U0001F525 {opener}"
        who = f"\U0001F4CD {who}"
        closer = f"\U0001F4F1 {closer}"
    elif style == "light":
        closer = f"\U0001F4F1 {closer}"

    # Laid out as lines, not one paragraph. On a phone a wall of text gets
    # scrolled past; a short opener with the equipment under it gets read.
    out = [opener]

    angle = _angle(rec, body, pick)
    if angle:
        out.append(angle)

    if feat_lines:
        out.append("")
        heading = pick([
            "What's on it:",
            "Here's what it's got:",
            "Equipment on this one:",
        ])
        out.append(("✅ " if style != "none" else "") + heading)
        for f in feat_lines:
            out.append(("• " if style != "heavy" else "") + f)
    elif featline:
        out.append(featline)

    out.append("")
    out.append(f"{who} {closer}")
    if stock:
        out.append(f"Stock #{stock}.")
    return "\n".join(p for p in out if p is not None).strip()


def full_ad(rec: dict) -> str:
    """
    The full sectioned ad -- highlights, luxury, tech, safety, capability,
    why buy here, location and contact.

    This is the one that goes out. The Posting helper and the one-file-in-
    Notepad version both pull it from here, so the ad you read is always the
    ad you post. Written in build_jt_listings.build(); kept behind this
    wrapper so there is only ever one place to change it.
    """
    try:
        from build_jt_listings import build
        ad, _gaps, _title = build(rec)
        if ad and ad.strip():
            return ad.strip()
    except Exception:
        pass
    return personal_description(rec)


def marketplace_title(rec: dict) -> str:
    """The listing title, in your style -- the same one build() produces."""
    try:
        from build_jt_listings import build
        _ad, _gaps, title = build(rec)
        if title and title.strip():
            return title.strip()
    except Exception:
        pass
    t = f"{rec.get('year','')} {rec.get('make','')} {rec.get('model','')}"
    if rec.get("trim"):
        t += f" {rec['trim']}"
    return t.strip()


# Facebook's own colour list. A dealer's paint name ("Patriot Blue Pearlcoat")
# becomes the nearest one ("Blue"); anything unclear is left for him to pick.
FB_COLORS = [("charcoal", "Charcoal"), ("off white", "Off white"), ("off-white", "Off white"),
             ("burgundy", "Burgundy"), ("maroon", "Burgundy"), ("turquoise", "Turquoise"),
             ("teal", "Turquoise"), ("beige", "Beige"), ("tan", "Tan"), ("gold", "Gold"),
             ("champagne", "Gold"), ("silver", "Silver"), ("gray", "Gray"), ("grey", "Gray"),
             ("granite", "Gray"), ("graphite", "Gray"), ("gunmetal", "Gray"), ("gun ", "Gray"),
             ("steel", "Gray"), ("magnetic", "Gray"), ("slate", "Gray"), ("boulder", "Gray"),
             ("platinum", "Silver"), ("sterling", "Silver"), ("lunar", "Silver"), ("titanium", "Silver"),
             ("obsidian", "Black"), ("onyx", "Black"), ("midnight", "Black"), ("jet", "Black"),
             ("crimson", "Red"), ("scarlet", "Red"), ("cherry", "Red"), ("copper", "Brown"), ("black", "Black"),
             ("ebony", "Black"), ("ivory", "Off white"),
             ("cream", "Off white"), ("blue", "Blue"), ("navy", "Blue"), ("red", "Red"), ("ruby", "Red"),
             ("green", "Green"), ("brown", "Brown"), ("bronze", "Brown"), ("orange", "Orange"),
             ("yellow", "Yellow"), ("purple", "Purple"), ("pink", "Pink"), ("white", "White")]


def fb_color(raw: str) -> str:
    t = (raw or "").lower()
    for word, name in FB_COLORS:
        if word in t:
            return name
    return ""


def fb_model(rec: dict) -> str:
    """Facebook builds the listing title from Year + Make + Model, so the
    Model box carries the rest of your title -- the trim, the flames and the
    stock number -- exactly as the Posting helper's Title has it."""
    import re
    title = marketplace_title(rec)
    year, make = str(rec.get("year") or ""), str(rec.get("make") or "")
    rest = re.sub(r"^\s*" + re.escape(year) + r"\s+" + re.escape(make) + r"\s*", "", title, flags=re.I) \
        if year and make else title
    if not rest or rest == title:
        rest = f"{rec.get('model','')} {rec.get('trim','')}".strip()
    stock = str(rec.get("stock") or "")
    if stock and stock.lower() not in rest.lower():
        rest = f"{rest} {stock}"
    return rest.strip()


def fb_fields(rec: dict, personal: bool = False) -> dict:
    """What the Chrome helper types into Facebook's vehicle form."""
    import track
    body = MODEL_TO_BODY.get(rec.get("model", ""), "")
    vt = vehicle_type(body)
    miles = rec.get("mileage") or 0
    return {
        "vehicle_type": "Motorcycle" if vt == "Motorcycle" else "Car/Truck",
        "year": str(rec.get("year", "") or ""),
        "make": rec.get("make", "") or "",
        "model": fb_model(rec),
        "mileage": str(miles or ""),
        "price": str(track.post_price(rec) or ""),
        "body_style": BODY_DISPLAY.get(body, ""),
        "exterior_color": fb_color(rec.get("exterior_color", "")),
        "interior_color": fb_color(rec.get("interior_color", "")),
        "condition": "Excellent" if miles and miles < 40000 else "Good",
        "fuel": fuel_display(rec.get("fuel_type", "")),
        "transmission": transmission_display(rec.get("transmission", "")),
        "description": _no_blanks(full_ad(rec) if personal else build_description(rec)),
    }


def _no_blanks(text: str) -> str:
    """The [[fill this in]] reminders are for a person reading the ad; the
    helper types straight into Facebook, so leave those bits out."""
    out = []
    for line in (text or "").split("\n"):
        if "[[" in line:
            parts = [p for p in line.split(" | ") if "[[" not in p]
            if not parts:
                continue
            line = " | ".join(parts)
        out.append(line)
    return "\n".join(out)


def fields_for(rec: dict, personal: bool = False) -> list[tuple[str, str]]:
    body = MODEL_TO_BODY.get(rec.get("model", ""), "")
    price = rec.get("final_price") or rec.get("moses_price")
    title = marketplace_title(rec)
    return [
        ("Title", title.strip()),
        ("Vehicle type", vehicle_type(body)),
        ("Year", str(rec.get("year", ""))),
        ("Make", rec.get("make", "")),
        ("Model", f"{rec.get('model','')} {rec.get('trim','')}".strip()),
        ("Body style", BODY_DISPLAY.get(body, "")),
        ("Mileage", str(rec.get("mileage", ""))),
        ("Price", str(price) if price else ""),
        ("Condition", "Excellent" if (rec.get("mileage") or 0) < 40000 else "Good"),
        # Marketplace's vehicle form asks for these four. scrape_details.py
        # already pulls them off the VDP, so they may as well be one click.
        ("Exterior color", rec.get("exterior_color", "")),
        ("Interior color", rec.get("interior_color", "")),
        ("Transmission", transmission_display(rec.get("transmission", ""))),
        ("Fuel type", fuel_display(rec.get("fuel_type", ""))),
        # Deliberately NOT labelled as a Marketplace field. Putting the VIN
        # in Marketplace's own VIN box causes trouble with the listing, so
        # this is here for your own reference -- looking the car up, answering
        # a buyer who asks -- not for pasting into the form.
        ("VIN (do not put in Marketplace)", rec.get("vin", "")),
        ("Stock", rec.get("stock", "")),
        ("Description", full_ad(rec) if personal else build_description(rec)),
    ]


HTML_HEAD = """<!doctype html>
<meta charset="utf-8">
<title>Marketplace Posting Helper</title>
<style>
  :root {
    --bg:#f6f7f9; --card:#fff; --ink:#16191d; --muted:#667085;
    --line:#e4e7ec; --accent:#00305f; --ok:#0a7c42;
  }
  @media (prefers-color-scheme: dark) {
    :root { --bg:#14171a; --card:#1d2125; --ink:#e8eaed; --muted:#9aa4b2;
            --line:#2c3238; --accent:#7aa7d9; --ok:#4ade80; }
  }
  * { box-sizing:border-box }
  body { margin:0; background:var(--bg); color:var(--ink);
         font:15px/1.5 -apple-system,Segoe UI,Roboto,sans-serif; }
  header { padding:20px 16px; border-bottom:1px solid var(--line);
           background:var(--card); position:sticky; top:0; z-index:5 }
  h1 { margin:0 0 4px; font-size:19px; letter-spacing:-.01em }
  .sub { color:var(--muted); font-size:13px }
  #q { margin-top:12px; width:100%; max-width:420px; padding:9px 12px;
       border:1px solid var(--line); border-radius:8px;
       background:var(--bg); color:var(--ink); font-size:14px }
  main { padding:16px; display:grid; gap:14px;
         grid-template-columns:repeat(auto-fill,minmax(330px,1fr)) }
  .v { background:var(--card); border:1px solid var(--line);
       border-radius:10px; padding:14px }
  .v h2 { margin:0 0 2px; font-size:15px; font-weight:650 }
  .stock { color:var(--muted); font-size:12px; font-variant-numeric:tabular-nums }
  .folder { margin:9px 0 11px; font-size:12px; color:var(--muted);
            word-break:break-all; padding:7px 9px; background:var(--bg);
            border-radius:6px; border:1px solid var(--line) }
  .f { display:flex; gap:8px; align-items:baseline; padding:4px 0;
       border-top:1px solid var(--line) }
  .f:first-of-type { border-top:0 }
  .k { flex:0 0 94px; color:var(--muted); font-size:12px }
  .c { flex:1; text-align:left; cursor:pointer; background:none; border:0;
       color:var(--ink); font:inherit; font-size:13.5px; padding:2px 4px;
       border-radius:4px; }
  .c:hover { background:var(--bg); outline:1px solid var(--line) }
  .c.copied { color:var(--ok); font-weight:600 }
  .desc { white-space:pre-wrap; font-size:12.5px; line-height:1.45 }
  .hide { display:none }
  .warnbar { margin:12px 0 0; padding:10px 14px; border-radius:6px;
             background:#FDF6E7; border-left:3px solid #8A5A00;
             color:#5C4206; font-size:13.5px; line-height:1.5 }
  @media (prefers-color-scheme: dark) {
    .warnbar { background:#2A2317; border-left-color:#C08A1E; color:#E6CF9B }
  }
  /* the VIN row, so it reads as a caution rather than another field */
  .k.nofill { color:#8A5A00 }
  @media (prefers-color-scheme: dark) { .k.nofill { color:#C08A1E } }
</style>
<header>
  <h1>Marketplace Posting Helper</h1>
  <div class="sub">Click any value to copy it. __N__ vehicles &middot;
    photos are in each vehicle&rsquo;s Photo Drop folder.</div>
  <div class="warnbar">Leave Marketplace&rsquo;s <b>VIN</b> box empty. Filling
    it in causes trouble with the listing. The VIN is here for your own
    reference &mdash; looking a car up, or answering a buyer who asks.</div>
  <input id="q" placeholder="Filter by stock, make, model, year&hellip;">
</header>
<main id="list">
"""

HTML_FOOT = """</main>
<script>
  document.addEventListener('click', e => {
    const b = e.target.closest('.c');
    if (!b) return;
    navigator.clipboard.writeText(b.dataset.v || b.textContent).then(() => {
      b.classList.add('copied');
      setTimeout(() => b.classList.remove('copied'), 900);
    });
  });
  const q = document.getElementById('q');
  q.addEventListener('input', () => {
    const t = q.value.toLowerCase().trim();
    document.querySelectorAll('.v').forEach(v => {
      v.classList.toggle('hide', t && !v.dataset.s.includes(t));
    });
  });
</script>
"""


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--personal", action="store_true",
                    help="copy written for posting from your own Marketplace "
                         "account: shorter, first person, states that you sell "
                         "at the store")
    ap.add_argument("--max-price", type=int, default=None,
                    help="only build cards at or under this price "
                         f"(default: config.FOCUS_MAX_PRICE)")
    ap.add_argument("--all", action="store_true",
                    help="ignore the price ceiling and build the whole lot")
    args = ap.parse_args()
    personal = args.personal

    cap = 0 if args.all else (
        args.max_price if args.max_price is not None
        else getattr(config, "FOCUS_MAX_PRICE", 0) or 0
    )

    if not config.INVENTORY_JSON.exists():
        print(f"No scraped inventory at {config.INVENTORY_JSON}")
        print("Run: python scrape_inventory.py")
        return 1

    records = json.loads(config.INVENTORY_JSON.read_text(encoding="utf-8"))

    total = len(records)
    skipped_over = skipped_nopx = 0
    left_out = 0
    # Same rule as the ads: only the cars he works, plus anything he already
    # has posted. Joe Holland's helper held all 131 cars -- 101 of them new,
    # with no ads and no photos -- for the 30 he actually posts.
    use_focus = not args.all and args.max_price is None
    if use_focus:
        try:
            import track
            import whats_new
            f = track.focus()
            live = whats_new.live_listings()
            def keep(r):
                if str(r.get("stock", "")).strip().upper() in live:
                    return True
                if track.focus_is_on(f):
                    return track.in_focus(r, f)
                return not track.is_other_store(r)
            kept = [r for r in records if keep(r)]
            left_out = total - len(kept)
            records = kept
            cap = 0
        except Exception:
            use_focus = False
    if cap:
        kept = []
        for r in records:
            p = r.get("final_price") or r.get("moses_price") or 0
            if not p:
                skipped_nopx += 1
            elif p > cap:
                skipped_over += 1
            else:
                kept.append(r)
        records = kept

    if not records and use_focus:
        print("No vehicles in what you work to build.")
        print("Run with --all to build the whole lot.")
        return 1
    if not records:
        print(f"Nothing at or under ${cap:,} to build.")
        print("Run with --all to build the whole lot.")
        return 1

    # Cheapest first -- that is the order you want to work them in.
    records.sort(key=lambda r: (r.get("final_price")
                                or r.get("moses_price") or 0))

    kit = config.LISTING_KIT
    kit.mkdir(parents=True, exist_ok=True)

    cards: list[str] = []
    index_rows: list[dict] = []
    helper_cars: list[dict] = []

    for rec in records:
        stock = rec.get("stock", "")
        fields = fields_for(rec, personal)
        folder = config.PHOTO_DROP / stock
        nphotos = len([f for f in folder.glob("*") if f.suffix.lower() in
                       (".jpg", ".jpeg", ".png", ".webp")
                       and not f.name.lower().startswith("bg_")]) if folder.exists() else 0
        # Show it relative, so the card reads the same on any machine instead
        # of baking in whatever absolute path generated the file.
        shown = f"{config.PHOTO_DROP.name}\\{stock}"

        # plain text file
        lines = [f"{k}: {v}" for k, v in fields if k != "Description"]
        desc = dict(fields)["Description"]
        lines += ["", "Photo folder: " + shown,
                  f"Photos on disk: {nphotos}", "", "Description:", desc]
        (kit / f"{stock}.txt").write_text("\n".join(lines), encoding="utf-8")

        # html card
        title = dict(fields)["Title"]
        search = " ".join(str(v) for _, v in fields).lower()
        rows = []
        for k, v in fields:
            if not v:
                continue
            cls = "c desc" if k == "Description" else "c"
            # The VIN still copies -- he may want it for his own use -- but
            # the label is tinted so it never reads as another box to fill.
            kcls = "k nofill" if k.startswith("VIN") else "k"
            rows.append(
                f'<div class="f"><span class="{kcls}">{html.escape(k)}</span>'
                f'<button class="{cls}" data-v="{html.escape(v, quote=True)}">'
                f"{html.escape(v)}</button></div>"
            )
        warn = "" if nphotos else ' &middot; <strong>no photos yet</strong>'
        cards.append(
            f'<section class="v" data-s="{html.escape(search, quote=True)}">'
            f"<h2>{html.escape(title)}</h2>"
            f'<div class="stock">Stock {html.escape(stock)}</div>'
            f'<div class="folder">{html.escape(shown)}<br>'
            f"{nphotos} photo(s){warn}</div>"
            + "".join(rows) + "</section>"
        )

        try:
            helper_cars.append({"stock": stock, "title": title, "folder": str(folder),
                                "photos": nphotos, "fb": fb_fields(rec, personal)})
        except Exception:
            pass

        index_rows.append({
            "Stock": stock,
            "Title": title,
            "Price": rec.get("final_price") or rec.get("moses_price") or "",
            "Mileage": rec.get("mileage", ""),
            "VIN": rec.get("vin", ""),
            "Photos_On_Disk": nphotos,
            "Photo_Folder": shown,
            "Posted_Date": "",
            "Marketplace_URL": "",
            "Notes": "",
        })

    # Last run's cards for cars that are now sold or outside what he works
    # would otherwise sit in the folder looking current. Only this program
    # writes <STOCK>.txt here, so clearing the ones not built today is safe.
    built = {str(r.get("stock", "")) for r in records}
    for old in kit.glob("*.txt"):
        if old.stem not in built:
            try:
                old.unlink()
            except OSError:
                pass

    (kit / "post_helper.html").write_text(
        HTML_HEAD.replace("__N__", str(len(records))) + "\n".join(cards) + HTML_FOOT,
        encoding="utf-8",
    )

    # For the Chrome helper: what to type into Facebook's form for each car.
    try:
        (kit / "cars.json").write_text(json.dumps({"store": getattr(config, "STORE_FULL", ""),
                                                   "cars": helper_cars}, indent=1), encoding="utf-8")
    except OSError:
        pass

    with open(kit / "index.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(index_rows[0].keys()))
        w.writeheader()
        w.writerows(index_rows)

    nophotos = [r["Stock"] for r in index_rows if not r["Photos_On_Disk"]]
    mode = "personal Marketplace" if personal else "dealer / general"
    print(f"Wrote {kit}   [copy mode: {mode}]")
    if cap:
        print(f"  Price ceiling    : ${cap:,}  "
              f"({len(records)} of {total} vehicles)")
        if skipped_over or skipped_nopx:
            bits = []
            if skipped_over:
                bits.append(f"{skipped_over} priced over ${cap:,}")
            if skipped_nopx:
                bits.append(f"{skipped_nopx} with no price yet")
            print(f"  Left out         : {', '.join(bits)}")
            print(f"                     (--all builds the whole lot)")
    if left_out:
        import track
        print(f"  {left_out} vehicle(s) left out -- you work "
              f"{track.focus_wording() or 'a narrower slice'}.")
    print(f"  post_helper.html : {len(records)} vehicles, cheapest first, "
          f"click-to-copy")
    print(f"  <STOCK>.txt      : {len(records)} files")
    print(f"  index.csv        : tracking sheet "
          f"(Posted_Date / Marketplace_URL left blank for you)")
    if nophotos:
        print(f"\n  {len(nophotos)} vehicle(s) have no photos on disk yet:")
        print(f"    {', '.join(nophotos[:18])}"
              + (" ..." if len(nophotos) > 18 else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
