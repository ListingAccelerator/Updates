"""
ai_reply.py -- the Reply helper in Accelerator CRM.

Each buyer of the program chooses, in Accelerator CRM -> AI replies:
    "copy"    Copy for AI (no setup): the program builds the whole request --
              the buyer's message, the car, and the playbook -- and the
              salesman pastes it into whatever AI he already uses.
    "gemini"  His own free Google Gemini key: replies appear right in the
              program.
    "plan"    Included with a plan (reserved for when license keys arrive).

PRIVACY: before anything leaves the computer, the customer's name, phone
numbers, email addresses and street address are taken out of everything
sent. Only the message, the car's details and what you've told the program
about the deal go -- never who the customer is.

The key lives in program\\customers\\ai_settings.json, next to the customers,
which updates never touch.
"""
from __future__ import annotations

import http.client
import json
import os
import re
import socket
import time
import urllib.error
import urllib.request

import customers
import playbook

FILE = customers.BOOK / "ai_settings.json"
API = os.environ.get("LA_AI_API_TEST") or "https://generativelanguage.googleapis.com/v1beta"
# Google changes which models a new key may use, so the program asks the
# key which ones it has and picks the best fast one (see pick_model). These
# are only tried if that list can't be read.
FALLBACK_MODELS = ["gemini-flash-latest", "gemini-3.8-flash", "gemini-3.5-flash",
                   "gemini-3.5-flash-lite"]
MODES = ("copy", "gemini", "openai", "claude", "plan")
FIELDS = {"key": "", "model": "", "tested": "", "openai_key": "", "openai_model": "",
          "claude_key": "", "claude_model": "", "copy_site": "chatgpt"}


# ------------------------------------------------------------- settings
def settings() -> dict:
    out = {"mode": "copy", **FIELDS}
    try:
        d = json.loads(FILE.read_text(encoding="utf-8"))
        if isinstance(d, dict):
            out["mode"] = d.get("mode") if d.get("mode") in MODES else "copy"
            for k in FIELDS:
                if d.get(k):
                    out[k] = str(d[k])
            if isinstance(d.get("tested_by"), dict):
                out["tested_by"] = d["tested_by"]
    except Exception:
        pass
    out.setdefault("tested_by", {})
    return out


def _write(s: dict) -> None:
    customers.BOOK.mkdir(parents=True, exist_ok=True)
    FILE.write_text(json.dumps(s, indent=1), encoding="utf-8")


def _hint(k: str) -> str:
    return ("…" + k[-4:]) if len(k) > 8 else ""


def public_settings() -> dict:
    """What the window may see -- never the whole key."""
    s = settings()
    k = s["key"]
    tb = s.get("tested_by") or {}
    return {"mode": s["mode"], "model": s["model"], "tested": s["tested"],
            "has_key": bool(k), "key_hint": _hint(k),
            "keys": {"gemini": {"has": bool(s["key"]), "hint": _hint(s["key"]),
                                "tested": tb.get("gemini") or s["tested"]},
                     "openai": {"has": bool(s["openai_key"]), "hint": _hint(s["openai_key"]),
                                "tested": tb.get("openai", "")},
                     "claude": {"has": bool(s["claude_key"]), "hint": _hint(s["claude_key"]),
                                "tested": tb.get("claude", "")}},
            "copy_site": s["copy_site"],
            "on": s["mode"] in ("gemini", "openai", "claude") and bool(
                {"gemini": s["key"], "openai": s["openai_key"], "claude": s["claude_key"]}[s["mode"]]),
            "provider": {"gemini": "Google Gemini", "openai": "OpenAI (ChatGPT)",
                         "claude": "Anthropic (Claude)"}.get(s["mode"], "")}


def save_settings(mode: str, key: str | None = None, copy_site: str | None = None) -> dict:
    s = settings()
    if mode in MODES:
        s["mode"] = mode
    if key is not None:
        key = key.strip()
        field = {"openai": "openai_key", "claude": "claude_key"}.get(s["mode"], "key")
        if key != s[field]:
            s[field] = key
            if field == "key":
                s["model"], s["tested"] = "", ""
    if copy_site:
        s["copy_site"] = str(copy_site)[:20]
    _write(s)
    return public_settings()


# ------------------------------------------------------------- privacy
def scrub(text: str, c: dict) -> str:
    """Take out who the customer is: name, phones, emails, street address."""
    t = str(text or "")
    t = customers.EMAIL.sub("[email]", t)
    t = customers.PHONE.sub("[phone]", t)
    t = re.sub(r"\b\d{2,6}\s+[A-Za-z0-9 .'-]{2,40}\b(?:St|Street|Rd|Road|Ave|Avenue|Dr|Drive|Ln|Lane|"
               r"Ct|Court|Blvd|Way|Hwy|Highway|Pike|Cir|Circle|Pl|Place)\b\.?", "[address]", t, flags=re.I)
    addr = str(c.get("address") or "").strip()
    if addr:
        t = t.replace(addr, "[address]")
    for part in sorted(str(c.get("name") or "").split(), key=len, reverse=True):
        if len(part) >= 2:
            t = re.sub(r"\b" + re.escape(part) + r"\b", "[customer]", t, flags=re.I)
    return t


# ------------------------------------------------------------- the request
def _store_settings(c: dict) -> dict:
    for st in customers.stores.all_stores():
        if st["key"] == c.get("store_key"):
            return st["settings"]
    allst = customers.stores.all_stores()
    return allst[0]["settings"] if allst else {}


def brief(c: dict, message: str, tweak: str = "") -> str:
    """Everything the AI needs about this deal -- with the customer taken out."""
    v = customers.view(c)
    st = _store_settings(c)
    L = []
    me = st.get("first_name") or ""
    store = st.get("store_name") or v.get("store") or ""
    if me or store:
        L.append(f"Salesperson: {me or 'the salesperson'}"
                 + (f" at {store}" + (f", {st.get('city')}" if st.get("city") else "") if store else ""))
    for car in v["cars"] or []:
        bits = [f"Vehicle: {car['stock']} {car['name']}".strip()]
        if isinstance(car.get("price"), (int, float)):
            bits.append(f"posted price ${car['price']:,}")
        if isinstance(car.get("miles"), (int, float)):
            bits.append(f"{car['miles']:,} miles")
        if car.get("on_lot") is True:
            bits.append("still on the website")
        elif car.get("on_lot") is False:
            bits.append("NO LONGER on the website (may have sold)")
        L.append(" · ".join(bits))
    if not v["cars"]:
        L.append("Vehicle: not picked yet")
    if c.get("wants"):
        L.append("They want: " + ", ".join(c["wants"]))
    if c.get("looking_for"):
        L.append({"New": "Looking for: a new vehicle", "Used": "Looking for: a used vehicle",
                  "Either": "Looking for: new or used, either one"}[c["looking_for"]])
    L.append(f"Where it stands: {c.get('status') or 'New'}")
    if c.get("appointment"):
        L.append(f"Appointment: {v.get('appt_word')}")
    if c.get("followup"):
        L.append(f"Follow-up planned: {v.get('followup_word')}"
                 + (f" ({scrub(c.get('followup_note'), c)})" if c.get("followup_note") else ""))
    if c.get("trade"):
        L.append("Their trade (what they said): " + scrub(c["trade"], c))
    ti = c.get("trade_info") or {}
    tbits = [str(ti.get(k) or "").strip() for k in ("year", "make", "model", "trim")]
    if any(tbits):
        t = " ".join(b for b in tbits if b)
        for k, lbl in (("miles", "miles"), ("payoff", "payoff $"), ("allowance", "allowance $"), ("condition", "condition:")):
            if str(ti.get(k) or "").strip():
                t += f", {lbl} {scrub(str(ti[k]), c)}" if lbl != "miles" else f", {ti[k]} miles"
        L.append("Trade-in on file: " + t)
    qs = c.get("quotes") or []
    if qs:
        q = qs[-1]
        L.append(f"Last payment quote: {q.get('vehicle', '')} ${q.get('payment', '')}/mo, "
                 f"${q.get('down', '')} down, {q.get('term', '')} months")
    # The whole conversation, in order: their messages, what he sent, his notes.
    tl = [(str(e.get("when") or ""), "CUSTOMER CHAT (pasted from Marketplace)", e.get("text") or "")
          for e in c.get("chat") or []]
    tl += [(str(e.get("when") or ""), "I SENT THEM", e.get("text") or "") for e in c.get("sent") or []]
    tl += [(str(e.get("when") or ""), "MY NOTE", e.get("text") or "") for e in c.get("notes") or []]
    tl.sort(key=lambda x: x[0])
    if tl:
        rows = [f"[{w[:16].replace('T', ' ')}] {k}: {scrub(t, c).strip()}" for w, k, t in tl]
        keep, size = [], 0
        for r in reversed(rows):                      # newest first, up to about 7,000 characters
            if size + len(r) > 7000:
                keep.append("[...older conversation left out...]")
                break
            keep.append(r)
            size += len(r)
        L.append("THE WHOLE CONVERSATION SO FAR (oldest first):\n" + "\n".join(reversed(keep)))
    msg = scrub(message, c).strip()
    L.append("THEIR LATEST MESSAGE:\n" + (msg or "(Nothing new pasted. Read the whole conversation above "
             "and write the best next message to move it forward and answer anything still open.)"))
    if tweak in playbook.TWEAKS:
        L.append("\n" + playbook.TWEAKS[tweak])
    if c.get("lang") == "es":
        L.append("\n" + SPANISH)
    return "\n".join(L)


SPANISH = ("LANGUAGE: This buyer writes in Spanish. Write all three replies in natural, "
           "friendly Spanish the way people text in the US (usted unless they used tú). "
           "Keep the label and the rule in English so the salesperson can follow along, "
           "and keep prices, miles and stock numbers exactly as written.")


def copy_text(c: dict, message: str) -> str:
    """The whole request, in plain English, ready to paste into any AI."""
    rules = playbook.RULES.split("OUTPUT")[0].rstrip()
    return (rules + "\n\nFIRST, read the whole conversation below and list every question or worry the "
            "customer has raised, marking each one answered or still open, and tell me in one or two "
            "sentences where this deal stands.\n"
            "THEN WRITE THREE REPLIES I can send, each 1 to 3 sentences (the third one answers "
            "everything still open):\n"
            "1. Keep them talking\n2. Set the appointment\n"
            "3. Answer what they asked, straight\n"
            "Under each one, name the rule it follows. Then tell me which one "
            "you'd send." + ("\nWrite the replies in Spanish; explain them to me in English."
                             if c.get("lang") == "es" else "") +
            "\n\n---\n\n" + brief(c, message))


# ------------------------------------------------------------- Gemini
def _post(url: str, key: str, body: dict | None = None, timeout: int = 40):
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, method="POST" if data else "GET",
                                 headers={"x-goog-api-key": key,
                                          "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


class SlowError(Exception):
    """Google took too long to answer -- it's busy, not broken."""


def _slow(e: Exception) -> bool:
    if isinstance(e, (TimeoutError, socket.timeout, http.client.HTTPException,
                      ConnectionResetError, ConnectionAbortedError)):
        return True
    return isinstance(e, urllib.error.URLError) and \
        isinstance(getattr(e, "reason", None), (TimeoutError, socket.timeout))


class GoogleError(Exception):
    """An HTTP error from Google, with its message read once."""
    def __init__(self, code: int, msg: str):
        super().__init__(f"{code} {msg}")
        self.code, self.msg = code, msg


def _google_error(e: urllib.error.HTTPError) -> GoogleError:
    try:
        msg = json.loads(e.read().decode("utf-8")).get("error", {}).get("message", "")
    except Exception:
        msg = ""
    return GoogleError(e.code, msg)


BUSY = (429, 500, 502, 503, 504)     # this model is busy or rate-limited: try another


def _why(e: Exception | None) -> str:
    if isinstance(e, urllib.error.HTTPError):
        e = _google_error(e)
    if isinstance(e, GoogleError):
        m = e.msg.lower()
        if e.code in (401, 403) or (e.code == 400 and "key" in m):
            return "Google didn't accept that key. Press Copy key in Google AI Studio, then Paste here."
        if e.code in BUSY:
            return ("Google's AI is very busy right now -- this happens on the free plan. "
                    "Wait a minute and try again, or use Copy for AI.")
        if e.code == 404:
            return "That AI model isn't available to this key."
        return f"Google said: {e.msg or e.code}"
    if isinstance(e, SlowError):
        return ("Google is taking too long to answer right now -- it's very busy on "
                "the free plan. Try again in a few minutes, or use Copy for AI.")
    if isinstance(e, urllib.error.URLError):
        return ("Couldn't reach Google from this computer. The network may block it "
                "(common on work computers) -- use Copy for AI instead.")
    if e is None:
        return "No AI model answered."
    return f"Something went wrong: {type(e).__name__}"


def _run(key: str, models: list[str], prompt: str):
    """
    Try the models in order. A busy or retired model just means: try the
    next one (a busy one gets one more go after a short wait). A key or
    network problem stops at once -- trying more models won't help.
    Returns (model, answer, last_error, key_was_accepted).
    """
    last, accepted = None, False
    started = time.time()
    for m in models:
        if time.time() - started > 75:       # don't keep him waiting forever
            break
        for attempt in (1, 2):
            try:
                return m, _ask(key, m, prompt), None, True
            except urllib.error.HTTPError as e:
                last = _google_error(e)
            except GoogleError as e:
                last = e
            except (ValueError, KeyError) as e:
                last = e              # an answer we couldn't read
                accepted = True
                break
            except Exception as e:
                if _slow(e):
                    last = SlowError()             # busy: next model
                    break
                return None, None, e, accepted     # network: stop
            if not isinstance(last, GoogleError):
                break
            if last.code in (401, 403) or (last.code == 400 and "key" in last.msg.lower()):
                return None, None, last, False     # the key itself
            accepted = True
            if last.code in BUSY and attempt == 1:
                time.sleep(2)
                continue
            break                                  # 404 or still busy: next model
    return None, None, last, accepted


def _rank(name: str) -> tuple:
    nums = [int(x) for x in re.findall(r"\d+", name)[:2]] + [0, 0]
    return (nums[0], nums[1], "lite" not in name, "latest" in name)


KEY_SEEN_OK = {"v": False}     # Google listed models for this key = the key is good


def pick_model(key: str) -> list[str]:
    """Fast text models this key can use, best first."""
    KEY_SEEN_OK["v"] = False
    try:
        d = _post(f"{API}/models?pageSize=200", key, timeout=20)
        KEY_SEEN_OK["v"] = True
        names = []
        for m in d.get("models", []):
            n = str(m.get("name", "")).split("/")[-1]
            if "generateContent" not in (m.get("supportedGenerationMethods") or []):
                continue
            if "flash" not in n or re.search(r"image|tts|audio|live|embed|vision|thinking|exp", n):
                continue
            names.append(n)
        names.sort(key=_rank, reverse=True)
        stable = [n for n in names if "preview" not in n]
        return (stable + [n for n in names if n not in stable]) or FALLBACK_MODELS
    except urllib.error.HTTPError as e:
        if e.code in (400, 401, 403):
            raise _google_error(e)
        return FALLBACK_MODELS
    except Exception:
        return FALLBACK_MODELS


def _ask(key: str, model: str, prompt: str) -> dict:
    body = {"systemInstruction": {"parts": [{"text": playbook.RULES}]},
            "contents": [{"role": "user", "parts": [{"text": prompt}]}],
            "generationConfig": {"temperature": 0.8,
                                 "responseMimeType": "application/json"}}
    d = _post(f"{API}/models/{model}:generateContent", key, body, timeout=25)
    parts = (((d.get("candidates") or [{}])[0].get("content") or {}).get("parts") or [])
    text = "".join(p.get("text", "") for p in parts).strip()
    m = re.search(r"\{.*\}", text, re.S)
    out = json.loads(m.group(0) if m else text)
    reps = [r for r in out.get("replies", []) if str(r.get("text", "")).strip()]
    if not reps:
        raise ValueError("no replies")
    return {"replies": reps[:3], "best": out.get("best") or "",
            "summary": str(out.get("summary") or ""), "open": _open(out)}


def _open(out: dict) -> list[dict]:
    """Everything the customer has asked or worried about, answered or not."""
    res = []
    for x in out.get("questions") or []:
        if isinstance(x, dict) and str(x.get("ask") or "").strip():
            res.append({"ask": str(x["ask"]).strip()[:160], "done": bool(x.get("answered")),
                        "how": str(x.get("how") or "").strip()[:220]})
    return res[:12]


def test_key(key: str | None = None, provider: str | None = None) -> dict:
    s = settings()
    provider = provider or (s["mode"] if s["mode"] in ("gemini", "openai", "claude") else "gemini")
    if provider in ("openai", "claude"):
        import ai_engine
        field = provider + "_key"
        key = (key or s[field]).strip()
        if not key:
            return {"ok": False, "message": "Paste your key first."}
        try:
            out = ai_engine.ask(["Reply with the single word OK."], provider=provider, key=key, timeout=40)
        except ai_engine.AIFail as e:
            return {"ok": False, "message": str(e)}
        s = settings()
        s[field] = key
        s["mode"] = provider
        s.setdefault("tested_by", {})[provider] = customers.datetime.now().strftime("%Y-%m-%d %H:%M")
        _write(s)
        return {"ok": True, "message": f"It works. {ai_engine.PROVIDERS[provider]} is on."}
    key = (key or s["key"]).strip()
    if not key:
        return {"ok": False, "message": "Paste your key first."}
    try:
        models = pick_model(key)
    except Exception as e:
        return {"ok": False, "message": _why(e)}
    seen_ok = KEY_SEEN_OK["v"]
    m, out, err, accepted = _run(key, models[:6],
                                 "Vehicle: 2020 Honda CR-V EX · posted price $21,980\n"
                                 "THEIR LATEST MESSAGE:\nIs this still available?")
    if m or accepted or seen_ok:
        s.update(key=key, model=m or "", mode="gemini",
                 tested=customers.datetime.now().strftime("%Y-%m-%d %H:%M"))
        customers.BOOK.mkdir(parents=True, exist_ok=True)
        FILE.write_text(json.dumps(s, indent=1), encoding="utf-8")
        if m:
            return {"ok": True, "model": m, "message": "It works. AI replies are on."}
        return {"ok": True, "busy": True,
                "message": "Your key works and AI replies are on. Google is very busy "
                           "right now, so the first replies may take a minute or two."}
    return {"ok": False, "message": _why(err)}


def write(c: dict, message: str, tweak: str = "") -> dict:
    s = settings()
    if s["mode"] in ("openai", "claude") and s[s["mode"] + "_key"]:
        if not str(message or "").strip() and not (c.get("chat") or c.get("sent") or c.get("notes")):
            return {"ok": False, "message": "Paste what they said first."}
        import ai_engine
        try:
            txt = ai_engine.ask([brief(c, message, tweak)], system=playbook.RULES, want_json=True,
                                temperature=0.8)
            out = ai_engine.json_from(txt)
        except ai_engine.AIFail as e:
            return {"ok": False, "message": str(e)}
        except Exception:
            return {"ok": False, "message": "The AI's answer couldn't be read. Try again."}
        reps = [r for r in out.get("replies", []) if str(r.get("text", "")).strip()]
        if not reps:
            return {"ok": False, "message": "The AI didn't write any replies. Try again."}
        return {"ok": True, "replies": reps[:3], "best": out.get("best") or "",
                "summary": str(out.get("summary") or ""), "open": _open(out)}
    if s["mode"] != "gemini" or not s["key"]:
        return {"ok": False, "off": True,
                "message": "AI replies aren't turned on. Use Copy for AI, or turn them on "
                           "in AI replies (free, about 2 minutes)."}
    if not str(message or "").strip() and not (c.get("chat") or c.get("sent") or c.get("notes")):
        return {"ok": False, "message": "Paste what they said first."}
    prompt = brief(c, message, tweak)
    models = [s["model"]] if s["model"] else []
    try:
        models += [x for x in pick_model(s["key"])[:5] if x not in models]
    except Exception:
        models += [x for x in FALLBACK_MODELS if x not in models]
    m, out, err, _ = _run(s["key"], models, prompt)
    if not m:
        return {"ok": False, "message": _why(err)}
    if m != s["model"]:
        s["model"] = m
        FILE.write_text(json.dumps(s, indent=1), encoding="utf-8")
    return {"ok": True, **out}
