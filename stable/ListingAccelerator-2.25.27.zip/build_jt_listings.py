"""
build_jt_listings.py -- generate Marketplace ads in JT's own format.

Modeled on two real listings (2023 Compass Latitude Lux, 2021 C8 Corvette
Stingray). What those two have in common is the skeleton; what differs is tuned
to the vehicle, and this reproduces both:

  * mileage tier     2,429 -> "ULTRA-LOW MILES", 28,569 -> "LOW MILES"
  * section names    "INTERIOR & CABIN COMFORT" on the Corvette,
                     "LUXURY & WINTER COMFORT" on the Compass
  * engine emoji     performance cars get a flex, economy cars get a gear
  * closer verb      a Corvette gets a "private showing", a Compass gets a
                     "test drive"
  * hook             written against what the vehicle actually is

TWO THINGS THIS WILL NOT INVENT

"ONE OWNER" and "CLEAN TITLE / NO ACCIDENTS" are material representations
about a specific vehicle. A generated claim that turns out false is a
misrepresentation in a vehicle sale -- that is your license, not a typo. They
print only when the record carries them, which means CARFAX data you supply.

Build-sheet detail (exact paint name, engine and horsepower, wheel sizes, seat
material, package names, recon work) is not on the website at all. Your ads use
it heavily, so this emits it as [[BRACKETED PLACEHOLDERS]] for you to fill from
the window sticker. That is deliberate: a skeleton you complete beats a
confident ad with invented specs.

Usage:
    python build_jt_listings.py
    python build_jt_listings.py --stock OW26483
    python build_jt_listings.py --no-placeholders
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from collections import Counter

import config
from build_fb_catalog import MODEL_TO_BODY

PERFORMANCE = {"Corvette", "Camaro", "Mustang", "Challenger", "Charger",
               "BRZ", "WRX", "SQ5", "SQ5 Sportback", "Q60", "Supra"}
PERF_TRIMS = ("srt", "392", "hellcat", "gt-line", "ecoboost premium",
              "n line")
OFFROAD_TRIMS = ("rubicon", "trail boss", "pro-4x", "z71", "willys",
                 "rock creek", "xrt", "trailhawk", "badlands", "big bend",
                 "wildtrak", "at4", "tremor")
LUXURY_MAKES = {"Audi", "INFINITI", "Cadillac", "Lincoln", "Lexus", "Acura",
                "BMW", "Mercedes-Benz", "Porsche", "Jaguar", "Land Rover"}
THREE_ROW = {"Grand Cherokee L", "Highlander", "Pilot", "Telluride",
             "Palisade", "Traverse", "Suburban", "Tahoe", "Yukon", "Yukon XL",
             "Expedition", "Expedition Max", "Pathfinder", "Ascent", "CX-90",
             "Durango", "Wagoneer", "QX80", "QX60", "Sequoia", "Acadia",
             "Carnival", "Odyssey", "Sienna", "Pacifica", "Grand Caravan"}

# feature -> (section, emoji, benefit). The benefit is the whole point.
FEATURES = {
    "heated seats": ("comfort", "\U0001F525", "Heated Front Seats – Warm in seconds on a cold West Virginia morning!"),
    "heated steering": ("comfort", "\U0001F525", "Heated Steering Wheel – Keep your hands warm and ditch the bulky gloves!"),
    "leather": ("comfort", "\U0001F4BA", "Leather Seating – Premium feel and easy to keep clean!"),
    "power seats": ("comfort", "\U0001FA9F", "Power Driver Seat – Dial in your perfect driving position!"),
    "remote start": ("comfort", "\U0001F511", "Remote Vehicle Start – Warm it up or cool it down before you ever step outside!"),
    "sunroof": ("comfort", "☀️", "Sunroof – Open it up on a perfect spring day!"),
    "moonroof": ("comfort", "☀️", "Moonroof – Open it up on a perfect spring day!"),
    "3rd row": ("comfort", "\U0001F46A", "3rd Row Seating – Room for the whole family plus the gear!"),
    "cooled seats": ("comfort", "❄️", "Ventilated Front Seats – Stay cool straight through August!"),
    "keyless entry": ("comfort", "\U0001F513", "Keyless Entry – Hands full? Walk up and go!"),
    "keyless ignition": ("comfort", "\U0001F680", "Push-Button Start – Keys never leave your pocket!"),

    "bluetooth": ("tech", "\U0001F399️", "Hands-Free Bluetooth® Audio & Calling – Both hands stay on the wheel!"),
    # Paired on purpose: these two ship together and your own ads bill them
    # on one line, so they collapse into one rather than the dedupe dropping
    # whichever came second.
    "apple carplay": ("tech", "\U0001F4F2", "Apple CarPlay® & Android Auto™ – Your maps, music and messages right on the screen!"),
    "android auto": ("tech", "\U0001F4F2", "Apple CarPlay® & Android Auto™ – Your maps, music and messages right on the screen!"),
    "navigation": ("tech", "\U0001F5FA️", "Built-In Navigation – Never lose signal on a back road again!"),
    "wi-fi": ("tech", "\U0001F310", "Built-In Wi-Fi® Hotspot – Keep everybody connected on a road trip!"),
    "aux input": ("tech", "\U0001F3B6", "Aux Input – Plug in and play whatever you want!"),

    "adaptive cruise": ("safety", "\U0001F6E3️", "Adaptive Cruise Control – Holds your following distance so I-64 stops wearing you out!"),
    "blind spot": ("safety", "\U0001F440", "Blind Spot Warning – Alerts you before you change lanes!"),
    "backup camera": ("safety", "\U0001F3A5", "HD Rear Backup Camera – See exactly what's behind you!"),
    "emergency brake": ("safety", "\U0001F6D1", "Emergency Brake Assist – Extra stopping power the moment you need it!"),
    "forward collision": ("safety", "\U0001F6D1", "Forward Collision Warning with Active Braking – Watches the road even when you blink!"),
    "lane departure": ("safety", "\U0001F6E3️", "Lane Departure Warning – Nudges you back if you drift!"),
    "lane keep": ("safety", "\U0001F6E3️", "Active Lane Management – Nudges you back if you drift!"),
    "parking sensors": ("safety", "\U0001F17F️", "Parking Sensors – Tight spots get a whole lot easier!"),

    "4wd/awd": ("capability", "⛰️", "4WD/AWD – Traction for our hills, snow and gravel roads!"),
    "tow": ("capability", "\U0001F69B", "Tow Package – Ready to pull the camper or the trailer!"),
    "bed liner": ("capability", "\U0001F6E0️", "Bed Liner – Work it hard without tearing up the paint!"),
}



# Scraped option lists pick up the page's price/spec table. These must never
# reach an ad -- one of them printed the DROP price inside the listing body.
OPTION_BLOCK = re.compile(
    r"^\s*[\$\-+]|\$[\d,]|"
    r"\b(retail price|savings|doc fee|price|msrp|mileage|odometer|"
    r"city/?highway|mpg|payment|financ|apr|est\.|monthly|trade|"
    r"value|disclaimer|terms|stock|vin)\b|"
    r"^(engine|transmission|drivetrain|drive type|fuel type|exterior|"
    r"interior|body style|doors|cylinders)\b|"
    r"^[\d,\.\s/]+$",
    re.I)


def clean_options(opts: list[str]) -> list[str]:
    out = []
    for o in opts:
        s = " ".join(str(o).split())
        if not s or len(s) < 4 or len(s) > 70:
            continue
        if OPTION_BLOCK.search(s):
            continue
        if sum(c.isdigit() for c in s) > len(s) / 2:
            continue
        out.append(s)
    seen = set()
    return [o for o in out if not (o in seen or seen.add(o))]


# Automotive acronyms that must stay shouting -- "Cvt" and "Vvt" look broken.
KEEP_CAPS = {
    "CVT", "VVT", "VVT-I", "DOHC", "SOHC", "GDI", "MPI", "TDI", "DCT", "PDK",
    "AWD", "FWD", "RWD", "4WD", "4X4", "4X2", "ABS", "LED", "HID", "USB",
    "GPS", "MPG", "HP", "EV", "PHEV", "HEV", "TFSI", "TSI", "FSI", "HEMI",
    "SRT", "ST", "RS", "SS", "GT", "LT", "LS", "SE", "XL", "XLT", "SR5",
    "LTZ", "RST", "AT4", "TRD", "GTI", "SV", "SL", "EX", "LX", "DX", "SX",
    "LE", "XLE", "XSE", "N", "SI", "TYPE-R", "AMG", "M", "RT", "GTS",
}


def desauce(s: str) -> str:
    """'8-SPEED AUTOMATIC 850RE' -> '8-Speed Automatic 850RE'."""
    if not s:
        return s
    words = []
    for w in str(s).split():
        # Hyphenated parts get handled individually, so "8-SPEED" becomes
        # "8-Speed" rather than being skipped for containing a digit.
        if w.upper().strip(".,") in KEEP_CAPS:
            words.append(w.upper())
        elif "-" in w:
            bits = [b if b.upper() in KEEP_CAPS
                    else (b.capitalize() if b.isupper() and len(b) > 2 else b)
                    for b in w.split("-")]
            words.append("-".join(bits))
        elif w.isupper() and len(w) > 2 and not any(c.isdigit() for c in w):
            words.append(w.capitalize())
        else:
            words.append(w)
    return " ".join(words)


ENGINE_TAIL = re.compile(
    r"\s+(upg\b.*|w/ess\b.*|-inc\b.*|\bi\s+w/.*|\bess\b.*)$", re.I)


def nice_engine(s: str) -> str | None:
    """Drop useless strings like 'V6 Cylinder Engine' that say nothing."""
    if not s:
        return None
    s = " ".join(str(s).split())
    m = re.fullmatch(r"(V|I)?(\d{1,2})[\s-]*cyl(?:inder)?s?(\s+engine)?", s, re.I)
    if m:
        # "4 Cylinder Engine" isn't much, but it's true -- say it plainly
        # rather than leave a blank someone fills in wrong.
        return f"{m.group(1).upper()}{m.group(2)}" if m.group(1) else f"{m.group(2)}-Cylinder"
    if s.lower() in ("engine", "gas", "gasoline", "electric"):
        return None
    s = ENGINE_TAIL.sub("", s).strip(" ,-")
    return desauce(s)


# The banner line keeps whatever wording the store already advertises,
# which is not always the full legal name.
WHY_BUY_NAME = getattr(config, "WHY_BUY_NAME",
                       config.STORE_FULL).upper()


def character(rec: dict) -> str:
    model = rec.get("model", "")
    trim = (rec.get("trim") or "").lower()
    body = MODEL_TO_BODY.get(model, "SUV")
    miles = rec.get("mileage") or 0
    price = rec.get("final_price") or rec.get("moses_price") or 0

    if model in PERFORMANCE or any(k in trim for k in PERF_TRIMS):
        return "performance"
    if any(k in trim for k in OFFROAD_TRIMS) or model in (
            "Wrangler", "Wrangler 4xe", "Gladiator", "Bronco"):
        return "offroad"
    if rec.get("make") in LUXURY_MAKES or "limited" in trim or "lux" in trim:
        return "luxury"
    if body in ("TRUCK", "VAN"):
        return "work"
    if model in THREE_ROW or body == "MINIVAN":
        return "family"
    if miles > 110000 or (price and price < 15000):
        return "value"
    return "standard"


# Calibrated against your own four ads: 2,429 -> "ULTRA-LOW MILES",
# 28,569 -> "LOW MILES", 31,859 and 55,939 -> plain "Miles". So the LOW
# boundary sits just under 30k, not 45k.
MILE_TIER = [
    (10_000, "ULTRA-LOW MILES"),
    (30_000, "LOW MILES"),
]

COMFORT_HEADER = {
    "offroad": "\U0001F6CB\uFE0F COMFORT & INTERIOR \U0001F6CB\uFE0F",

    "performance": "\U0001F451 INTERIOR & CABIN COMFORT \U0001F451",
    "sport": "\U0001F6CB\uFE0F COMFORT & INTERIOR \U0001F6CB\uFE0F",
    "luxury": "\U0001F451 LUXURY & WINTER COMFORT \U0001F451",
    "family": "\U0001F451 FAMILY COMFORT & CONVENIENCE \U0001F451",
    "work": "\U0001F451 CAB COMFORT & CONVENIENCE \U0001F451",
    "value": "\U0001F451 COMFORT & CONVENIENCE \U0001F451",
    "standard": "\U0001F451 COMFORT & CONVENIENCE \U0001F451",
}
SAFETY_HEADER = {
    "offroad": "\U0001F6E1\uFE0F SAFETY & DRIVER ASSIST \U0001F6E1\uFE0F",

    "performance": "\U0001F6E1️ SAFETY & CONVENIENCE \U0001F6E1️",
    "work": "\U0001F6E1️ SAFETY & DRIVER ASSIST \U0001F6E1️",
}
HOOK = {
    "offroad": ("legendary Trail-Rated capability",
                "the 4x4 hardware to conquer mountain trails, back roads and "
                "the daily drive",
                "\U0001F699\u26F0\uFE0F"),
    "performance": ("a head-turner in immaculate condition",
                    "pure performance, sound and presence",
                    "\U0001F3CE️\U0001F4A8"),
    "luxury": ("a premium, well-appointed ride",
               "high-end styling, comfort and cold-weather features",
               "\U0001F699\U0001F4A8"),
    "family": ("a roomy, family-ready hauler",
               "space for everybody plus all the gear",
               "\U0001F46A\U0001F698"),
    "work": ("a capable, hard-working rig",
             "the muscle and the room to earn its keep",
             "\U0001F69A\U0001F4A8"),
    "value": ("dependable transportation that won't stretch the budget",
              "honest miles at an honest price",
              "\U0001F698✅"),
    "standard": ("a sharp, well-equipped ride",
                 "the equipment, the miles and the price all in one place",
                 "\U0001F699\U0001F4A8"),
}
CLOSER_VERB = {
    "offroad": "test drive",

    "performance": "private showing",
    "luxury": "test drive",
    "family": "test drive",
    "work": "test drive",
    "value": "test drive",
    "standard": "test drive",
}


def mile_label(miles: int) -> str:
    for cap, label in MILE_TIER:
        if miles < cap:
            return label
    return "Miles"


def is_low_miles(miles: int) -> bool:
    return bool(miles) and miles < 30_000


def match_features(feats: list[str]) -> dict[str, list[str]]:
    out: dict[str, list[str]] = {}
    seen: set[str] = set()
    for raw in feats:
        low = raw.strip().lower()
        for key, (section, emoji, line) in FEATURES.items():
            if key not in low:
                continue
            # Two different features can carry the same selling line (lane
            # departure vs lane keep). Print the benefit once.
            benefit = line.split("\u2013", 1)[-1].strip().lower()
            if line in seen or benefit in seen:
                break
            seen.add(line)
            seen.add(benefit)
            out.setdefault(section, []).append(f"{emoji} {line}")
            break
    return out


def build(rec: dict, placeholders: bool = False) -> tuple[str, list[str]]:
    """The ad. placeholders=True adds [[FILL IN]] reminders for a person to
    finish by hand -- never for an ad that goes out as it is."""
    gaps: list[str] = []
    ph = (lambda s: s) if placeholders else (lambda s: "")

    year, make = rec.get("year", ""), rec.get("make", "")
    model, trim = rec.get("model", ""), rec.get("trim", "")
    veh = " ".join(str(x) for x in (year, make, model, trim) if x)
    miles = rec.get("mileage") or 0
    price = rec.get("final_price") or rec.get("moses_price")
    retail, savings = rec.get("retail_price"), rec.get("savings")
    body = MODEL_TO_BODY.get(model, "SUV")
    char = character(rec)
    stock = rec.get("stock", "")

    L: list[str] = [f"\U0001F525 {veh} \U0001F525"]

    color = rec.get("exterior_color")
    try:
        from vehicle_parser import _spec_value_ok
        if color and not _spec_value_ok(str(color)):
            color = None          # a price read as a colour -- never print it
    except Exception:
        pass
    if color:
        L.append(f"\U0001F3A8 Color: {color}")
    else:
        gaps.append("exterior_color")
        if placeholders:
            L.append("\U0001F3A8 Color: [[PAINT NAME — e.g. Elkhart Lake Blue Metallic]]")

    # Interior right under the paint -- buyers ask about both together.
    inside = str(rec.get("interior_color") or "").strip()
    try:
        from vehicle_parser import _spec_value_ok
        if inside and not _spec_value_ok(inside):
            inside = ""
    except Exception:
        pass
    if inside:
        L.append(f"\U0001F4BA Interior: {inside}")
    elif placeholders:
        L.append("\U0001F4BA Interior: [[INTERIOR COLOR — from the window sticker]]")

    if miles:
        L.append(f"\U0001F6E3️ {mile_label(miles)}: {miles:,}")

    engine = nice_engine(rec.get("engine_full") or rec.get("engine"))
    trans = desauce(rec.get("transmission"))
    eng_emoji = "\U0001F4AA" if char == "performance" else "⚙️"
    if engine or trans or placeholders:
        bits = []
        if engine:
            hp = f" ({rec['horsepower']}+ HP!)" if rec.get("horsepower") else ""
            bits.append(f"{eng_emoji} Engine: {engine}{hp}")
        elif placeholders:
            bits.append(f"{eng_emoji} Engine: [[ENGINE + HP — from the window sticker]]")
        if trans:
            bits.append(f"⚙️ Transmission: {trans}")
        elif placeholders:
            bits.append("⚙️ Transmission: [[TRANSMISSION]]")
        L.append(" | ".join(bits))
    if not engine:
        gaps.append("engine")
    if not trans:
        gaps.append("transmission")

    # No price line in the body. None of your four ads carry one -- the price
    # lives in Marketplace's own price field, and you post RETAIL there.

    want, delivers, emo = HOOK[char]
    L += ["", f"Looking for {want}? Look no further! This {veh} brings "
              f"{delivers} and it's ready to go today! {emo}"]

    hi: list[str] = []
    if rec.get("one_owner"):
        hi.append("✅ ONE OWNER! \U0001F464")
    if rec.get("clean_title"):
        hi.append("✅ CLEAN TITLE / NO ACCIDENTS! 0️⃣\U0001F4A5")
    if not (rec.get("one_owner") or rec.get("clean_title")):
        gaps.append("carfax (one_owner / clean_title)")
        if placeholders:
            hi.append("✅ [[CARFAX — add ONE OWNER / CLEAN TITLE only if the report says so]]")
    if is_low_miles(miles):
        hi.append(f"✅ {mile_label(miles)} – ONLY {miles:,} MILES! \U0001F6E3️")
    if placeholders:
        hi.append("✅ [[RECON — e.g. BRAND NEW TIRES & FULLY SERVICED! \U0001F6DE✨]]")
        gaps.append("recon notes")
    if trim:
        hi.append(f"✅ {trim} Trim \U0001F48E")
    # No markdown line in the body: you post at retail and drop the price in
    # Marketplace a day later, which is what fires the "Price dropped" badge.
    # Scraped build options become a sub-bullet group, the way your Rubicon ad
    # nests "4.10 Rear Axle Ratio" and the wheels under one highlight.
    opts = clean_options(rec.get("options") or [])
    # Anything that already prints as a themed feature line (heated seats,
    # leather) is left out here, or it shows up twice in the same ad.
    def is_themed(o: str) -> bool:
        low = o.lower()
        return any(k in low for k in FEATURES)

    # Spec-sheet filler. True of the vehicle, sells nothing.
    BORING = re.compile(
        r"gvwr|emission|payload|alternator|amp\b|battery|curb weight|"
        r"fuel tank|anti-roll|shock absorber|headliner|floor (mat|trim)|"
        r"glass|antenna|bracket|duty suspension|locking hubs|"
        r"steel/aluminum|rub strip|door bins|cupholder|visor|"
        r"power outlet|air filtration|immobilizer|side impact", re.I)
    # What a buyer actually reads.
    JUICY = re.compile(
        r"sunroof|moonroof|panoramic|leather|navigation|tow|trailer|"
        r"axle ratio|package|wheels?:|tires?:|4x4|four-wheel|limited slip|"
        r"off-road|skid|spoiler|roof rack|premium|bose|harman|alpine", re.I)

    cand = [o for o in opts if not is_themed(o) and not BORING.search(o)]
    cand.sort(key=lambda o: (0 if JUICY.search(o) else 1, len(o)))
    pick_opts = cand[:6]
    lead = []
    if rec.get("wheels"):
        lead.append(f"Wheels: {desauce(rec['wheels'])}")
    if rec.get("tires"):
        lead.append(f"Tires: {rec['tires']}")
    pick_opts = lead + [o for o in pick_opts if o not in lead]
    pick_opts = pick_opts[:6]

    if pick_opts:
        label = f"{trim} Setup" if trim else "Equipment"
        hi.append(f"✅ {label}:")
        hi += [f"• {o}" for o in pick_opts]
    elif placeholders:
        hi.append("✅ [[WHEELS — e.g. 19\" Front / 20\" Rear Aluminum Wheels]]")
    if hi:
        L += ["", "✨ VEHICLE HIGHLIGHTS ✨"] + hi

    grouped = match_features((rec.get("features") or []) + opts)
    if grouped.get("comfort") or rec.get("interior_color"):
        L += ["", COMFORT_HEADER[char]] + grouped.get("comfort", [])
        ic = rec.get("interior_color")
        if ic:
            L.append(f"\U0001F4BA {ic} Interior – Comfortable and built to last!")
        elif placeholders:
            L.append("\U0001F4BA [[SEAT MATERIAL / COLOR — from the window sticker]]")
    if grouped.get("tech"):
        L += ["", "\U0001F4F6 TECH & CONNECTIVITY \U0001F4F6"] + grouped["tech"]
        info = rec.get("infotainment")
        if info:
            L.append(f"\U0001F5A5️ {desauce(info)} – Everything right where "
                     "you can reach it!")
        elif placeholders:
            L.append("\U0001F5A5️ [[INFOTAINMENT SYSTEM NAME + SCREEN]]")
    if grouped.get("safety"):
        L += ["", SAFETY_HEADER.get(char,
              "\U0001F6E1️ ADVANCED SAFETY & DRIVER ASSIST \U0001F6E1️")] \
             + grouped["safety"]
    if grouped.get("capability"):
        L += ["", "⚡ CAPABILITY ⚡"] + grouped["capability"]

    L += ["", f"\U0001F91D WHY BUY FROM {WHY_BUY_NAME}?",
          f"At {config.STORE_FULL}, you aren't just buying a vehicle—"
          "you're investing in quality, reliability, and total peace of mind! "
          "\U0001F4AF",
          "\U0001F539 Transparent Pricing – No hidden fees or surprises!",
          "\U0001F539 Hassle-Free & Convenient buying experience!",
          "\U0001F539 Customer FIRST Service every single time! ❤️"]

    L += ["", "\U0001F4CD LOCATION & CONTACT",
          f"\U0001F4CD {config.STORE_FULL}",
          f"\U0001F3E2 Address: {config.STORE_ADDRESS_LINE}",
          f"\U0001F464 {config.SELLER_TITLE}: {config.SELLER_NAME} "
          "\U0001F468‍\U0001F4BC",
          f"\U0001F4DE {config.SELLER_CONTACT}: {config.DEALER_PHONE} "
          "\U0001F4F1"]

    # Your closers name the car by its PAINT plus its trim or nameplate:
    #   "this Hydro Blue Rubicon", "this Rapid Red ST-Line",
    #   "this Granite Crystal Compass Latitude Lux 4x4"
    # With no scraped color this falls back to year/make/model.
    if color:
        hue = " ".join(w for w in color.split()
                       if w.lower() not in ("metallic", "pearlcoat",
                                            "clearcoat", "tinted", "premium",
                                            "paint"))
        short = f"{hue} {trim or model}".strip()
    elif placeholders:
        short = f"[[COLOR]] {trim or model}".strip()
    else:
        short = f"{year} {make} {model}".strip()
    if miles and miles < 10000:
        short = f"{round(miles, -2):,.0f}-mile {model}"

    L += ["", f"\U0001F4A5 Message, call, or text me today to schedule your "
              f"{CLOSER_VERB[char]} before this {short} sells! "
              "\U0001F511\U0001F698"]

    # Marketplace listing title, the way he writes it:
    #   "2022 Jeep 🔥Grand Cherokee Limited 🔥 OW26309A"
    # Model and trim keep their proper capitals and the stock number is in
    # capitals, so it reads exactly like the stock number on the lot.
    awd = "4wd/awd" in " ".join(rec.get("features") or []).lower()
    tail = f"{model} {trim}".strip()
    if awd and body in ("SUV", "TRUCK") and "4x4" not in tail.lower():
        tail += " 4x4"
    title = (f"{year} {make} \U0001F525{tail} \U0001F525 "
             f"{str(stock).upper()}").strip()
    text = "\n".join(L)
    try:                         # each salesperson's own look (vary.py)
        import vary
        text, title = vary.ad(text, title, stock)
    except Exception:
        pass
    return text, gaps, title


def write_one_file(rows, outdir):
    """
    Every ad in one text file. Type the stock number into Find and you are
    at that car.

    A folder of 300 separate files means hunting for one, opening it,
    copying, closing it, going back. One file means Ctrl+F, copy, carry on.
    Notepad opens it, so there is nothing new to learn.

    The per-vehicle files stay for anyone who prefers one car at a time, but
    this is the one the window opens.
    """
    L = []
    L.append("=" * 64)
    L.append("   YOUR ADS" + f"({len(rows)} vehicles)".rjust(48))
    L.append("=" * 64)
    L.append("")
    L.append("   Press Ctrl and F, type the stock number, press Enter.")
    L.append("")
    L.append("")

    for stock, title, retail, drop, ad, _rec in rows:
        L.append("=" * 64)
        L.append(f"   {stock}")
        L.append("=" * 64)
        L.append("")
        L.append(f"   TITLE: {title}")
        L.append("")
        if retail and drop and retail > drop:
            L.append(f"   POST AT:  ${retail:,}")
            L.append(f"   DROP TO:  ${drop:,}      "
                     f"(-${retail - drop:,} tomorrow)")
        elif drop:
            L.append(f"   POST AT:  ${drop:,}      (no markdown on this one)")
        L.append("   " + "-" * 58)
        L.append("")
        for line in ad.splitlines():
            L.append(line.rstrip())
        L.append("")
        L.append("")

    # CRLF and a BOM so it opens tidily in Notepad on any Windows, with the
    # emoji intact rather than showing as question marks.
    (outdir / "ALL ADS.txt").write_text(
        "\r\n".join(L), encoding="utf-8-sig", newline="")



def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--stock")
    ap.add_argument("--no-placeholders", action="store_true")
    ap.add_argument("--placeholders", action="store_true",
                    help="add [[FILL IN]] reminders (off: ads go out as written)")
    args = ap.parse_args()

    if not config.INVENTORY_JSON.exists():
        print(f"No scraped inventory at {config.INVENTORY_JSON}")
        return 1

    records = json.loads(config.INVENTORY_JSON.read_text(encoding="utf-8"))
    records.sort(key=lambda r: r.get("stock", ""))

    # Only write ads for the cars he works. On a dealer-group website the
    # inventory holds the whole group -- Victory Toyota lists 228 and he can
    # sell about twenty of them -- and an ad for a car three towns away is
    # worse than no ad at all.
    if not args.stock:
        import track
        f = track.focus()
        if track.focus_is_on(f):
            before = len(records)
            records = [r for r in records if track.in_focus(r, f)]
            if before != len(records):
                print(f"{before - len(records)} vehicle(s) left out -- "
                      f"you work {track.focus_wording()}.")
        else:
            others = [r for r in records if track.is_other_store(r)]
            if others:
                records = [r for r in records
                           if not track.is_other_store(r)]
                print(f"{len(others)} vehicle(s) at another store left out.")
    if args.stock:
        records = [r for r in records if r.get("stock") == args.stock]
        if not records:
            print(f"No vehicle with stock {args.stock}")
            return 1

    # A car whose own page never really loaded is held back rather than
    # posted with blank colour and engine. Listed in out\detail_held.csv, and
    # it goes into the ads on the first run that reads it properly.
    #
    # Only when the details really are missing. A failed page with colour or
    # engine supplied some other way -- the store's feed -- is a complete car.
    def _held(r):
        return bool(r.get("detail_failed")
                    and not (r.get("exterior_color") or r.get("engine")))
    held = [r for r in records if _held(r)]
    held_file = config.OUT / "detail_held.csv"
    if not held and held_file.exists():
        # Yesterday's list is not today's. Leaving it would show cars as held
        # that went into the ads this morning.
        try:
            held_file.unlink()
        except Exception:
            pass
    if held:
        records = [r for r in records if not _held(r)]
        import csv
        with open(config.OUT / "detail_held.csv", "w", newline="",
                  encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(["stock", "year", "make", "model", "trim", "reason"])
            for r in held:
                w.writerow([r.get("stock", ""), r.get("year", ""),
                            r.get("make", ""), r.get("model", ""),
                            r.get("trim", ""), r.get("detail_error", "")])
        print(f"  held {len(held)} vehicle(s) whose page did not load fully "
              f"(see out\\detail_held.csv)")

    # A vehicle with no price can't be posted to Marketplace, so it gets no
    # ad. They're listed in out\no_price_yet.csv instead.
    unpriced = [r for r in records
                if not (r.get("final_price") or r.get("moses_price"))]
    records = [r for r in records
               if r.get("final_price") or r.get("moses_price")]

    outdir = config.OUT / "jt_listings"
    outdir.mkdir(parents=True, exist_ok=True)

    gaps: Counter = Counter()
    chars: Counter = Counter()
    everything = []          # for the one-file-in-Notepad version
    for rec in records:
        ad, missing, title = build(rec, bool(args.placeholders) and not args.no_placeholders)
        retail = rec.get("retail_price")
        drop = rec.get("final_price") or rec.get("moses_price")
        head = [f"TITLE: {title}", ""]
        if retail and drop and retail > drop:
            head += [f"POST AT:  ${retail:,}",
                     f"DROP TO:  ${drop:,}   (-${retail - drop:,} "
                     "after a day, to fire the Price Dropped badge)", ""]
        elif drop:
            head += [f"POST AT:  ${drop:,}   (no markdown on this one)", ""]
        (outdir / f"{rec['stock']}.txt").write_text(
            "\n".join(head) + f"{'-' * 60}\n\n{ad}\n", encoding="utf-8")
        everything.append((rec.get("stock", ""), title, retail, drop, ad, rec))
        for m in missing:
            gaps[m] += 1
        chars[character(rec)] += 1

    write_one_file(everything, outdir)

    # The ads folder is what he opens now, one file per car -- so an ad for a
    # car that sold, or that is outside what he works, must not be left in
    # it looking current. Only on a full run; "--stock X" rewrites one ad.
    if not args.stock:
        keep = {f"{e[0]}.txt" for e in everything} | {"ALL ADS.txt"}
        for old in outdir.glob("*.txt"):
            if old.name not in keep:
                try:
                    old.unlink()
                except OSError:
                    pass

    print(f"Wrote {len(records)} ad(s) to {outdir}")
    print(f"  and all of them in one file: {outdir / 'ALL ADS.txt'}")
    if unpriced:
        print(f"  skipped {len(unpriced)} vehicle(s) with no price yet "
              f"(see out\\no_price_yet.csv)")
    print(f"  vehicle character: {dict(chars)}")
    if gaps and args.placeholders and not args.no_placeholders:
        print("\n  Placeholders left for you to fill from the window sticker:")
        for f, n in gaps.most_common():
            print(f"    {f:34s} {n}/{len(records)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
