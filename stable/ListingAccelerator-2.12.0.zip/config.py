"""
config.py -- settings for this copy of the Listing Accelerator.

=====================================================================
  YOU DO NOT NEED TO OPEN THIS FILE
=====================================================================

  Your name, your phone number, your dealership and the web address
  of your inventory are not in here. You typed those into the setup
  screen the first time you ran the program, and they live next door
  in settings.json.

  To change any of them: open the program, press Settings, then
  "Open the setup screen".

  What IS in here are the factory defaults -- the starting point
  before your own answers are applied on top, at the bottom of this
  file. Everything the program writes stays inside this one folder,
  so the whole thing can be moved or copied as a unit.
=====================================================================
"""
from __future__ import annotations

import re
from pathlib import Path

# --- paths ------------------------------------------------------------------
# Everything lives inside this one folder. Move the folder anywhere and it
# still works.
BASE = Path(__file__).resolve().parent

# One program, several stores: each store keeps its own settings, ads and
# posting record in program\stores\<store>\. The window says which store
# it is working on through LA_STORE_DIR, and every step of the run inherits
# it. With no store named, this folder itself is the store -- exactly how a
# single-store copy has always worked.
import os as _os
STORE_DIR = Path(_os.environ["LA_STORE_DIR"]) if _os.environ.get("LA_STORE_DIR") \
    else BASE
OUT = STORE_DIR / "out"
PHOTO_DROP = STORE_DIR / "Photo Drop"

INVENTORY_JSON = OUT / "inventory.json"
INVENTORY_CSV = OUT / "inventory.csv"
FB_CATALOG_CSV = OUT / "facebook_vehicle_catalog.csv"
LISTING_KIT = OUT / "listing_kit"

# --- which website ----------------------------------------------------------
SITE_ROOT = ""            # filled in from the setup screen
# A store whose website turns programs away reads an inventory feed instead:
# a web link or a file/folder the store's website company sends each day.
FEED_SOURCE = ""
FEED_ADD_FEE = 0          # add this doc fee to the feed's price (0 = already in it)
INVENTORY_URL = ""        # filled in from the setup screen

# 0 means work it out. Most dealer sites show twelve vehicles per page, so a
# normal lot runs to several pages; after reading the first page the program
# knows the page size and the site's own total, and walks exactly as many
# pages as that needs. A lot that fits on one page still stops after one.
#
# Only put a number here to force a limit for a site that behaves oddly.
MAX_PAGES = 0

# The bit of the web address the site uses to ask for page 2, 3, 4... If the
# address you pasted already has one of these in it, the program picks it up
# by itself. "pt" covers DealerOn, "_p" covers Dealer Inspire.
PAGE_PARAM = "pt"

# --- how hard to work -------------------------------------------------------
# Reading a car's page and pulling its photos is almost entirely waiting on
# the website, so doing several at once costs nothing and turns an afternoon
# into a coffee break at a big store.
#
# These are deliberately modest -- about what a person clicking around the
# site would do. Set either to 1 if your dealership's website is slow or
# complains.
DETAIL_WORKERS = 5        # vehicle pages read at the same time
PHOTO_WORKERS = 6         # vehicles whose photos download at the same time

HEADLESS = True
PAGE_TIMEOUT_MS = 60_000
FETCH_DETAIL_PHOTOS = True
DETAIL_DELAY_MS = 750

# How many pictures of each car to pull down. Facebook allows 20 on a
# vehicle listing. More photos sell better; more photos also take longer
# to download.
#
# Do not edit this by hand -- the salesman sets it in the window under
# Settings, and that choice is kept in settings.json and applied below.
MAX_PHOTOS_PER_VEHICLE = 16

# --- the store --------------------------------------------------------------
DEALER_NAME = "Your Dealership"
DEALER_ID = "your-dealership"
DEALER_ADDR1 = ""
DEALER_CITY = ""
DEALER_REGION = ""
DEALER_POSTAL = ""
DEALER_COUNTRY = "US"
DEALER_LATITUDE = ""
DEALER_LONGITUDE = ""

# Your cell, so leads reach you and not a switchboard.
DEALER_PHONE = ""

FEED_PRICE_FIELD = "final"
CURRENCY = "USD"
FEED_PRICE_INCLUDES_DOC_FEE = False

# --- you --------------------------------------------------------------------
SELLER_NAME = ""
SELLER_FIRST_NAME = ""
SELLER_TITLE = "Sales Representative"

# A label, printed in the ads as "Call or Text Me Directly: <your number>"
SELLER_CONTACT = "Call or Text Me Directly"
# A verb, spliced into a sentence: "Call or text me at <your number> if..."
SELLER_CONTACT_VERB = "call or text"

STORE_SHORT = "Your Dealership"
STORE_FULL = "Your Dealership"
STORE_ADDRESS_LINE = ""

EMOJI_STYLE = "light"
WHY_BUY_NAME = "Your Dealership"

# --- the slice you work -----------------------------------------------------
# 0 means you work the whole lot. That is how it ships, and it is what most
# people want.
#
# If you would rather only see part of the lot -- say you do well under
# fifteen thousand and want the expensive units out of your way -- put that
# number here instead of the 0:
#
#     FOCUS_MAX_PRICE = 15000
#
# The rest of the lot is still read and still watched; it just is not put in
# front of you. Anything you already have posted keeps showing either way, so
# turning this on will never hide a live listing from you.
FOCUS_MAX_PRICE = 0

# The rest of the slice. All of these are set in the window under Settings;
# anything left empty means no limit. They only decide what is PUT IN FRONT
# OF YOU -- a vehicle you have already posted keeps showing for price drops
# and take-downs whatever it is, so a filter can never lose a live listing.
FOCUS_MIN_PRICE = 0        # e.g. 5000 to skip the cheap ones
FOCUS_YEAR_MIN = 0         # e.g. 2018 for 2018 and newer
FOCUS_YEAR_MAX = 0
FOCUS_MAKES = []           # e.g. ["Ford", "Chevrolet"]
FOCUS_MODELS = []          # e.g. ["F-150", "Silverado"]
FOCUS_BODIES = []          # e.g. ["Truck", "SUV"]
FOCUS_STOCK_PREFIX = ""    # e.g. "NT" for one store's stock numbers

# Two kinds of car rather than two more lists. Turning both on shows both
# groups, not only the cars that happen to be in both.
FOCUS_CERTIFIED_ONLY = False    # only Certified Pre-Owned
FOCUS_SPECIALS_ONLY = False     # only Manager's Specials and price drops
# "used" (default), "new", or "all". Franchise stores list their new cars on
# the same site; Joe Holland's run was 101 new and 30 used.
FOCUS_CONDITION = "used"

# --- very large stores ----------------------------------------------------
# Some dealer websites list two or three thousand vehicles -- usually because
# the store belongs to a big organisation and the page shows the whole group's
# inventory. If a run would take longer than this many hours, the program
# stops and says so instead of starting. Judged on the cars that are actually
# at HIS store, not the website's headline count.
BIG_LOT_HOURS = 2.5
# A run holding less than this share of the last one is treated as a broken
# read and refused, even when the website never printed its own car count.
# A lot does not lose 40% of its inventory overnight.
COLLAPSE_FLOOR = 0.60
# Ticked in Settings to say "yes, read the whole store anyway".
BIG_LOT_OK = False
# Measured, not guessed: 81 vehicles took twenty minutes with photos.
SECONDS_PER_CAR = 15.0
SECONDS_PER_PAGE = 12.0

# How big a website price move has to be before you hear about it. The site's
# retail, savings and doc-fee figures do not always reconcile to the penny.
PRICE_CHANGE_MIN = 50

# --- Sendible (company page scheduling; unused by the window) ---------------
SENDIBLE_CSV = OUT / "sendible_bulk_import.csv"
SENDIBLE_START_DATE = ""
SENDIBLE_TIMES = ["10:15"]
SENDIBLE_SKIP_WEEKENDS = False
SENDIBLE_DATE_FORMAT = "%Y-%m-%d %H:%M"
SENDIBLE_SELECT = "all"
SENDIBLE_LIMIT = 0
SENDIBLE_HASHTAGS = ""


# --- what the salesman chose in the window ----------------------------------
# Everything above is the factory setting. Anything he has picked under
# Settings lives in settings.json beside this file and wins over it, so a
# new copy of the program never wipes out his choices.
#
# Nothing here will crash if that file is missing, empty or hand-mangled --
# a bad value is simply ignored and the factory setting stands.
SETTINGS_FILE = STORE_DIR / "settings.json"


def _apply_saved_settings():
    import json as _json
    try:
        with open(SETTINGS_FILE, encoding="utf-8") as fh:
            saved = _json.load(fh)
        if not isinstance(saved, dict):
            return
    except Exception:
        return

    g = globals()

    n = saved.get("max_photos")
    if isinstance(n, int) and 1 <= n <= 20:
        g["MAX_PHOTOS_PER_VEHICLE"] = n

    # --- the slice he works -----------------------------------------------
    for key, name, hi in (("focus_max_price", "FOCUS_MAX_PRICE", 1_000_000),
                          ("focus_min_price", "FOCUS_MIN_PRICE", 1_000_000),
                          ("focus_year_min", "FOCUS_YEAR_MIN", 2100),
                          ("focus_year_max", "FOCUS_YEAR_MAX", 2100)):
        n = saved.get(key)
        if isinstance(n, bool):
            continue
        if isinstance(n, (int, float)) and 0 <= n <= hi:
            g[name] = int(n)

    for key, name in (("focus_makes", "FOCUS_MAKES"),
                      ("focus_models", "FOCUS_MODELS"),
                      ("focus_bodies", "FOCUS_BODIES")):
        v = saved.get(key)
        if isinstance(v, list):
            g[name] = [str(x).strip() for x in v if str(x).strip()][:60]
        elif isinstance(v, str):
            g[name] = [x.strip() for x in v.replace(",", "\n").split("\n")
                       if x.strip()][:60]

    v = saved.get("focus_stock_prefix")
    if isinstance(v, str):
        g["FOCUS_STOCK_PREFIX"] = v.strip()

    v = saved.get("focus_condition")
    if v in ("used", "new", "all"):
        g["FOCUS_CONDITION"] = v

    for key, name in (("focus_certified_only", "FOCUS_CERTIFIED_ONLY"),
                      ("focus_specials_only", "FOCUS_SPECIALS_ONLY"),
                      ("big_lot_ok", "BIG_LOT_OK")):
        v = saved.get(key)
        if isinstance(v, bool):
            g[name] = v

    s = saved.get("emoji_style")
    if s in ("heavy", "light", "none"):
        g["EMOJI_STYLE"] = s

    # --- what the salesman typed on the setup screen ----------------------
    def txt(key):
        v = saved.get(key)
        return v.strip() if isinstance(v, str) and v.strip() else None

    store = txt("store_name")
    addr1 = txt("address")
    city = txt("city")
    state = txt("state")
    zipc = txt("zip")
    phone = txt("phone")
    first = txt("first_name")
    full = txt("full_name")
    url = txt("inventory_url")

    if store:
        g["DEALER_NAME"] = store
        g["WHY_BUY_NAME"] = store
        g["STORE_FULL"] = store
        g["STORE_SHORT"] = f"{store} in {city}" if city else store
        g["DEALER_ID"] = re.sub(r"[^a-z0-9]+", "-", store.lower()).strip("-")
    # How the store is named in the middle of a sentence ("...here at
    # Moses Factory Outlet in Teays Valley"). Optional; carried over from
    # older copies of the program.
    short = txt("store_short")
    if short:
        g["STORE_SHORT"] = short
    if addr1:
        g["DEALER_ADDR1"] = addr1
    if city:
        g["DEALER_CITY"] = city
    if state:
        g["DEALER_REGION"] = state
    if zipc:
        g["DEALER_POSTAL"] = zipc
    if addr1 and city and state:
        g["STORE_ADDRESS_LINE"] = f"{addr1}, {city}, {state} {zipc or ''}".strip()
    if phone:
        g["DEALER_PHONE"] = phone
    if first:
        g["SELLER_FIRST_NAME"] = first
    if full:
        g["SELLER_NAME"] = full
    elif first:
        g["SELLER_NAME"] = first

    if url:
        g["INVENTORY_URL"] = url
        m = re.match(r"(https?://[^/]+)", url)
        if m:
            g["SITE_ROOT"] = m.group(1)
        # Most dealer platforms page with one of a handful of query names.
        # Whichever one is already in his URL is the one to walk.
        # "pn" is NOT one of them: on DealerOn sites (searchused.aspx) it is
        # how many cars to show per page, and pt is the page number. Paging
        # with pn would ask for "2 per page" instead of page 2.
        for param in ("pt", "_p", "page"):
            if re.search(rf"[?&]{param}=", url):
                g["PAGE_PARAM"] = param
                break

    # A store brought in from an older copy keeps its photos where they
    # already are, rather than moving gigabytes of pictures around.
    feed = txt("feed_source")
    if feed:
        g["FEED_SOURCE"] = feed
    try:
        g["FEED_ADD_FEE"] = max(0, int(saved.get("feed_add_fee") or 0))
    except (TypeError, ValueError):
        pass

    pd = txt("photo_drop")
    if pd:
        g["PHOTO_DROP"] = Path(pd)

    n = saved.get("max_pages")
    if isinstance(n, int) and n > 0:
        g["MAX_PAGES"] = n


def is_set_up() -> bool:
    """True once the salesman has filled in the setup screen."""
    try:
        import json as _json
        with open(SETTINGS_FILE, encoding="utf-8") as fh:
            saved = _json.load(fh)
        return bool(saved.get("store_name")
                    and (saved.get("inventory_url") or saved.get("feed_source"))
                    and saved.get("accepted_terms"))
    except Exception:
        return False


_apply_saved_settings()
