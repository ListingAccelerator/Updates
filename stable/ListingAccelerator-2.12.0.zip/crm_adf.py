"""
crm_adf.py -- hand a customer to the dealer CRM as a lead.

Dealer CRMs (VinSolutions, DealerSocket, Elead and the rest) take new leads
by email in one standard format, ADF ("Auto-lead Data Format", XML). It's how
Cars.com and CarGurus leads get in. Each store's CRM has a lead address; the
store's CRM administrator or internet manager has it.

The program writes the lead -- name, phone, email, the vehicle with its VIN,
stock number and price, the trade, the appointment, the notes -- and opens it
in an email to that address from his own email program. He presses Send.
Nothing is sent without him.
"""
from __future__ import annotations

import json
import re
import urllib.parse
from datetime import datetime
from pathlib import Path
from xml.sax.saxutils import escape


def _x(v) -> str:
    return escape(str(v or "").strip())


def _split_name(name: str) -> tuple[str, str]:
    bits = str(name or "").strip().split()
    if not bits:
        return "", ""
    if len(bits) == 1:
        return bits[0], ""
    return bits[0], " ".join(bits[1:])


def store_settings(store_key: str | None) -> dict:
    try:
        import stores
        d = stores.store_dir(store_key) if store_key else None
        if d and (d / "settings.json").exists():
            return json.loads((d / "settings.json").read_text(encoding="utf-8"))
    except Exception:
        pass
    try:
        import config
        return json.loads(Path(config.SETTINGS_FILE).read_text(encoding="utf-8"))
    except Exception:
        return {}


def adf(c: dict, view: dict, st: dict) -> str:
    """The ADF XML for one customer."""
    first, last = _split_name(c.get("name", ""))
    now = datetime.now().astimezone().isoformat(timespec="seconds")
    L = ['<?xml version="1.0" encoding="UTF-8"?>', '<?adf version="1.0"?>', "<adf>",
         '  <prospect status="new">', f"    <requestdate>{now}</requestdate>"]
    for car in view.get("cars") or []:
        rec = car.get("rec") or {}
        status = "new" if str(rec.get("condition", "")).lower() == "new" else "used"
        L.append(f'    <vehicle interest="buy" status="{status}">')
        name = str(car.get("name") or "")
        m = re.match(r"(\d{4})\s+(\S+)\s+(.*)", name)
        year = rec.get("year") or (m.group(1) if m else "")
        make = rec.get("make") or (m.group(2) if m else "")
        model = rec.get("model") or (m.group(3) if m else name)
        if year:
            L.append(f"      <year>{_x(year)}</year>")
        if make:
            L.append(f"      <make>{_x(make)}</make>")
        if model:
            L.append(f"      <model>{_x(model)}</model>")
        if rec.get("trim"):
            L.append(f"      <trim>{_x(rec['trim'])}</trim>")
        if rec.get("vin") or car.get("vin"):
            L.append(f"      <vin>{_x(rec.get('vin') or car.get('vin'))}</vin>")
        if car.get("stock"):
            L.append(f"      <stock>{_x(car['stock'])}</stock>")
        if rec.get("mileage") or car.get("miles"):
            L.append(f'      <odometer status="original" units="mi">{_x(rec.get("mileage") or car.get("miles"))}</odometer>')
        if isinstance(car.get("price"), (int, float)) and car["price"]:
            L.append(f'      <price type="asking" currency="USD">{int(car["price"])}</price>')
        L.append("    </vehicle>")
    if c.get("trade"):
        L += ['    <vehicle interest="trade-in" status="used">',
              f"      <comments>{_x(c['trade'])}</comments>", "    </vehicle>"]
    L += ["    <customer>", "      <contact>"]
    if first:
        L.append(f'        <name part="first">{_x(first)}</name>')
    if last:
        L.append(f'        <name part="last">{_x(last)}</name>')
    if c.get("email"):
        L.append(f"        <email>{_x(c['email'])}</email>")
    if c.get("phone"):
        L.append(f'        <phone type="voice" time="nopreference">{_x(c["phone"])}</phone>')
    if c.get("address"):
        L += ["        <address>", f'          <street line="1">{_x(c["address"])}</street>', "        </address>"]
    L.append("      </contact>")
    notes = []
    if c.get("wants"):
        notes.append("Wants: " + ", ".join(c["wants"]))
    if c.get("looking_for"):
        notes.append("New or used: " + c["looking_for"])
    if c.get("appointment"):
        try:
            t = datetime.fromisoformat(c["appointment"])
            notes.append("Appointment: " + t.strftime("%a %b %d, %Y %I:%M %p").replace(" 0", " "))
        except ValueError:
            notes.append(f"Appointment: {c['appointment']}")
    notes += [n.get("text", "") for n in (c.get("notes") or [])][-3:]
    chat = [n.get("text", "") for n in (c.get("chat") or [])][:1]
    if chat:
        notes.append("First message: " + chat[0][:400])
    seller = st.get("full_name") or st.get("first_name") or ""
    if seller:
        notes.append(f"Salesperson: {seller}")
    if notes:
        L.append(f"      <comments>{_x(' | '.join(n for n in notes if n))}</comments>")
    L.append("    </customer>")
    store = st.get("store_name") or ""
    L += ["    <vendor>", f"      <vendorname>{_x(store)}</vendorname>"]
    if seller:
        L += ["      <contact primarycontact=\"1\">", f'        <name part="full">{_x(seller)}</name>']
        if st.get("phone"):
            L.append(f'        <phone type="voice">{_x(st["phone"])}</phone>')
        L.append("      </contact>")
    L += ["    </vendor>", "    <provider>",
          f'      <name part="full">{_x(st.get("crm_source") or "Facebook Marketplace")}</name>',
          "      <service>Listing Accelerator</service>", "    </provider>",
          "  </prospect>", "</adf>"]
    return "\n".join(L)


def mail_link(to: str, subject: str, body: str) -> str:
    q = urllib.parse.urlencode({"subject": subject, "body": body}, quote_via=urllib.parse.quote)
    return f"mailto:{urllib.parse.quote(to, safe='@.+-_')}?{q}"


def valid_email(s: str) -> bool:
    return bool(re.fullmatch(r"[^@\s,;]+@[^@\s,;]+\.[A-Za-z]{2,}", str(s or "").strip()))
