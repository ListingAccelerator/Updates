"""
scrape_details.py -- fill in paint, engine, transmission and the full option
list by visiting each vehicle's detail page.

The search page carries almost nothing: color is a swatch, and engine and
transmission aren't on the card at all. Those live on the VDP, so this walks
them one at a time and merges what it finds back into out/inventory.json.

It tries three sources per page, best first:

  1. JSON-LD (<script type="application/ld+json">). Most dealer platforms emit
     a schema.org Vehicle object with color, vehicleEngine and
     vehicleTransmission already structured. When it's there it's exact, and
     no DOM guessing is needed.
  2. Inline data blobs the SPA hydrates from.
  3. Label/value pairs in the rendered DOM -- dl/dt/dd, table rows, and
     adjacent siblings where one side is a known spec label.

Resumable: a vehicle that already has engine + color is skipped, so a crash or
a Ctrl-C costs you only the page it was on. Re-run and it picks up.

Usage:
    python scrape_details.py
    python scrape_details.py --stock OW26451      # one vehicle
    python scrape_details.py --force              # re-scrape everything
    python scrape_details.py --show               # visible browser
    python scrape_details.py --limit 5            # try a handful first
"""
from __future__ import annotations

import argparse
import asyncio
import json
import re
import sys

import config

SPEC_JS = r"""
() => {
  const out = {jsonld: [], pairs: {}, options: []};

  // ---- 1. JSON-LD -------------------------------------------------------
  document.querySelectorAll('script[type="application/ld+json"]').forEach(s => {
    try { out.jsonld.push(JSON.parse(s.textContent)); } catch (e) {}
  });

  // ---- 2. inline hydration blobs ----------------------------------------
  for (const k of ['__INITIAL_STATE__','__NEXT_DATA__','__DATA__','vdpData']) {
    try { if (window[k]) out.pairs['_blob_' + k] = JSON.stringify(window[k]).slice(0, 400000); }
    catch (e) {}
  }

  // ---- 3. label / value pairs in the DOM --------------------------------
  const LABELS = ['exterior color','interior color','exterior','interior',
    'engine','transmission','drivetrain','drive type','fuel type','fuel economy',
    'body style','body','doors','horsepower','vin','stock','stock number',
    'mileage','odometer','cylinders','mpg'];
  const norm = s => (s || '').replace(/\s+/g,' ').replace(/[: ]/g,'').trim().toLowerCase();

  // dl / dt / dd
  document.querySelectorAll('dl').forEach(dl => {
    const dts = dl.querySelectorAll('dt'), dds = dl.querySelectorAll('dd');
    for (let i = 0; i < Math.min(dts.length, dds.length); i++) {
      const k = norm(dts[i].innerText);
      if (LABELS.includes(k)) out.pairs[k] = (dds[i].innerText || '').trim();
    }
  });

  // table rows
  document.querySelectorAll('tr').forEach(tr => {
    const c = tr.querySelectorAll('th,td');
    if (c.length >= 2) {
      const k = norm(c[0].innerText);
      if (LABELS.includes(k)) out.pairs[k] = (c[1].innerText || '').trim();
    }
  });

  // adjacent siblings / small containers holding "Label: Value"
  document.querySelectorAll('div,span,li,p').forEach(el => {
    if (el.children.length > 3) return;
    const t = (el.innerText || '').trim();
    if (!t || t.length > 120) return;
    const m = t.match(/^([A-Za-z .\/]{3,22})\s*:\s*(.+)$/);
    if (m) {
      const k = norm(m[1]);
      if (LABELS.includes(k) && !out.pairs[k]) out.pairs[k] = m[2].trim();
      return;
    }
    // label element followed by its value element
    const k = norm(t);
    if (LABELS.includes(k)) {
      const sib = el.nextElementSibling;
      if (sib) {
        const v = (sib.innerText || '').trim();
        if (v && v.length < 120 && norm(v) !== k && !out.pairs[k]) out.pairs[k] = v;
      }
    }
  });

  // ---- option / feature lists -------------------------------------------
  // Nav menus are also <ul> lists of short items, so they have to be ruled
  // out explicitly: by where they sit, by being mostly links, and by reading
  // like single-word labels rather than option names.
  document.querySelectorAll('ul,ol').forEach(ul => {
    if (ul.closest('nav,header,footer,[role="navigation"]')) return;
    if (/\b(nav|menu|breadcrumb|pagination|tabs?|social|footer|header)\b/i
        .test(ul.className + ' ' + ul.id)) return;

    const lis = Array.from(ul.querySelectorAll('li'));
    if (!lis.length) return;
    const linky = lis.filter(li => li.querySelector('a')).length;
    if (linky > lis.length / 2) return;

    const items = lis
      .map(li => (li.innerText || '').trim())
      .filter(s => s && s.length > 2 && s.length < 90 && !/^\d+$/.test(s));
    if (items.length < 4 || items.length >= 120) return;

    const oneWord = items.filter(s => !/\s/.test(s)).length;
    if (oneWord > items.length * 0.6) return;
    const avg = items.reduce((a, s) => a + s.length, 0) / items.length;
    if (avg < 8) return;

    out.options.push(...items);
  });
  out.options = Array.from(new Set(out.options));

  // ---- 4. is this the car, or the site's "are you human" screen? ---------
  const txt = (document.body && document.body.innerText) || '';
  out.challenge = /verifying you are human|enable javascript and cookies to continue/i.test(txt)
    || /just a moment/i.test(document.title || '');
  return out;
}
"""

COLOR_NOISE = re.compile(r"\b(exterior|interior|color|colour)\b", re.I)

TAGS = re.compile(r"<[^>]+>")


class Challenge(Exception):
    """The site answered with a verification page instead of the car."""


def strip_html(s: str) -> str:
    return " ".join(TAGS.sub(" ", s or "").split())


def from_description(rec: dict, blobs) -> list[str]:
    """
    The dealership's own VDP description carries what the structured fields
    don't: the real engine, the equipment run, and the CARFAX status the store
    itself publishes.

    On One Owner / No Accidents: this reads YOUR site's own published claim
    rather than generating one. That is a real difference -- the store has
    already made the representation. Still worth a glance against the actual
    report before posting, since a website blurb can go stale.
    """
    got: list[str] = []

    def walk(node, out):
        if isinstance(node, list):
            for n in node:
                walk(n, out)
        elif isinstance(node, dict):
            d = node.get("description")
            if isinstance(d, str) and len(d) > 200:
                out.append(d)
            for v in node.values():
                walk(v, out)

    descs: list[str] = []
    walk(blobs, descs)
    if not descs:
        return got
    text = strip_html(max(descs, key=len))

    if not rec.get("one_owner") and re.search(r"\bone owner\b", text, re.I):
        rec["one_owner"] = True
        got.append("one_owner")
    if not rec.get("clean_title") and re.search(
            r"\bno accidents?\b|\bclean (title|carfax)\b", text, re.I):
        rec["clean_title"] = True
        got.append("clean_title")

    # "ENGINE: 3.6L V6 24V VVT UPG I W/ESS, TRANSMISSION: ..." -- the real one
    m = re.search(r"\bENGINE:\s*([^,]{4,70}?)(?:,|\s+TRANSMISSION\b)", text, re.I)
    if m:
        eng = " ".join(m.group(1).split())
        if eng and not re.fullmatch(r"(V\d|I\d|\d)[\s-]*cylinder(\s+engine)?",
                                    eng, re.I):
            rec["engine_full"] = eng
            got.append("engine_full")
    return got


def from_options(rec: dict, opts: list[str]) -> list[str]:
    """Mine the option list for the specifics the ads actually use."""
    got: list[str] = []

    def grab(field, pattern, clean=True):
        if rec.get(field):
            return
        for o in opts:
            m = re.match(pattern, o.strip(), re.I)
            if m:
                v = " ".join(m.group(1).split())
                if clean and re.fullmatch(
                        r"(V\d|I\d|\d)[\s-]*cylinder(\s+engine)?", v, re.I):
                    continue
                if v:
                    rec[field] = v
                    got.append(field)
                    return

    grab("engine_full", r"Engine:\s*(.+)")
    grab("infotainment", r"Radio:\s*(.+)")
    grab("wheels", r"Wheels?:\s*(.+)")
    grab("tires", r"Tires?:\s*(.+)")

    if not rec.get("mpg_city"):
        for o in opts:
            m = re.search(r"City \(MPG\):\s*(\d+)", o, re.I)
            if m:
                rec["mpg_city"] = int(m.group(1))
                got.append("mpg_city")
        for o in opts:
            m = re.search(r"Hwy \(MPG\):\s*(\d+)", o, re.I)
            if m:
                rec["mpg_hwy"] = int(m.group(1))
    return got


def walk_jsonld(blobs) -> dict:
    """Pull Vehicle fields out of any schema.org object in the page."""
    found: dict = {}

    def visit(node):
        if isinstance(node, list):
            for n in node:
                visit(n)
            return
        if not isinstance(node, dict):
            return
        t = node.get("@type", "")
        types = t if isinstance(t, list) else [t]
        if any(str(x) in ("Vehicle", "Car", "Product", "Offer") for x in types):
            for src, dst in (("color", "exterior_color"),
                             ("vehicleInteriorColor", "interior_color"),
                             ("vehicleTransmission", "transmission"),
                             ("bodyType", "body_style"),
                             ("fuelType", "fuel_type"),
                             ("driveWheelConfiguration", "drivetrain"),
                             ("vehicleIdentificationNumber", "vin"),
                             ("sku", "stock_ld")):
                v = node.get(src)
                if isinstance(v, dict):
                    v = v.get("name") or v.get("value")
                if isinstance(v, str) and v.strip() and dst not in found:
                    found[dst] = v.strip()
            eng = node.get("vehicleEngine")
            if isinstance(eng, dict):
                name = (eng.get("name") or "").strip()
                disp = eng.get("engineDisplacement")
                if isinstance(disp, dict):
                    disp = f"{disp.get('value','')}{disp.get('unitText','')}".strip()
                power = eng.get("enginePower")
                if isinstance(power, dict):
                    power = power.get("value")
                label = name or " ".join(str(x) for x in (disp,) if x)
                if label and "engine" not in found:
                    found["engine"] = label
                if power and "horsepower" not in found:
                    try:
                        found["horsepower"] = int(float(power))
                    except (TypeError, ValueError):
                        pass
            elif isinstance(eng, str) and eng.strip() and "engine" not in found:
                found["engine"] = eng.strip()
        for v in node.values():
            visit(v)

    visit(blobs)
    return found


def clean_color(v: str) -> str:
    v = COLOR_NOISE.sub("", v).replace(":", "").strip(" ·-–")
    return " ".join(v.split())


def merge(rec: dict, spec: dict) -> list[str]:
    """Merge scraped spec into rec. Returns the field names actually filled."""
    filled = []
    ld = walk_jsonld(spec.get("jsonld") or [])
    pairs = {k: v for k, v in (spec.get("pairs") or {}).items()
             if not k.startswith("_blob_")}

    def take(field, *candidates):
        if rec.get(field):
            return
        for c in candidates:
            if c and str(c).strip():
                val = str(c).strip()
                if field.endswith("color"):
                    val = clean_color(val)
                if val:
                    rec[field] = val
                    filled.append(field)
                    return

    take("exterior_color", ld.get("exterior_color"),
         pairs.get("exterior color"), pairs.get("exterior"))
    take("interior_color", ld.get("interior_color"),
         pairs.get("interior color"), pairs.get("interior"))
    take("engine", ld.get("engine"), pairs.get("engine"))
    take("transmission", ld.get("transmission"), pairs.get("transmission"))
    take("drivetrain", ld.get("drivetrain"), pairs.get("drivetrain"),
         pairs.get("drive type"))
    take("fuel_type", ld.get("fuel_type"), pairs.get("fuel type"))

    if not rec.get("horsepower"):
        hp = ld.get("horsepower")
        if not hp:
            m = re.search(r"(\d{3,4})\s*(?:hp|horsepower)",
                          f"{pairs.get('horsepower','')} {rec.get('engine','')}",
                          re.I)
            hp = m.group(1) if m else None
        if hp:
            rec["horsepower"] = int(hp)
            filled.append("horsepower")

    opts = spec.get("options") or []
    filled += from_description(rec, spec.get("jsonld") or [])
    filled += from_options(rec, opts)

    if opts:
        have = set(rec.get("features") or [])
        extra = [o for o in opts if o not in have]
        if extra:
            rec["options"] = extra[:60]
            filled.append(f"options({len(extra[:60])})")
    return filled


def worker_count() -> int:
    """
    How many of the store's vehicle pages to read at the same time.

    This is the slowest step in the whole program by a long way: it opens
    every single car's own page and waits for it to render. Done one at a
    time, a 480-car store takes the better part of an hour. Done a handful
    at a time it takes minutes, because nearly all of that hour is spent
    waiting on the website rather than doing anything.

    Five is deliberately modest. It is a few more requests at once than a
    salesman clicking around the site would make, and nothing like enough to
    trouble a dealership web host. Set DETAIL_WORKERS = 1 in config.py to go
    back to one at a time.
    """
    n = getattr(config, "DETAIL_WORKERS", 5)
    try:
        n = int(n)
    except (TypeError, ValueError):
        return 5
    return max(1, min(n, 12))


async def visit_all(todo, records, args, filled_tally, failures, workers=None) -> None:
    """Read every car's page, a few at a time, and merge what comes back."""
    from playwright.async_api import async_playwright

    workers = min(workers or worker_count(), len(todo))
    jobs: asyncio.Queue = asyncio.Queue()
    for i, rec in enumerate(todo, 1):
        jobs.put_nowait((i, rec))

    total = len(todo)
    done = 0
    saved_debug = False

    print(f"Visiting {total} vehicle page(s), {workers} at a time...\n")

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=not args.show)
        ctx = await browser.new_context(
            viewport={"width": 1500, "height": 1000},
            user_agent=("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                        "AppleWebKit/537.36 (KHTML, like Gecko) "
                        "Chrome/124.0 Safari/537.36"),
        )

        async def one_worker():
            nonlocal done, saved_debug
            page = await ctx.new_page()
            try:
                while True:
                    try:
                        i, rec = jobs.get_nowait()
                    except asyncio.QueueEmpty:
                        return
                    stock = rec.get("stock", "?")
                    try:
                        await page.goto(rec["detail_url"],
                                        timeout=config.PAGE_TIMEOUT_MS,
                                        wait_until="domcontentloaded")
                        await page.wait_for_timeout(config.DETAIL_DELAY_MS)
                        for _ in range(6):
                            await page.mouse.wheel(0, 1800)
                            await page.wait_for_timeout(250)
                        spec = await page.evaluate(SPEC_JS)
                        # The verification screen can clear on its own.
                        # Give it a moment, then refuse it rather than save
                        # an empty page as if it were the car.
                        waited = 0
                        while spec.get('challenge') and waited < 20000:
                            await page.wait_for_timeout(2000)
                            waited += 2000
                            spec = await page.evaluate(SPEC_JS)
                        if spec.get('challenge'):
                            raise Challenge('the site showed its verification screen instead of the car')
                    except Exception as e:
                        done += 1
                        rec['detail_failed'] = True
                        rec['detail_error'] = str(e)[:200]
                        print(f"  [{done}/{total}] {stock}  FAILED: {e}")
                        failures.append(stock)
                        continue

                    if not saved_debug:
                        # Keep one page so extraction problems stay findable.
                        saved_debug = True
                        try:
                            (config.OUT / "debug_detail_page.html").write_text(
                                await page.content(), encoding="utf-8")
                            (config.OUT / "debug_detail_spec.json").write_text(
                                json.dumps(spec, indent=2)[:400000],
                                encoding="utf-8")
                        except Exception:
                            pass

                    # merge() and the counters are plain synchronous code and
                    # this is one thread, so no two workers can be inside
                    # here at once. Nothing to lock.
                    got = merge(rec, spec)
                    usable = bool(rec.get('exterior_color') or rec.get('engine'))
                    rec['detail_failed'] = not usable
                    rec['detail_error'] = None if usable else \
                        'page loaded but no vehicle details were found'
                    for g in got:
                        filled_tally[g.split("(")[0]] += 1
                    done += 1
                    shown = ", ".join(got) if got else "nothing found"
                    print(f"  [{done}/{total}] {stock:10s} {shown}")

                    if done % 25 == 0:
                        try:
                            config.INVENTORY_JSON.write_text(
                                json.dumps(records, indent=2),
                                encoding="utf-8")
                        except Exception:
                            pass
            finally:
                try:
                    await page.close()
                except Exception:
                    pass

        await asyncio.gather(*(one_worker() for _ in range(workers)))
        await browser.close()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--stock")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--show", action="store_true")
    args = ap.parse_args()

    if getattr(config, "FEED_SOURCE", ""):
        print("This store's cars come from its inventory feed -- the feed already has")
        print("the paint, engine and photos, so the website isn't opened.")
        return 0

    if not config.INVENTORY_JSON.exists():
        print(f"No inventory at {config.INVENTORY_JSON}")
        print("Run: python scrape_inventory.py")
        return 1

    records = json.loads(config.INVENTORY_JSON.read_text(encoding="utf-8"))

    # Only the cars he actually works get their detail page read.
    #
    # Reading every card is cheap and we want all of them, because that is
    # what tells us which cars have sold. Reading a detail page per car is
    # not cheap, and at a store with two thousand vehicles it is most of the
    # run. So the whole lot is still KNOWN, while the slow work is spent only
    # on the slice he is going to post.
    import track
    f = track.focus()
    narrowed = track.focus_is_on(f)
    skipped_focus = 0
    skipped_other = 0

    todo = []
    for r in records:
        if args.stock and r.get("stock") != args.stock:
            continue
        if not r.get("detail_url"):
            continue
        if not args.force and r.get("engine") and r.get("exterior_color"):
            continue
        if not args.stock and track.is_other_store(r):
            skipped_other += 1
            continue
        if narrowed and not args.stock and not track.in_focus(r, f):
            skipped_focus += 1
            continue
        todo.append(r)
    if args.limit:
        todo = todo[: args.limit]

    if skipped_other:
        print(f"Skipping {skipped_other} vehicle(s) that are at another "
              f"store, not yours.\n")
    if skipped_focus:
        print(f"Skipping {skipped_focus} vehicle(s) outside what you work "
              f"({track.focus_wording()}).")
        print("They stay in your inventory list -- just not looked up.\n")

    if not todo:
        print("Nothing to do. Every vehicle already has engine + color, "
              "or none have a detail_url (re-run scrape_inventory.py).")
        return 0

    missing_url = [r.get("stock") for r in records if not r.get("detail_url")]
    if missing_url:
        print(f"note: {len(missing_url)} vehicle(s) have no detail_url and "
              f"will be skipped\n")

    from collections import Counter
    filled_tally: Counter = Counter()
    failures: list[str] = []

    asyncio.run(visit_all(todo, records, args, filled_tally, failures))

    # One more try for anything that failed, one page at a time, so a busy
    # moment on the website does not cost a car its details.
    if failures:
        again = [r for r in todo if r.get('stock') in set(failures)]
        print(f'\nTrying the {len(again)} page(s) that failed once more, one at a time...\n')
        failures = []
        asyncio.run(visit_all(again, records, args, filled_tally, failures,
                              workers=1))

    config.INVENTORY_JSON.write_text(json.dumps(records, indent=2),
                                     encoding="utf-8")

    total = len(records)
    print(f"\nSaved {config.INVENTORY_JSON}")
    print("Coverage across all inventory:")
    for f in ("exterior_color", "interior_color", "engine", "transmission",
              "horsepower", "drivetrain", "fuel_type"):
        n = sum(1 for r in records if r.get(f))
        print(f"  {f:16s} {n}/{total}")
    if failures:
        print(f"\n  {len(failures)} page(s) failed: {', '.join(failures[:12])}")
    if not filled_tally:
        print("\n  Nothing extracted. The first page is saved as "
              "out/debug_detail_page.html\n  and what the extractor saw is in "
              "out/debug_detail_spec.json --\n  send me those two and I'll fix "
              "the selectors.")
    print("\nThen re-run:  python build_jt_listings.py")
    return 0


if __name__ == "__main__":
    sys.exit(main())
