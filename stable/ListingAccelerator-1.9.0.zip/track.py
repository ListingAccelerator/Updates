"""
track.py -- keep track of what you posted, what to drop, and what to take down.

Posting is the easy part. Keeping 87 live listings honest is the work: sold cars
leave listings collecting dead messages, and day-two price drops only help if
you actually remember to do them.

You log a stock number when you post it. Everything else it works out by
comparing against the current inventory.

    python track.py                      today's to-do list
    python track.py post OW26451         posted it just now
    python track.py post OW26451 OW26483 several at once
    python track.py drop OW26451         dropped the price today
    python track.py down OW26451         took the listing down
    python track.py synced OW26451       matched it to the website's new price
    python track.py note OW26451 waiting on recon
    python track.py post-all             one-time: log everything as posted
    python track.py post-all 2026-10-05  ...on a specific date
    python track.py all                  everything you have posted

The record lives in out\\posted.csv and opens fine in Excel if you would rather
edit it by hand.
"""
from __future__ import annotations

import csv
import json
import re
import sys
from datetime import date, datetime

import config

LEDGER = config.OUT / "posted.csv"
COLS = ["Stock", "Vehicle", "Posted_Date", "Posted_Price", "Dropped_Date",
        "Dropped_Price", "Status", "Marketplace_URL", "Notes"]


def load() -> dict[str, dict]:
    if not LEDGER.exists():
        return {}
    with open(LEDGER, newline="", encoding="utf-8") as f:
        return {r["Stock"]: r for r in csv.DictReader(f) if r.get("Stock")}


def save(rows: dict[str, dict]) -> None:
    config.OUT.mkdir(parents=True, exist_ok=True)
    with open(LEDGER, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=COLS, extrasaction="ignore")
        w.writeheader()
        for stock in sorted(rows):
            row = {c: "" for c in COLS}
            row.update(rows[stock])
            w.writerow(row)


def inventory() -> dict[str, dict]:
    if not config.INVENTORY_JSON.exists():
        return {}
    recs = json.loads(config.INVENTORY_JSON.read_text(encoding="utf-8"))
    return {r["stock"]: r for r in recs if r.get("stock")}


def price_of(v: dict) -> int:
    """What you would actually ask for this one today."""
    return v.get("final_price") or v.get("moses_price") or 0


def post_price(v: dict) -> int:
    """
    What the ad says to post at -- the same rule the ads use.

    With a markdown (the site's retail is above its sale price) you post at
    retail and drop to the sale price a day later. With no markdown, you post
    at the sale price and there is NO drop. On the Moses sites the sale price
    includes the $575 doc fee, so when there's no savings the "retail" figure
    is $575 LOWER than the real price -- posting at it, then "dropping" to
    the real price, was really a $575 raise.
    """
    retail = v.get("retail_price")
    sale = price_of(v)
    if retail and sale and retail > sale:
        return retail
    return sale or retail or 0


def has_markdown(v: dict) -> bool:
    retail, sale = v.get("retail_price"), price_of(v)
    return bool(retail and sale and retail > sale)


def price_noise() -> int:
    """
    Smallest price move worth telling you about (config.PRICE_CHANGE_MIN).

    Set it to 1 to be told about every last dollar.
    """
    return max(1, getattr(config, "PRICE_CHANGE_MIN", 50) or 1)


def focus_max() -> int:
    """
    The price ceiling you work (config.FOCUS_MAX_PRICE). 0 means no ceiling.

    This only narrows what gets SUGGESTED to you. Anything already posted stays
    tracked whatever it costs -- if you listed a $38,000 truck it still shows up
    for price drops and take-downs.
    """
    return getattr(config, "FOCUS_MAX_PRICE", 0) or 0


def _as_list(v) -> list[str]:
    if not v:
        return []
    if isinstance(v, str):
        v = v.replace(",", "\n").split("\n")
    return [str(x).strip().lower() for x in v if str(x).strip()]


def focus() -> dict:
    """
    The slice of the lot this salesman works.

    Everything here is optional and anything left empty means "no limit".
    Someone who only sells trucks under fifteen sets a ceiling and a couple
    of makes; someone who works the whole lot sets nothing and gets all of it.
    """
    g = lambda k, d=0: getattr(config, k, d) or d          # noqa: E731
    return {
        "min_price": int(g("FOCUS_MIN_PRICE")),
        "max_price": int(g("FOCUS_MAX_PRICE")),
        "min_year": int(g("FOCUS_YEAR_MIN")),
        "max_year": int(g("FOCUS_YEAR_MAX")),
        "makes": _as_list(getattr(config, "FOCUS_MAKES", [])),
        "models": _as_list(getattr(config, "FOCUS_MODELS", [])),
        "bodies": _as_list(getattr(config, "FOCUS_BODIES", [])),
        "stock": _as_list(getattr(config, "FOCUS_STOCK_PREFIX", "")),
        # Two switches rather than lists: either you want only that kind of
        # car in front of you, or you do not mind either way.
        "certified": bool(getattr(config, "FOCUS_CERTIFIED_ONLY", False)),
        "specials": bool(getattr(config, "FOCUS_SPECIALS_ONLY", False)),
        # "used" (the default), "new", or "all".
        "condition": _condition_setting(),
    }


def _condition_setting() -> str:
    v = str(getattr(config, "FOCUS_CONDITION", "used") or "used").lower()
    return v if v in ("used", "new", "all") else "used"


_NEW_URL = re.compile(r"/new-(?:[A-Za-z+%20_.-]+-)?(?:19|20)\d{2}-", re.I)
_USED_URL = re.compile(r"/(?:used|certified|pre-?owned|cpo)-", re.I)


def condition_of(rec: dict) -> str:
    """
    "new" or "used" -- and "new" only on real evidence.

    Joe Holland's inventory came back as 101 brand-new cars and 30 used. The
    new ones would have gone into his Marketplace ads, and opening their
    pages one by one is what sets off the site's bot check.

    The evidence, in order: what the store's feed or the car's own page
    states outright; the car's web address ("/inventory/new-2026-chevrolet-…"
    against "/used-…"); a title that begins "New". Anything without evidence
    counts as used, because hiding a used car he could sell is the worse
    mistake.
    """
    said = str(rec.get("condition") or "").strip().lower()
    if said in ("new",):
        return "new"
    if said in ("used", "certified", "certified used", "pre-owned", "cpo"):
        return "used"
    url = str(rec.get("detail_url") or "")
    if _USED_URL.search(url):
        return "used"
    if _NEW_URL.search(url):
        return "new"
    for k in ("title", "model_trim", "name"):
        if str(rec.get(k) or "").strip().lower().startswith("new "):
            return "new"
    return "used"


BODY_NAMES = ["Truck", "SUV", "Sedan", "Coupe", "Van", "Minivan",
              "Hatchback", "Convertible", "Wagon"]


def pretty_body(s: str) -> str:
    """'suvs' -> 'SUVs', 'trucks' -> 'Trucks'. Title() mangles SUV."""
    t = str(s).strip()
    low = t.lower().rstrip("s")
    for name in BODY_NAMES:
        if name.lower() == low:
            return name + ("s" if t.lower().endswith("s") else "")
    return t.title()


def body_of(rec: dict) -> str:
    """
    Truck, SUV, Sedan and so on.

    Prefer what the website actually said. Only fall back to looking the
    model name up in a table when the site did not tell us, since that table
    cannot know every model ever built.
    """
    said = str(rec.get("body_style") or "").strip()
    if said:
        for name in BODY_NAMES:
            if name.lower() in said.lower():
                return name
        return said
    try:
        from build_fb_catalog import MODEL_TO_BODY
    except Exception:
        return ""
    return MODEL_TO_BODY.get(rec.get("model", ""), "")


def _host(u: str) -> str:
    from urllib.parse import urlsplit
    try:
        h = urlsplit(str(u or "")).netloc.lower()
    except Exception:
        return ""
    return h[4:] if h.startswith("www.") else h


def other_store(rec: dict) -> str:
    """
    Does this vehicle sit on somebody else's lot?

    Big franchise websites often list the whole dealer group's inventory, or
    nearby dealers' cars, on one used page. Those are not his to sell, and
    posting one is worse than the program failing outright -- a buyer drives
    an hour to see a truck that is three towns away.

    Returns a short reason when the car looks like another store's, or "".
    Deliberately conservative: it only says so on firm evidence, because
    wrongly excluding his own cars would be the worse mistake.
    """
    mine_host = _host(getattr(config, "SITE_ROOT", ""))
    url = str(rec.get("detail_url") or "")

    # The listing links off to a different dealership's website.
    if mine_host and url:
        h = _host(url)
        if h and h != mine_host:
            return f"listed on {h}"

    # Many sites put the car's town in its own address, e.g.
    #   /used-Hurricane+WV-2018-GMC-Sierra+1500-SLT-3GTU...
    my_city = str(getattr(config, "DEALER_CITY", "") or "").strip().lower()
    if my_city and url:
        m = re.search(r"/(?:used|new|certified)-([A-Za-z+%20_-]+?)-(?:19|20)\d{2}-",
                      url)
        if m:
            town = re.sub(r"[+_]|%20", " ", m.group(1)).strip().lower()
            town = re.sub(r"\s+[a-z]{2}$", "", town)      # drop trailing state
            # "certified-used-2026-toyota-..." is not a car in a town called
            # Used. Reading it as one excluded every Certified vehicle on the
            # lot -- which are the very cars worth posting first.
            CONDITION = {"used", "new", "certified", "pre owned", "pre-owned",
                         "preowned", "cpo", "certified used", "demo", "loaner"}
            # Compared loosely: he may type "Saint Albans" where the website
            # writes "St Albans" -- the Supercenter's addresses do.
            if town and town not in CONDITION \
                    and _town_key(town) != _town_key(my_city) \
                    and len(town) > 2:
                return f"at {town.title()}"

    # The card itself names a different store.
    my_name = str(getattr(config, "DEALER_NAME", "") or "").strip().lower()
    said = str(rec.get("selling_store") or rec.get("location") or "").strip()
    if said and my_name and my_name not in said.lower():
        if not any(w and w in said.lower()
                   for w in my_name.split() if len(w) > 3):
            return f"at {said}"

    return ""


def is_other_store(rec: dict) -> bool:
    # The reading step decides this once for the whole lot, with the
    # safeguards that need every car in view. Use its verdict when there is
    # one; only re-check a record it never looked at.
    if rec.get("store_checked"):
        return bool(rec.get("other_store"))
    return bool(rec.get("other_store") or other_store(rec))


_TOWN_WORDS = {"saint": "st", "st.": "st", "mount": "mt", "mt.": "mt",
               "fort": "ft", "ft.": "ft", "port": "pt", "north": "n",
               "south": "s", "east": "e", "west": "w"}


def _town_key(name: str) -> str:
    """'Saint Albans', 'St. Albans' and 'St Albans' all come out the same."""
    words = re.sub(r"[^a-z0-9. ]", " ", (name or "").lower()).split()
    words = [_TOWN_WORDS.get(w, w).rstrip(".") for w in words]
    return "".join(words)


def stock_prefixes(records: list[dict]) -> list[dict]:
    """
    The stock-number prefixes this lot uses, with a count for each.

    On a dealer-group website the quickest way to tell his cars from the rest
    of the group's is the stock number: at Victory Toyota every car on his lot
    starts 78F, and the other two hundred belong to sister stores. The store
    knows this; the program should not make him go and ask. So show him what
    is actually out there and let him tick one.

    Only prefixes shared by a real share of the lot are offered -- a prefix
    matching three cars out of four hundred is a coincidence, not a store.
    """
    stocks = [str(r.get("stock") or "").strip().upper()
              for r in records or []]
    stocks = [s for s in stocks if len(s) >= 4]
    if len(stocks) < 8:
        return []

    def head(s: str) -> str:
        # How stores actually number cars: either a letter code up front
        # ("NT6821A", "TCP1849A") or digits with a letter in them
        # ("78F05023"). Anything longer than three characters starts cutting
        # into the number itself, and a prefix that is too specific would
        # leave out cars that really are his.
        m = re.match(r"^[A-Z]{2,3}", s)
        return m.group(0) if m else s[:3]

    groups: dict[str, int] = {}
    for s in stocks:
        groups[head(s)] = groups.get(head(s), 0) + 1

    floor = max(3, int(len(stocks) * 0.08))
    big = {p: c for p, c in groups.items() if c >= floor}

    # The point of this is to separate HIS cars from the rest of a group's.
    # If the whole lot shares one prefix there is nothing to choose, and
    # offering it would only invite him to filter out nothing. Likewise if
    # the prefixes explain hardly any of the lot.
    if len(big) < 2 or sum(big.values()) < len(stocks) * 0.80:
        return []

    out = [{"name": p, "n": c} for p, c in big.items()]
    out.sort(key=lambda d: (-d["n"], d["name"]))
    return out[:6]


def is_certified(rec: dict) -> bool:
    """Certified Pre-Owned, however this store words it."""
    if rec.get("certified"):
        return True
    # Some sites only say it in the vehicle's own title or body text rather
    # than as a badge on the card, so check the words we did capture.
    blob = " ".join(str(rec.get(k) or "") for k in
                    ("title", "trim", "model", "body_style", "condition"))
    return bool(re.search(r"certified|\bcpo\b", blob, re.I))


def is_special(rec: dict) -> bool:
    """
    A Manager's Special, a flagged special offer, or a price drop.

    All three mean the same thing to a salesman: the house wants this one
    gone, so it is the one to post first.
    """
    return bool(rec.get("managers_special") or rec.get("special_offer")
                or rec.get("price_drop"))


def focus_is_on(f: dict | None = None) -> bool:
    """
    Is anything narrowing the lot?

    Used-only is the default and it IS a narrowing -- on a franchise store
    it keeps a hundred new cars out of the ads and off the slow page-by-page
    step. Only "new and used" with nothing else set means the whole lot.
    """
    f = f or focus()
    if f.get("condition", "used") != "all":
        return True
    return any(v for k, v in f.items() if k != "condition")


def in_focus(rec: dict, f: dict | None = None) -> bool:
    """
    Is this vehicle one he works?

    Used only to decide what to PUT IN FRONT OF HIM. A car he has already
    posted is always shown regardless -- see the callers. Losing sight of a
    live listing because it fell outside a filter would be far worse than
    showing one car too many.
    """
    f = f or focus()

    # Another store's car is never his to post, whatever his filter says.
    # This one is not a preference, so it applies even with no filter set.
    if is_other_store(rec):
        return False

    cond = f.get("condition", "used")
    if cond != "all" and condition_of(rec) != cond:
        return False

    p = price_of(rec)

    if f["min_price"] and (not p or p < f["min_price"]):
        return False
    if f["max_price"] and (not p or p > f["max_price"]):
        return False

    try:
        year = int(rec.get("year") or 0)
    except (TypeError, ValueError):
        year = 0
    if f["min_year"] and (not year or year < f["min_year"]):
        return False
    if f["max_year"] and (not year or year > f["max_year"]):
        return False

    if f["makes"]:
        make = str(rec.get("make", "")).strip().lower()
        if not any(m == make or m in make for m in f["makes"]):
            return False

    if f["models"]:
        model = (f"{rec.get('model','')} {rec.get('trim','')}").strip().lower()
        if not any(m in model for m in f["models"]):
            return False

    if f["bodies"]:
        body = body_of(rec).lower()
        # A Jeep is a make, not a body style, but salesmen say "jeeps" the
        # way they say "trucks" -- so let that word match the make too.
        make = str(rec.get("make", "")).strip().lower()
        ok = False
        for want in f["bodies"]:
            w = want.rstrip("s")                    # trucks -> truck
            if body.startswith(w) or w in body:
                ok = True
            elif w in make:
                ok = True
        if not ok:
            return False

    if f["stock"]:
        s = str(rec.get("stock", "")).strip().lower()
        if not any(s.startswith(pre) for pre in f["stock"]):
            return False

    # Certified and Manager's Specials are two KINDS of car, not two boxes a
    # car has to tick at once. A salesman who turns both on is saying "show me
    # the certified ones and the specials", so these behave like the make and
    # body chips: match any one of the kinds that are switched on.
    if f["certified"] or f["specials"]:
        if not ((f["certified"] and is_certified(rec))
                or (f["specials"] and is_special(rec))):
            return False

    return True


def focus_wording() -> str:
    """One short line describing the slice, for the top of the window."""
    f = focus()
    bits = []
    if f["max_price"] and f["min_price"]:
        bits.append(f"${f['min_price']:,}-${f['max_price']:,}")
    elif f["max_price"]:
        bits.append(f"under ${f['max_price']:,}")
    elif f["min_price"]:
        bits.append(f"over ${f['min_price']:,}")
    if f["min_year"] and f["max_year"]:
        bits.append(f"{f['min_year']}-{f['max_year']}")
    elif f["min_year"]:
        bits.append(f"{f['min_year']} and newer")
    elif f["max_year"]:
        bits.append(f"{f['max_year']} and older")
    if f["makes"]:
        names = [m.title() for m in f["makes"]]
        bits.append(", ".join(names[:3]) +
                    (f" +{len(names) - 3} more" if len(names) > 3 else ""))
    if f["bodies"]:
        bits.append(", ".join(pretty_body(b) for b in f["bodies"][:4]))
    if f["models"]:
        bits.append(", ".join(m.title() for m in f["models"][:3]))
    if f["stock"]:
        bits.append("stock " + ", ".join(s.upper() + "…" for s in f["stock"][:3]))
    if f["certified"]:
        bits.append("Certified only")
    if f["specials"]:
        bits.append("Manager's Specials only")
    cond = f.get("condition", "used")
    if cond == "new":
        bits.insert(0, "new cars only")
    elif cond == "all":
        bits.insert(0, "new and used")
    elif not bits:
        # Used-only is the default. Only worth saying when nothing else is,
        # so an existing "under $20,000" line reads exactly as it always has.
        return "used cars"
    return " · ".join(bits)


def days_since(s: str) -> int | None:
    try:
        return (date.today() - datetime.strptime(s, "%Y-%m-%d").date()).days
    except (ValueError, TypeError):
        return None


def name_of(inv: dict, stock: str, rows: dict) -> str:
    r = inv.get(stock)
    if r:
        return (f"{r.get('year','')} {r.get('make','')} {r.get('model','')} "
                f"{r.get('trim','')}").strip()
    # Gone from inventory -- fall back to the name recorded when it was posted
    return rows.get(stock, {}).get("Vehicle", "") or "(sold or pulled)"



def price_check(rows: dict, inv: dict) -> list[tuple]:
    """
    Find listings whose price no longer matches the website.

    You post at retail, then drop to the sale price the next day. So what the
    listing SHOULD say depends on whether you've done that drop yet:

        not dropped yet  ->  should match the website's retail price
        already dropped  ->  should match the website's sale price

    The manager can move either number at any time, which is what makes a live
    listing go wrong without you touching it. This compares what you actually
    posted against what the site says right now.
    """
    out = []
    for s, r in rows.items():
        if r.get("Status") == "down" or s not in inv:
            continue
        v = inv[s]
        dropped = bool(r.get("Dropped_Date"))
        if dropped:
            should = v.get("final_price") or v.get("moses_price")
            actual = r.get("Dropped_Price")
            stage = "sale price"
        else:
            should = post_price(v)
            actual = r.get("Posted_Price")
            stage = "retail" if has_markdown(v) else "price"
        try:
            should_i, actual_i = int(should), int(actual)
        except (TypeError, ValueError):
            continue
        # A dollar or two is rounding, not a price change -- the site's retail,
        # sale and doc-fee figures do not always add up to the penny. Flagging
        # those sends you back into Marketplace to retype $15,346 as $15,345,
        # which is work for nothing. Only report a move worth acting on.
        if abs(should_i - actual_i) >= price_noise():
            out.append((s, stage, actual_i, should_i))
    return out


# --- commands ---------------------------------------------------------------
def cmd_post(stocks: list[str]) -> None:
    rows, inv = load(), inventory()
    today = date.today().isoformat()
    for s in stocks:
        s = s.upper()
        r = rows.get(s, {"Stock": s})
        r["Posted_Date"] = today
        r["Status"] = "live"
        r["Dropped_Date"] = ""
        r["Dropped_Price"] = ""
        v = inv.get(s)
        if v:
            r["Posted_Price"] = post_price(v) or ""
            r["Vehicle"] = (f"{v.get('year','')} {v.get('make','')} "
                            f"{v.get('model','')} {v.get('trim','')}").strip()
        rows[s] = r
        mark = "" if v else "   (warning: not in current inventory)"
        print(f"  posted  {s:10s} {name_of(inv, s, rows)}{mark}")
    save(rows)


def cmd_drop(stocks: list[str]) -> None:
    rows, inv = load(), inventory()
    today = date.today().isoformat()
    for s in stocks:
        s = s.upper()
        r = rows.get(s)
        if not r:
            print(f"  {s} isn't logged as posted. Use: track.py post {s}")
            continue
        r["Dropped_Date"] = today
        v = inv.get(s)
        if v:
            r["Dropped_Price"] = v.get("final_price") or v.get("moses_price") or ""
        rows[s] = r
        print(f"  dropped {s:10s} to ${r['Dropped_Price'] or '?'}")
    save(rows)


def cmd_down(stocks: list[str]) -> None:
    rows = load()
    for s in stocks:
        s = s.upper()
        r = rows.get(s, {"Stock": s})
        r["Status"] = "down"
        rows[s] = r
        print(f"  taken down  {s}")
    save(rows)


def cmd_note(stock: str, words: list[str]) -> None:
    rows = load()
    s = stock.upper()
    r = rows.get(s, {"Stock": s})
    r["Notes"] = " ".join(words)
    rows[s] = r
    save(rows)
    print(f"  note on {s}: {r['Notes']}")


def cmd_post_all(args: list[str] | str | None = None) -> None:
    """
    Log a whole batch of listings at once, instead of one command per car.

    By default this covers the same slice you actually work -- everything at or
    under config.FOCUS_MAX_PRICE. Logging all 355 when you posted 40 would have
    the tracker nagging you tomorrow to drop the price on 315 listings that do
    not exist.

        python track.py post-all               the under-ceiling batch, today
        python track.py post-all 2026-10-09    same, dated
        python track.py post-all --all         genuinely everything

    Anything already logged keeps its original date.
    """
    if isinstance(args, str):
        args = [args]
    args = args or []

    whole_lot = False
    when = None
    for a in args:
        if a.lower().lstrip("-") in ("all", "a", "everything"):
            whole_lot = True
        else:
            when = a

    rows, inv = load(), inventory()
    cap = 0 if whole_lot else focus_max()
    day = when or date.today().isoformat()
    try:
        datetime.strptime(day, "%Y-%m-%d")
    except ValueError:
        print(f"  Date must look like 2026-10-05, not {day!r}")
        return

    added = 0
    skipped = 0
    for s, v in inv.items():
        if s in rows and rows[s].get("Posted_Date"):
            continue
        if cap:
            p = price_of(v)
            if not p or p > cap:
                skipped += 1
                continue
        rows[s] = {
            "Stock": s,
            "Vehicle": (f"{v.get('year','')} {v.get('make','')} "
                        f"{v.get('model','')} {v.get('trim','')}").strip(),
            "Posted_Date": day,
            "Posted_Price": post_price(v) or "",
            "Status": "live",
        }
        added += 1
    save(rows)
    print(f"  Logged {added} listing(s) as posted on {day}.")
    if cap and skipped:
        print(f"  Left alone: {skipped} vehicle(s) over ${cap:,} or unpriced "
              f"-- you didn't post those.")
        print(f"  (python track.py post-all --all would include them.)")
    print(f"  {len(rows)} total tracked. Run 'python track.py' for your list.")


def cmd_synced(stocks: list[str]) -> None:
    """Record that you've updated the listing to the website's current price."""
    rows, inv = load(), inventory()
    for s in stocks:
        s = s.upper()
        r = rows.get(s)
        if not r:
            print(f"  {s} isn't logged as posted.")
            continue
        v = inv.get(s)
        if not v:
            print(f"  {s} is no longer in inventory -- take it down instead.")
            continue
        if r.get("Dropped_Date"):
            r["Dropped_Price"] = v.get("final_price") or v.get("moses_price") or ""
            now = r["Dropped_Price"]
        else:
            r["Posted_Price"] = post_price(v) or ""
            now = r["Posted_Price"]
        rows[s] = r
        print(f"  synced  {s:10s} now ${int(now):,}" if now else f"  synced  {s}")
    save(rows)


def cmd_all() -> None:
    rows, inv = load(), inventory()
    if not rows:
        print("Nothing logged yet.")
        return
    print(f"{'STOCK':11s} {'POSTED':11s} {'DROPPED':11s} {'STATUS':7s} VEHICLE")
    print("-" * 74)
    for s in sorted(rows):
        r = rows[s]
        print(f"{s:11s} {r.get('Posted_Date',''):11s} "
              f"{r.get('Dropped_Date','') or '-':11s} "
              f"{r.get('Status',''):7s} {name_of(inv, s, rows)}")


def cmd_drop_due() -> None:
    """
    Drop every listing that is due, without typing out the stock numbers.

    "Due" means: you posted it, at least a day has gone by, and you have not
    dropped it yet. That is exactly the DROP THE PRICE block on your to-do.
    Pasting twenty stock numbers by hand is where mistakes come from.
    """
    rows, inv = load(), inventory()
    due = []
    for s, r in rows.items():
        if r.get("Status") == "down" or s not in inv:
            continue
        if r.get("Dropped_Date"):
            continue
        d = days_since(r.get("Posted_Date", ""))
        if d is not None and d >= 1:
            due.append(s)

    if not due:
        print("\n  Nothing is due for a price drop.")
        return

    print(f"\n  Dropping {len(due)} listing(s):\n")
    cmd_drop(sorted(due))
    print("\n  Make sure you changed these on Marketplace too.")


def cmd_down_sold() -> None:
    """
    Take down every listing whose vehicle is no longer on the lot.

    Same list as the TAKE DOWN block. Delete them on Marketplace first --
    this only updates your records.
    """
    rows, inv = load(), inventory()
    sold = [s for s, r in rows.items()
            if r.get("Status") != "down" and s not in inv]
    if not sold:
        print("\n  Nothing sold that is still listed.")
        return
    print(f"\n  Taking down {len(sold)} listing(s):\n")
    cmd_down(sorted(sold))


def cmd_list() -> None:
    """
    Every listing you currently have up, in one roster.

    For checking yourself against Marketplace: if it is on this list it should
    be live on Facebook, and if it is live on Facebook it should be on this
    list. Anything that drifted apart shows up as a mismatch you can fix.

    Also written to out\\MY_LISTINGS.txt so you can print it.
    """
    rows, inv = load(), inventory()
    live = {s: r for s, r in rows.items() if r.get("Status") != "down"}

    L: list[str] = []
    if not live:
        print("\n  Nothing logged as posted yet.")
        return

    L.append("")
    L.append("=" * 74)
    L.append(f"  MY LIVE MARKETPLACE LISTINGS ({len(live)})")
    L.append(f"  {config.STORE_FULL}")
    L.append("=" * 74)
    L.append("")
    L.append(f"  {'STOCK':11s} {'POSTED':11s} {'PRICE':>9s}   VEHICLE")
    L.append("  " + "-" * 70)

    def sort_key(stock: str):
        return (live[stock].get("Posted_Date") or "", stock)

    waiting = dropped = sold = 0
    for s in sorted(live, key=sort_key):
        r = live[s]
        posted = r.get("Posted_Date") or "?"
        raw = r.get("Dropped_Price") or r.get("Posted_Price") or ""
        try:
            price = f"${int(raw):,}"
        except (TypeError, ValueError):
            price = "-"

        note = ""
        if s not in inv:
            note = "   <-- SOLD, take it down"
            sold += 1
        elif r.get("Dropped_Date"):
            dropped += 1
        else:
            note = "   (not dropped yet)"
            waiting += 1

        L.append(f"  {s:11s} {posted:11s} {price:>9s}   "
                 f"{name_of(inv, s, rows)}{note}")

    L.append("")
    L.append(f"  {len(live)} live   |   {dropped} dropped   |   "
             f"{waiting} awaiting a drop   |   {sold} sold")
    L.append("=" * 74)

    text = "\n".join(L)
    print(text)
    try:
        config.OUT.mkdir(parents=True, exist_ok=True)
        (config.OUT / "MY_LISTINGS.txt").write_text(text.lstrip("\n"),
                                                    encoding="utf-8")
        print(r"  Saved to out\MY_LISTINGS.txt")
    except OSError:
        pass


def todo_data() -> dict:
    """
    The same work cmd_todo prints, handed back as data.

    The command line and the window both need this list, and they must never
    disagree about it. One calculation, two faces.
    """
    rows, inv = load(), inventory()
    live = {s: r for s, r in rows.items() if r.get("Status") != "down"}
    cap = focus_max()
    f = focus()

    take_down, drop_today, waiting, not_posted = [], [], [], []
    over_cap = no_price = 0

    for s, r in live.items():
        if not inv:
            # Nothing read from the website yet (first start, or a failed
            # read). An empty lot does not mean every car sold -- never
            # tell him to take his whole Marketplace down.
            continue
        if s not in inv:
            take_down.append({"stock": s, "name": name_of(inv, s, rows)})
            continue
        if r.get("Dropped_Date"):
            continue
        d = days_since(r.get("Posted_Date", ""))
        if d is None:
            continue
        v = inv[s]
        if not has_markdown(v):
            continue          # posted at the sale price -- nothing to drop
        entry = {
            "stock": s,
            "name": name_of(inv, s, rows),
            "days": d,
            "was": v.get("retail_price"),
            "now": v.get("final_price") or v.get("moses_price"),
        }
        (drop_today if d >= 1 else waiting).append(entry)

    for s in inv:
        if s in rows:
            continue
        p = price_of(inv[s])
        # No price on the website yet, so there is nothing to post it at.
        # This holds whether or not a ceiling is set.
        if not p:
            no_price += 1
            continue
        if not in_focus(inv[s], f):
            over_cap += 1
            continue
        not_posted.append({"stock": s, "name": name_of(inv, s, rows),
                           "price": p})

    mismatched = [
        {"stock": s, "stage": stage, "yours": was, "should": now}
        for s, stage, was, now in sorted(price_check(live, inv))
    ]

    return {
        "store": getattr(config, "STORE_FULL", "Inventory"),
        "cap": cap,
        "vehicles": len(inv),
        "live": len(live),
        "take_down": sorted(take_down, key=lambda x: x["stock"]),
        "mismatched": mismatched,
        "drop_today": sorted(drop_today, key=lambda x: x["stock"]),
        "waiting": sorted(waiting, key=lambda x: x["stock"]),
        "not_posted": sorted(not_posted, key=lambda x: x["price"] or 0),
        "over_cap": over_cap,
        "no_price": no_price,
    }


def cmd_todo() -> None:
    rows, inv = load(), inventory()
    live = {s: r for s, r in rows.items() if r.get("Status") != "down"}

    take_down, drop_today, waiting, not_posted = [], [], [], []

    for s, r in live.items():
        if not inv:
            # Nothing read from the website yet (first start, or a failed
            # read). An empty lot does not mean every car sold -- never
            # tell him to take his whole Marketplace down.
            continue
        if s not in inv:
            take_down.append(s)
            continue
        if r.get("Dropped_Date"):
            continue
        d = days_since(r.get("Posted_Date", ""))
        if d is None:
            continue
        if not has_markdown(inv[s]):
            continue
        (drop_today if d >= 1 else waiting).append((s, d))

    cap = focus_max()
    f = focus()
    over_cap = 0
    no_price = 0
    for s in inv:
        if s in rows:
            continue
        p = price_of(inv[s])
        if not p:
            # Can't post what has no price yet -- out\no_price_yet.csv
            # already lists these. True with or without a ceiling.
            no_price += 1
            continue
        if not in_focus(inv[s], f):
            over_cap += 1
            continue
        not_posted.append(s)

    print()
    print("=" * 62)
    print("  MARKETPLACE TO-DO".ljust(62))
    print("=" * 62)

    mismatched = price_check(live, inv)
    if mismatched:
        print(f"\n  PRICE CHANGED ON THE WEBSITE ({len(mismatched)}) -- "
              f"your listing is out of date:")
        for s, stage, was, now in sorted(mismatched):
            d = "DOWN" if now < was else "UP"
            print(f"    [ ] {s:11s} {name_of(inv, s, rows)}")
            print(f"        {'':11s} yours ${was:,}  ->  change to ${now:,}"
                  f"   ({d} ${abs(now - was):,}, website {stage})")
        print("\n    Update these on Marketplace, then:  python track.py "
              f"synced {' '.join(s for s, _, _, _ in sorted(mismatched)[:3])}")

    if take_down:
        print(f"\n  TAKE DOWN ({len(take_down)}) -- sold, listing still live:")
        for s in sorted(take_down):
            print(f"    [ ] {s:11s} {name_of(inv, s, rows)}")
        print(f"\n    When done:  python track.py down "
              f"{' '.join(sorted(take_down)[:3])}")

    if drop_today:
        print(f"\n  DROP THE PRICE ({len(drop_today)}):")
        for s, d in sorted(drop_today):
            v = inv[s]
            was = v.get("retail_price")
            now = v.get("final_price") or v.get("moses_price")
            age = "1 day" if d == 1 else f"{d} days"
            print(f"    [ ] {s:11s} {name_of(inv, s, rows)}   (up {age})")
            if was and now and was > now:
                print(f"        {'':11s} ${was:,}  ->  ${now:,}")
        print(f"\n    When done:  python track.py drop "
              f"{' '.join(s for s, _ in sorted(drop_today)[:3])}")

    if waiting:
        print(f"\n  POSTED TODAY ({len(waiting)}) -- drop these tomorrow:")
        print("    " + ", ".join(s for s, _ in sorted(waiting)))

    if not_posted:
        label = f"NOT POSTED YET ({len(not_posted)})"
        if cap:
            label += f" -- under ${cap:,}"
        print(f"\n  {label}:")
        # Cheapest first: those are the ones that move.
        shown = sorted(not_posted, key=lambda s: price_of(inv[s]))[:15]
        for s in shown:
            p = price_of(inv[s])
            print(f"    [ ] {s:11s} ${p:>7,}  {name_of(inv, s, rows)}")
        if len(not_posted) > 15:
            print(f"    ... and {len(not_posted) - 15} more under ${cap:,}"
                  if cap else f"    ... and {len(not_posted) - 15} more")
        print(f"\n    When you post one:  python track.py post {shown[0]}")

    if over_cap or no_price:
        bits = []
        if over_cap:
            where = focus_wording()
            bits.append(f"{over_cap} outside what you work"
                        + (f" ({where})" if where else ""))
        if no_price:
            bits.append(f"{no_price} with no price on the website yet")
        print(f"\n  (not shown: {', '.join(bits)}. Still scraped, still "
              f"watched for price changes.")
        if focus_is_on():
            print("   Change what you work under Settings in the window.)")
        else:
            print("   They will show up here as soon as the store prices "
                  "them.)")

    done = len(live) - len(take_down) - len(drop_today) - len(waiting)
    if not (take_down or drop_today or not_posted or mismatched):
        print("\n  Nothing to do. Every listing is current.")
    print(f"\n  {len(live)} live listing(s), {done} fully worked")
    print("=" * 62)


def main() -> int:
    args = sys.argv[1:]
    if not args:
        cmd_todo()
        return 0

    cmd, rest = args[0].lower(), args[1:]
    if cmd == "post" and rest:
        cmd_post(rest)
    elif cmd == "drop" and rest:
        cmd_drop(rest)
    elif cmd in ("down", "sold", "remove") and rest:
        cmd_down(rest)
    elif cmd == "note" and len(rest) >= 2:
        cmd_note(rest[0], rest[1:])
    elif cmd in ("drop-due", "dropdue", "drop-all", "dropall"):
        cmd_drop_due()
    elif cmd in ("down-sold", "downsold", "down-all", "downall"):
        cmd_down_sold()
    elif cmd in ("list", "posted", "live", "mine"):
        cmd_list()
    elif cmd in ("post-all", "postall"):
        cmd_post_all(rest)
    elif cmd in ("synced", "sync", "matched") and rest:
        cmd_synced(rest)
    elif cmd == "all":
        cmd_all()
    else:
        print(__doc__)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
