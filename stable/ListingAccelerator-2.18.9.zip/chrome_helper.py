"""
chrome_helper.py -- the Chrome (or Edge) helper that fills in Facebook's
Marketplace vehicle form.

Two halves:

1. A small web server inside the program, on this computer only
   (127.0.0.1, port 8765). It hands the helper the cars that aren't posted
   yet -- the same words and photos the Posting helper has -- and records a
   car as posted when he says so. Nothing outside this computer can reach it,
   and web pages can't use it either: every request has to carry the helper's
   own header, which a web page isn't allowed to send.

2. The helper itself, a browser extension. The program writes its files into
   "Chrome helper" next to the program, and the salesperson loads that folder
   once in chrome://extensions (or edge://extensions).

On facebook.com/marketplace/create/vehicle the helper shows a panel: pick a
car, press Fill. It types the year, make, model, miles, price, colours, body,
condition, fuel, transmission and description, and adds the photos. It never
presses Next or Publish -- he looks it over and publishes it himself, the way
the program has always worked. Anything it couldn't fill is listed so he
can do that one box by hand. The VIN box is always left empty.

The extension's files live in this file (not a folder) so the one-click
updater, which ships the program's top-level files, keeps them current.
"""
from __future__ import annotations

import csv
import json
import mimetypes
import threading
import urllib.parse
from datetime import date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).resolve().parent
FOLDER = HERE / "Chrome helper"
PORTS = (8765, 8766, 8767)
HEADER = "X-Listing-Accelerator"
VERSION = "1.3.4"
_server = {"port": None}
# Things only the running program can do (the "Add to my cars" runner); the
# program fills these in when it starts.
HOOKS = {}


# ------------------------------------------------------------------ data
def _stores() -> list[dict]:
    import stores
    out = []
    for s in stores.all_stores():
        d = Path(s["dir"])
        out.append({"key": s["key"], "name": s["name"], "dir": d, "out": d / "out"})
    return out


def _posted(out_dir: Path) -> dict:
    p = out_dir / "posted.csv"
    if not p.exists():
        return {}
    with open(p, newline="", encoding="utf-8") as f:
        return {r["Stock"].upper(): r for r in csv.DictReader(f) if r.get("Stock")}


def _kit(out_dir: Path) -> dict:
    try:
        return json.loads((out_dir / "listing_kit" / "cars.json").read_text(encoding="utf-8"))
    except Exception:
        return {"cars": []}


def _photos(folder: Path) -> list[str]:
    """The posting set if there is one (background versions where made),
    otherwise the car's own photos -- up to 20, Facebook's limit."""
    post = folder / "post"
    if post.is_dir():
        pics = sorted(p.name for p in post.iterdir() if p.suffix.lower() in (".jpg", ".jpeg", ".png"))
        if pics:
            return ["post/" + n for n in pics][:20]
    try:
        import backgrounds
        return [p.name for p in backgrounds.originals(folder)][:20]
    except Exception:
        return sorted(p.name for p in folder.glob("*.jpg"))[:20] if folder.is_dir() else []


def cars(store_key: str = "") -> dict:
    out = []
    for s in _stores():
        if store_key and s["key"] != store_key:
            continue
        kit = _kit(s["out"])
        posted = _posted(s["out"])
        for c in kit.get("cars", []):
            r = posted.get(str(c.get("stock", "")).upper())
            live = bool(r and r.get("Status") != "down" and r.get("Posted_Date"))
            out.append({"store": s["key"], "store_name": s["name"], "stock": c.get("stock"),
                        "title": c.get("title"), "photos": c.get("photos", 0),
                        "posted": live, "posted_date": (r or {}).get("Posted_Date", "")})
    return {"ok": True, "version": VERSION,
            "stores": [{"key": s["key"], "name": s["name"],
                        "ready": (s["out"] / "listing_kit" / "cars.json").exists()} for s in _stores()],
            "cars": out}


def _find(store_key: str, stock: str):
    for s in _stores():
        if s["key"] != store_key:
            continue
        for c in _kit(s["out"]).get("cars", []):
            if str(c.get("stock", "")).upper() == str(stock).upper():
                return s, c
    return None, None


def car(store_key: str, stock: str) -> dict:
    s, c = _find(store_key, stock)
    if not c:
        return {"ok": False, "message": "That car isn't in the Posting helper. Run today's update."}
    folder = Path(c.get("folder") or "")
    pics = _photos(folder)
    q = urllib.parse.quote
    return {"ok": True, "stock": c["stock"], "title": c.get("title"), "fb": c.get("fb", {}),
            "photos": [{"name": n.split("/")[-1],
                        "url": f"/la/photo?store={q(store_key)}&stock={q(c['stock'])}&name={q(n)}"}
                       for n in pics]}


def photo_path(store_key: str, stock: str, name: str):
    s, c = _find(store_key, stock)
    if not c:
        return None
    folder = Path(c.get("folder") or "").resolve()
    allowed = set(_photos(folder))
    if name not in allowed:            # only the car's own listed photos
        return None
    p = (folder / name).resolve()
    if folder not in p.parents or not p.is_file():
        return None
    return p


def mark_posted(store_key: str, stock: str) -> dict:
    import track
    s, c = _find(store_key, stock)
    if not s:
        return {"ok": False, "message": "That car isn't in the Posting helper."}
    out_dir = s["out"]
    rows = _posted(out_dir)
    try:
        inv = {str(r.get("stock", "")).upper(): r for r in
               json.loads((out_dir / "inventory.json").read_text(encoding="utf-8"))}
    except Exception:
        inv = {}
    st = str(stock).upper()
    r = rows.get(st, {"Stock": st})
    r["Posted_Date"] = date.today().isoformat()
    r["Status"] = "live"
    r["Dropped_Date"] = ""
    r["Dropped_Price"] = ""
    v = inv.get(st)
    if v:
        r["Posted_Price"] = track.post_price(v) or ""
        r["Vehicle"] = " ".join(str(v.get(k) or "") for k in ("year", "make", "model", "trim")).strip()
    rows[st] = r
    out_dir.mkdir(parents=True, exist_ok=True)
    with open(out_dir / "posted.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=track.COLS, extrasaction="ignore")
        w.writeheader()
        for k in sorted(rows):
            row = {c2: "" for c2 in track.COLS}
            row.update(rows[k])
            w.writerow(row)
    return {"ok": True, "message": f"{st} recorded as posted."}


# ------------------------------------------------------------------ more of the program, for the helper
def _inv(out_dir: Path) -> dict:
    try:
        return {str(r.get("stock") or "").upper(): r for r in
                json.loads((out_dir / "inventory.json").read_text(encoding="utf-8")) if r.get("stock")}
    except Exception:
        return {}


def _write_posted(out_dir: Path, rows: dict) -> None:
    import track
    out_dir.mkdir(parents=True, exist_ok=True)
    tmp = out_dir / "posted.csv.tmp"
    with open(tmp, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=track.COLS, extrasaction="ignore")
        w.writeheader()
        for k in sorted(rows):
            row = {c2: "" for c2 in track.COLS}
            row.update(rows[k])
            w.writerow(row)
    import os
    os.replace(tmp, out_dir / "posted.csv")


def stocks() -> dict:
    """Every stock number the program knows, so the helper can spot them on a
    Facebook page (listing titles carry the stock number)."""
    out = set()
    for s in _stores():
        out |= set(_inv(s["out"]).keys())
        out |= set(_posted(s["out"]).keys())
    return {"ok": True, "stocks": sorted(x for x in out if len(x) >= 4)}


def _money(v) -> int:
    try:
        return int(float(str(v or "").replace("$", "").replace(",", "")))
    except ValueError:
        return 0


def want_price(rec: dict, row: dict | None) -> tuple[int, bool]:
    """(the price the listing should show today, is that a drop due).
    Posted at retail with a markdown -> drop to the sale price a day later."""
    import track
    today = date.today().isoformat()
    sale = track.price_of(rec) or 0
    first = track.post_price(rec) or sale
    r = row or {}
    posted = str(r.get("Posted_Date") or "")[:10]
    if r.get("Dropped_Date"):
        return sale, False
    if track.has_markdown(rec) and posted and posted < today:
        return sale, True
    return first, False


def sync(seen: list) -> dict:
    """He opened Your listings: these listings are on Facebook. Record the live
    ones as posted, and say what each one needs."""
    import track
    noise = 50
    stores_ = _stores()
    invs = {s["key"]: _inv(s["out"]) for s in stores_}
    posts = {s["key"]: _posted(s["out"]) for s in stores_}
    by_key = {s["key"]: s for s in stores_}
    results, recorded = [], []
    seen_set = set()
    for it in seen or []:
        st = str(it.get("stock") or "").strip().upper()
        if not st or st in seen_set:
            continue
        seen_set.add(st)
        page_price = _money(it.get("price"))
        fb_sold = bool(it.get("fb_sold"))
        key = next((k for k, inv in invs.items() if st in inv), "") or \
            next((k for k, p in posts.items() if st in p), "")
        res = {"stock": st, "store": key, "store_name": by_key[key]["name"] if key else "",
               "page_price": page_price, "fb_sold": fb_sold}
        if not key:
            res.update(status="unknown", say="Not in any of your stores")
        elif st not in invs[key]:
            res["vehicle"] = (posts[key].get(st) or {}).get("Vehicle") or st
            res.update(status="sold", say="Sold — off the website. Mark it sold on Facebook." if not fb_sold
                       else "Sold on the website and marked sold here ✓")
            if fb_sold:
                res["status"] = "done"
        elif fb_sold:
            res.update(status="fbsold", say="Marked sold on Facebook, but it's still on the website")
        else:
            rec = invs[key][st]
            row = posts[key].get(st)
            want, drop = want_price(rec, row)
            res["vehicle"] = " ".join(str(rec.get(k) or "") for k in ("year", "make", "model", "trim")).strip()
            res["want"] = want
            if not row or row.get("Status") == "down" or not row.get("Posted_Date"):
                rows = posts[key]
                r = rows.get(st, {"Stock": st})
                r.update(Posted_Date=date.today().isoformat(), Status="live",
                         Posted_Price=page_price or track.post_price(rec) or "",
                         Vehicle=res["vehicle"], Dropped_Date="", Dropped_Price="")
                rows[st] = r
                recorded.append(st)
                row = r
                want, drop = want_price(rec, row)
                res["want"] = want
            if page_price and want and page_price > want + noise:
                res.update(status="drop", say=f"Drop to ${want:,}" + (" — due today" if drop else ""))
            elif page_price and want and page_price < want - noise:
                res.update(status="up", say=f"The website price is ${want:,} now")
            else:
                res.update(status="ok", say="Price is right ✓")
        results.append(res)
    for k in {posts_k for posts_k in posts if any(r["store"] == posts_k and r["stock"] in recorded for r in results)}:
        _write_posted(by_key[k]["out"], posts[k])
    # what's ready to post but not on Facebook yet
    not_posted = []
    for s in stores_:
        live = {k for k, r in posts[s["key"]].items() if r.get("Posted_Date") and r.get("Status") != "down"}
        for c in _kit(s["out"]).get("cars", []):
            stck = str(c.get("stock") or "").upper()
            if stck not in live and stck not in seen_set and stck in invs[s["key"]]:
                not_posted.append({"stock": stck, "store": s["key"], "store_name": s["name"], "title": c.get("title")})
    # marked live in the program but not on this page (only meaningful once the page is fully scrolled)
    gone = []
    for s in stores_:
        for k, r in posts[s["key"]].items():
            if r.get("Posted_Date") and r.get("Status") != "down" and k not in seen_set:
                gone.append({"stock": k, "store": s["key"], "vehicle": r.get("Vehicle") or k})
    return {"ok": True, "results": results, "recorded": recorded, "not_posted": not_posted[:60],
            "not_posted_count": len(not_posted), "missing": gone[:60], "missing_count": len(gone)}


def drop_info(stock: str) -> dict:
    st = str(stock or "").strip().upper()
    for s in _stores():
        inv = _inv(s["out"])
        if st in inv:
            row = _posted(s["out"]).get(st)
            want, due = want_price(inv[st], row)
            return {"ok": True, "stock": st, "store": s["key"], "store_name": s["name"],
                    "vehicle": " ".join(str(inv[st].get(k) or "") for k in ("year", "make", "model", "trim")).strip(),
                    "want": want, "due": due, "posted_price": _money((row or {}).get("Posted_Price")),
                    "dropped": bool((row or {}).get("Dropped_Date"))}
    return {"ok": False, "message": f"{st} isn't on any of your stores' websites."}


def record_drop(store_key: str, stock: str, price) -> dict:
    st = str(stock or "").strip().upper()
    s = next((x for x in _stores() if x["key"] == store_key), None)
    if not s:
        return {"ok": False, "message": "No such store."}
    rows = _posted(s["out"])
    r = rows.get(st, {"Stock": st, "Posted_Date": date.today().isoformat(), "Status": "live"})
    r["Dropped_Date"] = date.today().isoformat()
    r["Dropped_Price"] = _money(price) or ""
    rows[st] = r
    _write_posted(s["out"], rows)
    return {"ok": True, "message": f"Recorded the drop on {st} to ${_money(price):,}."}


def crm_save(body: dict) -> dict:
    """He pressed Save to CRM in a chat: the buyer's name (as he typed or
    confirmed it), the car, and anything he highlighted."""
    import customers
    import quick_answers
    name = " ".join(str(body.get("name") or "").split())[:80]
    st = str(body.get("stock") or "").strip().upper()
    note = str(body.get("note") or "").strip()[:4000]
    phone = customers.tidy_phone(str(body.get("phone") or "").strip())[:30]
    email = str(body.get("email") or "").strip()[:120]
    if not name:
        return {"ok": False, "message": "Type the buyer's name."}
    key = quick_answers.find_store(st) if st else ""
    hit = None
    for c in customers.load():
        if c.get("status") in customers.CLOSED:
            continue
        if " ".join(str(c.get("name") or "").split()).lower() == name.lower():
            hit = c
            break
    new = hit is None
    if new:
        hit = customers.save({"name": name, "source": "Marketplace", "wants": ["Buying"], "looking_for": "Used",
                              "store_key": key, "followup": date.today().isoformat(), "phone": phone, "email": email})
    elif (phone and not hit.get("phone")) or (email and not hit.get("email")):
        hit = customers.save({"id": hit["id"], "name": hit["name"], "phone": hit.get("phone") or phone,
                              "email": hit.get("email") or email})
    if st and not any(str(v.get("stock") or "").upper() == st for v in hit.get("vehicles") or []):
        inv = _inv(next(x for x in _stores() if x["key"] == key)["out"]) if key else {}
        rec = inv.get(st, {})
        label = " ".join(str(rec.get(k) or "") for k in ("year", "make", "model", "trim")).strip() or st
        vehicles = list(hit.get("vehicles") or []) + [{"stock": st, "store_key": key, "label": label}]
        patch = {"id": hit["id"], "vehicles": vehicles}
        if not hit.get("store_key"):
            patch["store_key"] = key
        hit = customers.save(patch)
    if note:
        customers.add_entry(hit["id"], "chat", note)
    return {"ok": True, "id": hit["id"], "new": new,
            "message": (f"{name} is in Accelerator CRM" if new else f"Updated {name} in Accelerator CRM")
                       + (f" with {st}" if st else "") + (" and the chat you highlighted." if note else ".")}


def appointment(body: dict) -> dict:
    """He set the appointment in the chat: save the buyer as Appointment set,
    and hand back the confirmation to put in the chat."""
    import customers
    import quick_answers
    from datetime import datetime, timedelta
    name = " ".join(str(body.get("name") or "").split())
    if len(name.split()) < 2:
        return {"ok": False, "need": "contact", "message": "For the appointment you need their first and last name. Use \"Ask for their number\" to get it."}
    if not (str(body.get("phone") or "").strip() or str(body.get("email") or "").strip()):
        return {"ok": False, "need": "contact", "message": "For the appointment you need a phone number or email. Use \"Ask for their number\" to get it."}
    try:
        when = datetime.strptime(str(body.get("when") or "")[:16], "%Y-%m-%dT%H:%M")
    except ValueError:
        return {"ok": False, "message": "Pick the day and the time."}
    st = str(body.get("stock") or "").strip().upper()
    saved = crm_save({"name": name, "stock": st, "note": body.get("note") or "",
                      "phone": body.get("phone") or "", "email": body.get("email") or ""})
    if not saved.get("ok"):
        return saved
    cid = saved["id"]
    c = customers.get(cid)
    customers.save({"id": cid, "name": c.get("name"), "status": "Appointment set",
                    "appointment": when.strftime("%Y-%m-%dT%H:%M"), "followup": when.date().isoformat()})
    customers.add_entry(cid, "notes", f"Appointment set from the Marketplace chat: {when.strftime('%a %b %d, %I:%M %p').replace(' 0', ' ')}")
    f = quick_answers.facts("", st, name) if st else None
    key = (f or {}).get("store_key") or ""
    seller = ""
    for x in _stores():
        if x["key"] == key or not key:
            try:
                seller = json.loads((x["dir"] / "settings.json").read_text(encoding="utf-8")).get("first_name") or ""
            except Exception:
                seller = ""
            break
    es = body.get("lang") == "es"
    days = (when.date() - date.today()).days
    tm = when.strftime("%I:%M %p").lstrip("0").replace(":00 ", " ")
    if es:
        dias = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]
        day = "hoy" if days == 0 else "mañana" if days == 1 else f"el {dias[when.weekday()]} {when.day}"
        tm = when.strftime("%I:%M").lstrip("0") + (" de la tarde" if when.hour >= 12 else " de la mañana")
        where = f" en {f['store']}, {f['address']}" if f else ""
        car = f" el {f['car_short']}" if f else " el carro"
        text = (f"¡Perfecto, {name.split()[0]}! Queda confirmado para {day} a las {tm}{where}. "
                f"Le tengo{car} listo al frente." + (f" Pregunte por {seller} cuando llegue." if seller else "") + " ¡Nos vemos!")
    else:
        day = "today" if days == 0 else "tomorrow" if days == 1 else when.strftime("%A, %b %d").replace(" 0", " ")
        where = f" at {f['store']}, {f['address']}" if f else ""
        car = f"the {f['car_short']}" if f else "it"
        text = (f"Perfect, {name.split()[0]}! You're all set for {day} at {tm}{where}. "
                f"I'll have {car} pulled up front and ready for you." + (f" Ask for {seller} when you get here." if seller else "") + " See you then!")
    return {"ok": True, "id": cid, "text": text,
            "message": f"{name} is set for {when.strftime('%a %b %d, %I:%M %p').replace(' 0', ' ')} in Accelerator CRM."}


def spot_write(body: dict) -> dict:
    """A comment or private message for someone whose post says they're
    shopping, about one car that fits what they asked for."""
    import quick_answers
    st = str(body.get("stock") or "").strip().upper()
    f = quick_answers.facts(str(body.get("store") or ""), st, str(body.get("name") or ""))
    if not f:
        return {"ok": False, "message": "That car isn't on the website any more."}
    s = next((x for x in _stores() if x["key"] == f["store_key"]), None)
    stg = _store_settings(s) if s else {}
    seller = stg.get("first_name") or ""
    city = stg.get("city") or ""
    chips = [str(c).lower() for c in body.get("chips") or []]
    first = f["name"]
    hi = "Hi" + (f" {first}" if first else "") + "!"
    car = f["car"]
    bits = [f"{f['miles']} miles" if f["miles"] not in ("low", "") else "", f["price"]]
    line = f"{car}, " + ", ".join(b for b in bits if b)
    extra = ""
    if any("credit" in c for c in chips):
        extra = " We work with every credit situation, and a down payment helps."
    elif any("gas" in c for c in chips):
        extra = " It's easy on gas."
    elif any("first car" in c for c in chips):
        extra = " It would make a great first car."
    where = f"I'm at {f['store']}" + (f" in {city}" if city else "") + "."
    if body.get("kind") == "message":
        text = (f"{hi} I saw your post that you're looking for a vehicle. I have a {line}.{extra} "
                f"{where} I can send you pictures and the details{(': ' + f['link']) if f['link'] else ''} "
                f"When would be a good time to come see it?" + (f" — {seller}" if seller else ""))
    else:
        text = (f"{hi} I have a {line}.{extra} Want me to send you pictures? {where}"
                + (f" — {seller}" if seller else ""))
    return {"ok": True, "text": " ".join(text.split())}


def group_log(store_key: str, stock: str, url: str) -> dict:
    import re
    m = re.match(r"https://(?:www|web)\.facebook\.com/groups/[^/?#]+", str(url or ""))
    if not m:
        return {"ok": False}
    g = m.group(0).replace("web.facebook", "www.facebook")
    s = next((x for x in _stores() if x["key"] == store_key), None)
    if not s:
        return {"ok": False}
    f = s["dir"] / "groups_log.json"
    try:
        log = json.loads(f.read_text(encoding="utf-8"))
    except Exception:
        log = {}
    log.setdefault(str(stock).upper(), {})[g] = date.today().isoformat()
    f.write_text(json.dumps(log, indent=1), encoding="utf-8")
    return {"ok": True}


# ------------------------------------------------------------------ reading a website in his own Chrome
# For a store whose website turns programs away: the salesperson opens the
# used inventory in his own Chrome, clicks the helper's toolbar button, and the
# helper reads the cars on the page he's looking at -- the same way the program
# reads a website, but in his browser. The next update uses them.
def _norm_url(u: str) -> str:
    u = str(u or "").strip().lower().split("#")[0].split("?")[0]
    return u[:-1] if u.endswith("/") else u


def _host(u: str) -> str:
    h = urllib.parse.urlsplit(str(u or "")).netloc.lower()
    return h[4:] if h.startswith("www.") else h


def _store_settings(s: dict) -> dict:
    try:
        return json.loads((s["dir"] / "settings.json").read_text(encoding="utf-8"))
    except Exception:
        return {}


def which_store(url: str) -> dict:
    h = _host(url)
    sts = _stores()
    hits = [s for s in sts if h and _host(_store_settings(s).get("inventory_url")) == h]
    pick = hits[0] if hits else (sts[0] if len(sts) == 1 else None)
    return {"ok": True, "store": pick["key"] if pick else "", "store_name": pick["name"] if pick else "",
            "stores": [{"key": x["key"], "name": x["name"]} for x in sts], "matched": bool(hits)}


def _hfile(store_key: str):
    s = next((x for x in _stores() if x["key"] == store_key), None)
    return (s["out"] / "helper_cars.json") if s else None


def _session(store_key: str) -> dict:
    import time
    f = _hfile(store_key)
    try:
        d = json.loads(f.read_text(encoding="utf-8"))
    except Exception:
        d = {}
    stale = (time.time() - float(d.get("started") or 0)) > 20 * 3600
    if not d or d.get("used") or stale:
        d = {"started": time.time(), "cards": [], "pages": [], "galleries": {}, "done": False}
    return d


def _save_session(store_key: str, d: dict) -> None:
    f = _hfile(store_key)
    f.parent.mkdir(parents=True, exist_ok=True)
    tmp = f.with_suffix(".tmp")
    tmp.write_text(json.dumps(d), encoding="utf-8")
    import os
    os.replace(tmp, f)


def _card_key(c: dict) -> str:
    return _norm_url(c.get("href")) or " ".join(str(c.get("text") or "").split())[:200]


def read_page(store_key: str, url: str, cards: list, start_over: bool = False) -> dict:
    if not _hfile(store_key):
        return {"ok": False, "message": "Pick the store first."}
    import time
    d = {"started": time.time(), "cards": [], "pages": [], "galleries": {}, "done": False} if start_over else _session(store_key)
    if d.get("done"):
        d["done"] = False          # reading more after Done: add to it
    have = {_card_key(c) for c in d["cards"]}
    added = 0
    for c in cards or []:
        if not isinstance(c, dict):
            continue
        c = {"text": str(c.get("text") or "")[:4000], "href": str(c.get("href") or "")[:600],
             "images": [str(x)[:600] for x in (c.get("images") or [])][:40]}
        k = _card_key(c)
        if not k or k in have:
            continue
        have.add(k)
        d["cards"].append(c)
        added += 1
    if url and _norm_url(url) not in [_norm_url(x) for x in d["pages"]]:
        d["pages"].append(str(url)[:600])
    _save_session(store_key, d)
    return {"ok": True, "added": added, "total": len(d["cards"]), "pages": len(d["pages"]),
            "galleries": len(d["galleries"])}


def read_gallery(store_key: str, url: str, photos: list, page_text: str = "") -> dict:
    """A car's own page: its whole photo set."""
    if not _hfile(store_key):
        return {"ok": False, "message": "Pick the store first."}
    photos = [str(x)[:600] for x in (photos or []) if str(x).startswith("http")][:60]
    if len(photos) < 2:
        return {"ok": False, "message": "No photo gallery found on this page. Open the car's own page (where all its pictures are)."}
    d = _session(store_key)
    d["galleries"][_norm_url(url)] = photos
    _save_session(store_key, d)
    # already on the program's list? give it the photos now, so "Add to my cars" can use them
    s = next(x for x in _stores() if x["key"] == store_key)
    inv_f = s["out"] / "inventory.json"
    stock = ""
    try:
        recs = json.loads(inv_f.read_text(encoding="utf-8"))
        text = str(page_text or "").upper()
        for r in recs:
            if _norm_url(r.get("detail_url")) == _norm_url(url) or \
                    (r.get("vin") and str(r["vin"]).upper() in text):
                r["photos"] = photos[:int(_store_settings(s).get("max_photos") or 20)]
                r["gallery_read"] = True
                stock = r.get("stock") or ""
                break
        if stock:
            tmp = inv_f.with_suffix(".tmp")
            tmp.write_text(json.dumps(recs, indent=1, ensure_ascii=False), encoding="utf-8")
            import os
            os.replace(tmp, inv_f)
    except Exception:
        pass
    return {"ok": True, "photos": len(photos), "stock": stock, "store": store_key,
            "message": f"{len(photos)} photos read" + (f" for {stock}." if stock else ". They're used on the next update.")}


def read_done(store_key: str, run: bool = True) -> dict:
    import time
    d = _session(store_key)
    if not d["cards"]:
        return {"ok": False, "message": "No cars read yet. Press Read the cars on this page first."}
    d["done"] = True
    d["done_at"] = time.time()
    _save_session(store_key, d)
    started = False
    f = HOOKS.get("run_store")
    if run and f:
        r = f(store_key)
        started = bool(r and r.get("ok"))
    return {"ok": True, "total": len(d["cards"]), "started": started,
            "message": (f"{len(d['cards'])} cars sent. The program is updating this store now."
                        if started else f"{len(d['cards'])} cars sent. Press Run today's update in the program.")}


def read_state(store_key: str) -> dict:
    if not _hfile(store_key):
        return {"ok": False}
    d = _session(store_key)
    return {"ok": True, "total": len(d["cards"]), "pages": len(d["pages"]), "galleries": len(d["galleries"]),
            "done": bool(d.get("done"))}


# ------------------------------------------------------------------ server
class _H(BaseHTTPRequestHandler):
    server_version = "ListingAccelerator"

    def log_message(self, *a):
        pass

    def _ok_origin(self) -> bool:
        # Only the helper: it sends our header (a web page can't, without a
        # permission this server never gives) and only from this computer.
        return self.headers.get(HEADER) == "1" and self.client_address[0] in ("127.0.0.1", "::1")

    def _json(self, code, obj):
        b = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(b)

    def do_OPTIONS(self):
        self.send_response(403)        # no permission for web pages, ever
        self.end_headers()

    def do_GET(self):
        if not self._ok_origin():
            return self._json(403, {"ok": False})
        u = urllib.parse.urlparse(self.path)
        q = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
        try:
            if u.path == "/la/ping":
                return self._json(200, {"ok": True, "version": VERSION, "app": "Listing Accelerator"})
            if u.path == "/la/cars":
                return self._json(200, cars(q.get("store", "")))
            if u.path == "/la/car":
                return self._json(200, car(q.get("store", ""), q.get("stock", "")))
            if u.path == "/la/whichstore":
                return self._json(200, which_store(q.get("url", "")))
            if u.path == "/la/readstate":
                return self._json(200, read_state(q.get("store", "")))
            if u.path == "/la/stocks":
                return self._json(200, stocks())
            if u.path == "/la/replies":
                import quick_answers
                return self._json(200, quick_answers.answers(q.get("store", ""), q.get("stock", ""),
                                                             q.get("name", ""), q.get("lang", "en")))
            if u.path == "/la/drop":
                return self._json(200, drop_info(q.get("stock", "")))
            if u.path == "/la/find":
                import finder
                return self._json(200, finder.quick(q.get("q", "")))
            if u.path == "/la/workstatus":
                f = HOOKS.get("work_car_status")
                return self._json(200, f() if f else {"done": True, "ok": False, "message": "Open the program."})
            if u.path == "/la/photo":
                p = photo_path(q.get("store", ""), q.get("stock", ""), q.get("name", ""))
                if not p:
                    return self._json(404, {"ok": False})
                data = p.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", mimetypes.guess_type(p.name)[0] or "image/jpeg")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return
        except Exception as e:
            return self._json(500, {"ok": False, "message": str(e)})
        return self._json(404, {"ok": False})

    def do_POST(self):
        if not self._ok_origin():
            return self._json(403, {"ok": False})
        u = urllib.parse.urlparse(self.path)
        try:
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(n) or b"{}") if n else {}
            if u.path == "/la/posted":
                return self._json(200, mark_posted(str(body.get("store", "")), str(body.get("stock", ""))))
            if u.path == "/la/sync":
                return self._json(200, sync(body.get("seen") or []))
            if u.path == "/la/dropped":
                return self._json(200, record_drop(str(body.get("store", "")), str(body.get("stock", "")), body.get("price")))
            if u.path == "/la/crm":
                return self._json(200, crm_save(body))
            if u.path == "/la/read":
                return self._json(200, read_page(str(body.get("store", "")), str(body.get("url", "")),
                                                 body.get("cards") or [], bool(body.get("start_over"))))
            if u.path == "/la/gallery":
                return self._json(200, read_gallery(str(body.get("store", "")), str(body.get("url", "")),
                                                    body.get("photos") or [], str(body.get("text", ""))[:20000]))
            if u.path == "/la/readdone":
                return self._json(200, read_done(str(body.get("store", "")), body.get("run", True) is not False))
            if u.path == "/la/spot":
                import finder
                return self._json(200, finder.for_post(str(body.get("text", ""))[:3000]))
            if u.path == "/la/spotwrite":
                return self._json(200, spot_write(body))
            if u.path == "/la/appt":
                return self._json(200, appointment(body))
            if u.path == "/la/group":
                return self._json(200, group_log(str(body.get("store", "")), str(body.get("stock", "")), str(body.get("url", ""))))
            if u.path == "/la/work":
                f = HOOKS.get("work_car")
                return self._json(200, f(str(body.get("store", "")), str(body.get("stock", ""))) if f
                                  else {"ok": False, "message": "Open the program."})
        except Exception as e:
            return self._json(500, {"ok": False, "message": str(e)})
        return self._json(404, {"ok": False})


def start() -> int | None:
    """Start the server in the background. Quietly does nothing if another
    copy of the program already has the port."""
    if _server["port"]:
        return _server["port"]
    for port in PORTS:
        try:
            srv = ThreadingHTTPServer(("127.0.0.1", port), _H)
        except OSError:
            continue
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        _server["port"] = port
        return port
    return None


def running_port():
    return _server["port"]


# ------------------------------------------------------------------ the extension
MANIFEST = {
    "manifest_version": 3,
    "name": "Listing Accelerator – Marketplace Helper",
    "version": VERSION,
    "description": "Listing Accelerator on Facebook: answers buyers, fills the vehicle form, checks your listings. Reads your store's inventory page when you click it. You press every Send and Publish yourself.",
    # activeTab + scripting: only when he clicks the toolbar button, on the tab
    # he's looking at (his store's inventory page), can the helper read it.
    "permissions": ["activeTab", "scripting"],
    "host_permissions": ["http://127.0.0.1/*"],
    "action": {"default_title": "Listing Accelerator: read the cars on this page", "default_icon": {"128": "icon128.png"}},
    "background": {"service_worker": "background.js"},
    "content_scripts": [{
        # Every Facebook page: Facebook moves between pages without reloading,
        # so a helper that only loaded on Marketplace pages never showed up
        # when he clicked his way there. It only shows itself on Marketplace.
        "matches": ["https://www.facebook.com/*", "https://web.facebook.com/*"],
        "js": ["content.js"],
        "run_at": "document_idle",
    }],
    "icons": {"128": "icon128.png"},
}

BACKGROUND_JS = r"""
// Talks to Listing Accelerator on this computer. Only the helper can: the
// program answers requests that carry this header, which web pages can't send.
const PORTS = [8765, 8766, 8767];
let base = null;
async function findApp(){
  if (base) {
    try { const r = await fetch(base + "/la/ping", {headers: {"X-Listing-Accelerator": "1"}}); if (r.ok) return base; } catch (e) {}
    base = null;
  }
  for (const p of PORTS){
    try {
      const u = "http://127.0.0.1:" + p;
      const r = await fetch(u + "/la/ping", {headers: {"X-Listing-Accelerator": "1"}});
      if (r.ok){ const j = await r.json(); if (j.app === "Listing Accelerator"){ base = u; return base; } }
    } catch (e) {}
  }
  return null;
}
async function call(path, opts){
  const b = await findApp();
  if (!b) return {ok: false, noapp: true, message: "Open Listing Accelerator on this computer first."};
  const r = await fetch(b + path, Object.assign({headers: {"X-Listing-Accelerator": "1", "Content-Type": "application/json"}}, opts || {}));
  return r.json();
}
async function photoData(path){
  const b = await findApp();
  if (!b) return null;
  const r = await fetch(b + path, {headers: {"X-Listing-Accelerator": "1"}});
  if (!r.ok) return null;
  const blob = await r.blob();
  const buf = new Uint8Array(await blob.arrayBuffer());
  let s = ""; for (let i = 0; i < buf.length; i += 32768) s += String.fromCharCode.apply(null, buf.subarray(i, i + 32768));
  return {type: blob.type || "image/jpeg", b64: btoa(s)};
}
// The toolbar button: read the cars on the page he's looking at.
chrome.action.onClicked.addListener(tab => {
  if (!tab || !tab.id) return;
  chrome.scripting.executeScript({target: {tabId: tab.id}, files: ["reader.js"]}).catch(() => {});
});
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  (async () => {
    try {
      if (msg.t === "cars") return reply(await call("/la/cars"));
      if (msg.t === "car") return reply(await call("/la/car?store=" + encodeURIComponent(msg.store) + "&stock=" + encodeURIComponent(msg.stock)));
      if (msg.t === "photo") return reply(await photoData(msg.url));
      if (msg.t === "posted") return reply(await call("/la/posted", {method: "POST", body: JSON.stringify({store: msg.store, stock: msg.stock})}));
      if (msg.t === "stocks") return reply(await call("/la/stocks"));
      if (msg.t === "get" && /^\/la\/[a-z]+/.test(msg.path)) return reply(await call(msg.path));
      if (msg.t === "post" && /^\/la\/[a-z]+$/.test(msg.path)) return reply(await call(msg.path, {method: "POST", body: JSON.stringify(msg.body || {})}));
      reply({ok: false});
    } catch (e) { reply({ok: false, message: String(e)}); }
  })();
  return true;
});
"""

CONTENT_JS = r"""
// Listing Accelerator – Marketplace Helper
// Fills Facebook's forms, answers buyers, checks your listings. Never presses
// Next, Publish, Post, Update or Send: you check everything and do that
// yourself. Never reads your chats on its own -- only what you click.
(() => {
  if (window.__laHelper) return; window.__laHelper = true;
  // When the helper is reloaded or updated, the copy already running in an
  // open tab loses its connection ("Extension context invalidated"). Notice
  // that, stop quietly, and ask for F5 instead of throwing errors.
  let gone = false;
  const alive = () => { try { return !!(chrome.runtime && chrome.runtime.id); } catch (e) { return false; } };
  function retire(){
    if (gone) return; gone = true;
    try { setHTML($("#b"), `<p>The helper was just updated. Press <b>F5</b> to reload this page.</p>`); } catch (e) {}
  }
  const send = m => new Promise(res => {
    if (!alive()){ retire(); return res(null); }
    try { chrome.runtime.sendMessage(m, r => { if (chrome.runtime.lastError){ /* the program isn't open */ } res(r); }); }
    catch (e){ retire(); res(null); }
  });
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const norm = t => (t || "").replace(/\s+/g, " ").trim().toLowerCase();

  // Facebook's pages refuse innerHTML ("Trusted Types"), so the panel is
  // built from its own small, fixed templates with this little reader
  // instead -- no innerHTML anywhere.
  const ENT = {"&amp;": "&", "&lt;": "<", "&gt;": ">", "&quot;": '"', "&#39;": "'", "&nbsp;": " "};
  const dec = t => t.replace(/&(amp|lt|gt|quot|#39|nbsp);/g, m => ENT[m]);
  const VOID = new Set(["input", "br", "img", "hr"]);
  function setHTML(el, str){
    const top = document.createDocumentFragment();
    const stack = [top];
    const re = /<\/([a-zA-Z0-9]+)\s*>|<([a-zA-Z0-9]+)((?:\s+[\w-]+(?:="[^"]*")?)*)\s*\/?>|([^<]+)/g;
    let m;
    while ((m = re.exec(str))){
      const cur = stack[stack.length - 1];
      if (m[1]){ if (stack.length > 1) stack.pop(); continue; }
      if (m[2]){
        const node = document.createElement(m[2]);
        const ar = /([\w-]+)(?:="([^"]*)")?/g; let a;
        while ((a = ar.exec(m[3] || ""))) node.setAttribute(a[1], a[2] === undefined ? "" : dec(a[2]));
        cur.appendChild(node);
        if (!VOID.has(m[2].toLowerCase())) stack.push(node);
        continue;
      }
      if (m[4]) cur.appendChild(document.createTextNode(dec(m[4])));
    }
    el.replaceChildren(top);
  }

  // ---------- the panel ----------
  const host = document.createElement("div");
  host.style.cssText = "position:fixed;right:16px;bottom:16px;z-index:2147483647";
  const root = host.attachShadow({mode: "open"});
  setHTML(root, `<style>
    .p{width:340px;max-height:74vh;display:flex;flex-direction:column;background:#fff;color:#14181D;border-radius:12px;
       box-shadow:0 12px 40px rgba(0,0,0,.28);font:14px/1.45 "Segoe UI",Arial,sans-serif;overflow:hidden;border:1px solid #D9DEE5}
    .h{background:#00305F;color:#fff;padding:9px 12px;display:flex;align-items:center;gap:8px;cursor:move}
    .h b{flex:1;font-size:14px} .h button{background:none;border:0;color:#fff;font-size:16px;cursor:pointer}
    .tabs{display:flex;border-bottom:1px solid #D9DEE5;background:#F4F6F8}
    .tabs button{flex:1;border:0;background:none;padding:7px 0;font:inherit;font-size:12.5px;font-weight:700;color:#5C6671;cursor:pointer;border-bottom:3px solid transparent}
    .tabs button.on{color:#00305F;border-bottom-color:#C0392B;background:#fff}
    .b{padding:10px 12px;overflow:auto}
    input,select{width:100%;box-sizing:border-box;padding:7px 9px;border:1px solid #D9DEE5;border-radius:7px;font:inherit;margin:4px 0}
    .car{padding:7px 8px;border-radius:7px;cursor:pointer;border:1px solid transparent}
    .car:hover{background:#E4EBF3} .car.on{border-color:#00305F;background:#E4EBF3}
    .car small{color:#5C6671;display:block}
    .go{background:#00305F;color:#fff;border:0;border-radius:8px;padding:9px 12px;font:inherit;font-weight:700;cursor:pointer;width:100%;margin-top:8px}
    .go:disabled{opacity:.5}
    .ghost{background:#fff;color:#00305F;border:1px solid #D9DEE5;border-radius:8px;padding:8px 12px;font:inherit;cursor:pointer;width:100%;margin-top:6px}
    .sm{background:#fff;color:#00305F;border:1px solid #D9DEE5;border-radius:6px;padding:3px 8px;font:inherit;font-size:12px;cursor:pointer;margin:3px 4px 0 0}
    .note{font-size:12.5px;color:#5C6671;margin:6px 0}
    .warn{background:#FFF8E6;border:1px solid #E0A400;border-radius:7px;padding:7px 9px;font-size:12.5px;margin-top:8px}
    .okmsg{color:#0A6E3D} .bad{color:#B3261E}
    ul{margin:6px 0;padding-left:18px;font-size:13px} li.ok{color:#0A6E3D} li.no{color:#B3261E}
    .agrid{display:grid;grid-template-columns:1fr 1fr;gap:5px;margin:6px 0}
    .ans{border:1px solid #E3E6EA;border-radius:7px;padding:6px 8px;cursor:pointer;font-weight:600;font-size:12.5px;line-height:1.25}
    .ans:hover{background:#E4EBF3} .ans.on{border-color:#E0A400;background:#FFF6DD}
    .ans span{font-weight:400;color:#5C6671;font-size:11.5px}
    .row{display:flex;gap:6px;align-items:center} .row input{flex:1}
    .lang{display:flex;gap:4px;margin:4px 0} .lang button{border:1px solid #D9DEE5;background:#fff;border-radius:10px;padding:2px 9px;font:inherit;font-size:11.5px;cursor:pointer}
    .lang button.on{background:#00305F;color:#fff;border-color:#00305F}
    .res{border:1px solid #E3E6EA;border-radius:7px;padding:7px 9px;margin:5px 0;font-size:13px}
    .res b{display:block} .res small{color:#5C6671}
    .tot{display:grid;grid-template-columns:repeat(2,1fr);gap:6px;margin:6px 0}
    .tot div{border:1px solid #E3E6EA;border-radius:7px;padding:5px 8px;font-size:12px;color:#5C6671} .tot b{display:block;font-size:17px;color:#14181D}
    .who{border:1px solid #E3E6EA;border-radius:8px;padding:4px 8px;margin:6px 0}
    .who .row input{margin:3px 0}
    .appt{border:1px solid #9FC5E8;background:#EEF5FC;border-radius:8px;padding:8px 10px;margin-top:10px}
    .appt select,.appt input{margin:4px 0}
    .p.min .b,.p.min .tabs{display:none} .p.min{width:210px}
  </style>
  <div class="p"><div class="h"><b>Listing Accelerator <span style="font-weight:400;opacity:.7;font-size:11px">helper ${chrome.runtime.getManifest().version}</span></b><button id="min" title="Shrink">–</button></div>
    <div class="tabs" id="tabs"><button data-t="replies">💬 Replies</button><button data-t="spot">🚗 Spotter</button><button data-t="post">Post</button><button data-t="find">Find</button><button data-t="list">Listings</button></div>
    <div class="b" id="b"></div></div>`);
  document.documentElement.appendChild(host);
  const $ = s => root.querySelector(s);
  $("#min").onclick = () => { const p = root.querySelector(".p"); p.classList.toggle("min"); $("#min").textContent = p.classList.contains("min") ? "+" : "–"; };
  // drag the panel
  (() => { const h = root.querySelector(".h"); let sx, sy, ox, oy;
    h.addEventListener("mousedown", e => { if (e.target.tagName === "BUTTON") return; sx = e.clientX; sy = e.clientY;
      const r = host.getBoundingClientRect(); ox = r.left; oy = r.top;
      const mv = ev => { host.style.left = (ox + ev.clientX - sx) + "px"; host.style.top = (oy + ev.clientY - sy) + "px"; host.style.right = "auto"; host.style.bottom = "auto"; };
      const up = () => { document.removeEventListener("mousemove", mv); document.removeEventListener("mouseup", up); };
      document.addEventListener("mousemove", mv); document.addEventListener("mouseup", up); }); })();

  let S = {tab: "", cars: [], store: "", pick: null, filter: "", report: null, car: null, stocks: null,
           rep: {stock: "", store: "", name: "", first: "", last: "", phone: "", email: "", lang: "en", data: null, pickedKey: "", msg: "", day: "", time: ""},
           find: {q: "", data: null, msg: ""}, spot: {on: true, el: null, text: "", name: "", data: null, pick: 0, msg: "", counts: {onScreen: 0, hits: 0}}, list: {data: null, busy: false, last: ""}, drop: null, sel: "", lastBox: null};
  const esc = t => String(t ?? "").replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
  const money = n => n ? "$" + Number(n).toLocaleString("en-US") : "";
  const P = () => location.pathname;
  const onVehicleForm = () => /\/marketplace\/create\/vehicle/.test(P());
  const onEdit = () => /\/marketplace\/(edit|item\/[^/]+\/edit)/.test(P()) || /\/marketplace\/.*listing_id=/.test(location.href) && /edit/.test(location.href);
  const onSelling = () => /\/marketplace\/you\/(selling|listings)/.test(P()) || /\/marketplace\/selling/.test(P());
  const onChat = () => /^\/messages\//.test(P()) || /\/marketplace\/inbox/.test(P());
  const onGroup = () => /^\/groups\//.test(P());
  const onSearch = () => /^\/search\//.test(P());
  const shows = () => P().startsWith("/marketplace") || onChat() || onGroup() || onSearch();

  // remember the message box he last clicked in, and the text he highlights
  document.addEventListener("focusin", e => {
    const t = e.target;
    if (t && t !== host && (t.isContentEditable || t.tagName === "TEXTAREA")) S.lastBox = t;
  }, true);
  document.addEventListener("selectionchange", () => {
    const sel = document.getSelection(); const t = sel ? String(sel) : "";
    if (t.trim() && sel.anchorNode && !host.contains(sel.anchorNode)) S.sel = t.trim();
  });

  // stock numbers the program knows, found in this page's text
  async function knownStocks(){
    if (!S.stocks){ const r = await send({t: "stocks"}); S.stocks = new Set((r && r.stocks) || []); }
    return S.stocks;
  }
  function stocksIn(el){
    const known = S.stocks || new Set(); const out = [];
    const words = ((el || document.body).innerText || "").toUpperCase().match(/[A-Z0-9]{4,12}/g) || [];
    for (const w of words) if (known.has(w) && !out.includes(w)) out.push(w);
    return out;
  }
  const mainArea = () => document.querySelector("[role=main]") || document.body;

  // put text in Facebook's message box; never presses Send
  async function intoChat(text){
    let box = S.lastBox && S.lastBox.isConnected ? S.lastBox : null;
    if (!box){
      const cands = [...document.querySelectorAll('[contenteditable=true][role=textbox], [contenteditable=true], textarea')]
        .filter(e => e.offsetParent && !host.contains(e));
      const named = cands.filter(e => /message|mensaje|aa/i.test((e.getAttribute("aria-label") || "") + " " + (e.getAttribute("aria-placeholder") || "") + " " + (e.getAttribute("placeholder") || "")));
      const pickFrom = named.length ? named : cands;
      box = pickFrom.sort((a, b) => b.getBoundingClientRect().bottom - a.getBoundingClientRect().bottom)[0] || null;
    }
    if (box){
      box.focus();
      if (box.tagName === "TEXTAREA"){ setNative(box, (box.value ? box.value + " " : "") + text); box.focus(); }
      else document.execCommand("insertText", false, text);
      await sleep(150);
      const got = norm(box.tagName === "TEXTAREA" ? box.value : box.textContent);
      if (got.includes(norm(text).slice(0, 20))) return "box";
    }
    try { await navigator.clipboard.writeText(text); return "clip"; } catch (e) { return ""; }
  }
  const placedMsg = how => how === "box" ? `<p class="note okmsg">✓ In the message box. Read it over, then press Send yourself.</p>`
    : how === "clip" ? `<p class="note">Copied. Click in the message box and press <b>Ctrl + V</b>.</p>`
    : `<p class="note bad">Couldn't place it. Click in the message box first, then try again.</p>`;

  async function load(){
    const r = await send({t: "cars"});
    if (!r || !r.ok){ draw(r && r.noapp ? "noapp" : "err", r && r.message); return; }
    S.cars = r.cars; S.stores = r.stores;
    // the program has a newer helper than the one Chrome is running
    S.old = r.version && r.version !== chrome.runtime.getManifest().version;
    if (!S.store && r.stores.length) S.store = r.stores[0].key;
    await knownStocks();
    if (!S.tab) S.tab = defaultTab();
    draw();
    if (S.tab === "list" && onSelling()) checkListings();
    if (S.tab === "replies") detectChat();
  }
  function defaultTab(){
    if (onSelling()) return "list";
    if (onVehicleForm() || onEdit()) return "post";
    if (onGroup() || onSearch()) return "spot";
    return "replies";
  }
  function draw(state, msg){
    const b = $("#b");
    if (gone){ setHTML(b, `<p>The helper was just updated. Press <b>F5</b> to reload this page.</p>`); return; }
    root.querySelectorAll("#tabs [data-t]").forEach(x => { x.classList.toggle("on", x.dataset.t === S.tab);
      x.onclick = () => { S.tab = x.dataset.t; draw(); if (S.tab === "list" && onSelling() && !S.list.data) checkListings(); if (S.tab === "replies") detectChat(); }; });
    if (state === "noapp"){ setHTML(b, `<p>Open <b>Listing Accelerator</b> on this computer, then press Try again.</p><button class="go" id="again">Try again</button>`); $("#again").onclick = load; return; }
    if (state === "err"){ setHTML(b, `<p>${esc(msg || "Something went wrong.")}</p><button class="go" id="again">Try again</button>`); $("#again").onclick = load; return; }
    const old = S.old ? `<div class="warn" style="margin:0 0 8px;border-color:#B3261E;background:#FDECEA">This helper is out of date. Open <b>chrome://extensions</b>, press the round arrow on <b>Listing Accelerator – Marketplace Helper</b>, then press F5 here.</div>` : "";
    if (S.tab === "replies") return drawReplies(b, old);
    if (S.tab === "find") return drawFind(b, old);
    if (S.tab === "list") return drawList(b, old);
    if (S.tab === "spot") return drawSpot(b, old);
    return drawPost(b, old);
  }

  // ---------- Post: fill the vehicle form, a group's sell form, or a price drop ----------
  function drawPost(b, old){
    if (onEdit()) return drawDrop(b, old);
    if (!onVehicleForm() && !onGroup()){
      setHTML(b, `${old}<p class="note">Open the vehicle listing form and the helper fills it in for you. In one of your groups, it fills the group's sell form or post box.</p>
        <button class="go" id="tov">Create vehicle listing</button>
        <button class="ghost" id="tosell">Check my listings</button>`);
      $("#tov").onclick = () => location.href = "https://www.facebook.com/marketplace/create/vehicle";
      $("#tosell").onclick = () => { S.tab = "list"; location.href = "https://www.facebook.com/marketplace/you/selling"; };
      return;
    }
    const mine = S.cars.filter(c => c.store === S.store);
    const match = c => !S.filter || norm(c.title + " " + c.stock).includes(norm(S.filter));
    // searching shows already-posted cars too (to post one again); the plain list is what's left to post
    // a search looks in every store, so a stock number is found wherever it is
    const list = (S.filter || onGroup() ? (S.filter ? S.cars : mine) : mine).filter(c => (S.filter || onGroup() ? true : !c.posted) && match(c));
    const many = (S.stores || []).length > 1;
    const left = mine.filter(c => !c.posted).length;
    const stInfo = (S.stores || []).find(x => x.key === S.store) || {};
    const empty = stInfo.ready === false ? "This store's list isn't built yet. In Listing Accelerator, press <b>Run today's update</b>, then press F5 here."
      : S.filter ? "No car matches that. It may be outside <b>What you work</b>, or not on the website today. Try the <b>Find</b> tab."
      : "Everything is posted. New cars show up here after the next update.";
    setHTML(b, `${old}${S.stores.length > 1 ? `<select id="st">${S.stores.map(s => `<option value="${esc(s.key)}" ${s.key === S.store ? "selected" : ""}>${esc(s.name)}</option>`).join("")}</select>` : ""}
      <input id="q" placeholder="Stock number, year or model" value="${esc(S.filter)}">
      <div class="note">${onGroup() ? "Posting in this group · pick a car" : left + " not posted yet"}${S.filter ? ` · ${list.length} match` : ""}</div>
      <div id="list">${list.slice(0, 40).map(c => `<div class="car ${S.pick && S.pick.stock === c.stock ? "on" : ""}" data-s="${esc(c.stock)}" data-st="${esc(c.store)}">${esc(c.title)}<small>${esc(c.stock)}${many && S.filter ? " · " + esc(c.store_name) : ""} · ${c.photos} photos${c.posted ? " · posted " + esc(c.posted_date) : ""}</small></div>`).join("") || `<p class="note">${empty}</p>`}</div>
      ${S.pick ? `<button class="go" id="fill">${onGroup() ? "Fill this group post" : "Fill the form"}: ${esc(S.pick.stock)}</button>` : ""}
      <div id="rep">${S.report || ""}</div>
      ${S.car && !onGroup() ? `<button class="ghost" id="done">I published it — record it as posted</button>` : ""}
      ${S.car && onGroup() ? `<button class="ghost" id="gdone">I posted it in this group — log it</button>` : ""}
      <div class="warn">${onGroup() ? "Check it over, then press <b>Post</b> yourself." : "Check every box, then press <b>Next</b> and <b>Publish</b> yourself. Leave the <b>VIN</b> box empty."}</div>`);
    const st = $("#st"); if (st) st.onchange = () => { S.store = st.value; S.pick = null; draw(); };
    const q = $("#q"); q.oninput = () => { S.filter = q.value; const pos = q.selectionStart; draw(); const q2 = $("#q"); q2.focus(); q2.setSelectionRange(pos, pos); };
    root.querySelectorAll("[data-s]").forEach(el => el.onclick = () => { S.store = el.dataset.st || S.store; S.pick = S.cars.find(c => c.stock === el.dataset.s && c.store === S.store); S.report = null; S.car = null; draw(); });
    const f = $("#fill"); if (f) f.onclick = onGroup() ? fillGroup : fill;
    const d = $("#done"); if (d) d.onclick = async () => {
      const r = await send({t: "posted", store: S.store, stock: S.car.stock});
      S.report = r && r.ok ? `<p class="note okmsg">✓ ${esc(r.message)}</p>` : `<p class="note bad">${esc((r && r.message) || "Couldn't record it.")}</p>`;
      if (r && r.ok){ const c = S.cars.find(x => x.stock === S.car.stock && x.store === S.store); if (c) c.posted = true; S.pick = null; S.car = null; }
      draw();
    };
    const g = $("#gdone"); if (g) g.onclick = async () => {
      const r = await send({t: "post", path: "/la/group", body: {store: S.store, stock: S.car.stock, url: location.href}});
      S.report = r && r.ok ? `<p class="note okmsg">✓ Logged: ${esc(S.car.stock)} posted in this group today.</p>` : `<p class="note bad">Couldn't log it.</p>`;
      S.car = null; S.pick = null; draw();
    };
  }

  // ---------- a price drop, on the Edit listing page ----------
  async function drawDrop(b, old){
    if (!S.drop || S.drop.path !== location.href){
      setHTML(b, `${old}<p class="note">Reading this listing…</p>`);
      await sleep(600);
      let st = "";
      const boxes = [...document.querySelectorAll("input, textarea")].map(x => (x.value || "").toUpperCase()).join(" ");
      for (const w of (boxes.match(/[A-Z0-9]{4,12}/g) || [])) if (S.stocks.has(w)){ st = w; break; }
      if (!st) st = stocksIn(mainArea())[0] || "";
      S.drop = {path: location.href, stock: st, info: st ? await send({t: "get", path: "/la/drop?stock=" + encodeURIComponent(st)}) : null, msg: ""};
    }
    const D = S.drop, i = D.info;
    const priceBox = inputFor("Price");
    const now = priceBox ? Number(String(priceBox.value || "").replace(/[^0-9]/g, "")) : 0;
    if (!D.stock || !i || !i.ok){
      setHTML(b, `${old}<p class="note">Couldn't tell which car this is. The stock number should be in the title or model box (it is for listings the helper filled).</p>
        <div class="row"><input id="dst" placeholder="Stock #"><button class="sm" id="dgo">Look up</button></div>`);
      $("#dgo").onclick = async () => { const v = $("#dst").value.trim().toUpperCase(); S.drop = {path: location.href, stock: v, info: await send({t: "get", path: "/la/drop?stock=" + encodeURIComponent(v)}), msg: ""}; draw(); };
      return;
    }
    const diff = now && i.want ? now - i.want : 0;
    setHTML(b, `${old}<p><b>${esc(i.vehicle)}</b><br><span class="note">${esc(i.stock)} · ${esc(i.store_name)}</span></p>
      <div class="tot"><div>On this listing<b>${money(now) || "—"}</b></div><div>${i.due ? "Drop due today to" : "Should be"}<b>${money(i.want)}</b></div></div>
      ${diff > 50 ? `<button class="go" id="dfill">Put ${money(i.want)} in the price box</button>`
        : diff < -50 ? `<p class="note">The website price went <b>up</b> to ${money(i.want)}.</p><button class="ghost" id="dfill">Put ${money(i.want)} in the price box</button>`
        : `<p class="note okmsg">✓ The price is right.</p>`}
      ${D.msg}
      ${D.filled ? `<button class="ghost" id="drec">I pressed Update — record the drop</button>` : ""}
      <div class="warn">Check it, then press <b>Update</b> yourself.</div>`);
    const f = $("#dfill"); if (f) f.onclick = async () => {
      const ok = await typeInto("Price", String(i.want));
      D.filled = ok; D.msg = ok ? `<p class="note okmsg">✓ Price box set to ${money(i.want)}.</p>` : `<p class="note bad">Couldn't find the price box. Type ${money(i.want)} yourself.</p>`;
      draw();
    };
    const r = $("#drec"); if (r) r.onclick = async () => {
      const x = await send({t: "post", path: "/la/dropped", body: {store: i.store, stock: i.stock, price: i.want}});
      D.msg = `<p class="note ${x && x.ok ? "okmsg" : "bad"}">${esc((x && x.message) || "Couldn't record it.")}</p>`; D.filled = false; draw();
    };
  }

  // ---------- Replies: quick answers into the chat, and Save to CRM ----------
  function apptDays(){
    const out = [], d = new Date();
    for (let i = 0; i < 7; i++){
      const x = new Date(d.getFullYear(), d.getMonth(), d.getDate() + i);
      const v = x.getFullYear() + "-" + String(x.getMonth() + 1).padStart(2, "0") + "-" + String(x.getDate()).padStart(2, "0");
      out.push([v, i === 0 ? "Today" : i === 1 ? "Tomorrow" : x.toLocaleDateString("en-US", {weekday: "long", month: "short", day: "numeric"})]);
    }
    return out;
  }
  function guessName(){
    const t = (document.title || "").replace(/^\(\d+\)\s*/, "");
    const first = t.split("|")[0].trim();
    if (first && !/facebook|messenger|marketplace|messages|inbox/i.test(first) && /[a-z]/i.test(first) && first.length < 40) return first;
    return "";
  }
  function fromText(t){
    t = String(t || ""); const out = {};
    const ph = t.match(/(?:\+?1[\s.-]?)?\(?(\d{3})\)?[\s.-]?(\d{3})[\s.-]?(\d{4})(?!\d)/);
    if (ph) out.phone = `${ph[1]}-${ph[2]}-${ph[3]}`;
    const em = t.match(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/); if (em) out.email = em[0];
    const nm = t.replace(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/g, " ").match(/\b(?:my name is|i'm|im|this is|soy|me llamo)?\s*([A-Z][a-zA-Z'-]+)\s+([A-Z][a-zA-Z'-]+)\b/);
    if (nm && !/\d/.test(nm[0])){ out.first = nm[1]; out.last = nm[2]; }
    return out;
  }
  async function detectChat(){
    if (S.rep.stock) return;
    await knownStocks();
    const st = stocksIn(mainArea())[0] || "";
    if (st){ S.rep.stock = st; S.rep.auto = true; }
    if (!S.rep.first){ const g = guessName().split(/\s+/); S.rep.first = g[0] || ""; S.rep.last = g.slice(1).join(" "); S.rep.name = (S.rep.first + " " + S.rep.last).trim(); }
    if (S.rep.stock) await loadReplies();
    if (S.tab === "replies") draw();
  }
  async function loadReplies(){
    const R = S.rep;
    if (!R.stock){ R.data = null; return; }
    R.data = await send({t: "get", path: `/la/replies?stock=${encodeURIComponent(R.stock)}&store=${encodeURIComponent(R.store || "")}&name=${encodeURIComponent(R.name || "")}&lang=${R.lang}`});
  }
  function drawReplies(b, old){
    const R = S.rep, d = R.data;
    setHTML(b, `${old}<div class="row"><input id="rst" placeholder="Stock # of the car they're asking about" value="${esc(R.stock)}"><button class="sm" id="rgo">Use</button></div>
      ${d && d.ok ? `<div class="note">${R.auto ? "Found in this chat: " : ""}<b>${esc(d.car)}</b> · ${esc(d.price)}</div>` : d ? `<p class="note bad">${esc(d.message)}</p>` : `<p class="note">Open the buyer's chat, or type the stock number. The listing title has it.</p>`}
      <div class="who"><div class="row"><input id="rfirst" placeholder="First name" value="${esc(R.first)}"><input id="rlast" placeholder="Last name" value="${esc(R.last)}"></div>
        <div class="row"><input id="rphone" placeholder="Phone" value="${esc(R.phone)}"><input id="remail" placeholder="Email" value="${esc(R.email)}"></div>
        <div class="row" style="flex-wrap:wrap"><button class="sm" id="rsel" title="Highlight their number, email or name in the chat first">Use highlighted text</button>
          ${R.phone || R.email ? "" : `<button class="sm" id="rask">Ask for their number</button>`}</div></div>
      <div class="lang"><button data-l="en" class="${R.lang === "en" ? "on" : ""}">English</button><button data-l="es" class="${R.lang === "es" ? "on" : ""}">Español</button></div>
      ${d && d.ok ? `<div class="agrid">${d.answers.map(a => `<div class="ans ${R.pickedKey === a.key ? "on" : ""}" data-a="${esc(a.key)}">${R.pickedKey === a.key ? "✓ " : ""}${esc(a.label)}</div>`).join("")}</div>` : ""}
      ${R.msg || ""}
      <div class="appt"><b>📅 Set the appointment</b>
        <div class="row"><select id="aday">${apptDays().map(([v, l]) => `<option value="${v}" ${R.day === v ? "selected" : ""}>${l}</option>`).join("")}</select>
          <input id="atime" type="time" value="${esc(R.time || "14:00")}" style="width:110px"></div>
        <button class="go" id="appt">Confirm it in the chat &amp; save to CRM</button></div>
      <div style="border-top:1px solid #E3E6EA;margin-top:10px;padding-top:8px">
        <button class="ghost" id="rcrm">💾 Save ${esc(R.first || "this buyer")} to Accelerator CRM</button>
        ${R.first && (!R.last || !(R.phone || R.email)) ? `<div class="note">For your dealer CRM you'll still need ${[!R.last && "a last name", !(R.phone || R.email) && "a phone or email"].filter(Boolean).join(" and ")}.</div>` : ""}
        <div class="note">${S.sel ? `Includes the chat you highlighted (${S.sel.length} characters).` : "Tip: highlight their messages first and they're saved to the card too."}</div></div>
      <div class="warn">The answer goes in Facebook's message box. Read it, then press <b>Send</b> yourself.</div>`);
    const go = async () => { R.stock = $("#rst").value.trim().toUpperCase(); R.auto = false; if ($("#rfirst")) { R.first = $("#rfirst").value.trim(); R.last = ($("#rlast") || {value:""}).value.trim(); R.name = [R.first, R.last].filter(Boolean).join(" "); } R.msg = ""; await loadReplies(); draw(); };
    $("#rgo").onclick = go; $("#rst").onkeydown = e => { if (e.key === "Enter") go(); };
    const readWho = () => { R.first = $("#rfirst").value.trim(); R.last = $("#rlast").value.trim(); R.phone = $("#rphone").value.trim(); R.email = $("#remail").value.trim(); R.name = (R.first + " " + R.last).trim(); };
    ["#rfirst", "#rlast", "#rphone", "#remail"].forEach(id => $(id).onchange = async () => { const f0 = R.first; readWho(); if (R.first !== f0){ await loadReplies(); draw(); } });
    const rs = $("#rsel"); if (rs) rs.onclick = () => { readWho();
      if (!S.sel){ R.msg = `<p class="note">Highlight their phone number, email or name in the chat first, then press this again.</p>`; return draw(); }
      const got = fromText(S.sel);
      if (got.phone) R.phone = got.phone; if (got.email) R.email = got.email;
      if (got.first && !R.first) R.first = got.first; if (got.last && !R.last) R.last = got.last;
      R.name = (R.first + " " + R.last).trim();
      R.msg = got.phone || got.email || got.first ? `<p class="note okmsg">✓ Filled in ${[got.phone && "phone", got.email && "email", got.first && "name"].filter(Boolean).join(", ")}.</p>` : `<p class="note bad">No phone, email or name in what you highlighted.</p>`;
      draw(); };
    const ra = $("#rask"); if (ra) ra.onclick = async () => { readWho();
      const t = R.lang === "es" ? `Para mandarle la confirmación y la dirección por texto, ¿cuál es su apellido y el mejor número para comunicarme con usted?`
                                : `So I can text you a confirmation and directions${R.first ? ", " + R.first : ""}, what's your last name and the best number to reach you?`;
      R.msg = placedMsg(await intoChat(t)); draw(); };
    root.querySelectorAll("[data-l]").forEach(x => x.onclick = async () => { R.lang = x.dataset.l; await loadReplies(); draw(); });
    root.querySelectorAll("[data-a]").forEach(x => x.onclick = async () => {
      const a = d.answers.find(y => y.key === x.dataset.a);
      R.pickedKey = a.key; R.msg = placedMsg(await intoChat(a.text)); draw();
    });
    $("#aday").onchange = () => { R.day = $("#aday").value; };
    $("#atime").onchange = () => { R.time = $("#atime").value; };
    $("#appt").onclick = async () => {
      readWho(); R.day = $("#aday").value; R.time = $("#atime").value;
      const r = await send({t: "post", path: "/la/appt", body: {name: R.name, phone: R.phone, email: R.email, stock: R.stock, when: R.day + "T" + R.time, lang: R.lang, note: S.sel || ""}});
      if (!r || !r.ok){ R.msg = `<p class="note bad">${esc((r && r.message) || "Couldn't save it.")}</p>`; return draw(); }
      S.sel = "";
      R.msg = `<p class="note okmsg">✓ ${esc(r.message)}</p>` + placedMsg(await intoChat(r.text));
      draw();
    };
    $("#rcrm").onclick = async () => {
      readWho();
      if (!R.first){ R.msg = `<p class="note bad">Type at least their first name.</p>`; return draw(); }
      const r = await send({t: "post", path: "/la/crm", body: {name: R.name, phone: R.phone, email: R.email, stock: R.stock, note: S.sel || ""}});
      R.msg = `<p class="note ${r && r.ok ? "okmsg" : "bad"}">${esc((r && r.message) || "Couldn't save.")}</p>`;
      if (r && r.ok) S.sel = "";
      draw();
    };
  }

  // ---------- Find: search every store without leaving Facebook ----------
  function drawFind(b, old){
    const F = S.find, d = F.data;
    setHTML(b, `${old}<div class="row"><input id="fq" placeholder="e.g. RAV4 under 24k · truck 2019+ · AWD SUV" value="${esc(F.q)}"><button class="sm" id="fgo">Find</button></div>
      <div class="note">Every used car at every store, including ones you don't post.</div>
      ${F.msg || ""}
      ${d && d.ok ? `<div class="note">${d.total} match${d.total === 1 ? "" : "es"}${d.total > d.results.length ? " · best " + d.results.length + " shown" : ""}</div>` +
        d.results.map((x, i) => `<div class="res"><b>${esc(x.name)}</b><small>${money(x.price) || "Call"} · ${x.miles ? Number(x.miles).toLocaleString() + " mi" : ""} · ${esc(x.store)} · ${esc(x.stock)}${x.exact ? "" : " · close: " + esc((x.why || []).join(", "))}</small><br>
          <button class="sm" data-chat="${i}">Put in chat</button><button class="sm" data-ans="${i}">Answers</button>${x.photos_here ? "" : `<button class="sm" data-work="${i}">⬇ Add to my cars</button>`}</div>`).join("") : ""}`);
    const go = async () => { F.q = $("#fq").value.trim(); if (!F.q) return; F.msg = `<p class="note">Searching…</p>`; draw();
      F.data = await send({t: "get", path: "/la/find?q=" + encodeURIComponent(F.q)}); F.msg = ""; draw(); };
    $("#fgo").onclick = go; $("#fq").onkeydown = e => { if (e.key === "Enter") go(); };
    root.querySelectorAll("[data-chat]").forEach(x => x.onclick = async () => {
      const c = d.results[+x.dataset.chat];
      const text = `${c.name}: ${money(c.price)}${c.miles ? ", " + Number(c.miles).toLocaleString() + " miles" : ""}, at ${c.store}. ${c.url || ""}`.trim();
      F.msg = placedMsg(await intoChat(text)); draw();
    });
    root.querySelectorAll("[data-ans]").forEach(x => x.onclick = async () => {
      const c = d.results[+x.dataset.ans];
      S.rep.stock = c.stock; S.rep.store = c.store_key; S.rep.auto = false; await loadReplies(); S.tab = "replies"; draw();
    });
    root.querySelectorAll("[data-work]").forEach(x => x.onclick = async () => {
      const c = d.results[+x.dataset.work];
      const r = await send({t: "post", path: "/la/work", body: {store: c.store_key, stock: c.stock}});
      if (!r || !r.ok){ F.msg = `<p class="note bad">${esc((r && r.message) || "Couldn't start.")}</p>`; return draw(); }
      x.disabled = true;
      for (let n = 0; n < 240; n++){
        await sleep(1500);
        const w = await send({t: "get", path: "/la/workstatus"});
        x.textContent = w && !w.done ? "⏳ " + (w.step || "Working") : (w && w.ok ? "✓ In your cars" : "Try again");
        if (!w || w.done){ F.msg = `<p class="note ${w && w.ok ? "okmsg" : "bad"}">${esc((w && w.message) || "")}</p>`; if (w && w.ok){ c.photos_here = true; S.cars = []; load(); } else draw(); break; }
      }
    });
  }


  // ---------- Spotter: people shopping for a vehicle, on the page he's reading ----------
  // Only marks posts already on his screen. Never scrolls, never collects
  // names, never sends anything: he picks a post, a car, and presses Post.
  const INTENT = /\b(iso|i\.s\.o\.?|in search of|looking for|lf|lfm|wtb|want(?:ing)? to buy|shopping for|searching for|on the hunt for|in the market for|(?:help (?:me|us|her|him|them|my \w+)|need(?:ing)? to|trying to|want to|hoping to) (?:find|get|buy)|looking to (?:buy|get|find)|find (?:me |us |her |him )?(?:a|an) (?:[\w-]+\s+){0,3}(?:car|truck|suv|van|minivan|vehicle|ride|jeep|sedan)|need(?:ing)?\s+(?:a|an|another)\s+(?:[\w-]+\s+){0,3}(?:car|truck|suv|van|minivan|vehicle|ride|jeep|sedan)|budget|bad credit|no credit|poor credit|first car|recommend (?:a|any) (?:dealer|car lot|lot)|anyone (?:selling|know|have)|who (?:sells|has|finances)|buy here pay here)\b/i;
  const CARWORD = /\b(car|cars|truck|trucks|suv|van|minivan|sedan|jeep|vehicle|ride|4x4|awd|4wd|toyota|honda|ford|chevy|chevrolet|nissan|dodge|ram|gmc|hyundai|kia|subaru|mazda|volkswagen|vw|buick|cadillac|lexus|acura|tacoma|tundra|silverado|f-?150|camry|corolla|accord|civic|rav4|cr-?v|explorer|equinox|wrangler|cherokee|odyssey|sienna|altima|escape|malibu)\b/i;
  const SELLING = /\b(for sale|selling (?:my|a|our|this)|obo|asking \$?\d|price is firm|firm on price)\b/i;
  // the post's own words -- not the comments under it (each is its own article)
  function postText(a){
    let t = a.innerText || "";
    for (const c of a.querySelectorAll('[role=article]')) t = t.replace(c.innerText || "", " ");
    return t.replace(/🚗 Looking to buy.*?Find matches/s, "").slice(0, 1500);
  }
  // Every post, however the page is built: the ones Facebook labels as
  // posts, and -- on pages that don't (search results) -- each block that
  // holds exactly one post's own Like / Comment buttons.
  const LIKE = '[aria-label="Like"], [aria-label="Me gusta"], [aria-label="Comment"], [aria-label="Leave a comment"], [aria-label="Comentar"]';
  function likeButtons(el){ return [...el.querySelectorAll(LIKE)].filter(b => !b.closest(".la-spot")); }
  function postBoxes(){
    const out = [];
    for (const a of document.querySelectorAll('[role=article]')){
      if (host.contains(a) || !a.offsetParent) continue;
      if (a.parentElement && a.parentElement.closest('[role=article]')) continue;     // a comment, not a post
      out.push(a);
    }
    const seen = new Set(out);
    for (const b of document.querySelectorAll(LIKE)){
      if (host.contains(b) || !b.offsetParent || b.closest('[role=article]')) continue;
      let n = b, box = null;
      for (let i = 0; i < 30 && n.parentElement; i++){
        const par = n.parentElement;
        // the post is the biggest block that still has only this post's buttons
        const mine = likeButtons(par).filter(x => !(x.getAttribute("aria-label") || "").match(/comment|comentar/i)).length;
        if (mine > 1 || par === document.body || par.getAttribute("role") === "main" || par.getAttribute("role") === "feed") { box = n; break; }
        n = par;
      }
      if (box && !seen.has(box) && (box.innerText || "").length > 30){ seen.add(box); out.push(box); }
    }
    return out;
  }
  function scanSpot(){
    let onScreen = 0, hits = 0;
    for (const a of postBoxes()){
      onScreen++;
      const t = postText(a);
      const hit = INTENT.test(t) && CARWORD.test(t) && !(SELLING.test(t) && !/\b(iso|in search of|looking for|wtb)\b/i.test(t));
      if (hit){ hits++; markPost(a); }
    }
    const c = S.spot.counts; if (c.onScreen !== onScreen || c.hits !== hits){ S.spot.counts = {onScreen, hits}; if (S.tab === "spot") draw(); }
  }
  function markPost(a){
    if (a.querySelector(":scope > .la-spot")) return;
    a.style.outline = "3px solid #E5A100"; a.style.outlineOffset = "-3px"; a.style.borderRadius = "8px";
    const bar = document.createElement("div"); bar.className = "la-spot";
    bar.style.cssText = 'display:flex;gap:8px;align-items:center;padding:6px 12px;background:#FFF4D6;font:600 13px "Segoe UI",Arial,sans-serif;color:#7A4D00;border-radius:8px 8px 0 0';
    bar.append(document.createTextNode("🚗 Looking to buy"));
    const btn = document.createElement("button"); btn.textContent = "🔍 Find matches";
    btn.style.cssText = 'border:1px solid #00305F;background:#fff;color:#00305F;border-radius:7px;padding:3px 10px;font:700 12.5px "Segoe UI",Arial,sans-serif;cursor:pointer';
    btn.onclick = e => { e.preventDefault(); e.stopPropagation(); selectPost(a); };
    bar.append(btn);
    a.prepend(bar);
  }
  // The poster's name: the first short line that's just a name ("Rae Collins",
  // or "Rae Collins · 3h"), never a button row ("Like Comment Share").
  const NOTNAME = /^(like|comment|share|send|reply|follow|join|see more|see translation|most relevant|me gusta|comentar|compartir|looking|iso|anyone|need|find|public|sponsored)\b/i;
  function posterName(t){
    for (const raw of t.split("\n").map(x => x.trim()).filter(Boolean).slice(0, 5)){
      const ln = raw.split("·")[0].trim();
      if (NOTNAME.test(ln) || /\d/.test(ln) || ln.length > 40) continue;
      if (/^[A-Z][\w'’.-]*(?:\s+[A-Z][\w'’.-]*){0,3}$/.test(ln)) return ln;
    }
    return "";
  }
  async function selectPost(a){
    const t = postText(a);
    Object.assign(S.spot, {el: a, text: t, name: posterName(t), pick: 0, msg: "", data: null});
    S.tab = "spot";
    const p = root.querySelector(".p"); if (p.classList.contains("min")){ p.classList.remove("min"); $("#min").textContent = "–"; }
    draw();
    S.spot.data = await send({t: "post", path: "/la/spot", body: {text: t}});
    draw();
  }
  async function intoComment(a, text){
    const box = () => a.querySelector('[contenteditable=true][role=textbox], [contenteditable=true]');
    let el = box();
    if (!el){
      const btn = [...a.querySelectorAll('[role=button], button')].find(x => /^(comment|leave a comment|write a comment|comentar)$/i.test(((x.getAttribute("aria-label") || x.innerText || "") + "").trim()));
      if (btn){ btn.click(); for (let i = 0; i < 12 && !el; i++){ await sleep(250); el = box() || (document.activeElement && document.activeElement.isContentEditable && !host.contains(document.activeElement) ? document.activeElement : null); } }
    }
    if (el){
      el.focus(); document.execCommand("insertText", false, text); await sleep(150);
      if (norm(el.textContent).includes(norm(text).slice(0, 20))) return "box";
    }
    try { await navigator.clipboard.writeText(text); return "clip"; } catch (e) { return ""; }
  }
  function drawSpot(b, old){
    const P2 = S.spot, d = P2.data, c = P2.counts;
    const where = onGroup() || onSearch();
    let body = `${old}<div class="tot"><div>Posts on screen<b>${c.onScreen}</b></div><div>Looking to buy<b style="color:#B26A00">${c.hits}</b></div></div>
      <label class="note" style="display:flex;gap:6px;align-items:center"><input type="checkbox" id="son" ${P2.on ? "checked" : ""} style="width:auto;margin:0"> Mark posts from people shopping</label>`;
    if (!where){
      body += `<p class="note">Open one of your local buy/sell groups (or search Facebook posts for <i>ISO car</i>) and scroll as usual. Posts from people shopping for a vehicle light up. Press <b>Find matches</b> on one.</p>`;
    } else if (!P2.el){
      body += `<p class="note">Scroll as usual. Posts that sound like someone shopping get a yellow border and <b>🔍 Find matches</b>. Nothing is saved or sent.</p>`;
    } else {
      const r = d && d.ok ? d.results : [];
      body += `<div class="res" style="background:#F4F6F8"><small><b>${esc(P2.name || "They")} ${P2.name ? "is" : "are"} looking for</b></small><br>${d ? (d.chips || []).map(x => `<span class="sm" style="cursor:default">${esc(x)}</span>`).join("") || "<small>(nothing specific)</small>" : "<small>Reading the post…</small>"}</div>
        ${d && d.message ? `<p class="note">${esc(d.message)}</p>` : ""}
        ${d && d.ok && !d.message ? `<p class="note"><b>${d.total ? (d.total > r.length ? `Best ${r.length} of ${d.total}` : `${r.length}`) + " of your cars fit" : "Nothing fits yet"}</b> (all stores):</p>` : ""}
        ${r.map((x, i) => `<div class="car ${P2.pick === i ? "on" : ""}" data-pk="${i}">${esc(x.name)} · ${money(x.price) || "Call"}<small>${x.miles ? Number(x.miles).toLocaleString() + " mi · " : ""}${esc(x.store)}${x.exact ? "" : " · close: " + esc((x.why || []).join(", "))}${x.photos_here ? " · ✓ photos" : ""}</small></div>`).join("")}
        <div class="row"><input id="sname" placeholder="Their first name (optional)" value="${esc((P2.name || "").split(" ")[0])}"></div>
        ${r.length ? `<button class="go" id="scom">Write a comment about the ${esc(r[P2.pick].model || "car")}</button>
          <button class="ghost" id="smsg">Write a private message instead</button>
          ${r[P2.pick].photos_here ? "" : `<button class="ghost" id="swork">⬇ Get its photos</button>`}` : ""}
        ${P2.msg}
        <button class="ghost" id="scrm">💾 Save ${esc((P2.name || "them").split(" ")[0])} to Accelerator CRM (after they answer)</button>
        <div class="warn">Check the group's rules — some don't allow dealers to answer. Answer real requests one at a time, with a car that really fits. You press <b>Post</b> or <b>Send</b>.</div>`;
    }
    setHTML(b, body);
    $("#son").onchange = () => { S.spot.on = $("#son").checked; };
    root.querySelectorAll("[data-pk]").forEach(x => x.onclick = () => { P2.pick = +x.dataset.pk; P2.msg = ""; draw(); });
    const nameNow = () => { const n = $("#sname"); return n ? n.value.trim() : ""; };
    const write = async kind => {
      const x = d.results[P2.pick];
      const w = await send({t: "post", path: "/la/spotwrite", body: {stock: x.stock, store: x.store_key, name: nameNow(), chips: d.chips, kind}});
      if (!w || !w.ok){ P2.msg = `<p class="note bad">${esc((w && w.message) || "Couldn't write it.")}</p>`; return draw(); }
      if (kind === "comment"){
        const how = await intoComment(P2.el, w.text);
        P2.msg = how === "box" ? `<p class="note okmsg">✓ In the comment box under their post. Read it, then press Post yourself.</p>` : placedMsg(how);
      } else {
        try { await navigator.clipboard.writeText(w.text); } catch (e) {}
        P2.msg = `<p class="note">Message copied. Click their name, press <b>Message</b>, then <b>Ctrl + V</b> and Send.</p>`;
      }
      draw();
    };
    const sc = $("#scom"); if (sc) sc.onclick = () => write("comment");
    const sm = $("#smsg"); if (sm) sm.onclick = () => write("message");
    const sw = $("#swork"); if (sw) sw.onclick = async () => { const x = d.results[P2.pick];
      const r = await send({t: "post", path: "/la/work", body: {store: x.store_key, stock: x.stock}});
      P2.msg = `<p class="note ${r && r.ok ? "okmsg" : "bad"}">${esc((r && r.message) || "")}${r && r.ok ? " Ready in about a minute." : ""}</p>`; draw(); };
    const cr = $("#scrm"); if (cr) cr.onclick = async () => {
      const n = (nameNow() + " " + (P2.name || "").split(" ").slice(1).join(" ")).trim();
      if (!n){ P2.msg = `<p class="note bad">Type their name first.</p>`; return draw(); }
      const x = d && d.ok && d.results[P2.pick];
      const r = await send({t: "post", path: "/la/crm", body: {name: n, stock: x ? x.stock : "", note: "From a Facebook post: " + P2.text.slice(0, 600)}});
      P2.msg = `<p class="note ${r && r.ok ? "okmsg" : "bad"}">${esc((r && r.message) || "Couldn't save.")}</p>`; draw();
    };
  }
  // ---------- Listings: check Your listings against the program ----------
  function containerFor(el, stock){
    let n = el;
    for (let i = 0; i < 9 && n && n.parentElement; i++){
      n = n.parentElement;
      const t = n.innerText || "";
      if (/\$\s?[\d,]{3,}/.test(t)){
        const others = stocksIn(n).filter(x => x !== stock);
        return others.length ? null : n;
      }
    }
    return null;
  }
  function scanListings(){
    const found = [];
    const walker = document.createTreeWalker(mainArea(), NodeFilter.SHOW_TEXT);
    const seen = new Set();
    let tn;
    while ((tn = walker.nextNode())){
      const words = (tn.nodeValue || "").toUpperCase().match(/[A-Z0-9]{4,12}/g) || [];
      for (const w of words){
        if (!S.stocks.has(w) || seen.has(w)) continue;
        const el = tn.parentElement; if (!el || host.contains(el) || !el.offsetParent) continue;
        const box = containerFor(el, w);
        const text = box ? box.innerText : el.innerText;
        const m = text.match(/\$\s?([\d,]{3,})/);
        seen.add(w);
        found.push({stock: w, price: m ? m[1].replace(/,/g, "") : "", fb_sold: /\b(sold|marked as sold|vendido)\b/i.test(text.replace(w, "")), el});
      }
    }
    return found;
  }
  function badge(el, res){
    let bd = el.parentElement && el.parentElement.querySelector(":scope > .la-badge");
    if (!bd){ bd = document.createElement("span"); bd.className = "la-badge"; el.after(bd); }
    const col = {sold: "#B3261E", drop: "#B26A00", up: "#1F4F8B", ok: "#0A6E3D", fbsold: "#B26A00", done: "#5C6671", unknown: "#5C6671"}[res.status] || "#5C6671";
    bd.textContent = " " + ({sold: "🔴 ", drop: "🟡 ", up: "🔵 ", ok: "✅ ", fbsold: "🟡 ", done: "✔ ", unknown: ""}[res.status] || "") + res.say;
    bd.style.cssText = `display:inline-block;margin:2px 0 0 6px;padding:1px 7px;border-radius:9px;font:600 12px/1.5 "Segoe UI",Arial,sans-serif;color:#fff;background:${col}`;
  }
  async function checkListings(){
    if (S.list.busy) return;
    S.list.busy = true;
    await knownStocks();
    const items = scanListings();
    const key = items.map(x => x.stock + ":" + x.price + ":" + x.fb_sold).join("|");
    if (key && key !== S.list.last){
      S.list.last = key;
      const r = await send({t: "post", path: "/la/sync", body: {seen: items.map(({stock, price, fb_sold}) => ({stock, price, fb_sold}))}});
      if (r && r.ok){
        S.list.data = r;
        S.list.recorded = [...new Set([...(S.list.recorded || []), ...r.recorded])];
        for (const res of r.results){ const it = items.find(x => x.stock === res.stock); if (it) badge(it.el, res); }
        if (r.recorded.length) S.cars = [];
      }
    }
    S.list.busy = false;
    if (S.tab === "list") draw();
  }
  function drawList(b, old){
    if (!onSelling()){
      setHTML(b, `${old}<p class="note">Open <b>Your listings</b> on Marketplace and the helper checks every listing against the program: it records what's posted, and marks what's sold, what needs a price drop, and what isn't posted yet.</p>
        <button class="go" id="tosell">Open Your listings</button>`);
      $("#tosell").onclick = () => location.href = "https://www.facebook.com/marketplace/you/selling";
      return;
    }
    const d = S.list.data;
    if (!d){ setHTML(b, `${old}<p class="note">Checking your listings…</p><button class="ghost" id="lgo">Check again</button>`); $("#lgo").onclick = () => { S.list.last = ""; checkListings(); }; return; }
    const by = s => d.results.filter(x => x.status === s);
    const line = x => `<div class="res"><b>${esc(x.vehicle || x.stock)}</b><small>${esc(x.stock)} · ${esc(x.store_name)} · ${esc(x.say)}</small></div>`;
    setHTML(b, `${old}<div class="tot"><div>On this page<b>${d.results.length}</b></div><div>Recorded as posted just now<b>${(S.list.recorded || []).length}</b></div>
        <div>Sold — mark sold<b style="color:#B3261E">${by("sold").length}</b></div><div>Price drops due<b style="color:#B26A00">${by("drop").length}</b></div></div>
      ${by("sold").length ? `<p class="note"><b>Sold on the website</b> (mark these sold or delete them):</p>${by("sold").map(line).join("")}` : ""}
      ${by("drop").length ? `<p class="note"><b>Drop the price</b> (open the listing, press Edit, and the helper fills the new price):</p>${by("drop").map(line).join("")}` : ""}
      ${by("up").length ? `<p class="note"><b>The website price went up:</b></p>${by("up").map(line).join("")}` : ""}
      ${by("fbsold").length ? `<p class="note"><b>Marked sold here but still on the website:</b></p>${by("fbsold").map(line).join("")}` : ""}
      ${d.not_posted_count ? `<p class="note"><b>${d.not_posted_count} not posted yet</b>${d.not_posted_count > 8 ? " (first 8)" : ""}:</p>${d.not_posted.slice(0, 8).map(x => `<div class="res"><b>${esc(x.title)}</b><small>${esc(x.stock)} · ${esc(x.store_name)}</small></div>`).join("")}` : `<p class="note okmsg">✓ Everything ready to post is on Facebook.</p>`}
      <p class="note">Scroll down so Facebook loads all your listings. The helper checks new ones as they show up.</p>
      <button class="ghost" id="lgo">Check again</button>`);
    $("#lgo").onclick = () => { S.list.last = ""; checkListings(); };
  }

  // ---------- finding Facebook's boxes ----------
  // Facebook labels each box with its name ("Year", "Mileage"...). Find the
  // smallest visible element whose own text is exactly that name, then the
  // control that goes with it.
  // Every visible element whose own text is exactly the box's name. The
  // same words can appear elsewhere on the page (the preview shows "Price",
  // a heading says "Description"), so each one is tried until one has a box.
  function labelHosts(name){
    const want = norm(name);
    return [...document.querySelectorAll("label span, label div, span, div, h2, h3")].filter(e => {
      if (!e.offsetParent || e.children.length) return false;
      return norm(e.textContent) === want;
    }).map(s => s.closest("label") || s.closest("[role=combobox]") || s.parentElement).filter(Boolean);
  }
  function labelEl(name){ return labelHosts(name)[0] || null; }
  const TEXTBOX = "input:not([type=file]):not([type=checkbox]):not([type=radio]), textarea, [contenteditable=true], [role=textbox]";
  function inputFor(name){
    for (const l of labelHosts(name)){
      const c = l.matches && l.matches(TEXTBOX) ? l : l.querySelector(TEXTBOX) ||
                (l.id && document.querySelector(`[aria-labelledby~="${l.id}"]`));
      if (c) return c;
    }
    // last try: a box that names itself
    const want = norm(name);
    return [...document.querySelectorAll(TEXTBOX)].find(e => e.offsetParent &&
      (norm(e.getAttribute("aria-label")) === want || norm(e.getAttribute("placeholder")) === want)) || null;
  }
  function comboFor(name){
    const hosts = labelHosts(name);
    for (const l of hosts){
      if (l.getAttribute("role") === "combobox" || l.getAttribute("aria-haspopup")) return l;
      const c = l.querySelector("[role=combobox],[aria-haspopup]") || l.closest("[role=combobox],[aria-haspopup]");
      if (c) return c;
    }
    return hosts[0] || null;
  }
  function setNative(el, value){
    const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
    el.focus();
    setter.call(el, value);
    el.dispatchEvent(new Event("input", {bubbles: true}));
    el.dispatchEvent(new Event("change", {bubbles: true}));
    el.blur();
  }
  async function typeInto(name, value){
    if (!value) return null;
    const el = inputFor(name);
    if (!el) return false;
    if (!/^(INPUT|TEXTAREA)$/.test(el.tagName)){
      // a rich text box: select what's there and type over it
      el.focus();
      document.execCommand("selectAll", false, null);
      document.execCommand("insertText", false, value);
      await sleep(200);
      return norm(el.textContent).length > 0;
    }
    setNative(el, value);
    await sleep(150);
    return norm(el.value) === norm(value) || norm(el.value).replace(/[^0-9]/g, "") === norm(value).replace(/[^0-9]/g, "");
  }
  function clickEl(el){
    for (const t of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"])
      el.dispatchEvent(new MouseEvent(t, {bubbles: true, cancelable: true, view: window}));
  }
  async function pick(name, value, also){
    if (!value) return null;
    const cb = comboFor(name);
    if (!cb) return false;
    cb.scrollIntoView({block: "center"});
    clickEl(cb);
    let opts = [];
    for (let i = 0; i < 20 && !opts.length; i++){ await sleep(120); opts = [...document.querySelectorAll("[role=option]")].filter(o => o.offsetParent); }
    // a typeahead (Make on some forms): type to narrow the list
    const inner = cb.querySelector("input") || (document.activeElement && document.activeElement.tagName === "INPUT" ? document.activeElement : null);
    if (!opts.length && inner){ setNative(inner, value); for (let i = 0; i < 15 && !opts.length; i++){ await sleep(150); opts = [...document.querySelectorAll("[role=option]")].filter(o => o.offsetParent); } }
    const wants = [value, ...(also || [])].map(norm);
    let hit = null;
    for (const w of wants){ hit = opts.find(o => norm(o.textContent) === w); if (hit) break; }
    if (!hit) for (const w of wants){ hit = opts.find(o => norm(o.textContent).startsWith(w)); if (hit) break; }
    if (!hit){ document.dispatchEvent(new KeyboardEvent("keydown", {key: "Escape", bubbles: true})); clickEl(document.body); await sleep(150); return false; }
    hit.scrollIntoView({block: "center"});
    clickEl(hit);
    await sleep(350);
    return true;
  }
  async function addPhotos(car){
    const input = [...document.querySelectorAll("input[type=file]")].find(i => /image/.test(i.accept || "image"));
    if (!input) return false;
    const dt = new DataTransfer();
    for (const p of car.photos.slice(0, 20)){
      const d = await send({t: "photo", url: p.url});
      if (!d) continue;
      const bin = atob(d.b64); const arr = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
      dt.items.add(new File([arr], p.name, {type: d.type}));
    }
    if (!dt.files.length) return false;
    input.files = dt.files;
    input.dispatchEvent(new Event("input", {bubbles: true}));
    input.dispatchEvent(new Event("change", {bubbles: true}));
    await sleep(1200);
    return dt.files.length;
  }


  async function fill(){
    const btn = $("#fill"); if (btn){ btn.disabled = true; btn.textContent = "Filling…"; }
    const r = await send({t: "car", store: S.store, stock: S.pick.stock});
    if (!r || !r.ok){ S.report = `<p class="note bad">${esc((r && r.message) || "Couldn't get that car.")}</p>`; return draw(); }
    const f = r.fb || {};
    const done = [], missed = [];
    const step = async (label, res) => { if (res === null) return; (res ? done : missed).push(label); };
    await step("Vehicle type", await pick("Vehicle type", f.vehicle_type, ["Car/Truck", "Car/truck"]));
    await sleep(600);    // the rest of the form appears after the type is picked
    const n = await addPhotos(r); (n ? done : missed).push(n ? `Photos (${n})` : "Photos");
    await step("Year", await pick("Year", f.year));
    await step("Make", await pick("Make", f.make));
    await step("Model", await typeInto("Model", f.model));
    await step("Mileage", await typeInto("Mileage", f.mileage));
    await step("Price", await typeInto("Price", f.price));
    await step("Body style", await pick("Body style", f.body_style));
    await step("Exterior color", await pick("Exterior color", f.exterior_color));
    await step("Interior color", await pick("Interior color", f.interior_color));
    await step("Vehicle condition", await pick("Vehicle condition", f.condition));
    await step("Fuel type", await pick("Fuel type", f.fuel));
    await step("Transmission", await pick("Transmission", f.transmission));
    await step("Description", await typeInto("Description", f.description));
    S.car = r;
    S.report = `<ul>${done.map(x => `<li class="ok">✓ ${esc(x)}</li>`).join("")}${missed.map(x => `<li class="no">✗ ${esc(x)} — fill this one yourself</li>`).join("")}</ul>
      <p class="note">Price ${esc(f.price ? "$" + Number(f.price).toLocaleString() : "")} · Clean title: tick it yourself only if it's true.</p>`;
    draw();
  }

  // A group: its sell form (Title, Price, Description) if it has one,
  // otherwise its "Write something" box. Photos either way.
  async function fillGroup(){
    const btn = $("#fill"); if (btn){ btn.disabled = true; btn.textContent = "Filling…"; }
    const r = await send({t: "car", store: S.store, stock: S.pick.stock});
    if (!r || !r.ok){ S.report = `<p class="note bad">${esc((r && r.message) || "Couldn't get that car.")}</p>`; return draw(); }
    const f = r.fb || {};
    const done = [], missed = [];
    const step = (label, res) => { if (res === null) return; (res ? done : missed).push(label); };
    const title = r.title || [f.year, f.make, f.model].filter(Boolean).join(" ");
    if (inputFor("Title")){
      step("Title", await typeInto("Title", title));
      step("Price", await typeInto("Price", f.price));
      step("Description", await typeInto("Description", f.description));
    } else {
      // the post box: the one he clicked, or the group's "Write something..."
      let box = S.lastBox && S.lastBox.isConnected ? S.lastBox : [...document.querySelectorAll('[contenteditable=true][role=textbox]')]
        .find(e => e.offsetParent && !host.contains(e) && /write|post|sell|escribe/i.test((e.getAttribute("aria-label") || "") + (e.getAttribute("aria-placeholder") || "")));
      if (box){ box.focus(); document.execCommand("insertText", false, f.description || title); await sleep(200); step("Post text", norm(box.textContent).length > 10); }
      else missed.push("Post text — click Write something… first, then press Fill again");
    }
    const n = await addPhotos(r); (n ? done : missed).push(n ? `Photos (${n})` : "Photos");
    S.car = r;
    S.report = `<ul>${done.map(x => `<li class="ok">✓ ${esc(x)}</li>`).join("")}${missed.map(x => `<li class="no">✗ ${esc(x)}</li>`).join("")}</ul>`;
    draw();
  }

  // Facebook changes pages without reloading: keep the panel in step.
  let last = location.href;
  let loaded = false;
  const show = () => {
    host.style.display = shows() ? "" : "none";
    if (shows() && !loaded){ loaded = true; load(); }
  };
  setInterval(() => {
    if (gone) return;
    if (location.href !== last){
      last = location.href; S.report = null; S.car = null; S.drop = null;
      if (onSelling()) { S.tab = "list"; S.list.last = ""; }
      else if (onChat()) { S.tab = "replies"; Object.assign(S.rep, {stock: "", data: null, name: "", first: "", last: "", phone: "", email: "", pickedKey: "", msg: ""}); detectChat(); }
      else if (onEdit() || onVehicleForm()) S.tab = "post";
      else if (onGroup() || onSearch()) { S.tab = "spot"; S.spot.el = null; S.spot.data = null; S.spot.msg = ""; }
      if (loaded) draw();
    }
    show();
  }, 800);
  // the Spotter: mark posts from people shopping, as he scrolls
  setInterval(() => { if (gone || !alive()) return; if (loaded && S.spot.on && (onGroup() || onSearch()) && document.visibilityState === "visible") scanSpot(); }, 2000);
  // Your listings loads more as you scroll: check the new ones
  setInterval(() => { if (gone || !alive()) return; if (loaded && onSelling() && document.visibilityState === "visible") checkListings(); }, 4000);
  show();
})();
"""


READER_JS = r"""
// Listing Accelerator – read the cars on this page.
// Runs only when he clicks the helper's toolbar button, on the page he's
// looking at. Reads what's on screen, the way the program reads a website,
// and hands it to the program on this computer. Nothing else.
(() => {
  if (window.__laReader){ window.__laReader.style.display = window.__laReader.style.display === "none" ? "" : "none"; return; }
  const CARD = (__CARD_JS__);
  const LINKCARD = (__LINK_CARD_JS__);
  const GALLERY = (__GALLERY_JS__);
  const send = m => new Promise(res => {
    try { if (!chrome.runtime || !chrome.runtime.id) return res({ok: false, message: "The helper was just updated. Press F5, then click the button again."});
      chrome.runtime.sendMessage(m, r => { if (chrome.runtime.lastError){} res(r); }); }
    catch (e){ res({ok: false, message: "The helper was just updated. Press F5, then click the button again."}); }
  });
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const esc = t => String(t ?? "").replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
  const ENT = {"&amp;": "&", "&lt;": "<", "&gt;": ">", "&quot;": '"', "&#39;": "'"};
  function setHTML(el, str){
    const top = document.createDocumentFragment(), stack = [top];
    const re = /<\/([a-zA-Z0-9]+)\s*>|<([a-zA-Z0-9]+)((?:\s+[\w-]+(?:="[^"]*")?)*)\s*\/?>|([^<]+)/g; let m;
    while ((m = re.exec(str))){
      const cur = stack[stack.length - 1];
      if (m[1]){ if (stack.length > 1) stack.pop(); continue; }
      if (m[2]){ const n = document.createElement(m[2]); const ar = /([\w-]+)(?:="([^"]*)")?/g; let a;
        while ((a = ar.exec(m[3] || ""))) n.setAttribute(a[1], a[2] === undefined ? "" : a[2].replace(/&(amp|lt|gt|quot|#39);/g, x => ENT[x]));
        cur.appendChild(n); if (!/^(input|br|img|hr)$/i.test(m[2])) stack.push(n); continue; }
      if (m[4]) cur.appendChild(document.createTextNode(m[4].replace(/&(amp|lt|gt|quot|#39);/g, x => ENT[x])));
    }
    el.replaceChildren(top);
  }
  const host = document.createElement("div");
  host.style.cssText = "position:fixed;right:16px;top:16px;z-index:2147483647";
  window.__laReader = host;
  const root = host.attachShadow({mode: "open"});
  setHTML(root, `<style>
    .p{width:330px;background:#fff;color:#14181D;border-radius:12px;box-shadow:0 12px 40px rgba(0,0,0,.3);font:14px/1.45 "Segoe UI",Arial,sans-serif;border:1px solid #D9DEE5;overflow:hidden}
    .h{background:#00305F;color:#fff;padding:9px 12px;display:flex;align-items:center} .h b{flex:1} .h button{background:none;border:0;color:#fff;font-size:16px;cursor:pointer}
    .b{padding:10px 12px} select{width:100%;padding:6px;border:1px solid #D9DEE5;border-radius:7px;font:inherit;margin:4px 0}
    .go{background:#00305F;color:#fff;border:0;border-radius:8px;padding:9px 12px;font:inherit;font-weight:700;cursor:pointer;width:100%;margin-top:8px}
    .go:disabled{opacity:.5}
    .ghost{background:#fff;color:#00305F;border:1px solid #D9DEE5;border-radius:8px;padding:8px 12px;font:inherit;cursor:pointer;width:100%;margin-top:6px}
    .note{font-size:12.5px;color:#5C6671;margin:6px 0} .ok{color:#0A6E3D} .bad{color:#B3261E}
    .tot{display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;margin:8px 0} .tot div{border:1px solid #E3E6EA;border-radius:7px;padding:5px;text-align:center;font-size:11.5px;color:#5C6671} .tot b{display:block;font-size:18px;color:#14181D}
    a{color:#00305F;font-size:12.5px}
  </style><div class="p"><div class="h"><b>Listing Accelerator · read this website</b><button id="x" title="Close">✕</button></div><div class="b" id="b"></div></div>`);
  document.documentElement.appendChild(host);
  const $ = s => root.querySelector(s);
  $("#x").onclick = () => { host.style.display = "none"; };
  let S = {store: "", stores: [], matched: false, st: null, msg: "", busy: false};
  const abs = u => { try { return new URL(u, location.href).href; } catch (e) { return ""; } };

  async function init(){
    if (/(^|\.)facebook\.com$/.test(location.hostname)){
      setHTML($("#b"), `<p>This button reads your <b>store's inventory page</b>. Open your store's used inventory in this tab, then click the button again.</p><p class="note">On Facebook, the helper box at the bottom right does the work.</p>`);
      return;
    }
    const w = await send({t: "get", path: "/la/whichstore?url=" + encodeURIComponent(location.href)});
    if (!w || !w.ok){ setHTML($("#b"), `<p>Open <b>Listing Accelerator</b> on this computer, then click the button again.</p>`); return; }
    S.store = w.store; S.stores = w.stores; S.matched = w.matched;
    await refresh();
  }
  async function refresh(){
    S.st = S.store ? await send({t: "get", path: "/la/readstate?store=" + encodeURIComponent(S.store)}) : null;
    draw();
  }
  function draw(){
    const st = S.st || {total: 0, pages: 0, galleries: 0};
    setHTML($("#b"), `
      ${S.stores.length > 1 || !S.store ? `<select id="st"><option value="">Which store is this?</option>${S.stores.map(x => `<option value="${esc(x.key)}" ${x.key === S.store ? "selected" : ""}>${esc(x.name)}</option>`).join("")}</select>` : ""}
      ${S.store && !S.matched ? `<p class="note">This website isn't the one on file for this store. Make sure it's the right store.</p>` : ""}
      <div class="tot"><div>Cars read<b>${st.total}</b></div><div>Pages<b>${st.pages}</b></div><div>Photo sets<b>${st.galleries}</b></div></div>
      <button class="go" id="read" ${S.store && !S.busy ? "" : "disabled"}>${S.busy ? "Reading…" : "Read the cars on this page"}</button>
      <p class="note">On the list of cars. It scrolls down first so every car loads. Then go to the next page and press it again.</p>
      <button class="ghost" id="gal" ${S.store && !S.busy ? "" : "disabled"}>Read this car's photos</button>
      <p class="note">On one car's own page, for its whole photo set.</p>
      ${S.msg}
      <button class="go" id="done" ${S.store && st.total && !S.busy ? "" : "disabled"} style="background:#0A6E3D">Done — update with these ${st.total} cars</button>
      <p class="note"><a href="#" id="over">Start over</a> · Reads only what's on your screen, in your own browser.</p>`);
    const sel = $("#st"); if (sel) sel.onchange = () => { S.store = sel.value; refresh(); };
    $("#read").onclick = readPage; $("#gal").onclick = readGallery; $("#done").onclick = done;
    $("#over").onclick = async e => { e.preventDefault(); if (!S.store) return;
      await send({t: "post", path: "/la/read", body: {store: S.store, url: "", cards: [], start_over: true}}); S.msg = `<p class="note">Started over.</p>`; refresh(); };
  }
  async function scrollAll(){
    let last = -1;
    for (let i = 0; i < 60; i++){
      window.scrollBy(0, Math.max(600, window.innerHeight * 0.9));
      await sleep(350);
      const h = document.documentElement.scrollHeight;
      if (window.innerHeight + window.scrollY >= h - 4){ if (h === last) break; last = h; await sleep(700); }
    }
    window.scrollTo(0, 0);
  }
  async function readPage(){
    S.busy = true; S.msg = ""; draw();
    await scrollAll();
    let cards = [];
    try { cards = CARD(); } catch (e) {}
    if (!cards.length){ try { cards = LINKCARD(); } catch (e) {} }
    cards = cards.map(c => ({text: c.text || "", href: abs(c.href || ""), images: (c.images || []).map(abs).filter(Boolean)}));
    S.busy = false;
    if (!cards.length){ S.msg = `<p class="note bad">No cars found on this page. Open the store's list of used cars (the page with many cars on it).</p>`; return draw(); }
    const r = await send({t: "post", path: "/la/read", body: {store: S.store, url: location.href, cards}});
    S.msg = r && r.ok ? `<p class="note ok">✓ ${r.added} new car${r.added === 1 ? "" : "s"} on this page (${r.total} so far). Next page, then press it again — or press Done.</p>`
                      : `<p class="note bad">${esc((r && r.message) || "Couldn't send them to the program.")}</p>`;
    refresh();
  }
  async function readGallery(){
    S.busy = true; draw();
    await scrollAll();
    let pics = [];
    try { pics = GALLERY().map(abs).filter(u => /^https?:/.test(u)); } catch (e) {}
    S.busy = false;
    const r = await send({t: "post", path: "/la/gallery", body: {store: S.store, url: location.href, photos: pics, text: (document.body.innerText || "").slice(0, 20000)}});
    S.msg = r && r.ok ? `<p class="note ok">✓ ${esc(r.message)}</p>${r.stock ? `<button class="ghost" id="work">⬇ Get its photos and add it to my cars now</button>` : ""}`
                      : `<p class="note bad">${esc((r && r.message) || "Couldn't read them.")}</p>`;
    await refresh();
    const w = $("#work"); if (w) w.onclick = async () => {
      const x = await send({t: "post", path: "/la/work", body: {store: r.store, stock: r.stock}});
      S.msg = `<p class="note ${x && x.ok ? "ok" : "bad"}">${esc((x && x.message) || "")}${x && x.ok ? " It's ready in the program in about a minute." : ""}</p>`; draw();
    };
  }
  async function done(){
    const r = await send({t: "post", path: "/la/readdone", body: {store: S.store}});
    S.msg = `<p class="note ${r && r.ok ? "ok" : "bad"}">${esc((r && r.message) || "Couldn't send them.")}</p>`;
    refresh();
  }
  init();
})();
"""


def _icon_png() -> bytes:
    """A 128px icon: the program's navy tag."""
    try:
        from PIL import Image, ImageDraw
        import io
        im = Image.new("RGBA", (128, 128), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        d.rounded_rectangle([4, 4, 124, 124], 26, fill=(0, 48, 95, 255))
        d.polygon([(30, 40), (78, 40), (100, 64), (78, 88), (30, 88)], fill=(255, 255, 255, 255))
        d.ellipse([40, 57, 54, 71], fill=(0, 48, 95, 255))
        b = io.BytesIO()
        im.save(b, "PNG")
        return b.getvalue()
    except Exception:
        return b""


def reader_js() -> str:
    """The page reader, with the program's own card and gallery readers in it."""
    import scrape_inventory as si
    return (READER_JS.strip().replace("__CARD_JS__", si.CARD_JS.strip())
            .replace("__LINK_CARD_JS__", si.LINK_CARD_JS.strip())
            .replace("__GALLERY_JS__", si.GALLERY_JS.strip()) + "\n")


def write_extension() -> Path:
    """Put the helper's files in "Chrome helper" (again, if they're old)."""
    FOLDER.mkdir(parents=True, exist_ok=True)
    (FOLDER / "manifest.json").write_text(json.dumps(MANIFEST, indent=1), encoding="utf-8")
    (FOLDER / "background.js").write_text(BACKGROUND_JS.strip() + "\n", encoding="utf-8")
    (FOLDER / "content.js").write_text(CONTENT_JS.strip() + "\n", encoding="utf-8")
    (FOLDER / "reader.js").write_text(reader_js(), encoding="utf-8")
    ico = _icon_png()
    if ico:
        (FOLDER / "icon128.png").write_bytes(ico)
    (FOLDER / "READ ME.txt").write_text(
        "Listing Accelerator - Marketplace Helper\n\n"
        "Load this folder once in Chrome (or Edge):\n"
        "  1. Open chrome://extensions  (Edge: edge://extensions)\n"
        "  2. Turn on Developer mode (top right; Edge: left side)\n"
        "  3. Press Load unpacked and pick this folder\n\n"
        "Then open Facebook Marketplace -> Create new listing -> Vehicle for sale.\n"
        "If your store's website turns programs away: open its used inventory in\n"
        "Chrome and click the Listing Accelerator button in the toolbar.\n"
        "The helper fills the form; you check it and press Publish yourself.\n"
        "Keep Listing Accelerator open while you post.\n", encoding="utf-8")
    return FOLDER


def installed_version() -> str:
    try:
        return json.loads((FOLDER / "manifest.json").read_text(encoding="utf-8")).get("version", "")
    except Exception:
        return ""
