"""
Listing Accelerator -- application host.

The window itself is ui.html. This file is the engine behind it: it reads the
inventory, runs the morning update, and records what the salesman has done.

The window is a real desktop window (pywebview over the Edge WebView2 runtime
that ships with Windows), not a browser tab. No address bar, no tabs, its own
entry in the taskbar.

Everything store-specific comes from config.py in the same folder, so one copy
of this program runs any dealership.
"""
from __future__ import annotations

import json
import os
import queue
import subprocess
import sys
import threading
import time
import traceback
import webbrowser
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import importlib       # noqa: E402
import config          # noqa: E402
import track           # noqa: E402
import photo_watch     # noqa: E402
import stores          # noqa: E402


def use_store(key):
    """
    Point the whole program at one store: its settings, its out folder, its
    photos. Every step of a run started after this inherits the same store.
    """
    global config, track, photo_watch
    if key and key != stores.HERE_KEY:
        os.environ["LA_STORE_DIR"] = str(stores.store_dir(key))
    else:
        os.environ.pop("LA_STORE_DIR", None)
    config = importlib.reload(config)
    track = importlib.reload(track)
    photo_watch = importlib.reload(photo_watch)

# Each step of the morning run, in the order it has to happen.
#
# The two numbers after each step are how long it tends to take: a fixed
# number of seconds, plus a number of seconds for every car on the lot.
# They are only used to show a sensible "about N minutes left" -- a big
# lot takes a lot longer than a small one and the salesman deserves to
# be told that up front rather than left watching a bar.
# Measured on a real 81-car lot, 15 Oct 2026: 20 minutes end to end.
# Do not "tidy" these downward without timing a real run first.
PIPELINE = [
    ("Reading the website",         "scrape_inventory.py",             25, 2.00),
    ("Collecting paint and engine", "scrape_details.py",                5, 7.00),
    ("Making photo folders",        "create_photo_drop_folders.py",     2, 0.01),
    ("Downloading photos",          "download_photos.py",               5, 0.90),
    ("Writing the ads",             "build_jt_listings.py",             3, 0.05),
    ("Building the posting helper", "build_listing_kit.py --personal",  3, 0.05),
    ("Working out what changed",    "whats_new.py",                     2, 0.02),
    # The one-page sheet behind the "Print report" button. Nothing built it
    # before, so the button always said "run today's update first".
    ("Making the printed report",   "make_report.py",                   1, 0.00),
]

# Steps 2 and 4 now do several vehicles at once, so their per-car figures
# above (measured one-at-a-time) need dividing by how many run together.
# Not the full factor -- some of the time is the computer's own work, which
# does not go away -- so three quarters of it, which errs on the long side.
PARALLEL = {1: ("DETAIL_WORKERS", 5), 3: ("PHOTO_WORKERS", 6)}

# The photo step is the one that moves when he changes the photo count, so
# its per-car figure above is PER PHOTO (about nine tenths of a second each,
# measured) and gets multiplied by however many he has asked for.
PHOTO_STEP = 3

# Until the website has been read we do not know how big the lot is.
# Assume a middling one so the first guess is not wild.
ASSUMED_LOT = 120


def photo_count():
    n = getattr(config, "MAX_PHOTOS_PER_VEHICLE", 16)
    return n if isinstance(n, int) and n > 0 else 16


def step_seconds(i, count):
    """How long step i (0-based) should take on a lot of `count` cars."""
    fixed, per_car = PIPELINE[i][2], PIPELINE[i][3]
    if i == PHOTO_STEP:
        per_car *= photo_count()
    if i in PARALLEL:
        name, default = PARALLEL[i]
        try:
            n = max(1, min(int(getattr(config, name, default)), 16))
        except (TypeError, ValueError):
            n = default
        if n > 1:
            per_car /= 1 + (n - 1) * 0.75
    return fixed + per_car * (count if count else ASSUMED_LOT)


def plain_minutes(secs):
    """Seconds -> something a person would actually say out loud."""
    if secs <= 45:
        return "nearly done"
    m = int(round(secs / 60.0))
    if m <= 1:
        return "about a minute left"
    return f"about {m} minutes left"

VERB = {
    "down":   "taken down",
    "drop":   "dropped",
    "post":   "posted",
    "synced": "matched",
    "photos": "photos updated",
}


def money(v):
    try:
        return "${:,}".format(int(v))
    except (TypeError, ValueError):
        return None


# Windows asks "Select an app to open this .html file" when no browser has
# been made the default -- which is common on a machine nobody has set up.
# A salesman pressing Posting helper should not be asked to pick a program,
# so find a browser ourselves and only fall back to Windows if we cannot.
# Chrome first, deliberately. The helper and the ads are things he copies
# from and pastes into Marketplace, and Facebook is almost always open in
# Chrome. Opening them in Edge means two browsers and no Facebook session in
# the one he is looking at. Edge is only the fallback because every Windows
# machine has it.
BROWSERS = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
]


def browser_exe():
    if sys.platform != "win32":
        return None
    for p in BROWSERS:
        p = os.path.expandvars(p)
        if "%" not in p and Path(p).exists():
            return p
    return None


def open_page(f: Path):
    """Open one of our own HTML pages, without Windows asking anything."""
    exe = browser_exe()
    if exe:
        try:
            subprocess.Popen([exe, f.as_uri()],
                             creationflags=getattr(subprocess,
                                                   "CREATE_NO_WINDOW", 0))
            return True
        except Exception:
            pass
    try:
        webbrowser.open(f.as_uri())
        return True
    except Exception:
        return False


def open_path(p: Path):
    try:
        if sys.platform == "win32":
            subprocess.Popen(["explorer", str(p)])
        else:
            subprocess.Popen(["xdg-open", str(p)])
    except Exception:
        pass


class Api:
    """Everything the window is allowed to ask for."""

    def __init__(self):
        self.lock = threading.Lock()
        self.run_state = {
            "running": False,
            "step": 0,
            "total": len(PIPELINE),
            "label": "",
            "finished": False,
            "error": "",
            "lines": [],
            "count": 0,          # cars on the lot, once we know
            "started": 0.0,      # when the current step began
        }

    # --- all stores ---------------------------------------------------------
    store_key = None            # the store the window is on; None = home

    def _store_summary(self, s):
        """The one line per store on the home screen."""
        use_store(s["key"])
        row = {"key": s["key"], "name": s["name"], "read": None,
               "vehicles": None, "live": None, "todo": 0, "new": 0,
               "down": 0, "prices": 0, "photos": 0, "post": 0,
               "set_up": True}
        try:
            inv = config.INVENTORY_JSON
            if Path(inv).exists():
                t = datetime.fromtimestamp(Path(inv).stat().st_mtime)
                row["read"] = t.strftime("%a %I:%M %p").replace(" 0", " ")
            d = track.todo_data()
            row.update(vehicles=d["vehicles"], live=d["live"],
                       down=len(d["take_down"]),
                       prices=len(d["mismatched"]) + len(d["drop_today"]),
                       post=len(d["not_posted"]))
            try:
                pend = photo_watch.load_pending()
                row["photos"] = len(pend)
            except Exception:
                pass
            row["todo"] = row["down"] + row["prices"] + row["post"] + row["photos"]
        except Exception:
            pass
        return row

    def home(self):
        """Every store at a glance -- or, on a single-store copy, just that."""
        multi = stores.multi()
        if self.is_running():
            # never switch stores under a running update -- show the last
            # summaries and say which one is updating
            rows = getattr(self, "_home_cache", None) or \
                [{"key": s["key"], "name": s["name"]} for s in stores.all_stores()]
        else:
            keep = self.store_key
            rows = [self._store_summary(s) for s in stores.all_stores()]
            use_store(keep if keep else (stores.HERE_KEY if not multi else None))
            self._home_cache = rows
        with self.lock:
            run = {"running": self.run_state["running"],
                   "store": self.run_state.get("store_name", "")}
        return {"multi": multi, "stores": rows, "run": run,
                "current": self.store_key,
                "date": datetime.now().strftime("%A, %B %d").replace(" 0", " ")}

    def open_store(self, key):
        if self.is_running() and key != self.run_state.get("store_key"):
            return {"ok": False, "message": "A store is updating right now. "
                    "You can look at that one, or wait for it to finish."}
        if key not in {s["key"] for s in stores.all_stores()}:
            return {"ok": False, "message": "That store isn't set up."}
        self.store_key = key
        use_store(key)
        return {"ok": True, "data": self.bootstrap()}

    def go_home(self):
        if not self.is_running():
            self.store_key = None
        return self.home()

    def add_store_from_copy(self):
        """Bring in a store from an older copy of the program."""
        if self.is_running():
            return {"ok": False, "message": "Wait for the update to finish."}
        try:
            import webview
            picked = self._window.create_file_dialog(webview.FOLDER_DIALOG)
        except Exception:
            picked = None
        if not picked:
            return {"ok": False, "message": "No folder picked."}
        folder = picked[0] if isinstance(picked, (list, tuple)) else picked
        first = stores.adopt_here()
        if first and not first.get("ok"):
            return first
        res = stores.import_copy(folder)
        if res.get("ok") and first and first.get("ok"):
            res["message"] = (f"Both stores are in: {first['name']} and "
                              f"{res['name']}. Photos stay where they are.")
        return res

    def add_store_new(self):
        """Set up a brand-new store with the setup screen."""
        if self.is_running():
            return {"ok": False, "message": "Wait for the update to finish."}
        first = stores.adopt_here()
        if first and not first.get("ok"):
            return first
        d = stores.new_store_dir("new store")
        return self.open_setup(env=stores.environ_for(d.name))

    def store_icon(self, key):
        """A desktop icon that opens straight to this store."""
        names = {s["key"]: s["name"] for s in stores.all_stores()}
        if key not in names:
            return {"ok": False, "message": "That store isn't set up."}
        try:
            import wizard
            ok = wizard.make_desktop_shortcut(names[key], args=f"--store {key}")
        except Exception:
            ok = False
        return ({"ok": True, "message": f"Desktop icon made: \"Listing Accelerator - "
                 f"{names[key]}\". It opens straight to that store."} if ok else
                {"ok": False, "message": "Couldn't make the icon on this computer."})

    def remove_store(self, key):
        if self.is_running():
            return {"ok": False, "message": "Wait for the update to finish."}
        if key == self.store_key:
            self.store_key = None
        return stores.remove(key)

    # --- what the sheet shows ---------------------------------------------
    def bootstrap(self):
        store = getattr(config, "STORE_FULL", "Inventory")
        now = datetime.now()
        out = {
            "store": store,
            "date": now.strftime("%A, %B %d").replace(" 0", " "),
            "read": None,
            "vehicles": None,
            "live": None,
            "cap": None,
            "sections": [],
            "footnotes": [],
            "error": None,
            "multi": stores.multi(),
            "store_key": self.store_key,
        }

        inv = getattr(config, "INVENTORY_JSON", None)
        if inv and Path(inv).exists():
            t = datetime.fromtimestamp(Path(inv).stat().st_mtime)
            out["read"] = t.strftime("%I:%M %p").lstrip("0")

        try:
            d = track.todo_data()
        except Exception as e:
            out["error"] = str(e)
            return out

        out["vehicles"] = d["vehicles"]
        out["live"] = d["live"]
        out["cap"] = money(d["cap"]) if d["cap"] else None

        def rows(items, fn):
            return [fn(r) for r in items]

        if d["take_down"]:
            out["sections"].append({
                "key": "down", "tone": "sold",
                "title": "Sold — take these down",
                "note": "Delete these on Marketplace, then record them here.",
                "verb": VERB["down"],
                "rows": rows(d["take_down"], lambda r: {
                    "stock": r["stock"], "name": r["name"], "detail": None}),
            })

        if d["mismatched"]:
            out["sections"].append({
                "key": "synced", "tone": "reprice",
                "title": "The store changed the price",
                "note": "Your listing is out of date. Correct it, then record it.",
                "verb": VERB["synced"],
                "rows": rows(d["mismatched"], lambda r: {
                    "stock": r["stock"],
                    "name": "Listing says " + (money(r["yours"]) or "—"),
                    "detail": "change to " + (money(r["should"]) or "—")}),
            })

        if d["drop_today"]:
            def drop_row(r):
                was, now_ = money(r["was"]), money(r["now"])
                detail = f"{was} → {now_}" if was and now_ else None
                age = "up 1 day" if r["days"] == 1 else f"up {r['days']} days"
                return {"stock": r["stock"], "name": r["name"],
                        "detail": detail or age, "age": age}
            out["sections"].append({
                "key": "drop", "tone": "drop",
                "title": "Drop the price",
                "note": "Lower these on Marketplace, then record them.",
                "verb": VERB["drop"],
                "rows": rows(d["drop_today"], drop_row),
            })

        # Cars he has up whose pictures changed on the website -- usually the
        # real photos replacing the stock ones. Kept until he says done.
        try:
            pend = photo_watch.load_pending()
            rows_l = track.load()
            inv_now = track.inventory()
            live_now = {s for s, r in rows_l.items()
                        if r.get("Status") != "down"}
            pend = {s: v for s, v in pend.items()
                    if s in live_now and s in inv_now}
        except Exception:
            pend = {}
        if pend:
            out["sections"].append({
                "key": "photos", "tone": "reprice",
                "title": "New photos on the website",
                "note": "Your ad is up with the old pictures. Swap in the new "
                        "ones from the Photos folder, then record them.",
                "verb": VERB["photos"],
                "rows": [{"stock": s, "name": v.get("name", ""),
                          "detail": v.get("what")}
                         for s, v in sorted(pend.items())],
            })

        def stock_note(stock):
            try:
                rec_ = inv_all.get(stock) or {}
                info = photo_watch.summary(rec_.get("photos"), rec_.get("vin"))
            except Exception:
                return ""
            return " · stock photos only" if (info["stock"] and
                                              not info["real"]) else ""

        try:
            inv_all = track.inventory()
        except Exception:
            inv_all = {}

        if d["not_posted"]:
            title = "Not posted yet"
            if d["cap"]:
                title += " — under " + money(d["cap"])
            out["sections"].append({
                "key": "post", "tone": "new",
                "title": title,
                "note": "Put these up, then record them.",
                "verb": VERB["post"],
                "rows": rows(d["not_posted"], lambda r: {
                    "stock": r["stock"], "name": r["name"],
                    "detail": (money(r["price"]) or "")
                    + stock_note(r["stock"])}),
            })

        if d["waiting"]:
            out["footnotes"].append(
                "Posted today, drop tomorrow: "
                + ", ".join(r["stock"] for r in d["waiting"]))
        if d["over_cap"] or d["no_price"]:
            bits = []
            if d["over_cap"]:
                bits.append(f"{d['over_cap']} priced over {money(d['cap'])}")
            if d["no_price"]:
                bits.append(f"{d['no_price']} the store hasn't priced yet")
            out["footnotes"].append(
                "Not shown: " + ", ".join(bits)
                + ". Still read, still watched for price changes.")

        return out

    # --- recording work ----------------------------------------------------
    def record(self, action, stocks):
        if action not in VERB:
            return {"ok": False, "message": "Unknown action."}
        stocks = [s for s in (stocks or []) if s]
        if not stocks:
            return {"ok": False, "message": "Nothing selected."}
        fn = {"down": track.cmd_down, "drop": track.cmd_drop,
              "post": track.cmd_post, "synced": track.cmd_synced,
              "photos": photo_watch.clear_pending}[action]
        try:
            fn(stocks)
        except Exception:
            return {"ok": False,
                    "message": "Nothing was saved.",
                    "detail": traceback.format_exc()}
        n = len(stocks)
        return {"ok": True,
                "message": f"Recorded {n} as {VERB[action]}."}

    # --- the morning run ---------------------------------------------------
    def run_update(self):
        key = self.store_key or (None if stores.multi() else stores.HERE_KEY)
        if not key:
            return {"ok": False, "message": "Pick a store first."}
        return self._start_runs([key])

    def run_all(self):
        """Update every store, one after the other."""
        keys = [s["key"] for s in stores.all_stores()]
        if not keys:
            return {"ok": False, "message": "No stores are set up yet."}
        return self._start_runs(keys)

    def _start_runs(self, keys):
        with self.lock:
            if self.run_state["running"]:
                return {"ok": False, "message": "An update is already running."}
            self.run_state = {
                "running": True, "step": 0, "total": len(PIPELINE),
                "label": "Starting", "finished": False, "error": "",
                "lines": [], "count": 0, "started": time.time(),
                "queue": list(keys), "store_key": keys[0], "store_name": "",
                "store_no": 1, "store_count": len(keys), "done_stores": [],
            }
        threading.Thread(target=self._run_queue, daemon=True).start()
        return {"ok": True}

    def _run_queue(self):
        keys = list(self.run_state["queue"])
        names = {s["key"]: s["name"] for s in stores.all_stores()}
        for n, key in enumerate(keys, 1):
            use_store(key)
            with self.lock:
                self.run_state.update(
                    store_key=key, store_name=names.get(key, key), store_no=n,
                    out=str(config.OUT),
                    step=0, label="Starting", count=self._lot_size(),
                    started=time.time(), finished=False, error="",
                    lines=[], all_lines=[])
            if len(keys) > 1:
                self._push(f"\n===== {names.get(key, key)} ({n} of {len(keys)}) =====")
            self._worker(final=(n == len(keys)), env=stores.environ_for(key))
            with self.lock:
                self.run_state["done_stores"].append(
                    {"key": key, "name": names.get(key, key),
                     "error": self.run_state.get("error", "")})
        # back to whichever store the window is showing
        use_store(self.store_key if self.store_key else
                  (None if stores.multi() else stores.HERE_KEY))
        with self.lock:
            self.run_state.update(running=False, finished=True,
                                  step=len(PIPELINE))

    def _save_log(self):
        """
        Drop the whole run log into a file next to the output.

        When a run fails the detail is the only thing that says why, and it
        should not depend on the salesman knowing to scroll down a window.
        A file he can open, or send to whoever sold him the program.
        """
        try:
            Path(self.run_state.get("out") or config.OUT).mkdir(parents=True, exist_ok=True)
            with self.lock:
                lines = list(self.run_state.get("all_lines")
                             or self.run_state["lines"])
            head = [
                "Listing Accelerator -- what happened on the last run",
                datetime.now().strftime("%A, %d %B %Y at %I:%M %p"),
                f"store    : {getattr(config, 'STORE_FULL', '')}",
                f"inventory: {getattr(config, 'INVENTORY_URL', '')}",
                "-" * 64, "",
            ]
            out_dir = Path(self.run_state.get("out") or config.OUT)
            (out_dir / "last run detail.txt").write_text(
                "\r\n".join(head + lines), encoding="utf-8-sig", newline="")
        except Exception:
            pass

    def open_log(self):
        f = config.OUT / "last run detail.txt"
        if f.exists():
            open_path(f)
            return {"ok": True, "message": "Opened the detail from the last run."}
        return {"ok": False, "message": "There's no run detail saved yet."}

    def _push(self, line):
        with self.lock:
            self.run_state["lines"].append(line.rstrip("\n"))
            # the saved log keeps everything -- the start of a run is where
            # the photo pages and anything that failed get reported
            full = self.run_state.setdefault("all_lines", [])
            if len(full) < 50000:
                full.append(line.rstrip("\n"))
            # keep the panel light; nobody scrolls back a thousand lines
            if len(self.run_state["lines"]) > 400:
                del self.run_state["lines"][:200]

    def open_setup(self, env=None):
        """Reopen the setup screen -- new phone number, moved stores, etc."""
        if env is None:
            env = stores.environ_for(self.store_key or stores.HERE_KEY)
        try:
            exe = sys.executable
            if sys.platform == "win32":
                w = Path(exe).with_name("pythonw.exe")
                if w.exists():
                    exe = str(w)
            subprocess.Popen([exe, str(HERE / "wizard.py")], cwd=str(HERE),
                             env=env,
                             creationflags=getattr(subprocess,
                                                   "CREATE_NO_WINDOW", 0))
        except Exception:
            return {"ok": False,
                    "message": "Couldn't open the setup screen.",
                    "detail": traceback.format_exc()}
        return {"ok": True,
                "message": "Setup is opening. This window will close when "
                           "you save."}

    def open_instructions(self):
        for name in ("Instructions.html", "Instructions.pdf",
                     "Read me first.txt"):
            f = HERE.parent / name
            if f.exists():
                open_page(f)
                return {"ok": True,
                        "message": "Instructions open. Ctrl+P to print them."}
        return {"ok": False, "message": "The instructions file is missing."}

    # --- settings ----------------------------------------------------------
    def get_settings(self):
        """What the Settings panel shows, with the time cost worked out."""
        cars = self._lot_size()
        now = photo_count()
        choices = []
        for n, blurb in ((10, "Quickest"),
                         (16, "Recommended"),
                         (20, "Everything Facebook allows")):
            secs = PIPELINE[PHOTO_STEP][2] + \
                PIPELINE[PHOTO_STEP][3] * n * (cars or ASSUMED_LOT)
            mins = max(1, int(round(secs / 60.0)))
            choices.append({
                "n": n,
                "blurb": blurb,
                "cost": f"about {mins} minute{'s' if mins != 1 else ''} "
                        f"of downloading" + (f" for {cars} cars" if cars else ""),
            })
        return {"max_photos": now, "choices": choices, "cars": cars}

    def focus_options(self):
        """
        What the "what you work" panel shows.

        The makes and body styles are read off HIS OWN LOT rather than a
        fixed list, so he ticks what is actually out there -- with a count
        beside each, which is the quickest way to see what a choice costs.
        """
        makes, bodies, years, prices = {}, {}, [], []
        n_certified = n_specials = 0
        n_new = n_used = 0
        try:
            with open(config.INVENTORY_JSON, encoding="utf-8") as fh:
                recs = json.load(fh)
        except Exception:
            recs = []

        for r in recs:
            if track.is_certified(r):
                n_certified += 1
            if track.is_special(r):
                n_specials += 1
            if track.condition_of(r) == "new":
                n_new += 1
            else:
                n_used += 1
            mk = str(r.get("make", "")).strip()
            if mk:
                makes[mk] = makes.get(mk, 0) + 1
            b = track.body_of(r)
            if b:
                nice = track.pretty_body(b)
                bodies[nice] = bodies.get(nice, 0) + 1
            try:
                y = int(r.get("year") or 0)
                if 1950 < y < 2100:
                    years.append(y)
            except (TypeError, ValueError):
                pass
            p = track.price_of(r)
            if p:
                prices.append(p)

        f = track.focus()
        return {
            "makes": [{"name": k, "n": v} for k, v in
                      sorted(makes.items(), key=lambda kv: (-kv[1], kv[0]))],
            "bodies": [{"name": k, "n": v} for k, v in
                       sorted(bodies.items(), key=lambda kv: (-kv[1], kv[0]))],
            "year_lo": min(years) if years else 0,
            "year_hi": max(years) if years else 0,
            "price_hi": max(prices) if prices else 0,
            "total": len(recs),
            # How many of his own cars are in each group, so the switch shows
            # what it costs before he flips it. A store with no certified
            # inventory shows zero and the panel greys the switch out.
            "n_certified": n_certified,
            "n_specials": n_specials,
            "n_new": n_new,
            "n_used": n_used,
            # Only offered when the lot actually splits into stores, which is
            # the one case where this matters.
            "prefixes": track.stock_prefixes(recs),
            "current": {
                "min_price": f["min_price"], "max_price": f["max_price"],
                "min_year": f["min_year"], "max_year": f["max_year"],
                "makes": [m for m in getattr(config, "FOCUS_MAKES", [])],
                "bodies": [b for b in getattr(config, "FOCUS_BODIES", [])],
                "models": ", ".join(getattr(config, "FOCUS_MODELS", [])),
                "stock": getattr(config, "FOCUS_STOCK_PREFIX", ""),
                "certified": f["certified"],
                "specials": f["specials"],
                "condition": f["condition"],
            },
            "wording": track.focus_wording(),
        }

    def preview_focus(self, focus):
        """How many of his cars a set of choices would leave him."""
        try:
            with open(config.INVENTORY_JSON, encoding="utf-8") as fh:
                recs = json.load(fh)
        except Exception:
            return {"ok": False, "n": 0, "total": 0}

        saved = {k: getattr(config, k, None) for k in
                 ("FOCUS_MIN_PRICE", "FOCUS_MAX_PRICE", "FOCUS_YEAR_MIN",
                  "FOCUS_YEAR_MAX", "FOCUS_MAKES", "FOCUS_MODELS",
                  "FOCUS_BODIES", "FOCUS_STOCK_PREFIX",
                  "FOCUS_CERTIFIED_ONLY", "FOCUS_SPECIALS_ONLY",
                  "FOCUS_CONDITION")}
        try:
            self._apply_focus(focus or {})
            n = sum(1 for r in recs
                    if track.price_of(r) and track.in_focus(r))
            wording = track.focus_wording()
        finally:
            for k, v in saved.items():
                setattr(config, k, v)
        return {"ok": True, "n": n, "total": len(recs), "wording": wording}

    @staticmethod
    def _apply_focus(d):
        def num(key):
            try:
                return max(0, int(d.get(key) or 0))
            except (TypeError, ValueError):
                return 0

        def words(key):
            v = d.get(key) or []
            if isinstance(v, str):
                v = v.replace(",", "\n").split("\n")
            return [str(x).strip() for x in v if str(x).strip()][:60]

        config.FOCUS_MIN_PRICE = num("min_price")
        config.FOCUS_MAX_PRICE = num("max_price")
        config.FOCUS_YEAR_MIN = num("min_year")
        config.FOCUS_YEAR_MAX = num("max_year")
        config.FOCUS_MAKES = words("makes")
        config.FOCUS_BODIES = words("bodies")
        config.FOCUS_MODELS = words("models")
        config.FOCUS_STOCK_PREFIX = str(d.get("stock") or "").strip()
        config.FOCUS_CERTIFIED_ONLY = bool(d.get("certified"))
        config.FOCUS_SPECIALS_ONLY = bool(d.get("specials"))
        c = str(d.get("condition") or "used").lower()
        config.FOCUS_CONDITION = c if c in ("used", "new", "all") else "used"

    def save_focus(self, focus):
        d = focus or {}
        try:
            saved = {}
            if config.SETTINGS_FILE.exists():
                with open(config.SETTINGS_FILE, encoding="utf-8") as fh:
                    loaded = json.load(fh)
                if isinstance(loaded, dict):
                    saved = loaded

            self._apply_focus(d)
            saved["focus_min_price"] = config.FOCUS_MIN_PRICE
            saved["focus_max_price"] = config.FOCUS_MAX_PRICE
            saved["focus_year_min"] = config.FOCUS_YEAR_MIN
            saved["focus_year_max"] = config.FOCUS_YEAR_MAX
            saved["focus_makes"] = config.FOCUS_MAKES
            saved["focus_bodies"] = config.FOCUS_BODIES
            saved["focus_models"] = config.FOCUS_MODELS
            saved["focus_stock_prefix"] = config.FOCUS_STOCK_PREFIX
            saved["focus_certified_only"] = config.FOCUS_CERTIFIED_ONLY
            saved["focus_specials_only"] = config.FOCUS_SPECIALS_ONLY
            saved["focus_condition"] = config.FOCUS_CONDITION

            with open(config.SETTINGS_FILE, "w", encoding="utf-8") as fh:
                json.dump(saved, fh, indent=2)
        except Exception:
            return {"ok": False, "message": "Couldn't save that.",
                    "detail": traceback.format_exc()}

        where = track.focus_wording()
        return {"ok": True,
                "message": ("Saved. You're working " + where + "."
                            if where else "Saved. You're working the whole lot.")}

    def save_settings(self, max_photos):
        try:
            n = int(max_photos)
        except (TypeError, ValueError):
            return {"ok": False, "message": "That isn't a number."}
        if not 1 <= n <= 20:
            return {"ok": False,
                    "message": "Facebook allows up to 20 photos on a vehicle."}
        try:
            saved = {}
            if config.SETTINGS_FILE.exists():
                with open(config.SETTINGS_FILE, encoding="utf-8") as fh:
                    loaded = json.load(fh)
                if isinstance(loaded, dict):
                    saved = loaded
            saved["max_photos"] = n
            with open(config.SETTINGS_FILE, "w", encoding="utf-8") as fh:
                json.dump(saved, fh, indent=2)
        except Exception:
            return {"ok": False,
                    "message": "Couldn't save that.",
                    "detail": traceback.format_exc()}
        # Take effect now, so the estimate on screen updates immediately.
        config.MAX_PHOTOS_PER_VEHICLE = n
        return {"ok": True,
                "message": f"Saved. {n} photos per vehicle from the next "
                           f"update on."}

    def is_running(self):
        with self.lock:
            return bool(self.run_state["running"])

    def _lot_size(self):
        """
        How many cars the next run will actually WORK. Zero before the first.

        Not the size of the lot. On a dealer-group website the inventory holds
        the whole group, and the slow steps only touch the cars he works -- so
        counting all of them put "228 vehicles" and an hours-long estimate on
        screen for a job that is twenty cars. That is what made the program
        look like it was still doing everything.
        """
        try:
            with open(config.INVENTORY_JSON, encoding="utf-8") as f:
                recs = json.load(f)
        except Exception:
            return 0
        try:
            f = track.focus()
            if track.focus_is_on(f):
                return sum(1 for r in recs if track.in_focus(r, f))
            return sum(1 for r in recs if not track.is_other_store(r))
        except Exception:
            return len(recs)

    def _worker(self, final=True, env=None):
        for i, step in enumerate(PIPELINE, start=1):
            label, cmd = step[0], step[1]
            with self.lock:
                self.run_state["step"] = i
                self.run_state["label"] = label
                self.run_state["started"] = time.time()
            self._push(f"\n--- {label} ---")
            try:
                proc = subprocess.Popen(
                    [sys.executable, "-u"] + cmd.split(), cwd=str(HERE),
                    env=env,
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    text=True, bufsize=1,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            except Exception as e:
                self._push(f"could not start {cmd}: {e}")
                self._save_log()
                continue
            for line in proc.stdout:
                self._push(line)
            if proc.wait() != 0:
                self._push(f"{cmd} stopped with an error.")
                # A bad inventory read poisons everything after it.
                if "scrape_inventory" in cmd:
                    self._save_log()
                    with self.lock:
                        self.run_state.update(
                            error="The website didn't read properly, so "
                                  "nothing was changed. Nothing is broken — "
                                  "it stopped rather than give you a wrong "
                                  "list. The detail is below, and saved to "
                                  "\"last run detail.txt\" in your out "
                                  "folder.")
                    return
            # The website read is what tells us how big this lot is. From
            # here on the time left is a real number, not a guess.
            if "scrape_inventory" in cmd:
                n = self._lot_size()
                if n:
                    with self.lock:
                        self.run_state["count"] = n
        self._save_log()

    def status(self):
        with self.lock:
            s = dict(self.run_state)
            s.pop("all_lines", None)        # the window only shows the tail
            s["lines"] = "\n".join(s["lines"][-220:])
            count, step, started = s["count"], s["step"], s["started"]

        # How far along, and how much longer -- worked out from the size of
        # the lot rather than from which step number we happen to be on, so
        # the bar crawls through the long steps instead of sitting still.
        costs = [step_seconds(i, count) for i in range(len(PIPELINE))]
        total = sum(costs) or 1
        if step <= 0:
            done, left = 0.0, total
        else:
            before = sum(costs[:step - 1])
            here = costs[step - 1]
            inside = min(max(time.time() - started, 0.0), here)
            done = before + inside
            left = max(total - done, 0.0)
        s["frac"] = min(done / total, 0.995) if s["running"] else 1.0
        s["left"] = plain_minutes(left) if s["running"] else ""
        s["cars"] = count
        return s

    # --- buttons -----------------------------------------------------------
    def open_helper(self):
        f = config.OUT / "listing_kit" / "post_helper.html"
        if f.exists():
            open_page(f)
            return {"ok": True, "message": "Posting helper open. Click any line to copy it."}
        return {"ok": False, "message": "Run today's update first — the helper isn't built yet."}

    def open_ads(self):
        # The folder of ads, one file per car named by its stock number --
        # the way he works Teays Valley: open the folder, click the car, copy
        # the ad. "ALL ADS.txt" is still in there for anyone who wants every
        # ad in one file.
        f = config.OUT / "jt_listings"
        if f.exists():
            open_path(f)
            return {"ok": True,
                    "message": "Ads folder open -- one file per car, named "
                               "by stock number."}
        return {"ok": False,
                "message": "Run today's update first — the ads aren't written yet."}

    def open_photos(self):
        f = getattr(config, "PHOTO_DROP", None)
        if f and Path(f).exists():
            open_path(Path(f))
            return {"ok": True, "message": "Photo folders open."}
        return {"ok": False, "message": "Run today's update first — there are no photos yet."}

    def open_report(self):
        for name in ("MORNING_REPORT.html", "MORNING_REPORT.txt"):
            f = config.OUT / name
            if f.exists():
                open_page(f)
                return {"ok": True, "message": "Report open. Press Ctrl+P to print."}
        return {"ok": False, "message": "Run today's update first — there's no report yet."}

    # ---------------------------------------------------------- updates
    def update_check(self):
        try:
            import updater
            if not updater.enabled():
                return {"available": False, "current": updater.current_version()}
            f = updater.check()
            self._update_found = f
            return {"available": f.get("available", False),
                    "current": f.get("current"), "version": f.get("version"),
                    "notes": f.get("notes", []), "critical": f.get("critical", False),
                    "snoozed": updater.snoozed(f.get("version", "")),
                    "error": f.get("error", "")}
        except Exception as e:
            return {"available": False, "error": str(e)}

    def update_later(self):
        try:
            import updater
            f = getattr(self, "_update_found", {}) or {}
            updater.snooze(f.get("version", ""),
                           hours=4 if f.get("critical") else 20)
        except Exception:
            pass
        return {"ok": True}

    def update_install(self):
        if self.is_running():
            return {"ok": False, "message": "Today's run is still going. "
                    "Update when it finishes."}
        f = getattr(self, "_update_found", None)
        if not f or not f.get("available"):
            return {"ok": False, "message": "No update to install."}
        self._upd = {"lines": [], "done": False, "result": None}

        def work():
            import updater
            res = updater.install(f, progress=lambda m: self._upd["lines"].append(m))
            self._upd.update(done=True, result=res)
        threading.Thread(target=work, daemon=True).start()
        return {"ok": True}

    def update_status(self):
        u = getattr(self, "_upd", None) or {"lines": [], "done": False, "result": None}
        return {"lines": list(u["lines"]), "done": u["done"], "result": u["result"]}

    def update_rollback(self):
        import updater
        return updater.rollback()

    def version(self):
        try:
            import updater
            return updater.current_version()
        except Exception:
            return ""

    def restart(self):
        """Start the program again from its (new) files and close this window."""
        import subprocess
        exe = sys.executable
        if exe.lower().endswith("python.exe"):
            w = Path(exe).with_name("pythonw.exe")
            if w.exists():
                exe = str(w)
        try:
            subprocess.Popen([exe, str(HERE / "app.py")], cwd=str(HERE))
        except Exception as e:
            return {"ok": False, "message": f"Close and reopen the program ({e})."}
        try:
            self._window.destroy()
        except Exception:
            os._exit(0)
        return {"ok": True}


def main():
    try:
        import webview
    except ImportError:
        print("The window library isn't installed. Run MARKETPLACE.bat.")
        return 1

    # Older desktop icons open the .bat file, which makes Windows ask "Do
    # you want to run this file?" every morning. Repoint them, once, in the
    # background so the window isn't held up.
    if sys.platform == "win32":
        try:
            import wizard
            threading.Thread(target=wizard.fix_old_icons, daemon=True).start()
        except Exception:
            pass

    api = Api()
    # A desktop icon can open straight to one store: app.py --store <name>
    if "--store" in sys.argv:
        try:
            want = sys.argv[sys.argv.index("--store") + 1]
            if want in {s["key"] for s in stores.all_stores()}:
                api.store_key = want
                use_store(want)
        except IndexError:
            pass
    elif not stores.multi():
        api.store_key = stores.HERE_KEY
    store = "all your stores" if stores.multi() and not api.store_key \
        else getattr(config, "STORE_FULL", "Inventory")
    win = webview.create_window(
        f"Listing Accelerator — {store}",
        str(HERE / "ui.html"),
        js_api=api,
        width=1180, height=860, min_size=(960, 640),
        background_color="#EEF1F4",
        text_select=False,
    )
    api._window = win

    # A salesman starts the update, a customer walks on the lot, and the
    # window gets closed out of habit -- which kills the run partway. Catch
    # that and tell him he can just leave it alone instead.
    def on_closing():
        if not api.is_running():
            return True
        try:
            return bool(win.create_confirmation_dialog(
                "Still working",
                "Today's update is still running.\n\n"
                "You do not have to sit here. Leave this window open, go work "
                "your customer, and come back when you have a minute -- it "
                "keeps going on its own.\n\n"
                "Close it now and the update stops partway. Nothing is "
                "damaged; you would just start it again later.\n\n"
                "Close anyway?"))
        except Exception:
            # Never trap him in a window he cannot shut.
            return True

    try:
        win.events.closing += on_closing
    except Exception:
        pass

    # Give the taskbar its own icon rather than a generic Python one.
    ico = HERE / "app.ico"
    try:
        if ico.exists():
            webview.start(icon=str(ico))
        else:
            webview.start()
    except TypeError:
        # Older pywebview has no icon argument; not worth failing over.
        webview.start()
    return 0


if __name__ == "__main__":
    sys.exit(main())
