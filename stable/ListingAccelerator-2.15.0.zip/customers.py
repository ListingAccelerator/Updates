"""
customers.py -- the customer book.

Marketplace leads before (and after) the appointment: who they are, what
they want, which car, what you sent them, notes, and the chat you pasted.

    program\\customers\\customers.json        every customer, all stores
    program\\customers\\book_settings.json    your days off
    program\\customers\\daily\\                one copy a day, last 30 days

Everything stays on this computer. Nothing here is ever sent anywhere, and
updates never touch this folder (updater.py refuses it, and its backups
only take the program's own top-level files).

Built-in rule: a Marketplace lead goes into the dealership's CRM
(VinSolutions, DealerSocket, Elead, ...) once an appointment is set -- not
before. A customer at "Appointment set" (or later) who isn't ticked
"Entered in CRM" is flagged at the top of the book until they are.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import uuid
from datetime import date, datetime, timedelta
from pathlib import Path

import stores
import threading
import functools

# The screen can save two things at once (a box saved as you type while a
# quote is being made). Customer changes take turns so neither is lost.
_LOCK = threading.RLock()


def _locked(fn):
    @functools.wraps(fn)
    def run(*a, **kw):
        with _LOCK:
            return fn(*a, **kw)
    return run

HERE = Path(__file__).resolve().parent
BOOK = HERE / "customers"
FILE = BOOK / "customers.json"
SETTINGS = BOOK / "book_settings.json"
DAILY = BOOK / "daily"
KEEP_DAILY = 30

STATUSES = ["New", "Talking", "Appointment set", "Showed", "Sold", "Lost"]
WANTS = ["Buying", "Trade-in", "Financing", "Just looking"]
# from here on the store wants them in its CRM
VIN_FROM = {"Appointment set", "Showed", "Sold"}
CLOSED = {"Sold", "Lost"}


# ------------------------------------------------------------- storage
def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def _today() -> str:
    return date.today().isoformat()


def load() -> list[dict]:
    try:
        d = json.loads(FILE.read_text(encoding="utf-8"))
        return d.get("customers", []) if isinstance(d, dict) else []
    except FileNotFoundError:
        return []
    except Exception:
        # a damaged file must never be overwritten with an empty book --
        # set it aside and start from the newest daily copy instead
        try:
            bad = FILE.with_name(f"customers-damaged-{datetime.now():%Y%m%d-%H%M%S}.json")
            shutil.copy2(FILE, bad)
        except Exception:
            pass
        for f in sorted(DAILY.glob("customers-*.json"), reverse=True):
            try:
                return json.loads(f.read_text(encoding="utf-8")).get("customers", [])
            except Exception:
                continue
        return []


def _write(all_: list[dict]):
    BOOK.mkdir(parents=True, exist_ok=True)
    raw = json.dumps({"customers": all_, "saved": _now()}, indent=1,
                     ensure_ascii=False)
    tmp = FILE.with_name(f"customers-{uuid.uuid4().hex[:8]}.tmp")
    tmp.write_text(raw, encoding="utf-8")
    os.replace(tmp, FILE)
    # one copy per day, so a bad day can always be undone
    try:
        DAILY.mkdir(exist_ok=True)
        today = DAILY / f"customers-{_today()}.json"
        today.write_text(raw, encoding="utf-8")
        for old in sorted(DAILY.glob("customers-*.json"))[:-KEEP_DAILY]:
            old.unlink()
    except Exception:
        pass


def get(cid: str) -> dict | None:
    return next((c for c in load() if c.get("id") == cid), None)


def blank() -> dict:
    return {"id": "", "name": "", "phone": "", "email": "", "address": "",
            "store_key": "", "vehicles": [], "wants": [], "status": "New",
            "appointment": "", "followup": "", "followup_note": "",
            "trade": "", "looking_for": "", "sent": [], "notes": [], "chat": [],
            "vin_entered": False, "vin_entered_on": "",
            "added": "", "last_contact": "", "source": "Marketplace", "lang": "en",
            "search": {}, "search_seen": [], "search_saved": "", "trade_info": {}, "deal": {}, "quotes": []}


EDITABLE = {"name", "phone", "email", "address", "store_key", "vehicles",
            "wants", "status", "appointment", "followup", "followup_note",
            "trade", "vin_entered", "source", "looking_for", "lang", "trade_info", "deal"}
DEAL_KEYS = ["price", "doc_fee", "tax", "tags", "other", "other_label", "rebate", "down", "apr", "term"]
TRADE_KEYS = ["year", "make", "model", "trim", "vin", "miles", "color", "payoff", "lender",
              "allowance", "condition", "details"]


def _money_num(v) -> int:
    try:
        return int(round(float(re.sub(r"[^0-9.\-]", "", str(v or "")) or 0)))
    except ValueError:
        return 0


def trade_equity(t: dict) -> int | None:
    """Allowance less payoff -- negative when they owe more than it's worth."""
    t = t or {}
    if not (str(t.get("allowance") or "").strip() or str(t.get("payoff") or "").strip()):
        return None
    return _money_num(t.get("allowance")) - _money_num(t.get("payoff"))


def deal_calc(c: dict, first_price=0) -> dict:
    """The deal on the card: what's financed and the payment. Empty boxes count
    as nothing, except price (the first vehicle's), APR and term (the car
    finder's numbers)."""
    import finder
    d = c.get("deal") or {}
    fs = finder.settings()
    q = c.get("search") or {}
    price = _money_num(d.get("price")) or int(first_price or 0)
    eq = trade_equity(c.get("trade_info") or {}) or 0
    apr = float(re.sub(r"[^0-9.]", "", str(d.get("apr") or "")) or q.get("apr") or fs["apr"])
    term = int(_money_num(d.get("term")) or _money_num(q.get("term")) or fs["term"])
    down = _money_num(d.get("down")) if str(d.get("down") or "").strip() else _money_num(q.get("down", fs["down"]))
    fees = sum(_money_num(d.get(k)) for k in ("doc_fee", "tax", "tags", "other"))
    financed = max(0, price + fees - _money_num(d.get("rebate")) - down - eq) if price else 0
    return {"price": price, "fees": fees, "equity": eq, "down": down, "apr": apr, "term": term,
            "rebate": _money_num(d.get("rebate")), "financed": financed,
            "payment": finder.pay_on(financed, apr, term) if financed else None}


# ------------------------------------------------------------- deal desk
# Deal numbers, quotes and the deal sheet. Some stores only let managers
# pencil a deal, so a manager can turn it off (and back on) behind a PIN.
# It's a lock for the store's rules, kept on this computer -- not security.
DESK = BOOK / "deal desk.json"


def _pin_hash(pin: str, salt: str) -> str:
    import hashlib
    return hashlib.sha256((salt + ":" + str(pin).strip()).encode()).hexdigest()


def desk() -> dict:
    try:
        d = json.loads(DESK.read_text(encoding="utf-8"))
        if isinstance(d, dict):
            return {"on": d.get("on", True) is not False, "pin": bool(d.get("pin")),
                    "_pin": d.get("pin") or "", "_salt": d.get("salt") or ""}
    except Exception:
        pass
    return {"on": True, "pin": False, "_pin": "", "_salt": ""}


def desk_public() -> dict:
    d = desk()
    return {"on": d["on"], "pin": d["pin"]}


def desk_set(on: bool, pin: str = "", new_pin: str = "") -> dict:
    d = desk()
    pin, new_pin = str(pin or "").strip(), str(new_pin or "").strip()
    if d["pin"]:
        if _pin_hash(pin, d["_salt"]) != d["_pin"]:
            return {"ok": False, "message": "That manager PIN isn't right."}
    elif not new_pin:
        return {"ok": False, "message": "Set a manager PIN first (4 to 8 numbers)."}
    rec = {"on": bool(on), "pin": d["_pin"], "salt": d["_salt"]}
    if new_pin:
        if not re.fullmatch(r"\d{4,8}", new_pin):
            return {"ok": False, "message": "The PIN has to be 4 to 8 numbers."}
        rec["salt"] = uuid.uuid4().hex[:12]
        rec["pin"] = _pin_hash(new_pin, rec["salt"])
    BOOK.mkdir(parents=True, exist_ok=True)
    DESK.write_text(json.dumps(rec, indent=1), encoding="utf-8")
    return {"ok": True, "on": rec["on"], "pin": True,
            "message": "Deal desk is on: deal numbers, quotes and the deal sheet show on customer cards."
            if rec["on"] else "Deal desk is off: deal numbers, quotes and the deal sheet are hidden until a manager turns it on."}


DEAL_NOS = BOOK / "deal numbers.json"
FIRST_DEAL_NO = 1001


@_locked
def ensure_deal_no(cid: str) -> str:
    """The customer's deal number, made the first time a deal goes out."""
    all_ = load()
    c = next((x for x in all_ if x.get("id") == cid), None)
    if c is None:
        return ""
    if c.get("deal_no"):
        return c["deal_no"]
    try:
        n = int(json.loads(DEAL_NOS.read_text(encoding="utf-8")).get("next") or FIRST_DEAL_NO)
    except Exception:
        n = FIRST_DEAL_NO
    used = {str(x.get("deal_no") or "") for x in all_}
    while str(n) in used:
        n += 1
    c["deal_no"] = str(n)
    BOOK.mkdir(parents=True, exist_ok=True)
    DEAL_NOS.write_text(json.dumps({"next": n + 1}), encoding="utf-8")
    _write(all_)
    return c["deal_no"]


@_locked
def add_quote(cid: str, how: str) -> dict | None:
    """Keep the deal as it stands now on the card: what he quoted, when, and
    how it went out (texted or printed). Newest last; the last 25 kept."""
    if not ensure_deal_no(cid):
        return None
    all_ = load()
    c = next((x for x in all_ if x.get("id") == cid), None)
    if c is None:
        return None
    invs = inventories()
    cars = [_vehicle_info(x, invs) for x in c.get("vehicles") or []]
    first = cars[0] if cars else {}
    k = deal_calc(c, first.get("price") or 0)
    if not k["price"]:
        return None
    d = c.get("deal") or {}
    q = {"when": _now(), "how": how, "deal_no": c.get("deal_no", ""), "stock": first.get("stock", ""), "vehicle": first.get("name", ""),
         "price": k["price"], "fees": k["fees"], "rebate": k["rebate"], "down": k["down"],
         "equity": k["equity"], "apr": k["apr"], "term": k["term"], "financed": k["financed"],
         "payment": k["payment"], "other_label": d.get("other_label", "")}
    qs = c.setdefault("quotes", [])
    last = qs[-1] if qs else None
    same = last and all(last.get(x) == q[x] for x in ("stock", "price", "fees", "down", "equity", "apr", "term"))
    if same and last.get("when", "")[:10] == q["when"][:10]:
        last["when"], last["how"] = q["when"], (last["how"] if last["how"] == how else f"{last['how']} & {how}")
    else:
        qs.append(q)
    c["quotes"] = qs[-25:]
    c["last_contact"] = _today()
    _write(all_)
    return q


def quote_text(c: dict, q: dict) -> str:
    first = (c.get("name") or "").split()[0] if c.get("name") else ""
    money = lambda n: f"${int(n):,}"
    fees = " Taxes and fees are included." if q.get("fees") else ""
    trade = ""
    if q.get("equity"):
        trade = " and your trade" if q["equity"] > 0 else f" (your trade's {money(-q['equity'])} payoff difference included)"
    if c.get("lang") == "es":
        return (f"Hola{' ' + first if first else ''}! Estos son los números del {q['vehicle']} (stock {q['stock']}): "
                f"precio {money(q['price'])}, con {money(q['down'])} de entrada{' y su trade-in' if q.get('equity', 0) > 0 else ''}, "
                f"aproximadamente {money(q['payment'])} al mes por {q['term']} meses al {q['apr']:g}% APR, con crédito aprobado."
                f"{' Incluye impuestos y cargos.' if q.get('fees') else ''} ¿Cuándo puede venir?")
    return (f"Hi{' ' + first if first else ''}! Here are the numbers on the {q['vehicle']} (stock {q['stock']}): "
            f"selling price {money(q['price'])}, with {money(q['down'])} down{trade}, about {money(q['payment'])}/mo "
            f"for {q['term']} months at {q['apr']:g}% APR, with approved credit.{fees} When can you come in?")


def trade_words(t: dict) -> str:
    t = t or {}
    car = " ".join(str(t.get(k) or "").strip() for k in ("year", "make", "model", "trim")).strip()
    bits = [car] if car else []
    if str(t.get("miles") or "").strip():
        bits.append(f"{t['miles']} miles")
    return ", ".join(bits)
LOOKING = ["New", "Used", "Either"]


@_locked
def save(data: dict) -> dict:
    """Add or change one customer. Returns the saved customer."""
    all_ = load()
    cid = data.get("id") or ""
    cur = next((c for c in all_ if c.get("id") == cid), None) if cid else None
    if cur is None:
        cur = blank()
        cur["id"] = uuid.uuid4().hex[:12]
        cur["added"] = _now()
        cur["last_contact"] = _today()
        all_.append(cur)
    for k in EDITABLE:
        if k in data:
            cur[k] = data[k]
    cur["name"] = " ".join(str(cur.get("name") or "").split())
    cur["phone"] = tidy_phone(cur.get("phone") or "")
    if cur.get("status") not in STATUSES:
        cur["status"] = "New"
    cur["wants"] = [w for w in cur.get("wants") or [] if w in WANTS]
    if cur.get("lang") not in ("en", "es"):
        cur["lang"] = "en"
    dl = cur.get("deal") if isinstance(cur.get("deal"), dict) else {}
    cur["deal"] = {k: str(dl.get(k) or "").strip()[:60] for k in DEAL_KEYS if str(dl.get(k) or "").strip()}
    ti = cur.get("trade_info") if isinstance(cur.get("trade_info"), dict) else {}
    cur["trade_info"] = {k: str(ti.get(k) or "").strip()[:120] for k in TRADE_KEYS if str(ti.get(k) or "").strip()}
    if cur["trade_info"].get("vin"):
        cur["trade_info"]["vin"] = cur["trade_info"]["vin"].upper().replace(" ", "")
    if cur.get("looking_for") not in LOOKING:
        cur["looking_for"] = ""
    if cur.get("vin_entered") and not cur.get("vin_entered_on"):
        cur["vin_entered_on"] = _today()
    if not cur.get("vin_entered"):
        cur["vin_entered_on"] = ""
    if cur["status"] in CLOSED:
        cur["followup"] = ""
    # a first chat pasted while adding
    first = str(data.get("first_chat") or "").strip()
    if first and not cur["chat"]:
        cur["chat"].append({"when": _now(), "text": first})
    _write(all_)
    return cur


@_locked
def set_fields(cid: str, **kw) -> dict | None:
    """Change program-kept fields (a saved car search) without touching the rest."""
    all_ = load()
    c = next((x for x in all_ if x.get("id") == cid), None)
    if c is None:
        return None
    c.update(kw)
    _write(all_)
    return c


@_locked
def add_entry(cid: str, kind: str, text: str) -> dict | None:
    """kind: 'notes' | 'sent' | 'chat'. Counts as contact today."""
    text = str(text or "").strip()
    if kind not in ("notes", "sent", "chat") or not text:
        return get(cid)
    all_ = load()
    c = next((x for x in all_ if x.get("id") == cid), None)
    if not c:
        return None
    c.setdefault(kind, []).append({"when": _now(), "text": text})
    c["last_contact"] = _today()
    _write(all_)
    return c


@_locked
def remove_entry(cid: str, kind: str, when: str, text: str) -> dict | None:
    all_ = load()
    c = next((x for x in all_ if x.get("id") == cid), None)
    if not c or kind not in ("notes", "sent", "chat"):
        return c
    for i, e in enumerate(c.get(kind) or []):
        if e.get("when") == when and e.get("text") == text:
            del c[kind][i]
            break
    _write(all_)
    return c


@_locked
def delete(cid: str) -> bool:
    all_ = load()
    keep = [c for c in all_ if c.get("id") != cid]
    if len(keep) == len(all_):
        return False
    _write(keep)
    return True


# ------------------------------------------------------------- settings
def settings() -> dict:
    try:
        d = json.loads(SETTINGS.read_text(encoding="utf-8"))
        if isinstance(d, dict):
            return {"days_off": [int(x) for x in d.get("days_off", [])
                                 if 0 <= int(x) <= 6]}
    except Exception:
        pass
    return {"days_off": []}


def set_days_off(days: list[int]) -> dict:
    BOOK.mkdir(parents=True, exist_ok=True)
    d = {"days_off": sorted({int(x) for x in days if 0 <= int(x) <= 6})}
    SETTINGS.write_text(json.dumps(d), encoding="utf-8")
    return d


def next_workday(start: date, days_ahead: int) -> date:
    """`days_ahead` days from start, moved past your days off."""
    off = set(settings()["days_off"])
    d = start + timedelta(days=days_ahead)
    for _ in range(7):
        if d.weekday() not in off:
            break
        d += timedelta(days=1)
    return d


# ------------------------------------------------------------- inventory
def _inv_for(st: dict) -> tuple[dict, Path]:
    d = Path(st["dir"])
    photos = st["settings"].get("photo_drop") or str(d / "Photo Drop")
    try:
        recs = json.loads((d / "out" / "inventory.json").read_text(encoding="utf-8"))
    except Exception:
        recs = []
    return {str(r.get("stock") or "").upper(): r for r in recs
            if r.get("stock")}, Path(photos)


def inventories() -> dict:
    """{store_key: {"name", "cars": {STOCK: rec}, "photos": Path}}"""
    out = {}
    for st in stores.all_stores():
        cars, photos = _inv_for(st)
        out[st["key"]] = {"name": st["name"], "cars": cars, "photos": photos}
    return out


def car_name(r: dict) -> str:
    model = str(r.get("model") or "").strip()
    trim = str(r.get("trim") or "").strip()
    if trim and model.lower().endswith(trim.lower()):
        trim = ""
    return " ".join(str(x) for x in (r.get("year"), r.get("make"), model, trim)
                    if x and str(x).strip())


def car_price(r: dict):
    return r.get("final_price") or r.get("moses_price") or r.get("retail_price")


def search(q: str, limit: int = 12) -> list[dict]:
    """Stock number, year, make or model -- every store's lot."""
    words = [w for w in re.split(r"\s+", str(q or "").lower().strip()) if w]
    if not words:
        return []
    hits = []
    for key, inv in inventories().items():
        for stock, r in inv["cars"].items():
            hay = f"{stock} {car_name(r)} {r.get('vin') or ''}".lower()
            if all(w in hay for w in words):
                exact = stock.lower() == words[0]
                hits.append((0 if exact else 1, stock, {
                    "stock": stock, "store_key": key, "store": inv["name"],
                    "name": car_name(r), "price": car_price(r),
                    "miles": r.get("mileage")}))
    hits.sort(key=lambda h: (h[0], h[1]))
    return [h[2] for h in hits[:limit]]


# ------------------------------------------------------------- reading
def _vehicle_info(v: dict, invs: dict) -> dict:
    stock = str(v.get("stock") or "").upper()
    key = v.get("store_key") or ""
    inv = invs.get(key)
    rec = inv["cars"].get(stock) if inv else None
    if rec is None and not inv:
        # store not known (removed?) -- look everywhere
        for k, i in invs.items():
            if stock in i["cars"]:
                key, inv, rec = k, i, i["cars"][stock]
                break
    info = {"stock": stock, "store_key": key,
            "store": inv["name"] if inv else "",
            "label": v.get("label") or "",
            "on_lot": None, "name": "", "price": None, "miles": None, "photos_here": False}
    if rec:
        info.update(on_lot=True, name=car_name(rec), price=car_price(rec),
                    miles=rec.get("mileage"))
    elif inv and inv["cars"]:
        info["on_lot"] = False          # we read that lot and it isn't there
    if not info["name"]:
        info["name"] = info["label"]
    info["thumb"] = ""
    try:
        folder = inv["photos"] / stock if inv else None
        if folder and folder.is_dir():
            pics = sorted(p for p in folder.iterdir()
                          if p.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp"))
            if pics:
                info["thumb"] = pics[0].resolve().as_uri()
                info["photos_here"] = True
    except Exception:
        pass
    if not info["thumb"] and rec:
        ph = rec.get("photos")
        if isinstance(ph, list) and ph and str(ph[0]).startswith("https://"):
            info["thumb"] = str(ph[0])
    return info


def _followup_word(d: str) -> str:
    if not d:
        return ""
    try:
        f = date.fromisoformat(d)
    except ValueError:
        return d
    t = date.today()
    if f < t:
        return "Overdue · " + f.strftime("%a %b %d").replace(" 0", " ")
    if f == t:
        return "Today"
    if f == t + timedelta(days=1):
        return "Tomorrow"
    return f.strftime("%a %b %d").replace(" 0", " ")


def _appt_word(a: str) -> str:
    if not a:
        return ""
    try:
        t = datetime.fromisoformat(a)
    except ValueError:
        return a
    s = t.strftime("%a %b %d · %I:%M %p").replace(" 0", " ")
    if t.date() == date.today():
        s = "Today · " + t.strftime("%I:%M %p").lstrip("0")
    return s


def view(c: dict, invs: dict | None = None) -> dict:
    """A customer with everything the screens show worked out."""
    invs = invs if invs is not None else inventories()
    v = dict(c)
    v["cars"] = [_vehicle_info(x, invs) for x in c.get("vehicles") or []]
    v["store"] = invs.get(c.get("store_key"), {}).get("name", "") or \
        (v["cars"][0]["store"] if v["cars"] else "")
    v["followup_word"] = _followup_word(c.get("followup") or "")
    v["appt_word"] = _appt_word(c.get("appointment") or "")
    t = date.today().isoformat()
    open_ = c.get("status") not in CLOSED
    v["due"] = bool(open_ and c.get("followup") and c["followup"] <= t)
    v["needs_vin"] = c.get("status") in VIN_FROM and not c.get("vin_entered")
    v["car_gone"] = bool(open_ and any(x["on_lot"] is False for x in v["cars"]))
    v["appt_today"] = bool(c.get("appointment", "")[:10] == t and open_)
    v["trade_equity"] = trade_equity(c.get("trade_info") or {})
    try:
        v["deal_calc"] = deal_calc(c, (v["cars"][0].get("price") if v["cars"] else 0) or 0)
        first = v["cars"][0] if v["cars"] else None
        rec = (invs.get(first["store_key"]) or {}).get("cars", {}).get(first["stock"]) if first else None
        v["deal_calc"]["web_doc_fee"] = (rec or {}).get("doc_fee") or 0
    except Exception:
        v["deal_calc"] = None
    try:
        import finder
        v["search_words"] = finder.describe(c.get("search") or {})
    except Exception:
        v["search_words"] = ""
    return v


def book() -> dict:
    invs = inventories()
    rows = [view(c, invs) for c in load()]
    order = {s: i for i, s in enumerate(STATUSES)}

    def k(r):
        return (r["status"] in CLOSED, r.get("followup") or "9999",
                order.get(r["status"], 9), r["name"].lower())
    rows.sort(key=k)
    try:
        import finder
        new = {x["id"]: sum(1 for _ in x["cars"]) + x["more"] for x in finder.alerts()["customers"]}
    except Exception:
        new = {}
    for r in rows:
        r["new_matches"] = new.get(r["id"], 0)
    attention = [r for r in rows if r["needs_vin"] or r["car_gone"] or r["new_matches"]
                 or r["due"] or r["appt_today"]]
    return {"customers": rows, "attention": attention,
            "stores": [{"key": k, "name": i["name"]} for k, i in invs.items()],
            "statuses": STATUSES, "wants": WANTS, "looking": LOOKING,
            "settings": settings(), "today": _today(), "desk": desk_public()}


# ------------------------------------------------------------- helpers
PHONE = re.compile(r"(?<!\d)(?:\+?1[\s.-]?)?\(?(\d{3})\)?[\s.-]?(\d{3})[\s.-]?(\d{4})(?!\d)")
EMAIL = re.compile(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+")


def tidy_phone(p: str) -> str:
    m = PHONE.search(str(p or ""))
    return f"{m.group(1)}-{m.group(2)}-{m.group(3)}" if m else str(p or "").strip()


def parse_chat(text: str) -> dict:
    """
    What can be picked out of a pasted Marketplace chat. Only fills in what
    is plainly there -- he checks it before saving.
    """
    t = str(text or "")
    out = {"name": "", "phone": "", "email": "", "wants": [], "stock": ""}
    m = PHONE.search(t)
    if m:
        out["phone"] = f"{m.group(1)}-{m.group(2)}-{m.group(3)}"
    m = EMAIL.search(t)
    if m:
        out["email"] = m.group(0)
    # Facebook puts the buyer's name on a line of its own, often
    # "Name · Marketplace" or "Name · <listing title>"
    for line in t.splitlines()[:6]:
        line = line.strip()
        m = re.match(r"^([A-Z][a-zA-Z'.-]+(?: [A-Z][a-zA-Z'.-]+){1,2})\s*(?:·|-|\|)", line)
        if m:
            out["name"] = m.group(1)
            break
    if not out["name"]:
        m = re.search(r"\b(?i:my name is|this is)\s+([A-Z][a-z]+(?: [A-Z][a-z]+)?)", t)
        if m:
            out["name"] = m.group(1)
    low = t.lower()
    if re.search(r"pre[- ]?approv|financ|payment|credit|\$?\d[\d,]* down|monthly|a month|apr\b", low):
        out["wants"].append("Financing")
    if re.search(r"\btrad(?:e|es|ed|ing)\b|trade-in|my old car|payoff", low):
        out["wants"].append("Trade-in")
    if re.search(r"still available|interested|buy|cash|look at it|come see|test drive", low) \
            or not out["wants"]:
        out["wants"].insert(0, "Buying")
    m = re.search(r"\b([A-Z]{1,4}\d{4,6}[A-Z]?)\b", t)
    if m:
        out["stock"] = m.group(1)
    return out


def vin_text(cid: str) -> str:
    """What goes into the dealership CRM, ready to paste."""
    c = get(cid)
    if not c:
        return ""
    v = view(c)
    L = [f"Name: {c.get('name', '')}"]
    if c.get("phone"):
        L.append(f"Phone: {c['phone']}")
    if c.get("email"):
        L.append(f"Email: {c['email']}")
    if c.get("address"):
        L.append(f"Address: {c['address']}")
    L.append(f"Source: Facebook Marketplace")
    for car in v["cars"]:
        price = f" - ${car['price']:,}" if isinstance(car.get("price"), (int, float)) else ""
        L.append(f"Vehicle of interest: {car['stock']} {car['name']}{price}".rstrip())
    if c.get("wants"):
        L.append("Wants: " + ", ".join(c["wants"]))
    if c.get("looking_for"):
        L.append("New or used: " + c["looking_for"])
    if c.get("trade"):
        L.append(f"Trade: {c['trade']}")
    if c.get("appointment"):
        try:
            t = datetime.fromisoformat(c["appointment"])
            L.append("Appointment: " + t.strftime("%a %b %d, %Y at %I:%M %p")
                     .replace(" 0", " "))
        except ValueError:
            L.append(f"Appointment: {c['appointment']}")
    notes = [n["text"] for n in (c.get("notes") or [])][-3:]
    if notes:
        L.append("Notes: " + " / ".join(notes))
    return "\n".join(L)
