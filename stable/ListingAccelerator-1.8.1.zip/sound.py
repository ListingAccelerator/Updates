"""
sound.py -- music and a voice for walkaround videos. Free, on this computer.

VOICE: the voices built into Windows (Microsoft David, Mark, Zira ...) read
the title and price, each caption he approved, and "Call or text <name> at
<number>". Nothing leaves the computer and nothing costs anything. The
voice only ever says what is on screen -- the same captions that can only
come from the car's website listing.

MUSIC: "Country rock" is composed here the first time it's needed (from
scratch -- royalty-free, safe to sell with the program) and kept in
program\\media\\. Or his own music file, or none.
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
import tempfile
import wave
from pathlib import Path

HERE = Path(__file__).resolve().parent
MEDIA = HERE / "media"
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
MUSIC = {"country": "Country rock (free)", "none": "No music", "own": "My own music file"}
CHOICES = MEDIA / "sound_choices.json"     # updates never touch media\


def choices() -> dict:
    try:
        d = json.loads(CHOICES.read_text(encoding="utf-8"))
        if isinstance(d, dict):
            return {"sound": d.get("sound") or "both", "music": d.get("music") or "country",
                    "own": d.get("own") or "", "voice": d.get("voice") or ""}
    except Exception:
        pass
    return {"sound": "both", "music": "country", "own": "", "voice": ""}


def save_choices(d: dict) -> dict:
    c = choices()
    for k in ("sound", "music", "own", "voice"):
        if k in d and d[k] is not None:
            c[k] = str(d[k])
    MEDIA.mkdir(parents=True, exist_ok=True)
    CHOICES.write_text(json.dumps(c, indent=1), encoding="utf-8")
    return c


# ------------------------------------------------------------ voice
def _ps(script: str, timeout: int = 120):
    return subprocess.run(["powershell", "-NoProfile", "-NonInteractive",
                           "-ExecutionPolicy", "Bypass", "-Command", script],
                          capture_output=True, text=True, timeout=timeout,
                          creationflags=NO_WINDOW)


def voices() -> list[str]:
    """The Windows voices on this computer, men first (they suit car ads)."""
    if sys.platform != "win32":
        return []
    try:
        r = _ps("Add-Type -AssemblyName System.Speech; "
                "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                "$s.GetInstalledVoices() | Where-Object { $_.Enabled } | "
                "ForEach-Object { $_.VoiceInfo.Name + '|' + $_.VoiceInfo.Gender }", 40)
        out = []
        for line in r.stdout.splitlines():
            if "|" in line:
                name, g = line.strip().split("|", 1)
                out.append((0 if g.strip().lower() == "male" else 1, name.strip()))
        return [n for _, n in sorted(out)]
    except Exception:
        return []


def _esc(s: str) -> str:
    return str(s).replace("'", "''")


def speak(lines: list[str], voice: str, folder: Path) -> list[Path | None]:
    """One WAV per line, with the chosen Windows voice."""
    folder.mkdir(parents=True, exist_ok=True)
    paths = [folder / f"line{i:02d}.wav" for i in range(len(lines))]
    if sys.platform == "win32":
        body = "\n".join(
            f"$s.SetOutputToWaveFile('{_esc(p)}'); $s.Speak('{_esc(t)}');"
            for p, t in zip(paths, lines) if t.strip())
        script = ("Add-Type -AssemblyName System.Speech\n"
                  "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer\n"
                  f"try {{ $s.SelectVoice('{_esc(voice)}') }} catch {{}}\n"
                  "$s.Rate = 0\n" + body + "\n$s.SetOutputToNull(); $s.Dispose()")
        _ps(script, 300)
    else:                                   # for testing away from Windows
        import shutil
        import walkaround
        exe = shutil.which("ffmpeg") or walkaround.ffmpeg_exe()
        for p, t in zip(paths, lines):
            if t.strip() and exe:
                txt = folder / (p.stem + ".txt")
                txt.write_text(t, encoding="utf-8")
                subprocess.run([exe, "-y", "-loglevel", "error", "-f", "lavfi", "-i",
                                f"flite=textfile='{txt}'", str(p)], capture_output=True)
    return [p if p.exists() else None for p in paths]


def seconds(p: Path | None) -> float:
    if not p:
        return 0.0
    try:
        with wave.open(str(p)) as w:
            return w.getnframes() / float(w.getframerate())
    except Exception:
        return 0.0


# what the voice says -- the caption, made sayable
SAY = [(r"\s*·\s*", ", "), (r"\b4WD/AWD\b", "four wheel drive"), (r"\b4WD\b", "four wheel drive"),
       (r"\bAWD\b", "all wheel drive"), (r"\bFWD\b", "front wheel drive"), (r"\bRWD\b", "rear wheel drive"),
       (r"\b4x4\b", "four by four"), (r"(\d(?:\.\d)?)L\b", r"\1 liter"), (r'(\d+(?:\.\d)?)"\s*x\s*\d+(?:\.\d)?"', r"\1 inch"),
       (r'(\d+(?:\.\d)?)"', r"\1 inch"), (r"\bMPG\b", "miles per gallon"), (r"\bLED\b", "L E D"),
       (r"\bUSB\b", "U S B"), (r"\bClass IV\b", "Class four"), (r"\bClass III\b", "Class three"),
       (r"/", " and "), (r"\s+", " ")]
JUNK = re.compile(r"\b(MDS|VVT|ETORQUE|DOHC|SOHC|GDI|MPI|SFI|PDI|TFSI|TSI|ATC|BSW|LRR|8HP75)\b", re.I)


def sayable(text: str) -> str:
    t = JUNK.sub("", str(text or ""))
    t = re.sub(r"\b\d{3}/\d{2}Z?R\d{2}(?:\.\d)?\s*(?:SL|XL|LT|P)?\b", "", t)   # tire sizes
    for a, b in SAY:
        t = re.sub(a, b, t)
    return t.strip(" ,.")


def say_price(price: str) -> str:
    return price.replace("$", "") + " dollars" if price else ""


def say_phone(phone: str) -> str:
    d = re.sub(r"\D", "", phone or "")
    if len(d) == 10:
        return f"{' '.join(d[:3])}, {' '.join(d[3:6])}, {' '.join(d[6:])}"
    return phone or ""


# ------------------------------------------------------------ music
def music_file(kind: str, own: str = "") -> Path | None:
    if kind == "own":
        p = Path(own) if own else None
        return p if p and p.exists() else None
    if kind == "country":
        f = MEDIA / "country-rock.wav"
        if not f.exists():
            compose_country(f)
        return f if f.exists() else None
    return None


def compose_country(out: Path, seconds_long: float = 64.0):
    """An upbeat country-rock bed: strummed guitar, bass, drums. Made here."""
    import numpy as np
    SR = 32000
    BPM = 112
    beat = 60 / BPM
    bar = 4 * beat
    rng = np.random.default_rng(7)

    def pluck(freq, dur, bright, decay):
        # Karplus-Strong, a block at a time so it runs quickly
        n, p = int(SR * dur), max(2, int(SR / freq))
        buf = rng.uniform(-1, 1, p) * bright + (1 - bright) * np.sin(np.linspace(0, 2 * np.pi, p, endpoint=False))
        out_ = np.empty(n)
        k = 0
        while k < n:
            m = min(p, n - k)
            out_[k:k + m] = buf[:m]
            buf = decay * 0.5 * (buf + np.roll(buf, -1))
            k += m
        return out_

    def note(m):
        return 440 * 2 ** ((m - 69) / 12)

    ch = {"G": [43, 47, 50, 55, 59, 67], "D": [50, 57, 62, 66], "Em": [40, 47, 52, 55, 59, 64],
          "C": [48, 52, 55, 60, 64]}
    bass = {"G": 31, "D": 38, "Em": 28, "C": 36}
    bars = int(seconds_long / bar)
    prog = (["G", "D", "Em", "C"] * 40)[:bars - 1] + ["G"]
    mix = np.zeros(int(SR * (len(prog) * bar + 2.5)))

    def add(sig, t, g):
        i = int(t * SR)
        j = min(len(mix), i + len(sig))
        mix[i:j] += sig[:j - i] * g

    cache = {}
    for bi, c in enumerate(prog):
        t0 = bi * bar
        last = bi == len(prog) - 1
        for k, sb in enumerate([0] if last else [0, 1, 1.5, 2.5, 3, 3.5]):
            notes = ch[c] if k % 2 == 0 else ch[c][::-1][:4]
            for j, m in enumerate(notes):
                key = (m, k % 2, last)
                if key not in cache:
                    cache[key] = pluck(note(m), 2.2 if last else 1.2,
                                       0.35 if k % 2 else 0.55, 0.9985 if last else 0.9965)
                add(cache[key], t0 + sb * beat + j * 0.012, 0.16 if k % 2 == 0 else 0.10)
        if last:
            break
        for b in range(4):
            m = bass[c] + (7 if b in (1, 3) else 0)
            t = np.arange(int(SR * beat * 0.9)) / SR
            add(np.sin(2 * np.pi * note(m) * t) * np.exp(-t * 3.0), t0 + b * beat, 0.35)
            tt = t0 + b * beat
            if b in (0, 2):
                t = np.arange(int(SR * 0.25)) / SR
                f = 110 * np.exp(-t * 18) + 45
                add(np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 12), tt, 0.6)
            else:
                t = np.arange(int(SR * 0.18)) / SR
                add(rng.uniform(-1, 1, len(t)) * np.exp(-t * 22) + 0.3 * np.sin(2 * np.pi * 190 * t) * np.exp(-t * 25), tt, 0.28)
            for h in (0, 0.5):
                t = np.arange(int(SR * 0.05)) / SR
                nz = np.diff(np.concatenate([[0], rng.uniform(-1, 1, len(t))])) * np.exp(-t * 80)
                add(nz, tt + h * beat, 0.10)
    mix = np.tanh(mix * 1.2)
    mix /= np.abs(mix).max() * 1.1
    pcm = (mix * 32767 * 0.9).astype("<i2")
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_suffix(".tmp")
    with wave.open(str(tmp), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())
    tmp.replace(out)


# ------------------------------------------------------------ the mix
def mix(exe: str, total: float, voice_at: list[tuple[float, Path]], music: Path | None,
        out: Path) -> Path | None:
    """Voice lines at their times, music underneath (quieter under the voice)."""
    if not voice_at and not music:
        return None
    args, parts, n = [exe, "-y", "-loglevel", "error"], [], 0
    for t, p in voice_at:
        args += ["-i", str(p)]
        ms = int(max(0, t) * 1000)
        parts.append(f"[{n}:a]aresample=44100,aformat=channel_layouts=stereo,adelay={ms}|{ms},apad[v{n}]")
        n += 1
    labels = [f"[v{i}]" for i in range(n)]
    if music:
        args += ["-stream_loop", "-1", "-i", str(music)]
        vol = 0.22 if voice_at else 0.85
        parts.append(f"[{n}:a]aresample=44100,aformat=channel_layouts=stereo,volume={vol},"
                     f"afade=t=in:d=0.6,atrim=0:{total:.2f},afade=t=out:st={max(0, total - 1.8):.2f}:d=1.8[m]")
        labels.append("[m]")
        n += 1
    parts.append("".join(labels) + f"amix=inputs={len(labels)}:normalize=0:dropout_transition=0,"
                 f"atrim=0:{total:.2f},alimiter=limit=0.95[out]")
    args += ["-filter_complex", ";".join(parts), "-map", "[out]", "-c:a", "aac", "-b:a", "160k", str(out)]
    r = subprocess.run(args, capture_output=True, creationflags=NO_WINDOW)
    return out if r.returncode == 0 and out.exists() else None
