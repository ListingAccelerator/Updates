"""
walkaround.py -- turn a car's photos into a short vertical walkaround video.

    title card (car, price, store) -> each photo with a slow zoom and its
    caption -> end card with the salesperson's own name and number.
    No music, no voice. Vertical 1080x1920, like a phone.

CAPTIONS NEVER CLAIM WHAT THE WEBSITE DOESN'T SAY. Every caption choice
comes from the car's own website listing: its paint, miles, drivetrain,
engine, "One owner" only when the site says so, and its listed features.
The salesman reviews each one before the video is made.

Matching captions to photos:
  - With his Gemini key on (AI replies), the AI looks at each photo and
    picks the matching caption -- from the website list only.
  - Otherwise, by photo order: dealer photos run outside first, then inside.
Either way it is only a suggestion until he presses Make video.

Needs Pillow and ffmpeg (the imageio-ffmpeg package). They are installed
the first time a video is made -- one time, about 30 MB.
"""
from __future__ import annotations

import base64
import io
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

PARTS = ["pillow", "imageio-ffmpeg", "numpy"]
PHOTO_EXT = (".jpg", ".jpeg", ".png", ".webp")
MAX_PHOTOS = 16
DEFAULT_PHOTOS = 12
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


# ------------------------------------------------------------ the add-ons
def ffmpeg_exe() -> str | None:
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return shutil.which("ffmpeg")


def ready() -> bool:
    try:
        import PIL  # noqa: F401
        import numpy  # noqa: F401
    except Exception:
        return False
    return bool(ffmpeg_exe())


def install_parts() -> dict:
    """One time: fetch Pillow and ffmpeg, the same way setup fetched the rest."""
    try:
        r = subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", *PARTS],
                           capture_output=True, text=True, timeout=600,
                           creationflags=NO_WINDOW)
        if r.returncode != 0:
            tail = (r.stderr or r.stdout or "").strip().splitlines()[-1:] or [""]
            return {"ok": False, "message": "Couldn't get the video maker. "
                    "Check the internet connection and try again. " + tail[0][:160]}
    except Exception as e:
        return {"ok": False, "message": f"Couldn't get the video maker: {e}"}
    import importlib
    importlib.invalidate_caches()
    return {"ok": ready(), "message": "Video maker ready." if ready()
            else "Installed, but the video maker still isn't answering. Restart the program."}


# ------------------------------------------------------------ captions
def _tidy(s: str) -> str:
    s = str(s or "").replace("®", "").replace("™", "").replace('""', '"')
    s = re.sub(r"\s+", " ", s).strip(" -·,")
    return s


# what a buyer cares about, best first -- for suggesting, not for limiting
APPEAL = [
    "heated and ventilated", "ventilated", "heated front seat", "heated seat",
    "heated steering", "remote start", "panoramic", "sunroof", "moonroof",
    "navigation", "apple carplay", "android auto", "leather", "third row",
    "3rd row", "360", "surround view", "blind spot", "adaptive cruise",
    "lane keep", "lane departure", "rear view camera", "backup camera",
    "rearview camera", "tow", "hitch", "trailer", "power liftgate",
    "hands-free", "wireless charg", "premium audio", "bose", "harman", "jbl",
    "subwoofer", "keyless", "push button", "led headl", "fog", "running board",
    "bed liner", "bedliner", "sliding window", "dual zone", "park assist",
    "parksense", "power seat", "memory", "heated mirror", "power-folding",
    "garage door", "alloy", "aluminum wheel", "cast-aluminum",
]
OUTSIDE = re.compile(r"fog|led|headl|lamp|mirror|(?<!steering )wheel|tire|hitch|tow|receiver|"
                     r"trailer|bed|liner|sunroof|moonroof|panoramic|roof|running board|"
                     r"step|tailgate|liftgate|grille|spoiler|chrome|rack|sliding window|"
                     r"bumper|exhaust", re.I)
SKIP = re.compile(r"emission|gvwr|axle ratio|telematics|glove box|sun visor|vanity|"
                  r"dome|courtesy|convex|supplemental|badge|defroster|tether|latch|"
                  r"airbag|air bag|immobilizer|stability|traction|brake assist|"
                  r"abs|tire pressure|tpms|child|owner's|manual|spare", re.I)


def _rank(f: str) -> int:
    low = f.lower()
    for i, k in enumerate(APPEAL):
        if k in low:
            return i
    return len(APPEAL) + 1


def caption_choices(rec: dict) -> dict:
    """Everything a caption may say, all taken from the car's website listing."""
    specs = []
    color = _tidy(rec.get("exterior_color"))
    try:
        from vehicle_parser import _spec_value_ok
        if color and not _spec_value_ok(color):
            color = ""
    except Exception:
        pass
    if color:
        specs.append(color)
    inside = _tidy(rec.get("interior_color"))
    if inside:
        specs.append(f"{inside} Interior" if "interior" not in inside.lower() else inside)
    miles = rec.get("mileage")
    if isinstance(miles, (int, float)) and miles > 0:
        specs.append(f"{int(miles):,} miles")
        if rec.get("one_owner") is True:
            specs.append(f"{int(miles):,} miles · One owner")
    if rec.get("one_owner") is True:
        specs.append("One owner")
    drive = _tidy(rec.get("drivetrain"))
    engine = _tidy(rec.get("engine_full") or rec.get("engine"))
    if drive:
        specs.append(drive)
    if engine and len(engine) <= 40:
        specs.append(engine)
    if drive and engine and len(engine) <= 30:
        specs.append(f"{drive} · {engine}")
    try:
        if rec.get("mpg_hwy"):
            specs.append(f"Up to {int(rec['mpg_hwy'])} MPG highway")
    except Exception:
        pass
    wheels = _tidy(rec.get("wheels"))
    if wheels and len(wheels) <= 40:
        specs.append(wheels if "wheel" in wheels.lower() else f"{wheels} Wheels")

    feats = []
    try:
        from build_jt_listings import clean_options
        opts = clean_options(rec.get("options") or [])
    except Exception:
        opts = [o for o in (rec.get("options") or []) if isinstance(o, str)]
    seen = {s.lower() for s in specs}
    for o in opts:
        t = _tidy(o)
        if not t or len(t) > 48 or "\n" in str(o) or t.lower() in seen:
            continue
        seen.add(t.lower())
        feats.append(t)
    feats.sort(key=lambda f: (SKIP.search(f) is not None, _rank(f)))
    return {"specs": specs, "features": feats}


def suggest(rec: dict, count: int) -> list[str]:
    """Captions by photo order: outside first, then inside. Each used once."""
    ch = caption_choices(rec)
    specs, feats = ch["specs"], [f for f in ch["features"] if not SKIP.search(f)]
    good = [f for f in feats if _rank(f) <= len(APPEAL)]
    outside = [f for f in good if OUTSIDE.search(f)]
    inside = [f for f in good if not OUTSIDE.search(f)]
    color = specs[0] if specs and "mile" not in specs[0].lower() else ""
    drive_engine = next((s for s in specs if " · " in s and "mile" not in s), "") or \
        next((s for s in specs if re.search(r"4wd|awd|4x4|fwd|rwd|cylinder|v6|v8|engine|turbo", s, re.I)), "")
    miles = next((s for s in specs if "One owner" in s), "") or \
        next((s for s in specs if "miles" in s), "")
    out_seq = [c for c in (color, drive_engine, miles) if c] + outside
    in_seq = inside
    n_out = max(1, round(count * 0.5))
    caps = []
    for i in range(count):
        seq = out_seq if i < n_out else in_seq
        caps.append(seq.pop(0) if seq else "")
    # anything good left over fills empty slots
    rest = out_seq + in_seq
    caps = [c or (rest.pop(0) if rest else "") for c in caps]
    return caps


def all_choices(rec: dict) -> list[str]:
    ch = caption_choices(rec)
    return ch["specs"] + ch["features"]


# ------------------------------------------------------------ photos
def photos_for(folder: Path) -> list[Path]:
    if not folder.is_dir():
        return []
    pics = [p for p in folder.iterdir() if p.suffix.lower() in PHOTO_EXT
            and not p.name.lower().startswith(("thumb", "."))]
    return sorted(pics, key=lambda p: (not p.name.lower().startswith("web_"), p.name.lower()))


# ------------------------------------------------------------ AI matching
def ai_match(rec: dict, photos: list[Path], choices: list[str]) -> dict:
    """Ask Gemini what each photo shows and which listed caption fits."""
    import ai_reply
    s = ai_reply.settings()
    if s["mode"] != "gemini" or not s["key"]:
        return {"ok": False, "off": True}
    try:
        from PIL import Image
    except Exception:
        return {"ok": False, "message": "Get the video maker first."}
    parts = [{"text": (
        "These photos are all of the same used vehicle for sale: "
        f"{rec.get('year', '')} {rec.get('make', '')} {rec.get('model', '')} {rec.get('trim', '')}. "
        "For each photo, in order, say what it shows in 1 to 3 words (front, side, rear, "
        "wheel, bed, cargo, dash, steering wheel, front seats, rear seats, screen, gauges, "
        "engine, badge, sunroof...). Then pick ONE caption for it from the CAPTION LIST "
        "that is clearly visible in that photo or directly about what it shows. Use each "
        "caption at most once. Copy captions exactly as written in the list. If nothing "
        "fits, use an empty caption. For the first outside photo, prefer the paint color.\n\n"
        "CAPTION LIST:\n" + "\n".join(f"- {c}" for c in choices) +
        '\n\nReturn JSON only: {"photos": [{"n": 1, "shows": "front", "caption": "..."}]}')}]
    for i, p in enumerate(photos, 1):
        try:
            im = Image.open(p).convert("RGB")
            im.thumbnail((640, 640))
            buf = io.BytesIO()
            im.save(buf, "JPEG", quality=80)
            parts.append({"text": f"Photo {i}:"})
            parts.append({"inline_data": {"mime_type": "image/jpeg",
                                          "data": base64.b64encode(buf.getvalue()).decode()}})
        except Exception:
            parts.append({"text": f"Photo {i}: (could not be read)"})
    body = {"contents": [{"role": "user", "parts": parts}],
            "generationConfig": {"temperature": 0.2, "responseMimeType": "application/json"}}
    models = [s["model"]] if s["model"] else []
    try:
        models += [m for m in ai_reply.pick_model(s["key"])[:4] if m not in models]
    except Exception as e:
        return {"ok": False, "message": ai_reply._why(e)}
    last = None
    allowed = {c: c for c in choices}
    allowed_low = {c.lower().strip(): c for c in choices}
    for m in models:
        try:
            d = ai_reply._post(f"{ai_reply.API}/models/{m}:generateContent", s["key"], body, timeout=60)
            txt = "".join(x.get("text", "") for x in
                          (((d.get("candidates") or [{}])[0].get("content") or {}).get("parts") or []))
            mm = re.search(r"\{.*\}", txt, re.S)
            got = json.loads(mm.group(0) if mm else txt).get("photos", [])
            caps, shows, used = [""] * len(photos), [""] * len(photos), set()
            for g in got:
                try:
                    k = int(g.get("n")) - 1
                except Exception:
                    continue
                if not 0 <= k < len(photos):
                    continue
                shows[k] = str(g.get("shows") or "")[:30]
                c = str(g.get("caption") or "")
                c = allowed.get(c) or allowed_low.get(c.lower().strip(), "")
                if c and c not in used:         # only from the website list, once each
                    caps[k] = c
                    used.add(c)
            return {"ok": True, "captions": caps, "shows": shows}
        except Exception as e:
            last = e
            if ai_reply._slow(e):
                continue
            if hasattr(e, "code") and getattr(e, "code", 0) in (404, 429, 500, 502, 503, 504):
                continue
            break
    return {"ok": False, "message": ai_reply._why(last)}


# ------------------------------------------------------------ the video
W, H, FPS = 1080, 1920, 30
NAVY = (11, 42, 85)
WHITE = (255, 255, 255)
SOFT = (201, 214, 234)
ACCENT = (255, 196, 64)
PHOTO_SECS, FADE_SECS, TITLE_SECS, END_SECS = 2.3, 0.4, 2.4, 3.2
PHOTO_BOX = (0, 560, W, 560 + 810)


def _font(bold: bool, size: int):
    from PIL import ImageFont
    names = (["segoeuib.ttf", "arialbd.ttf", "DejaVuSans-Bold.ttf"] if bold
             else ["segoeui.ttf", "arial.ttf", "DejaVuSans.ttf"])
    dirs = [Path("C:/Windows/Fonts"), Path("/usr/share/fonts/truetype/dejavu"),
            Path("/Library/Fonts"), Path("/System/Library/Fonts/Supplemental")]
    for n in names:
        for d in dirs:
            if (d / n).exists():
                return ImageFont.truetype(str(d / n), size)
    return ImageFont.load_default()


def _wrap(draw, text, f, width):
    words, lines, cur = str(text).split(), [], ""
    for w in words:
        t = (cur + " " + w).strip()
        if draw.textlength(t, font=f) <= width:
            cur = t
        else:
            if cur:
                lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


def _centered(draw, y, text, f, fill, width=W - 120):
    for line in _wrap(draw, text, f, width):
        tw = draw.textlength(line, font=f)
        draw.text(((W - tw) / 2, y), line, font=f, fill=fill)
        y += int(f.size * 1.22)
    return y


def render(car: dict, items: list[dict], out: Path, progress=lambda f: None,
           audio: Path | None = None, sound_opts: dict | None = None):
    """
    car: title, price, seller, phone, store (and optional title_secs/end_secs).
    items: [{path, caption, secs?}] -- secs lets a photo stay up as long as
    its spoken line. audio: a sound track (music, voice, or both) mixed in.
    """
    from PIL import Image, ImageDraw
    exe = ffmpeg_exe()
    if not exe:
        raise RuntimeError("The video maker isn't installed yet.")
    bw, bh = PHOTO_BOX[2] - PHOTO_BOX[0], PHOTO_BOX[3] - PHOTO_BOX[1]

    def prep(p):
        im = Image.open(p).convert("RGB")
        s = max(bw * 1.12 / im.width, bh * 1.12 / im.height)
        return im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))), Image.LANCZOS)

    photos = [prep(it["path"]) for it in items]

    base = Image.new("RGB", (W, H), NAVY)
    d = ImageDraw.Draw(base)
    y = _centered(d, 150, car["title"], _font(True, 64), WHITE)
    if car.get("price"):
        f = _font(True, 58)
        tw = d.textlength(car["price"], font=f)
        x0 = (W - tw) / 2 - 28
        d.rounded_rectangle([x0, y + 20, x0 + tw + 56, y + 104], radius=18, fill=ACCENT)
        d.text(((W - tw) / 2, y + 28), car["price"], font=f, fill=NAVY)
    if car.get("phone"):
        _centered(d, H - 250, f"Call or Text {car['phone']}", _font(True, 44), WHITE)
    _centered(d, H - 180, car.get("seller") or car.get("store") or "", _font(False, 38), SOFT)

    def card(lines):
        img = Image.new("RGB", (W, H), NAVY)
        dd = ImageDraw.Draw(img)
        total = sum(int(f.size * 1.22) * len(_wrap(dd, t, f, W - 160)) + gap
                    for t, f, c, gap in lines if t)
        yy = (H - total) / 2
        for t, f, c, gap in lines:
            if t:
                yy = _centered(dd, yy, t, f, c, W - 160) + gap
        return img

    title = card([(car["title"], _font(True, 86), WHITE, 40),
                  (car.get("price", ""), _font(True, 96), ACCENT, 40),
                  (car.get("store", ""), _font(False, 40), SOFT, 0)])
    end = card([(car.get("seller", ""), _font(True, 72), WHITE, 30),
                ("Call or Text Me Directly" if car.get("phone") else "", _font(False, 44), SOFT, 10),
                (car.get("phone", ""), _font(True, 96), ACCENT, 50),
                (car.get("store", ""), _font(False, 40), SOFT, 0)])

    capf = _font(True, 52)

    def frame(img, t, i, caption, alpha):
        z = 1.0 + 0.08 * t
        cw, ch = img.width / 1.12 / z, img.height / 1.12 / z
        cw, ch = min(cw, img.width), min(ch, img.height)
        dx = (img.width - cw) * (0.5 + (0.25 if i % 2 else -0.25) * (t - 0.5))
        dy = (img.height - ch) * 0.5
        crop = img.crop((int(dx), int(dy), int(dx + cw), int(dy + ch))).resize((bw, bh), Image.BILINEAR)
        fr = base.copy()
        fr.paste(crop, (PHOTO_BOX[0], PHOTO_BOX[1]))
        if caption and alpha > 0:
            layer = Image.new("RGBA", (W, 260), (0, 0, 0, 0))
            dl = ImageDraw.Draw(layer)
            lines = _wrap(dl, caption, capf, W - 140)[:2]
            a = int(255 * alpha)
            yy = 30
            for ln in lines:
                tw = dl.textlength(ln, font=capf)
                dl.rounded_rectangle([(W - tw) / 2 - 30, yy - 12, (W + tw) / 2 + 30, yy + 74],
                                     radius=16, fill=(255, 255, 255, int(a * 0.14)))
                dl.text(((W - tw) / 2, yy), ln, font=capf, fill=(255, 255, 255, a))
                yy += 92
            fr = fr.convert("RGBA")
            fr.alpha_composite(layer, (0, PHOTO_BOX[3] + 20))
            fr = fr.convert("RGB")
        return fr

    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_name(out.stem + ".making.mp4")
    ff = subprocess.Popen(
        [exe, "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24",
         "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
         "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "21", "-preset", "veryfast",
         "-movflags", "+faststart", str(tmp)],
        stdin=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=NO_WINDOW)
    title_secs = float(car.get("title_secs") or TITLE_SECS)
    end_secs = float(car.get("end_secs") or END_SECS)
    lens = [max(1.2, float(it.get("secs") or PHOTO_SECS)) for it in items]

    # ---- the voice: each photo stays up as long as its line takes
    import tempfile
    import sound
    so = sound_opts or {}
    work = Path(tempfile.mkdtemp(prefix="la_wa_"))
    lines_wav = []
    if so.get("voice"):
        first = (car.get("seller") or "").split(" ")[0] or "me"
        lines = ([f"{car['title']}. {sound.say_price(car.get('price', ''))}."]
                 + [sound.sayable(it.get("caption") or "") for it in items]
                 + [f"Call or text {first} at {sound.say_phone(car.get('phone', ''))}."
                    if car.get("phone") else ""])
        lines_wav = sound.speak(lines, so["voice"], work)
        d = [sound.seconds(x) for x in lines_wav]
        if d and d[0]:
            title_secs = max(title_secs, d[0] + 0.7)
        for i in range(len(items)):
            if d[i + 1]:
                lens[i] = max(lens[i], d[i + 1] + 0.6)
        if d and d[-1]:
            end_secs = max(end_secs, d[-1] + 1.0)
    total = int(title_secs * FPS) + sum(int(x * FPS) + int(FADE_SECS * FPS) for x in lens) + \
        int((FADE_SECS + end_secs) * FPS)
    done = [0]

    def emit(img):
        ff.stdin.write(img.tobytes())
        done[0] += 1
        if done[0] % 15 == 0:
            progress(min(0.99, done[0] / total))

    def hold(img, secs):
        for _ in range(int(secs * FPS)):
            emit(img)

    def fade(a, b, secs):
        k = int(secs * FPS)
        for j in range(k):
            emit(Image.blend(a, b, (j + 1) / k))

    try:
        hold(title, title_secs)
        prev = title
        for i, img in enumerate(photos):
            cap = items[i].get("caption") or ""
            frames = []
            n = int(lens[i] * FPS)
            for k in range(n):
                t = k / (n - 1)
                ca = max(0.0, min(1.0, (t - 0.10) / 0.15, (0.95 - t) / 0.12))
                frames.append(frame(img, t, i, cap, ca))
            fade(prev, frames[0], FADE_SECS)
            for f in frames:
                emit(f)
            prev = frames[-1]
        fade(prev, end, FADE_SECS)
        hold(end, end_secs)
    finally:
        try:
            ff.stdin.close()
        except Exception:
            pass
        err = ff.stderr.read().decode("utf-8", "replace") if ff.stderr else ""
        ff.wait()
    if ff.returncode != 0 or not tmp.exists():
        tmp.unlink(missing_ok=True)
        raise RuntimeError("The video couldn't be written. " + err[-200:])
    # ---- the sound track: voice lines at their photos, music underneath
    if so and not audio:
        voice_at, t = [], title_secs
        if lines_wav:
            if lines_wav[0]:
                voice_at.append((0.3, lines_wav[0]))
            for i, ln in enumerate(lens):
                t += FADE_SECS
                if lines_wav[i + 1]:
                    voice_at.append((t + 0.15, lines_wav[i + 1]))
                t += ln
            t += FADE_SECS
            if lines_wav[-1]:
                voice_at.append((t + 0.2, lines_wav[-1]))
        try:
            music = sound.music_file(so.get("music") or "none", so.get("own") or "")
        except Exception:
            music = None
        audio = sound.mix(exe, total / FPS, voice_at, music, work / "track.m4a")
    if audio and Path(audio).exists():
        dur = total / FPS
        mixed = out.with_name(out.stem + ".sound.mp4")
        r = subprocess.run(
            [exe, "-y", "-loglevel", "error", "-i", str(tmp), "-i", str(audio),
             "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-b:a", "160k",
             "-af", f"apad,atrim=0:{dur:.2f},afade=t=out:st={max(0, dur - 1.5):.2f}:d=1.5",
             "-shortest", "-movflags", "+faststart", str(mixed)],
            capture_output=True, creationflags=NO_WINDOW)
        if r.returncode == 0 and mixed.exists():
            tmp.unlink(missing_ok=True)
            tmp = mixed
        else:
            mixed.unlink(missing_ok=True)
    tmp.replace(out)
    try:
        import shutil as _sh
        _sh.rmtree(work, ignore_errors=True)
    except Exception:
        pass
    progress(1.0)
    return out
