"""
teamlock.py -- locks the copy of a salesperson's customers that sits in the
dealership's shared folder, so only the manager's program can open it.

Nothing extra to install: everything here is the Python that ships with the
program.

  * Each side has a key pair (X25519, RFC 7748). The manager's public key sits
    in the shared folder; his private key stays on his computer, itself locked
    with his manager PIN.
  * A salesperson's program seals the customer copy to the manager's public
    key; the manager seals his changes to that salesperson's public key.
  * Sealing: a fresh one-time key pair per file, the shared secret run through
    HKDF-SHA256, the data encrypted with a SHA-256 counter-mode key stream and
    checked with HMAC-SHA256. A changed or damaged file is refused.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import zlib

# ------------------------------------------------------------------ X25519
_P = 2 ** 255 - 19
_A24 = 121665


def _clamp(k: bytes) -> int:
    b = bytearray(k)
    b[0] &= 248
    b[31] &= 127
    b[31] |= 64
    return int.from_bytes(bytes(b), "little")


def _x25519(k: bytes, u: bytes) -> bytes:
    k_i = _clamp(k)
    x1 = int.from_bytes(u, "little") & ((1 << 255) - 1)
    x2, z2, x3, z3, swap = 1, 0, x1, 1, 0
    for t in range(254, -1, -1):
        kt = (k_i >> t) & 1
        swap ^= kt
        if swap:
            x2, x3, z2, z3 = x3, x2, z3, z2
        swap = kt
        a, b = (x2 + z2) % _P, (x2 - z2) % _P
        aa, bb = a * a % _P, b * b % _P
        e = (aa - bb) % _P
        c, d = (x3 + z3) % _P, (x3 - z3) % _P
        da, cb = d * a % _P, c * b % _P
        x3 = (da + cb) ** 2 % _P
        z3 = x1 * (da - cb) ** 2 % _P
        x2 = aa * bb % _P
        z2 = e * (aa + _A24 * e) % _P
    if swap:
        x2, x3, z2, z3 = x3, x2, z3, z2
    return (x2 * pow(z2, _P - 2, _P) % _P).to_bytes(32, "little")


_BASE = (9).to_bytes(32, "little")


def new_keys() -> tuple[str, str]:
    """(private, public), both base64 text."""
    priv = os.urandom(32)
    return _b64(priv), _b64(_x25519(priv, _BASE))


def _b64(b: bytes) -> str:
    return base64.b64encode(b).decode()


def _unb64(s: str) -> bytes:
    return base64.b64decode(str(s or "").encode())


# ------------------------------------------------------------------ sealing
def _hkdf(secret: bytes, info: bytes, n: int = 64) -> bytes:
    prk = hmac.new(b"listing-accelerator-team", secret, hashlib.sha256).digest()
    out, t, i = b"", b"", 1
    while len(out) < n:
        t = hmac.new(prk, t + info + bytes([i]), hashlib.sha256).digest()
        out += t
        i += 1
    return out[:n]


def _stream(key: bytes, nonce: bytes, data: bytes) -> bytes:
    out = bytearray(len(data))
    for i in range(0, len(data), 32):
        block = hashlib.sha256(key + nonce + i.to_bytes(8, "big")).digest()
        chunk = data[i:i + 32]
        out[i:i + len(chunk)] = bytes(a ^ b for a, b in zip(chunk, block))
    return bytes(out)


def seal(obj, to_public: str) -> bytes:
    """Lock any JSON-able thing so only the holder of to_public's key can open it."""
    raw = zlib.compress(json.dumps(obj, ensure_ascii=False).encode("utf-8"), 6)
    eph_priv = os.urandom(32)
    eph_pub = _x25519(eph_priv, _BASE)
    pub = _unb64(to_public)
    shared = _x25519(eph_priv, pub)
    keys = _hkdf(shared, eph_pub + pub)
    nonce = os.urandom(16)
    body = _stream(keys[:32], nonce, raw)
    tag = hmac.new(keys[32:], eph_pub + nonce + body, hashlib.sha256).digest()
    return b"LAT1" + eph_pub + nonce + tag + body


def unseal(blob: bytes, my_private: str):
    if not blob.startswith(b"LAT1") or len(blob) < 4 + 32 + 16 + 32:
        raise ValueError("Not a locked team file.")
    eph_pub, nonce, tag, body = blob[4:36], blob[36:52], blob[52:84], blob[84:]
    priv = _unb64(my_private)
    pub = _x25519(priv, _BASE)
    keys = _hkdf(_x25519(priv, eph_pub), eph_pub + pub)
    good = hmac.new(keys[32:], eph_pub + nonce + body, hashlib.sha256).digest()
    if not hmac.compare_digest(good, tag):
        raise ValueError("This file was changed or isn't for this computer.")
    return json.loads(zlib.decompress(_stream(keys[:32], nonce, body)).decode("utf-8"))


# ------------------------------------------------------------------ a key kept under a PIN
def lock_with_pin(secret: str, pin: str) -> dict:
    salt = os.urandom(16)
    k = hashlib.pbkdf2_hmac("sha256", str(pin).encode(), salt, 200_000, 64)
    data = secret.encode()
    nonce = os.urandom(16)
    body = _stream(k[:32], nonce, data)
    tag = hmac.new(k[32:], nonce + body, hashlib.sha256).digest()
    return {"salt": _b64(salt), "nonce": _b64(nonce), "body": _b64(body), "tag": _b64(tag)}


def open_with_pin(locked: dict, pin: str) -> str | None:
    try:
        salt, nonce = _unb64(locked["salt"]), _unb64(locked["nonce"])
        body, tag = _unb64(locked["body"]), _unb64(locked["tag"])
    except Exception:
        return None
    k = hashlib.pbkdf2_hmac("sha256", str(pin).encode(), salt, 200_000, 64)
    if not hmac.compare_digest(hmac.new(k[32:], nonce + body, hashlib.sha256).digest(), tag):
        return None
    return _stream(k[:32], nonce, body).decode()
