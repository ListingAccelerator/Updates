"""
quick_answers.py -- one-click answers to what Marketplace buyers ask most.

"Is it still available?", "What's your lowest?", "Do you finance?"... Each
answer is written the Automotive Sales Accelerator way (answer plainly, ask a
question, move to a day and time) and filled in with THAT car's facts: its
posted price, miles, the store's address, its web page, an estimated payment.
No AI, no internet: instant, and the same every time.

The words are his to change. Every answer is a template with blanks in
curly brackets ({price}, {miles}...); his own versions are kept in
"my answers.json" (program-wide) and win over the built-in ones.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

# key, label, English, Spanish
DEFAULTS = [
    ("available", "Still available?",
     "Yes{name_comma}, the {car} is still here! {highlight} Are you looking for yourself or for someone else?",
     "¡Sí{name_comma}, el {car} todavía está disponible! {highlight} ¿Lo busca para usted o para alguien más?"),
    ("price", "Lowest price?",
     "Great question{name_comma}. It's listed at {price}, and that's the same whether you're texting me or standing on the lot. "
     "To give you a straight out-the-door number I just need two things: are you trading anything in, and are you paying cash or financing? "
     "Then I'll have it pulled up front for you. Does later today or tomorrow work better?",
     "Buena pregunta{name_comma}. Está en {price}, y es el mismo precio por mensaje o aquí en el lote. "
     "Para darle un número final necesito dos cosas: ¿tiene un carro para cambiar, y va a pagar en efectivo o financiar? "
     "Así se lo tengo listo al frente. ¿Le queda mejor hoy más tarde o mañana?"),
    ("miles", "Miles?",
     "It has {miles} miles{name_comma}. {extras} Want to come drive it? I can have it ready later today or tomorrow.",
     "Tiene {miles} millas{name_comma}. {extras} ¿Quiere venir a manejarlo? Se lo tengo listo hoy más tarde o mañana."),
    ("finance", "Do you finance?",
     "Yes{name_comma}, we finance. We work with a lot of banks and credit unions, so we can usually find something that fits. "
     "Are you thinking about a certain monthly payment? If you come in we can get you a real answer in about 30 minutes. "
     "Does today or tomorrow work better?",
     "Sí{name_comma}, tenemos financiamiento. Trabajamos con muchos bancos y cooperativas de crédito. "
     "¿Tiene en mente un pago mensual? Si viene le damos una respuesta real en unos 30 minutos. ¿Le queda mejor hoy o mañana?"),
    ("credit", "Bad credit OK?",
     "We help people in every credit situation{name_comma}, and we work with lenders that look at more than just a score. "
     "I can't promise an approval over chat, but I'll get you an honest answer fast. "
     "Do you have a down payment or a trade to put toward it? When could you come in, today or tomorrow?",
     "Ayudamos a personas con todo tipo de crédito{name_comma}, y trabajamos con prestamistas que miran más que el puntaje. "
     "No puedo prometer una aprobación por mensaje, pero le doy una respuesta honesta rápido. "
     "¿Tiene un enganche o un carro para cambiar? ¿Cuándo podría venir, hoy o mañana?"),
    ("trade", "Trade?",
     "Yes{name_comma}, we take trades! I can't give you a fair number without seeing it, but bring it with you and we'll appraise it while you drive the {car_short}. "
     "What are you trading: year, make, model and about how many miles?",
     "¡Sí{name_comma}, aceptamos carros a cambio! No puedo darle un número justo sin verlo, pero tráigalo y lo evaluamos mientras maneja el {car_short}. "
     "¿Qué carro tiene: año, marca, modelo y más o menos cuántas millas?"),
    ("payment", "Payment?",
     "At {price}, with {down} down, it's about {payment}/mo for {term} months at {apr}% APR, with approved credit{name_comma}. "
     "Your rate depends on your credit, so the real number could be lower or higher. Want me to work up exact numbers when you come in today or tomorrow?",
     "En {price}, con {down} de enganche, son aproximadamente {payment} al mes por {term} meses al {apr}% APR, con crédito aprobado{name_comma}. "
     "La tasa depende de su crédito. ¿Quiere que le prepare los números exactos cuando venga hoy o mañana?"),
    ("where", "Where are you?",
     "We're at {store}, {address}{name_comma}. I'll have the {car_short} pulled up front for you. What time works best, later today or tomorrow?",
     "Estamos en {store}, {address}{name_comma}. Le tengo el {car_short} listo al frente. ¿Qué hora le queda mejor, hoy más tarde o mañana?"),
    ("hours", "Hours / when?",
     "I'm here today and can have the {car_short} ready for you{name_comma}. What time works best for you, today or tomorrow?",
     "Estoy aquí hoy y le puedo tener el {car_short} listo{name_comma}. ¿Qué hora le queda mejor, hoy o mañana?"),
    ("pictures", "More pictures",
     "Here's every picture of it{name_comma}: {link} I can also send you a walkaround video. Want me to?",
     "Aquí están todas las fotos{name_comma}: {link} También le puedo mandar un video del carro. ¿Quiere?"),
    ("has", "Does it have…?",
     "{features_line} Is there anything specific you need it to have{name_comma}? Easiest way to see it all is in person. Today or tomorrow?",
     "{features_line} ¿Hay algo específico que necesite{name_comma}? Lo mejor es verlo en persona. ¿Hoy o mañana?"),
    ("history", "Carfax / history",
     "Absolutely{name_comma}, I'll send you the vehicle history report on the {car_short}. What's the best number or email to send it to?",
     "Claro{name_comma}, le mando el reporte de historial del {car_short}. ¿A qué número o correo se lo envío?"),
    ("sold", "Sold – offer another",
     "I'm sorry{name_comma}, the {car_short} has been sold. I do have over {lot_count} vehicles to choose from. "
     "If you could tell me exactly what you're looking for, I may have another one close to it. What are you looking for?",
     "Lo siento{name_comma}, el {car_short} ya se vendió. Tengo más de {lot_count} vehículos para escoger. "
     "Si me dice exactamente qué busca, puede que tenga otro parecido. ¿Qué está buscando?"),
    # Not a button: what goes after a fact ("It has 166,995 miles") when the car is sold.
    ("sold_tail", "(Sold) after the fact",
     "But it has been sold. I do have over {lot_count} vehicles to choose from. "
     "If you could tell me exactly what you're looking for, I may have another one close to what you're looking for?",
     "Pero ya se vendió. Tengo más de {lot_count} vehículos para escoger. "
     "Si me dice exactamente qué busca, puede que tenga otro parecido a lo que quiere."),
    ("carfax", "Send the CarFax",
     "Here's the free CARFAX report on the {car_short}{name_comma}: {carfax} Take a look, and let me know when you'd like to come see it. Today or tomorrow?",
     "Aquí está el reporte CARFAX gratis del {car_short}{name_comma}: {carfax} Échele un vistazo y dígame cuándo quiere venir a verlo. ¿Hoy o mañana?"),
]
# When the car is sold: the plain fact for each question, then {sold_tail}.
SOLD_FACTS = {
    "miles": ("It has {miles} miles{name_comma}.", "Tiene {miles} millas{name_comma}."),
    "price": ("It was listed at {price}{name_comma}.", "Estaba en {price}{name_comma}."),
    "has": ("{features_line}", "{features_line}"),
    "available": ("", ""),       # the Sold answer covers "is it still available?"
}
FIELDS = ["name", "name_comma", "car", "car_short", "price", "miles", "lot_count", "store", "address", "link", "payment",
          "down", "apr", "term", "stock", "carfax", "color", "highlight", "extras", "features", "features_line"]


def _file() -> Path:
    import config
    return Path(config.BASE) / "my answers.json"


def mine() -> dict:
    try:
        d = json.loads(_file().read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def templates() -> list[dict]:
    m = mine()
    out = []
    for key, label, en, es in DEFAULTS:
        own = m.get(key) or {}
        out.append({"key": key, "label": own.get("label") or label,
                    "en": own.get("en") or en, "es": own.get("es") or es,
                    "default_en": en, "default_es": es, "default_label": label,
                    "changed": bool(own.get("en") or own.get("es") or own.get("label"))})
    # answers he added himself
    for i, o in enumerate(m.get("_own") or []):
        if isinstance(o, dict) and (o.get("en") or o.get("es")) and o.get("label"):
            out.append({"key": f"own{i + 1}", "label": o["label"], "en": o.get("en") or o.get("es"),
                        "es": o.get("es") or o.get("en"), "default_en": "", "default_es": "",
                        "default_label": "", "changed": True, "own": True})
    return out


def save(items: list[dict]) -> dict:
    """His words for each answer. Empty or unchanged = the built-in one."""
    d = {}
    base = {k: (label, en, es) for k, label, en, es in DEFAULTS}
    for it in items or []:
        k = str(it.get("key") or "")
        if k.startswith("own") or k == "new":
            label = str(it.get("label") or "").strip()[:60]
            en, es = str(it.get("en") or "").strip()[:1500], str(it.get("es") or "").strip()[:1500]
            if label and (en or es) and not it.get("remove"):
                d.setdefault("_own", []).append({"label": label, "en": en, "es": es})
            continue
        if k not in base:
            continue
        label, en, es = base[k]
        own = {}
        for f, dflt in (("label", label), ("en", en), ("es", es)):
            v = str(it.get(f) or "").strip()
            if v and v != dflt:
                own[f] = v[:1500]
        if own:
            d[k] = own
    _file().write_text(json.dumps(d, indent=1, ensure_ascii=False), encoding="utf-8")
    return {"ok": True, "message": "Your answers are saved."}


# ------------------------------------------------------------------ the car's facts
def _store(store_key: str) -> dict:
    import stores
    for s in stores.all_stores():
        if s["key"] == store_key:
            return s
    return {}


def _inventory(store_dir: Path) -> dict:
    try:
        recs = json.loads((store_dir / "out" / "inventory.json").read_text(encoding="utf-8"))
        return {str(r.get("stock") or "").upper(): r for r in recs if r.get("stock")}
    except Exception:
        return {}


def _gone(store_dir: Path) -> dict:
    """Cars that have left the website (sold) -- kept 90 days for answering buyers."""
    try:
        d = json.loads((store_dir / "out" / "sold cars.json").read_text(encoding="utf-8"))
        return {k.upper(): v.get("rec") or {} for k, v in d.items() if isinstance(v, dict)}
    except Exception:
        return {}


def _posted_row(store_dir: Path, st: str) -> dict | None:
    import csv
    try:
        with open(store_dir / "out" / "posted.csv", newline="", encoding="utf-8") as f:
            return next((r for r in csv.DictReader(f) if str(r.get("Stock") or "").upper() == st), None)
    except Exception:
        return None


def lot_count() -> str:
    """Every used car across his stores, rounded down: "1,000" from 1,048."""
    import stores
    seen = set()
    for s in stores.all_stores():
        seen |= set(_inventory(Path(s["dir"])))
    n = len(seen)
    if n >= 1000:
        n = n // 100 * 100
    elif n >= 100:
        n = n // 50 * 50
    elif n >= 20:
        n = n // 10 * 10
    return f"{n:,}"


def find_store(stock: str) -> str:
    import stores
    st = str(stock or "").strip().upper()
    for s in stores.all_stores():
        if st in _inventory(Path(s["dir"])):
            return s["key"]
    for s in stores.all_stores():          # sold: off the website, but he posted it
        d = Path(s["dir"])
        if st in _gone(d) or _posted_row(d, st):
            return s["key"]
    return ""


def listed_price(rec: dict, posted_row: dict | None) -> int:
    """What the buyer sees: the price it was posted at on Marketplace, or the
    price it was dropped to; for a car not posted, the website's price."""
    import track
    r = posted_row or {}
    for k in ("Dropped_Price", "Posted_Price"):
        try:
            v = int(float(str(r.get(k) or "").replace("$", "").replace(",", "")))
            if v:
                return v
        except ValueError:
            pass
    # not on Marketplace yet: what the dealer's website shows
    return track.price_of(rec) or track.post_price(rec) or 0


def facts(store_key: str, stock: str, name: str = "") -> dict | None:
    import csv
    import finder
    st = str(stock or "").strip().upper()
    store_key = store_key or find_store(st)
    s = _store(store_key)
    if not s:
        return None
    d = Path(s["dir"])
    rec = _inventory(d).get(st)
    sold = False
    if not rec:
        rec = _gone(d).get(st)
        if not rec:
            pr = _posted_row(d, st)
            if not pr:
                return None
            rec = {"stock": st, "title": pr.get("Vehicle") or ""}
            y = re.match(r"((?:19|20)\d{2})\s+(\S+)\s+(.*)", str(pr.get("Vehicle") or ""))
            if y:
                rec.update(year=y.group(1), make=y.group(2), model=y.group(3))
        sold = True
    row = None
    try:
        with open(d / "out" / "posted.csv", newline="", encoding="utf-8") as f:
            row = next((r for r in csv.DictReader(f) if str(r.get("Stock") or "").upper() == st), None)
    except Exception:
        pass
    price = listed_price(rec, row)
    m = finder.settings()
    pay = finder.payment(price, m) if price else None
    try:            # payment quotes in the chat follow the manager's Deal desk switch
        import customers
        if not customers.desk()["on"]:
            pay = None
    except Exception:
        pass
    stg = s.get("settings") or {}
    addr = ", ".join(x for x in (stg.get("address"), stg.get("city"),
                                 " ".join(y for y in (stg.get("state"), stg.get("zip")) if y)) if x)
    car = " ".join(str(rec.get(k) or "") for k in ("year", "make", "model", "trim")).strip()
    text, _full = finder._car_text(rec)
    feats = [label for k, label, rx in finder.OPTIONS if k not in ("hybrid", "diesel", "v8") and re.search(rx, text, re.I)]
    drive = str(rec.get("drivetrain") or "").strip()
    hi = []
    if drive and re.search(r"awd|4wd|4x4|all", drive, re.I):
        hi.append("4WD/AWD" if "/" in drive else drive)
    hi += [f for f in feats if f not in ("4WD / AWD", "Bluetooth", "Backup camera")][:2]
    miles = int(rec.get("mileage") or 0)
    first = str(name or "").strip().split(" ")[0] if name else ""
    features = ", ".join(feats[:6])
    return {
        "store_key": store_key, "stock": rec.get("stock"), "sold": sold, "lot_count": lot_count(),
        "name": first, "name_comma": f", {first}" if first else "",
        "car": car, "car_short": " ".join(str(rec.get(k) or "") for k in ("make", "model")).strip() or car,
        "price": f"${price:,}" if price else "the price on the listing",
        "miles": f"{miles:,}" if miles else "low",
        "store": s.get("name") or "", "address": addr or "the dealership",
        "link": str(rec.get("detail_url") or "").strip(),
        "carfax": str(rec.get("carfax_url") or "").strip(),
        "payment": f"${pay:,}" if pay else "", "down": f"${m['down']:,}", "apr": f"{m['apr']:g}", "term": str(m["term"]),
        "color": finder._color(rec),
        "highlight": (("It's got " + ", ".join(hi) + " and only " + f"{miles:,} miles.") if hi and miles
                      else (f"Only {miles:,} miles on it." if miles else "")),
        "extras": ("It's got " + (", ".join(hi[:-1]) + " and " + hi[-1] if len(hi) > 1 else hi[0]) + ".") if hi else "",
        "features": features,
        "features_line": (f"Here's what it has: {features}." if features else
                          "Let me walk out and check that for you right now."),
    }


def _fill(tpl: str, f: dict) -> str:
    out = re.sub(r"\{(\w+)\}", lambda m: str(f.get(m.group(1), m.group(0))), tpl)
    out = re.sub(r"[ \t]+([,.!?])", r"\1", out)
    return re.sub(r"\s{2,}", " ", out).strip()


def answers(store_key: str, stock: str, name: str = "", lang: str = "en", sold: str = "") -> dict:
    f = facts(store_key, stock, name)
    if not f:
        return {"ok": False, "message": f"{stock} isn't on any of your stores' websites (as of the last update)."}
    es = lang == "es"
    if es:
        f = dict(f, features_line=(f"Esto es lo que tiene: {f['features']}." if f["features"]
                                   else "Déjeme ir a revisarlo ahora mismo."),
                 highlight=("" if not f["miles"] or f["miles"] == "low" else f"Solo tiene {f['miles']} millas."),
                 extras="")
    is_sold = bool(f.get("sold")) if sold in ("", None) else str(sold) in ("1", "true", "yes")
    tpls = templates()
    if is_sold:
        by = {t["key"]: t for t in tpls}
        tail = _fill(by["sold_tail"]["es" if es else "en"], f)
        out = [{"key": "sold", "label": by["sold"]["label"], "text": _fill(by["sold"]["es" if es else "en"], f)}]
        for k, (en_t, es_t) in SOLD_FACTS.items():
            if not (en_t or es_t) or k not in by:
                continue
            if k == "miles" and f["miles"] == "low":
                continue
            out.append({"key": k, "label": by[k]["label"], "text": _fill((es_t if es else en_t) + " " + tail, f)})
        out += [{"key": t["key"], "label": t["label"], "text": _fill(t["es"] if es else t["en"], f)}
                for t in tpls if t.get("own")]
        return {"ok": True, "car": f["car"], "stock": f["stock"], "store_key": f["store_key"],
                "price": f["price"], "sold": True, "sold_auto": bool(f.get("sold")), "answers": out}
    out = []
    for t in tpls:
        if t["key"] in ("sold", "sold_tail"):
            continue
        if t["key"] == "payment" and not f["payment"]:
            continue
        if t["key"] == "pictures" and not f["link"]:
            continue
        if t["key"] == "carfax" and not f.get("carfax"):
            continue
        out.append({"key": t["key"], "label": t["label"], "text": _fill(t["es"] if es else t["en"], f)})
    return {"ok": True, "car": f["car"], "stock": f["stock"], "store_key": f["store_key"],
            "price": f["price"], "sold": False, "answers": out}
