"""
xmas_music.py -- four free Christmas background tracks for the walkaround videos.

Composed here from scratch, like the other free music: no recordings, no samples.
The melodies are old public-domain carols (Jingle Bells, 1857; We Wish You a
Merry Christmas, traditional); the arrangements and sounds are made by the program,
so they are safe to sell with the program and to post anywhere.

    render_style("xmas_jingle_rock", 62.0)  ->  numpy array at 32000 Hz
"""
import numpy as np

SR = 32000
rng = np.random.default_rng(11)

def rng_reset():
    global rng
    rng = np.random.default_rng(11)

def hz(m): return 440 * 2 ** ((m - 69) / 12)

def pluck(freq, dur, bright=0.5, decay=0.996):
    n, p = int(SR * dur), max(2, int(SR / freq))
    buf = rng.uniform(-1, 1, p) * bright + (1 - bright) * np.sin(np.linspace(0, 2*np.pi, p, endpoint=False))
    o = np.empty(n); k = 0
    while k < n:
        m = min(p, n - k); o[k:k+m] = buf[:m]
        buf = decay * 0.5 * (buf + np.roll(buf, -1)); k += m
    return o

def bell(freq, dur, rate=3.0):
    t = np.arange(int(SR * dur)) / SR
    s = (0.60*np.sin(2*np.pi*freq*t) + 0.25*np.sin(2*np.pi*freq*2.0*t) + 0.12*np.sin(2*np.pi*freq*3.0*t)
         + 0.08*np.sin(2*np.pi*freq*4.2*t)) * np.exp(-t*rate)
    a = int(SR*0.004); s[:a] *= np.linspace(0, 1, a)
    return s

def pad(freq, dur):
    t = np.arange(int(SR * dur)) / SR
    s = np.sin(2*np.pi*freq*t) + 0.4*np.sin(2*np.pi*freq*2*t)
    env = np.minimum(1, t/0.25) * np.minimum(1, (dur-t)/0.35)
    return s*env

def sleigh(dur=0.16):
    t = np.arange(int(SR*dur))/SR
    nz = np.diff(np.concatenate([[0], rng.uniform(-1, 1, len(t))]))
    ring = sum(np.sin(2*np.pi*f*t) for f in (4100, 5200, 6300))/3
    return (nz*0.5 + ring*0.5) * np.exp(-t*28)

def kick():
    t = np.arange(int(SR*0.25))/SR
    return np.sin(2*np.pi*np.cumsum(110*np.exp(-t*18)+45)/SR) * np.exp(-t*12)

def snare():
    t = np.arange(int(SR*0.18))/SR
    return rng.uniform(-1, 1, len(t))*np.exp(-t*22) + 0.3*np.sin(2*np.pi*190*t)*np.exp(-t*25)

CH = {  # chord -> (bass midi, strum midis)
 "C": (36, [48, 52, 55, 60, 64]), "F": (41, [53, 57, 60, 65, 69]), "G": (31, [43, 47, 50, 55, 59]),
 "D": (38, [50, 54, 57, 62, 66]), "Em": (40, [52, 55, 59, 64]), "Am": (33, [45, 52, 57, 60, 64]),
 "G7": (31, [43, 47, 50, 53, 59]), "Bm": (35, [47, 54, 59, 62, 66]),
}

# melodies: (midi or None, beats). Octave 4/5. Chord per bar listed separately.
JB_A = [(64,1),(64,1),(64,2),(64,1),(64,1),(64,2),(64,1),(67,1),(60,1.5),(62,.5),(64,4),
        (65,1),(65,1),(65,1.5),(65,.5),(65,1),(64,1),(64,1),(64,.5),(64,.5),(64,1),(62,1),(62,1),(64,1),(62,2),(67,2)]
JB_B = [(64,1),(64,1),(64,2),(64,1),(64,1),(64,2),(64,1),(67,1),(60,1.5),(62,.5),(64,4),
        (65,1),(65,1),(65,1.5),(65,.5),(65,1),(64,1),(64,1),(64,.5),(64,.5),(67,1),(67,1),(65,1),(62,1),(60,4)]
JB_CH = ["C","C","C","C","F","F","C","G"] + ["C","C","C","C","F","F","G","C"]
JB = JB_A + JB_B

WW = [(62,1),
      (67,1),(67,.5),(69,.5),(67,.5),(66,.5),(64,1),(64,1),(64,1),(69,1),(69,.5),(71,.5),(69,.5),(67,.5),
      (66,1),(62,1),(62,1),(71,1),(71,.5),(72,.5),(71,.5),(69,.5),(67,1),(64,1),(62,.5),(62,.5),
      (64,1),(69,1),(66,1),(67,3)]
WW_CH = ["G","C","D","D","G","G","D","G"]   # one chord per bar after the 1-beat pickup

def render(melody, chords, bpm, beats_per_bar, style, pickup=0.0, loops=1):
    rng_reset()
    beat = 60/bpm
    total_beats = sum(d for _, d in melody)
    total = (total_beats*loops + 3) * beat + 2.5
    mix = np.zeros(int(SR*total))
    def add(sig, t, g):
        i = int(t*SR)
        if i >= len(mix): return
        j = min(len(mix), i+len(sig)); mix[i:j] += sig[:j-i]*g
    cache = {}
    for L in range(loops):
        off = L*total_beats
        # melody
        t = off
        for m, d in melody:
            if m is not None:
                if style == "country":
                    key = ("p", m, d)
                    if key not in cache: cache[key] = pluck(hz(m+12) if m < 60 else hz(m), min(2.0, d*beat+.5), .35, .997)
                    add(cache[key], t*beat, 0.22)
                    key = ("b", m, d)
                    if key not in cache: cache[key] = bell(hz(m+12), min(1.5, d*beat+.4), 4.0)
                    add(cache[key], t*beat, 0.09)
                else:
                    key = ("b", m, d)
                    if key not in cache: cache[key] = bell(hz(m+12) if m < 72 else hz(m), min(2.5, d*beat+.7), 2.6)
                    add(cache[key], t*beat, 0.30)
            t += d
        # accompaniment per bar
        nbars = int(np.ceil((total_beats - pickup)/beats_per_bar))
        for bi in range(nbars):
            ch = chords[bi % len(chords)]
            bass, notes = CH[ch]
            t0 = (off + pickup + bi*beats_per_bar)*beat
            if style == "country":
                for k, sb in enumerate([0, 1, 1.5, 2.5, 3, 3.5][:] if beats_per_bar == 4 else [0, 1, 2]):
                    seq = notes if k % 2 == 0 else notes[::-1][:4]
                    for j, m in enumerate(seq):
                        key = ("s", m, k % 2)
                        if key not in cache: cache[key] = pluck(hz(m), 1.1, .5 if k % 2 == 0 else .35, .9965)
                        add(cache[key], t0 + sb*beat + j*0.012, 0.10 if k % 2 == 0 else 0.06)
                for b in range(beats_per_bar):
                    tt = t0 + b*beat
                    bm = bass + (7 if b % 2 == 1 else 0)
                    tb = np.arange(int(SR*beat*.9))/SR
                    add(np.sin(2*np.pi*hz(bm)*tb)*np.exp(-tb*3), tt, 0.30)
                    add(kick() if b % 2 == 0 else snare(), tt, 0.55 if b % 2 == 0 else 0.22)
                    add(sleigh(), tt, 0.10); add(sleigh(), tt + .5*beat, 0.06)
            else:
                dur = beats_per_bar*beat
                for m in notes[:4]:
                    add(pad(hz(m), dur+.2), t0, 0.05)
                for b in range(beats_per_bar):
                    tt = t0 + b*beat
                    tb = np.arange(int(SR*beat*.8))/SR
                    add(np.sin(2*np.pi*hz(bass + (12 if b % 2 else 0))*tb)*np.exp(-tb*4), tt, 0.20)
                    add(sleigh(), tt, 0.12)
                    add(sleigh(0.1), tt + .5*beat, 0.07)
    mix = np.tanh(mix*1.2)
    mix /= np.abs(mix).max()*1.1
    return mix


# name -> (melody, chords, bpm, beats per bar, sound, pickup beats)
TRACKS = {
    "xmas_jingle_rock":  (JB, JB_CH, 124, 4, "country", 0.0),
    "xmas_jingle_bells": (JB, JB_CH, 112, 4, "bells", 0.0),
    "xmas_wish_waltz":   (WW, WW_CH, 138, 3, "country", 1.0),
    "xmas_wish_box":     (WW, WW_CH, 120, 3, "bells", 1.0),
}
LABELS = {
    "xmas_jingle_rock": "Christmas - Jingle Bells, country rock (free)",
    "xmas_jingle_bells": "Christmas - Jingle Bells, sleigh bells (free)",
    "xmas_wish_waltz": "Christmas - We Wish You a Merry Christmas, country waltz (free)",
    "xmas_wish_box": "Christmas - We Wish You a Merry Christmas, music box (free)",
}


def render_style(style: str, seconds: float = 62.0):
    mel, ch, bpm, bpb, snd, pick = TRACKS[style]
    beat = 60 / bpm
    once = sum(d for _, d in mel) * beat
    loops = max(1, int(np.ceil(seconds / once)))
    return render(mel, ch, bpm, bpb, snd, pick, loops)
