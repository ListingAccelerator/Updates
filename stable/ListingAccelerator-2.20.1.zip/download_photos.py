"""
download_photos.py -- pull each vehicle's website photos into its Photo Drop folder.

The scraper collects photo URLs; this fetches the actual image files and drops
them into D:\\Photo Drop\\<STOCK>\\ so every car has photos ready to attach,
without you shooting anything.

Your own photos are never touched. Downloaded files are named web_01.jpg,
web_02.jpg and so on, so anything you shot yourself keeps its own name and sits
alongside. Re-running skips files already on disk, so it is safe to run as often
as you like and cheap after the first time.

When the website's pictures for a car change -- most often the stock
pictures being replaced by real photos of the car -- the web_ files in that
folder are replaced with the new set. Only the web_ files; yours stay put.
Real photos are taken in preference to stock ones whenever the site has any.

Usage:
    python download_photos.py
    python download_photos.py --stock OW26451     # one vehicle
    python download_photos.py --max 8             # first 8 photos per vehicle
    python download_photos.py --only-empty        # skip folders that have photos
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

import config
import photo_watch


def photo_workers() -> int:
    """
    How many vehicles' photos to fetch at the same time.

    Downloading is nearly all waiting, so this is where the first day of a
    big store stops being an afternoon. Six at once is gentle -- a browser
    loading one gallery page opens about as many connections.
    """
    n = getattr(config, "PHOTO_WORKERS", 6)
    try:
        n = int(n)
    except (TypeError, ValueError):
        return 6
    return max(1, min(n, 16))

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")


def ext_for(url: str) -> str:
    tail = url.split("?")[0].rsplit(".", 1)
    if len(tail) == 2 and 2 <= len(tail[1]) <= 4:
        return "." + tail[1].lower()
    return ".jpg"


def is_image(data: bytes) -> bool:
    head = data[:16]
    return (head.startswith(b"\xff\xd8\xff")              # JPEG
            or head.startswith(b"\x89PNG")                  # PNG
            or head[:4] == b"GIF8"                          # GIF
            or (head[:4] == b"RIFF" and head[8:12] == b"WEBP")
            or head[4:8] == b"ftyp")                        # AVIF / HEIC


def fetch(url: str, dest: Path) -> int:
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=30) as r:
        data = r.read()
    if len(data) < 1024:            # a 1KB "image" is a placeholder or error
        raise ValueError(f"suspiciously small ({len(data)} bytes)")
    # Only keep it if it really is a picture. A web page saved as "01.jpg"
    # (Gary's Pinterest share link did exactly this) looks like a photo in
    # the folder and uploads as a broken image.
    if not is_image(data):
        raise ValueError("not a picture (the address returned a web page)")
    dest.write_bytes(data)
    return len(data)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--stock")
    ap.add_argument("--max", type=int, default=config.MAX_PHOTOS_PER_VEHICLE)
    ap.add_argument("--only-empty", action="store_true",
                    help="skip any folder that already has files in it")
    args = ap.parse_args()

    if not config.INVENTORY_JSON.exists():
        print(f"No inventory at {config.INVENTORY_JSON}")
        print("Run: python scrape_inventory.py")
        return 1

    records = json.loads(config.INVENTORY_JSON.read_text(encoding="utf-8"))
    records.sort(key=lambda r: r.get("stock", ""))
    if args.stock:
        records = [r for r in records if r.get("stock") == args.stock]
        if not records:
            print(f"No vehicle with stock {args.stock}")
            return 1
    else:
        # Photos are the slowest part of the whole program -- sixteen files
        # per car -- so they are only fetched for the cars he works. The rest
        # stay in the inventory list; they simply have no pictures waiting.
        import track
        # Another store's cars never get photos pulled -- he cannot sell them.
        elsewhere = [r for r in records if track.is_other_store(r)]
        if elsewhere:
            records = [r for r in records if not track.is_other_store(r)]
            print(f"Skipping {len(elsewhere)} vehicle(s) at another store.\n")
        f = track.focus()
        if track.focus_is_on(f):
            before = len(records)
            records = [r for r in records if track.in_focus(r, f)]
            left_out = before - len(records)
            if left_out:
                print(f"Only the {len(records)} vehicle(s) you work "
                      f"({track.focus_wording()}).")
                print(f"{left_out} other vehicle(s) skipped -- "
                      f"that is {left_out * args.max:,} photos not "
                      f"downloaded.\n")

    config.PHOTO_DROP.mkdir(parents=True, exist_ok=True)

    got = skipped = failed = 0
    refreshed: list[str] = []
    kept_full: list[str] = []
    stock_only: list[str] = []
    bytes_in = 0
    no_urls = []

    print(f"Photo Drop: {config.PHOTO_DROP}")
    print(f"{len(records)} vehicle(s), up to {args.max} photos each\n")

    # One car at a time, one photo at a time, is almost all waiting: the
    # computer sits idle while the image comes over the wire. Fetching a
    # handful at once turns two hours into twenty minutes at a big store.
    # Each worker takes a whole vehicle, so a car's photos stay in order and
    # the per-vehicle line still prints as one tidy result.
    lock = threading.Lock()
    counter = {"i": 0}

    def do_vehicle(rec):
        nonlocal got, skipped, failed, bytes_in
        stock = rec.get("stock")
        urls, only_stock = photo_watch.pick_for_download(rec.get("photos"),
                                                          args.max,
                                                          rec.get("vin"))
        if not stock:
            return
        if not urls:
            with lock:
                no_urls.append(stock)
            return

        folder = config.PHOTO_DROP / stock
        folder.mkdir(parents=True, exist_ok=True)

        if args.only_empty and any(folder.iterdir()):
            return

        # Has the website's set of pictures changed since we last filled
        # this folder? Then the old web_ files are the old pictures (very
        # often the stock ones) and have to make way for the new set.
        import hashlib
        sig = hashlib.sha1("\n".join(photo_watch._key(u) for u in urls)
                           .encode()).hexdigest()[:16]
        manifest = folder / ".web_photos.json"
        olds = sorted(folder.glob("web_*"))
        stale = False
        try:
            stale = json.loads(manifest.read_text(encoding="utf-8")) \
                .get("sig") != sig
        except Exception:
            # Filled before this check existed. Same number of pictures as
            # the site has now: assume they are the same ones. Otherwise
            # they are an older set.
            stale = bool(olds) and len(olds) != len(urls)
        # A full set dropping to one or two pictures overnight is almost
        # never the website -- it is a page that didn't load. Wiping the
        # folder then threw away a good set of photos (OW26415, Oct 21).
        # Keep what is there; a real change will come with a full set.
        if stale and len(olds) >= 5 and len(urls) <= 2:
            with lock:
                kept_full.append(stock)
            return
        if stale and olds:
            for f in olds:
                try:
                    f.unlink()
                except OSError:
                    pass          # open in a viewer -- it will be overwritten
            with lock:
                refreshed.append(stock)
        if only_stock:
            with lock:
                stock_only.append(stock)

        new = have = bad = 0
        took = 0
        for n, url in enumerate(urls, 1):
            dest = folder / f"web_{n:02d}{ext_for(url)}"
            if not stale and dest.exists() and dest.stat().st_size > 1024:
                have += 1
                continue
            try:
                took += fetch(url, dest)
                new += 1
                time.sleep(0.05)        # still a pause between each one
            except (urllib.error.URLError, urllib.error.HTTPError,
                    ValueError, OSError):
                bad += 1
                if dest.exists():
                    dest.unlink(missing_ok=True)

        try:
            manifest.write_text(json.dumps({"sig": sig, "count": len(urls),
                                            "stock_only": only_stock}),
                                encoding="utf-8")
        except OSError:
            pass

        with lock:
            got += new
            skipped += have
            failed += bad
            bytes_in += took
            counter["i"] += 1
            flag = "  <-- some failed" if bad else ""
            if stock in refreshed:
                flag += "  (website photos changed -- replaced)"
            if only_stock:
                flag += "  (stock photos only so far)"
            print(f"  [{counter['i']}/{len(records)}] {stock:10s} "
                  f"{new} new, {have} already there{flag}")

    workers = photo_workers()
    if workers > 1 and len(records) > 1:
        print(f"  (fetching {workers} vehicles at a time)\n")
        with cf.ThreadPoolExecutor(max_workers=workers) as pool:
            list(pool.map(do_vehicle, records))
    else:
        for rec in records:
            do_vehicle(rec)

    print("\n=== Summary ===")
    print(f"downloaded : {got} photo(s), {bytes_in / 1_048_576:.0f} MB")
    print(f"already had: {skipped}")
    if failed:
        print(f"failed     : {failed}")
    if kept_full:
        print(f"kept the full photo set (the website only showed 1-2 this "
              f"time): {len(kept_full)} -> {', '.join(sorted(kept_full)[:12])}")
    if refreshed:
        print(f"new photos on the website, folder refreshed: "
              f"{len(refreshed)} -> {', '.join(sorted(refreshed)[:12])}")
    if stock_only:
        print(f"still stock photos only: {len(stock_only)} -> "
              f"{', '.join(sorted(stock_only)[:12])}")
    if no_urls:
        print(f"no photo URLs on {len(no_urls)} vehicle(s): "
              f"{', '.join(no_urls[:10])}")
        print("  (re-run scrape_inventory.py to collect them)")

    empties = [p.name for p in config.PHOTO_DROP.iterdir()
               if p.is_dir() and not any(p.iterdir())]
    if empties:
        print(f"\nstill empty: {len(empties)} folder(s) -> "
              f"{', '.join(sorted(empties)[:12])}")
    else:
        print("\nEvery Photo Drop folder has photos in it.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
