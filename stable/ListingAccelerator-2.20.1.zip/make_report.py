"""
make_report.py -- build the one-page morning report you print.

whats_new.py and track.py each print their own thing to the screen. This pulls
both together into a single sheet with the numbers at the top, so you can read
it standing at the printer instead of scrolling a console.

Writes out\\MORNING_REPORT.txt.

Usage:
    python make_report.py
"""
from __future__ import annotations

import csv
import io
import json
import sys
from contextlib import redirect_stdout
from datetime import date, datetime

import config

REPORT = config.OUT / "MORNING_REPORT.txt"


def capture(fn) -> str:
    """Run something that prints, and catch what it printed."""
    buf = io.StringIO()
    try:
        with redirect_stdout(buf):
            fn()
    except SystemExit:
        pass
    except Exception as e:  # a broken section shouldn't lose the whole report
        return f"  (section failed: {e})"
    return buf.getvalue().rstrip()


def main() -> int:
    records = []
    if config.INVENTORY_JSON.exists():
        records = json.loads(config.INVENTORY_JSON.read_text(encoding="utf-8"))

    priced = [r for r in records if r.get("final_price") or r.get("moses_price")]
    unpriced = len(records) - len(priced)

    photos_ready = 0
    if config.PHOTO_DROP.exists():
        for r in records:
            f = config.PHOTO_DROP / (r.get("stock") or "")
            if f.is_dir() and any(f.iterdir()):
                photos_ready += 1

    posted = 0
    ledger = config.OUT / "posted.csv"
    if ledger.exists():
        with open(ledger, newline="", encoding="utf-8") as f:
            posted = sum(1 for r in csv.DictReader(f)
                         if r.get("Status") != "down")

    stamp = datetime.now().strftime("%A, %B %d, %Y  %I:%M %p").replace(" 0", " ")

    L = [
        "=" * 64,
        f"  {config.STORE_FULL.upper()}".ljust(64),
        f"  MORNING REPORT - {stamp}",
        "=" * 64,
        "",
        f"  Vehicles on the lot .......... {len(records)}",
        f"  Priced and postable .......... {len(priced)}",
        f"  Waiting on a price ........... {unpriced}",
        f"  With photos ready ............ {photos_ready}",
        f"  Listings you have posted ..... {posted}",
        "",
    ]

    # --- what changed overnight -------------------------------------------
    # READ the briefing; do not re-run it.
    #
    # whats_new.py both writes the briefing and records what it has seen, so
    # running it a second time in the same morning always reports "no changes
    # since the last run" -- which is exactly what this report printed every
    # day while the real briefing sat unread in out\WHATS_NEW.txt. morning_run
    # and DAILY UPDATE already run it before they get here.
    brief = config.OUT / "WHATS_NEW.txt"
    if brief.exists():
        try:
            L += ["", brief.read_text(encoding="utf-8").rstrip(), ""]
        except OSError as e:
            L += [f"  (could not read {brief.name}: {e})", ""]
    else:
        # Nothing has written it yet -- generate it now, this once.
        try:
            import whats_new
            L += ["", capture(whats_new.main), ""]
        except Exception as e:
            L += [f"  (what's-new section unavailable: {e})", ""]

    # --- today's to-do ------------------------------------------------------
    try:
        import track
        L += ["", capture(track.cmd_todo), ""]
    except Exception as e:
        L += [f"  (to-do section unavailable: {e})", ""]

    L += [
        "=" * 64,
        r"  Ads:    out\jt_listings\<STOCK>.txt",
        f"  Photos: {config.PHOTO_DROP}\\<STOCK>\\",
        r"  No price yet: out\no_price_yet.csv",
        "=" * 64,
    ]

    text = "\n".join(L)
    config.OUT.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(text, encoding="utf-8")

    # The same sheet as a page the browser prints cleanly -- the window's
    # "Print report" button opens this one. Plain text in Notepad prints in
    # a tiny font with the lines wrapped wherever they fall.
    import html as _html
    page = (
        "<!doctype html><html><head><meta charset='utf-8'>"
        f"<title>{_html.escape(config.STORE_FULL)} - Morning Report</title>"
        "<style>"
        "body{font-family:Consolas,'Courier New',monospace;font-size:13px;"
        "margin:24px;color:#111;background:#fff}"
        "pre{white-space:pre-wrap;margin:0}"
        ".tip{font-family:Segoe UI,Arial,sans-serif;font-size:13px;"
        "color:#555;margin-bottom:14px}"
        "@media print{.tip{display:none}body{margin:0}}"
        "</style></head><body>"
        "<div class='tip'>Press Ctrl+P to print this report.</div>"
        f"<pre>{_html.escape(text)}</pre></body></html>")
    (config.OUT / "MORNING_REPORT.html").write_text(page, encoding="utf-8")
    print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
