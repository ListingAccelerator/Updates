"""
work_car.py -- "Add to my cars": make one car his, right now.

    python work_car.py STOCK          (LA_STORE_DIR picks the store)

For a car outside what he works -- the $24,000 RAV4 a customer wants at the
store where he only posts under $20,000. Without waiting for tomorrow's
update it:

  1. adds the stock number to the store's "extra cars.json", so every run
     from now on treats it as one of his (photos, ad, posting helper);
  2. gets its whole photo set: the site's numbered pictures (1.jpg, 2.jpg...)
     when it names them that way, otherwise from the car's own page;
  3. reads its paint and engine (scrape_details.py --stock);
  4. makes its photo folder and downloads the photos;
  5. writes the ads and the posting helper again, so it's in both.

Everything else on the lot is left exactly as it was.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import config
import track

HERE = Path(__file__).resolve().parent


def say(msg: str) -> None:
    print(msg, flush=True)


def _save_record(stock: str, rec: dict) -> None:
    recs = json.loads(config.INVENTORY_JSON.read_text(encoding="utf-8"))
    for i, r in enumerate(recs):
        if str(r.get("stock") or "").upper() == stock.upper():
            recs[i] = rec
    tmp = config.INVENTORY_JSON.with_name("inventory.work.tmp")
    tmp.write_text(json.dumps(recs, indent=1, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, config.INVENTORY_JSON)


def gallery(rec: dict) -> list[str]:
    """The car's whole photo set, the gentlest way first."""
    want = int(getattr(config, "MAX_PHOTOS_PER_VEHICLE", 20) or 20)
    have = list(rec.get("photos") or [])
    if len(have) >= want or rec.get("gallery_read"):
        return have
    import photo_fill
    first = photo_fill.first_numbered(have, rec.get("vin")) or (have[0] if have else "")
    try:
        nums = photo_fill.numbered(first, want) if first else []
    except Exception:
        nums = []
    if len(nums) > len(have):
        say(f"  {len(nums)} pictures found on the website.")
        return nums[:want]
    if not rec.get("detail_url"):
        return have
    say("  Opening the car's page for its pictures...")
    try:
        import scrape_inventory as si
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            b = p.chromium.launch(headless=True)
            page = b.new_page()
            page.goto(rec["detail_url"], timeout=config.PAGE_TIMEOUT_MS, wait_until="domcontentloaded")
            page.wait_for_timeout(config.DETAIL_DELAY_MS)
            si.scroll_through(page)
            shots = page.evaluate(si.GALLERY_JS)
            b.close()
        got = si.clean_photos(have + list(shots))[:want]
        say(f"  {len(got)} pictures found on its page.")
        return got if len(got) >= len(have) else have
    except Exception as e:
        say(f"  The car's page didn't give its pictures ({str(e).splitlines()[0][:80] if str(e) else 'error'}).")
        return have


def run(script: str) -> int:
    proc = subprocess.Popen([sys.executable, "-u"] + script.split(), cwd=str(HERE), env=os.environ.copy(),
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1,
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    for line in proc.stdout:
        line = line.rstrip()
        if line:
            print("    " + line, flush=True)
    return proc.wait()


def main() -> int:
    if len(sys.argv) < 2:
        say("Usage: work_car.py STOCK")
        return 2
    stock = sys.argv[1].strip().upper()
    if not config.INVENTORY_JSON.exists():
        say("This store hasn't been read yet. Run its update first.")
        return 1
    recs = json.loads(config.INVENTORY_JSON.read_text(encoding="utf-8"))
    rec = next((r for r in recs if str(r.get("stock") or "").upper() == stock), None)
    if not rec:
        say(f"{stock} isn't on {getattr(config, 'STORE_FULL', 'this store')}'s website any more (as of the last update).")
        return 1
    real = rec.get("stock")
    name = " ".join(str(rec.get(k) or "") for k in ("year", "make", "model", "trim")).strip()

    say(f"STEP 1/5 Adding {name} ({real}) to your cars")
    track.set_extra(real, True)

    say("STEP 2/5 Getting all its pictures")
    photos = gallery(rec)
    if photos and photos != rec.get("photos"):
        rec["photos"] = photos
        try:
            import photo_fill
            rec["gallery_checked"] = photo_fill.today() if len(photos) > 1 else ""
        except Exception:
            pass
        _save_record(real, rec)

    say("STEP 3/5 Reading its paint and engine")
    run(f"scrape_details.py --stock {real}")

    say("STEP 4/5 Downloading the photos")
    run("create_photo_drop_folders.py")
    run(f"download_photos.py --stock {real}")

    say("STEP 5/5 Writing the ad and the posting helper")
    run("build_jt_listings.py")
    run("build_listing_kit.py --personal")

    folder = Path(config.PHOTO_DROP) / real
    n = len([p for p in folder.iterdir() if p.is_file() and not p.name.startswith(".")
             and p.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp")]) if folder.is_dir() else 0
    say(f"DONE {real} {n}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
