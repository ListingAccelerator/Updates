"""
build_fb_catalog.py -- emit a Meta vehicles catalog feed from scraped inventory.

This is the dealer-grade path onto Facebook. You upload or host this file as a
catalog data feed in Meta Commerce Manager; Meta then renders the vehicles as
Automotive Inventory Ads, which serve in Marketplace and Feed placements. It is
the mechanism the inventory vendors (Dealer Specialties, HomeNet, Cars.com et
al) use on a dealer's behalf.

Two honest caveats:
  * Meta changes required fields periodically. Always run the generated file
    through Commerce Manager's feed validator and fix whatever it flags --
    treat its complaints as authoritative over this script.
  * Automotive Inventory Ads are ads. They need a Business Manager, a
    connected catalog and budget. A catalog feed is not a free posting robot,
    and nothing legitimate is.

Usage:
    python build_fb_catalog.py
"""
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

import config

# Meta body_style enum. Inferred from the nameplate -- a convenience, not
# gospel: spot-check these before you go live.
BODY_STYLE = {
    "SUV": {
        "Grand Cherokee", "Grand Cherokee L", "Cherokee", "Compass", "Renegade",
        "Wagoneer", "Grand Wagoneer", "Wrangler", "Wrangler 4xe", "Bronco",
        "Bronco Sport", "Explorer", "Explorer Hybrid", "Escape", "Escape Hybrid",
        "Expedition", "Expedition Max", "Edge", "Equinox", "Traverse", "Suburban",
        "Tahoe", "Blazer", "Trailblazer", "Trax", "Yukon", "Yukon XL", "Acadia",
        "Terrain", "Santa Fe", "Tucson", "Kona", "Venue", "Palisade", "4Runner",
        "Highlander", "RAV4", "RAV4 Hybrid", "Sequoia", "CR-V", "CR-V Hybrid",
        "HR-V", "Pilot", "Passport", "Outback", "Forester", "Crosstrek",
        "Ascent", "Rogue", "Rogue Sport", "Murano", "Pathfinder", "Armada",
        "Kicks", "CX-5", "CX-9", "CX-30", "CX-50", "CX-70", "CX-90",
        "Outlander", "Outlander Sport", "Eclipse Cross", "Sportage", "Sorento",
        "Telluride", "Seltos", "Soul", "Niro", "Tiguan", "Atlas",
        "Atlas Cross Sport", "Taos", "QX50", "QX55", "QX60", "QX80", "SQ5",
        "SQ5 Sportback", "Q3", "Q5", "Q5 Sportback", "Q7", "Q8", "Encore",
        "Encore GX", "Envision", "Enclave", "Escalade", "Escalade ESV", "XT4",
        "XT5", "XT6", "Navigator", "Navigator L", "Aviator", "Corsair",
        "Nautilus", "MDX", "RDX", "ZDX", "Durango", "Hornet", "Journey",
    },
    "TRUCK": {
        "F-150", "F-150 Lightning", "F-250", "F-350", "Super Duty", "Ranger",
        "Maverick", "Maverick Hybrid", "Silverado 1500", "Silverado 2500HD",
        "Silverado 3500HD", "Colorado", "Sierra 1500", "Sierra 2500HD",
        "Sierra 3500HD", "Canyon", "1500", "1500 Classic", "2500", "3500",
        "Tacoma", "Tundra", "Frontier", "Titan", "Ridgeline", "Gladiator",
        "Santa Cruz",
    },
    "VAN": {
        "Transit 150", "Transit 250", "Transit 350", "Transit Connect",
        "ProMaster", "ProMaster City", "ProMaster Cargo Van", "Savana",
    },
    "MINIVAN": {
        "Pacifica", "Pacifica Hybrid", "Voyager", "Odyssey", "Sienna",
        "Carnival", "Grand Caravan",
    },
    "COUPE": {"Corvette", "Camaro", "Challenger", "BRZ", "Q60"},
    "CONVERTIBLE": {"MX-5 Miata"},
    "SEDAN": {
        "Elantra", "Sonata", "Accent", "Camry", "Camry Hybrid", "Corolla",
        "Avalon", "Prius", "Civic", "Accord", "Accord Hybrid", "Insight",
        "Altima", "Sentra", "Versa", "Maxima", "Legacy", "Impreza", "WRX",
        "K5", "Forte", "Rio", "Stinger", "Jetta", "Passat", "Arteon",
        "Mazda3", "Mazda6", "Mirage G4", "Charger", "300", "A3", "A4", "A5",
        "A6", "A7", "Q50", "CT4", "CT5", "TLX", "ILX", "Integra", "ES", "IS",
        "ES 350", "IS 350", "Malibu", "Fusion",
    },
    "HATCHBACK": {"Mirage", "Golf GTI", "Bolt", "Bolt EUV", "LEAF", "Mustang"},
}

MODEL_TO_BODY = {m: style for style, models in BODY_STYLE.items() for m in models}

# Meta's CSV header for a vehicles catalog. Keep the exact spellings.
HEADERS = [
    "vehicle_id", "title", "description", "url",
    "make", "model", "year", "trim", "body_style",
    "mileage.value", "mileage.unit",
    "price", "state_of_vehicle", "condition", "availability",
    "vin", "stock_number",
    "exterior_color", "interior_color", "transmission", "fuel_type", "drivetrain",
    "dealer_id", "dealer_name", "dealer_phone",
    "address", "latitude", "longitude",
    "custom_label_0",
] + [f"image[{i}].url" for i in range(config.MAX_PHOTOS_PER_VEHICLE)]


def build_description(rec: dict) -> str:
    bits = []
    yr = rec.get("year", "")
    name = " ".join(x for x in (rec.get("make"), rec.get("model"), rec.get("trim")) if x)
    bits.append(f"{yr} {name}".strip() + f" at {config.DEALER_NAME}.")
    if rec.get("mileage"):
        bits.append(f"{rec['mileage']:,} miles.")
    if rec.get("vin"):
        bits.append(f"VIN {rec['vin']}.")
    feats = rec.get("features") or []
    if feats:
        bits.append("Features: " + ", ".join(feats[:10]) + ".")
    bits.append("Call or stop by for a test drive. "
                "Price excludes tax, title and fees unless stated.")
    return " ".join(bits)


def feed_price(rec: dict) -> str | None:
    field = {"final": "final_price", "moses": "moses_price",
             "retail": "retail_price"}[config.FEED_PRICE_FIELD]
    v = rec.get(field) or rec.get("final_price") or rec.get("moses_price")
    if not v:
        return None
    if config.FEED_PRICE_INCLUDES_DOC_FEE and rec.get("doc_fee"):
        v = v + rec["doc_fee"]
    return f"{v} {config.CURRENCY}"


def main() -> int:
    if not config.INVENTORY_JSON.exists():
        print(f"No scraped inventory at {config.INVENTORY_JSON}")
        print("Run: python scrape_inventory.py")
        return 1

    records = json.loads(config.INVENTORY_JSON.read_text(encoding="utf-8"))

    placeholders = [n for n, v in (
        ("DEALER_PHONE", config.DEALER_PHONE),
        ("DEALER_ADDR1", config.DEALER_ADDR1),
        ("DEALER_POSTAL", config.DEALER_POSTAL),
    ) if v == "FILL IN"]

    address = json.dumps({
        "addr1": config.DEALER_ADDR1,
        "city": config.DEALER_CITY,
        "region": config.DEALER_REGION,
        "postal_code": config.DEALER_POSTAL,
        "country": config.DEALER_COUNTRY,
    })

    rows, skipped = [], []
    for rec in records:
        price = feed_price(rec)
        photos = rec.get("photos") or []
        why = []
        if not price:
            why.append("no price")
        if not photos:
            why.append("no photo")
        if not rec.get("year") or not rec.get("make") or not rec.get("model"):
            why.append("incomplete ymm")
        if why:
            skipped.append((rec.get("stock", "?"), ", ".join(why)))
            continue

        title = f"{rec['year']} {rec['make']} {rec['model']}"
        if rec.get("trim"):
            title = f"{title} {rec['trim']}"

        row = {
            "vehicle_id": rec.get("stock") or rec.get("vin"),
            "title": title[:100],
            "description": build_description(rec)[:5000],
            "url": rec.get("detail_url", ""),
            "make": rec["make"],
            "model": rec["model"],
            "year": rec["year"],
            "trim": rec.get("trim", ""),
            "body_style": MODEL_TO_BODY.get(rec["model"], ""),
            "mileage.value": rec.get("mileage", ""),
            "mileage.unit": "MI",
            "price": price,
            "state_of_vehicle": "USED",
            "condition": "EXCELLENT" if (rec.get("mileage") or 0) < 40000 else "GOOD",
            "availability": "AVAILABLE",
            "vin": rec.get("vin", ""),
            "stock_number": rec.get("stock", ""),
            "exterior_color": rec.get("exterior_color", ""),
            "interior_color": rec.get("interior_color", ""),
            "transmission": rec.get("transmission", ""),
            "fuel_type": rec.get("fuel_type", ""),
            "drivetrain": rec.get("drivetrain", ""),
            "dealer_id": config.DEALER_ID,
            "dealer_name": config.DEALER_NAME,
            "dealer_phone": config.DEALER_PHONE,
            "address": address,
            "latitude": config.DEALER_LATITUDE,
            "longitude": config.DEALER_LONGITUDE,
            "custom_label_0": "price_drop" if rec.get("price_drop") else "",
        }
        for i in range(config.MAX_PHOTOS_PER_VEHICLE):
            row[f"image[{i}].url"] = photos[i] if i < len(photos) else ""
        rows.append(row)

    config.OUT.mkdir(parents=True, exist_ok=True)
    with open(config.FB_CATALOG_CSV, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=HEADERS, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)

    print(f"Wrote {config.FB_CATALOG_CSV}")
    print(f"  rows in feed : {len(rows)}")
    no_body = [r["stock_number"] for r in rows if not r["body_style"]]
    no_color = [r["stock_number"] for r in rows if not r["exterior_color"]]
    if no_body:
        print(f"  no body_style: {len(no_body)} -> {no_body[:10]}")
    if no_color:
        print(f"  no exterior_color: {len(no_color)} (recommended field; "
              f"the site shows colors as swatches, not text)")
    if skipped:
        print(f"\n  EXCLUDED {len(skipped)} vehicle(s) -- Meta rejects rows "
              f"missing a price or image:")
        for stock, why in skipped:
            print(f"    {stock:10s} {why}")
    if placeholders:
        print(f"\n  !! Still FILL IN in config.py: {', '.join(placeholders)}")
        print("     Do not upload this feed until those are real values.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
