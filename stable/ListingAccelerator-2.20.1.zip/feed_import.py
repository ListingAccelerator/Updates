"""
feed_import.py -- read a store's inventory from a feed or an export file
instead of its website.

Some stores' websites turn programs away (Akamai, DataDome, Cloudflare...).
The program doesn't get around that. But every dealership already sends its
inventory out every day -- to Facebook, Cars.com, CarGurus, Autotrader -- and
the store can send the same thing to its salesperson: a web link that always
has today's cars, or a file (CSV, Excel, XML or JSON) emailed or dropped in a
folder each morning.

    python feed_import.py <link or file>      try one and see what it reads

Column names differ from company to company (Dealer.com, vAuto, HomeNet,
DealerSocket, a Facebook catalog...), so each field is found by the names
those exports use.
"""
from __future__ import annotations

import csv
import io
import json
import re
import sys
import urllib.request
from pathlib import Path

import config

# what we call it -> the names exports use for it (compared without
# spaces, dashes, underscores, dots or case)
NAMES = {
    "stock": ["stock", "stocknumber", "stockno", "stocknum", "stock#", "stk", "stockid",
              "vehicleid", "id"],
    "vin": ["vin", "vinnumber", "vehiclevin"],
    "year": ["year", "modelyear", "vehicleyear"],
    "make": ["make", "brand", "vehiclemake"],
    "model": ["model", "vehiclemodel", "modelname"],
    "trim": ["trim", "series", "trimlevel", "style", "seriesdetail"],
    "mileage": ["mileage", "miles", "odometer", "mileagevalue", "odometerreading", "kilometers"],
    "price": ["internetprice", "sellingprice", "saleprice", "ourprice", "specialprice",
              "finalprice", "price", "askingprice", "listprice", "pricevalue", "amount"],
    "retail": ["msrp", "retailprice", "retail", "originalprice", "bookvalue", "stickerprice"],
    "doc_fee": ["docfee", "documentfee", "dealerfee", "processingfee", "dealerprocessingfee"],
    "exterior_color": ["exteriorcolor", "extcolor", "color", "exteriorcolour", "colour",
                       "genericexteriorcolor"],
    "interior_color": ["interiorcolor", "intcolor", "interiorcolour"],
    "engine": ["engine", "enginedescription", "enginedesc"],
    "transmission": ["transmission", "trans", "transmissiondescription"],
    "drivetrain": ["drivetrain", "drivetype", "drive", "drivetrainwheels"],
    "body_style": ["bodystyle", "body", "bodytype", "vehicletype"],
    "fuel_type": ["fueltype", "fuel"],
    "condition": ["condition", "newused", "type", "stateofvehicle", "inventorytype",
                  "vehiclecondition", "used"],
    "certified": ["certified", "cpo", "iscertified"],
    "photos": ["imagelist", "images", "photos", "photourls", "imageurls", "photourl",
               "imageurl", "image", "pictures", "pictureurls", "imagelinks", "media"],
    "features": ["options", "features", "equipment", "optionlist", "featurelist",
                 "factoryoptions", "highlights"],
    "description": ["description", "comments", "sellernotes", "dealercomments", "notes"],
    "detail_url": ["url", "vdpurl", "link", "detailurl", "vehicleurl", "permalink"],
    "mpg_city": ["citympg", "mpgcity", "epacity"],
    "mpg_hwy": ["highwaympg", "hwympg", "mpghighway", "mpghwy", "epahighway"],
    "date_in_stock": ["dateinstock", "instockdate", "datein", "receiveddate", "inventorydate"],
}


def _norm(k: str) -> str:
    return re.sub(r"[\s_\-./#()\[\]]", "", str(k or "")).lower()


def _money(v) -> int:
    if v in (None, ""):
        return 0
    if isinstance(v, (int, float)):
        return int(v)
    m = re.search(r"\d[\d,]*(?:\.\d+)?", str(v))
    if not m:
        return 0
    try:
        return int(float(m.group(0).replace(",", "")))
    except ValueError:
        return 0


def _split(v) -> list[str]:
    if isinstance(v, list):
        out = []
        for x in v:
            if isinstance(x, dict):
                x = x.get("url") or x.get("src") or x.get("href") or x.get("name") or ""
            out.append(str(x))
        return [x.strip() for x in out if str(x).strip()]
    s = str(v or "")
    parts = re.split(r"\s*[|;\n]\s*|,(?=\s*https?://)|\s+(?=https?://)", s) if "http" in s \
        else re.split(r"\s*[|;\n]\s*|\s*,\s*", s)
    return [p.strip() for p in parts if p.strip()]


def _flatten(d: dict, prefix: str = "") -> dict:
    """{"mileage": {"value": 5}} -> {"mileage.value": 5}; lists of pictures kept."""
    out = {}
    for k, v in d.items():
        key = f"{prefix}{k}"
        if isinstance(v, dict):
            out.update(_flatten(v, key + "."))
            out.setdefault(key, v)
        else:
            out[key] = v
    return out


def _pick(row: dict, field: str):
    """The value for one of our fields from a row with the export's own names."""
    want = NAMES[field]
    normed = {}
    for k, v in row.items():
        normed.setdefault(_norm(k), v)
    for w in want:
        v = normed.get(w)
        if v not in (None, "", []):
            return v
    # numbered photo columns: image1, image_2, photo url 3...
    if field == "photos":
        nums = []
        for k, v in row.items():
            m = re.fullmatch(r"(?:image|photo|picture|img)(?:url)?\[?(\d+)\]?(?:url)?", _norm(k))
            if m and v:
                nums.append((int(m.group(1)), v))
        if nums:
            return [v for _, v in sorted(nums)]
    return None


def _rows_from_xml(text: str) -> list[dict]:
    import xml.etree.ElementTree as ET
    root = ET.fromstring(text.encode("utf-8") if isinstance(text, str) else text)

    def strip(t):
        return t.split("}", 1)[-1]
    # the repeated element that holds a VIN or a stock number is a vehicle
    best = []
    for el in root.iter():
        kids = list(el)
        if not kids:
            continue
        names = {_norm(strip(k.tag)) for k in kids}
        if names & {"vin", "stock", "stocknumber", "stockno"}:
            best.append(el)
    rows = []
    for el in best:
        row = {}
        for k in el:
            tag = strip(k.tag)
            sub = list(k)
            if sub and all(len(list(s)) == 0 for s in sub):
                vals = [(s.text or "").strip() for s in sub if (s.text or "").strip()]
                if len(vals) > 1 or (sub and _norm(strip(sub[0].tag)) in ("url", "image", "photo", "option")):
                    row[tag] = vals
                    continue
            row[tag] = (k.text or "").strip()
        row.update({f"@{a}": b for a, b in el.attrib.items()})
        rows.append(row)
    return rows


def _rows_from_json(data) -> list[dict]:
    if isinstance(data, dict):
        for k in ("vehicles", "inventory", "listings", "items", "data", "results", "records"):
            if isinstance(data.get(k), list):
                data = data[k]
                break
        else:
            lists = [v for v in data.values() if isinstance(v, list) and v and isinstance(v[0], dict)]
            data = lists[0] if lists else []
    return [_flatten(x) for x in data if isinstance(x, dict)]


def _rows_from_csv(text: str) -> list[dict]:
    sample = text[:5000]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",\t|;")
    except csv.Error:
        dialect = csv.excel
    return list(csv.DictReader(io.StringIO(text), dialect=dialect))


def _rows_from_xlsx(raw: bytes) -> list[dict]:
    try:
        import openpyxl
    except Exception:
        raise RuntimeError("That's an Excel file. Save it as CSV in Excel (File > Save As > "
                           "CSV) and pick the CSV instead.")
    wb = openpyxl.load_workbook(io.BytesIO(raw), read_only=True, data_only=True)
    ws = wb.active
    it = ws.iter_rows(values_only=True)
    head = [str(h or "").strip() for h in next(it, [])]
    return [{head[i]: v for i, v in enumerate(r) if i < len(head)} for r in it]


def fetch(source: str) -> tuple[bytes, str]:
    """The raw feed: a web link, a file, or the newest file in a folder."""
    source = str(source or "").strip().strip('"')
    if not source:
        raise RuntimeError("No feed link or file set up for this store.")
    if re.match(r"https?://", source, re.I):
        req = urllib.request.Request(source, headers={"User-Agent": "ListingAccelerator feed reader"})
        with urllib.request.urlopen(req, timeout=90) as r:
            raw = r.read()
            ctype = r.headers.get("Content-Type", "")
        name = source.split("?")[0].lower()
        if raw[:200].lstrip().lower().startswith((b"<!doctype html", b"<html")):
            raise RuntimeError("That link opens a web page, not an inventory feed. Ask for the "
                               "feed or export link itself (it usually ends in .csv, .xml or .json).")
        return raw, name + " " + ctype
    p = Path(source).expanduser()
    if p.is_dir():
        files = [f for f in p.iterdir() if f.suffix.lower() in
                 (".csv", ".txt", ".tsv", ".xml", ".json", ".xlsx")]
        if not files:
            raise RuntimeError(f"No inventory file in {p} yet.")
        p = max(files, key=lambda f: f.stat().st_mtime)
    if not p.exists():
        raise RuntimeError(f"Can't find {p}.")
    return p.read_bytes(), p.name.lower()


def rows(source: str) -> list[dict]:
    raw, hint = fetch(source)
    if hint.split()[0].endswith(".xlsx") or raw[:2] == b"PK":
        return _rows_from_xlsx(raw)
    text = raw.decode("utf-8-sig", errors="replace")
    head = text.lstrip()[:1]
    if head == "<":
        return _rows_from_xml(text)
    if head in "[{":
        return _rows_from_json(json.loads(text))
    return _rows_from_csv(text)


def record(row: dict, doc_fee_add: int = 0) -> dict | None:
    """One export row as one of the program's vehicles."""
    stock = str(_pick(row, "stock") or "").strip()
    vin = str(_pick(row, "vin") or "").strip().upper()
    if not stock and vin:
        stock = vin[-8:]                    # some feeds carry only the VIN
    if not stock:
        return None
    rec: dict = {"stock": stock}
    if re.fullmatch(r"[A-HJ-NPR-Z0-9]{17}", vin):
        rec["vin"] = vin
    y = _money(_pick(row, "year"))
    if 1950 < y < 2100:
        rec["year"] = y
    for k in ("make", "model", "trim", "exterior_color", "interior_color", "engine",
              "transmission", "drivetrain", "body_style", "fuel_type", "detail_url"):
        v = _pick(row, k)
        if isinstance(v, (str, int, float)) and str(v).strip():
            rec[k] = str(v).strip()
    title = str(row.get("title") or row.get("Title") or "")
    if title and not rec.get("model"):
        bits = title.split()
        if len(bits) >= 3 and re.fullmatch(r"\d{4}", bits[0]):
            rec.setdefault("year", int(bits[0]))
            rec.setdefault("make", bits[1])
            rec["model"] = " ".join(bits[2:])
    mi = _money(_pick(row, "mileage"))
    if mi > 0:
        rec["mileage"] = mi
    price = _money(_pick(row, "price"))
    retail = _money(_pick(row, "retail"))
    fee = _money(_pick(row, "doc_fee")) or int(doc_fee_add or 0)
    if price and doc_fee_add:
        rec["price_before_fees"] = price
        price += int(doc_fee_add)
    if price:
        rec["final_price"] = price
    if retail:
        rec["retail_price"] = retail
        base = rec.get("price_before_fees") or price
        if base and retail > base:
            rec["savings"] = retail - base      # the website's "Savings" line
    if fee:
        rec["doc_fee"] = fee
    for k in ("mpg_city", "mpg_hwy"):
        n = _money(_pick(row, k))
        if 0 < n < 200:
            rec[k] = n
    cond = str(_pick(row, "condition") or "").lower()
    rec["condition"] = "new" if re.search(r"\bnew\b", cond) and "pre" not in cond else "used"
    cert = str(_pick(row, "certified") or "").lower()
    rec["certified"] = cert in ("1", "true", "yes", "y", "certified") or "certified" in cond
    photos = _pick(row, "photos")
    if photos:
        urls = [u for u in _split(photos) if re.match(r"https?://", u)]
        if urls:
            cap = int(getattr(config, "MAX_PHOTOS_PER_VEHICLE", 16) or 16)
            seen, keep = set(), []
            for u in urls:
                if u not in seen:
                    seen.add(u)
                    keep.append(u)
            rec["photos"] = keep[:cap]
    feats = _pick(row, "features")
    if feats:
        clean = [f for f in _split(feats) if 2 < len(f) < 60]
        if clean:
            rec["features"] = clean[:40]
    desc = _pick(row, "description")
    if isinstance(desc, str) and desc.strip():
        rec["description"] = desc.strip()[:4000]
        if re.search(r"\bone[- ]owner\b|\b1[- ]owner\b", desc, re.I):
            rec["one_owner"] = True
    d = str(_pick(row, "date_in_stock") or "")[:10]
    if d:
        rec["date_in_stock"] = d
    if re.search(r"4wd|awd|4x4|all.wheel|four.wheel", " ".join(
            str(rec.get(k, "")) for k in ("drivetrain", "trim", "model")), re.I):
        rec.setdefault("drivetrain", "4WD/AWD")
    return rec


def records(source: str | None = None, doc_fee_add: int | None = None) -> tuple[list[dict], dict]:
    """Every used vehicle in the feed, and a little report of what was read."""
    source = source if source is not None else getattr(config, "FEED_SOURCE", "")
    fee = doc_fee_add if doc_fee_add is not None else int(getattr(config, "FEED_ADD_FEE", 0) or 0)
    want = str(getattr(config, "FOCUS_CONDITION", "used") or "used").lower()
    out, new, bad = {}, 0, 0
    for row in rows(source):
        r = record(row, fee)
        if not r:
            bad += 1
            continue
        if r.get("condition") == "new" and want == "used":
            new += 1
            continue
        out[r["stock"]] = r
    recs = list(out.values())
    report = {"count": len(recs), "new_skipped": new, "unreadable": bad,
              "priced": sum(1 for r in recs if r.get("final_price")),
              "photos": sum(1 for r in recs if r.get("photos")),
              "sample": [f"{r.get('stock')} · {r.get('year', '')} {r.get('make', '')} "
                         f"{r.get('model', '')} {r.get('trim', '')} · "
                         f"{('$' + format(r['final_price'], ',')) if r.get('final_price') else 'no price'}"
                         f" · {len(r.get('photos') or [])} photos" for r in recs[:3]]}
    return recs, report


if __name__ == "__main__":
    recs, rep = records(sys.argv[1] if len(sys.argv) > 1 else None)
    print(json.dumps(rep, indent=1))
