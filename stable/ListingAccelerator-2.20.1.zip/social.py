"""
social.py -- ready-to-post pictures and captions for Facebook, Instagram,
TikTok and YouTube. All made on this computer, free.

Everything on a picture or in a caption comes from the car's own website
listing: the name, the price, the savings, the miles, the features. The car
is always its real photo. Nothing is posted for you -- the program makes the
files and the text; you post them.

Files go in the car's folder under "social" (Photo Drop\\STOCK\\social), and
store-wide pictures (today's deals, the "I've got it" ad, sold posts) in
out\\social.
"""
from __future__ import annotations

import json
import math
import re
from datetime import date
from pathlib import Path

import config

SIZES = {"square": (1080, 1080), "story": (1080, 1920), "wide": (1200, 630)}
NAVY = (11, 42, 85)
YELLOW = (255, 196, 64)
RED = (200, 30, 36)
WHITE = (255, 255, 255)
INK = (20, 32, 46)


# ------------------------------------------------------------ settings
DEFAULTS = {"headshot": "", "logo": "", "tags": "", "name": "", "cta": "",
            "page": "", "use_photo": "yes", "use_logo": "yes",
            # Posting for the store's own page instead of himself: no name,
            # no cell, no photo -- the store's phone and website instead.
            "post_as": "me", "store_phone": "", "store_web": "", "co_tags": "",
            "company_on": "no", "mp_tags": ""}


def _sfile() -> Path:
    return Path(config.STORE_DIR) / "social.json"


# You are the same person at every store: your photo and name are kept once
# for the whole program. Logo and hashtags belong to each store.
MINE = ("headshot", "name", "use_photo", "company_on")


def _mefile() -> Path:
    return Path(config.BASE) / "my profile.json"


def _read(p: Path) -> dict:
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def settings() -> dict:
    d = _read(_sfile())
    me = _read(_mefile())
    s = {**DEFAULTS, **{k: v for k, v in d.items() if k in DEFAULTS}}
    # a photo or name saved for one store before this: share it with them all
    moved = {k: d[k] for k in MINE if d.get(k) and not me.get(k)}
    if moved:
        me.update(moved)
        try:
            _mefile().write_text(json.dumps(me, indent=1), encoding="utf-8")
        except OSError:
            pass
    for k in MINE:
        if me.get(k):
            s[k] = me[k]
    if not s["name"]:
        s["name"] = config.SELLER_NAME or ""
    return s


def save_settings(d: dict) -> dict:
    s = settings()
    for k in DEFAULTS:
        if k in d:
            s[k] = str(d[k] or "").strip()
    try:
        _sfile().write_text(json.dumps({k: v for k, v in s.items() if k not in MINE}, indent=1),
                            encoding="utf-8")
        me = _read(_mefile())
        for k in MINE:
            if k in d:
                me[k] = s[k]
        _mefile().write_text(json.dumps(me, indent=1), encoding="utf-8")
    except OSError as e:
        return {"ok": False, "message": f"Couldn't save: {e}"}
    return {"ok": True, **s}


def mypage(s: dict | None = None) -> bool:
    """Posting for his own Facebook business page: still him -- his name,
    cell and photo -- but a page's daily plan instead of Marketplace's."""
    return (s or settings()).get("post_as") == "mypage"


def page_plan(s: dict | None = None) -> bool:
    s = s or settings()
    return company(s) or mypage(s)


def company(s: dict | None = None) -> bool:
    """Posting for the company page (the store speaks) rather than for himself."""
    s = s or settings()
    return s.get("company_on") == "yes" and s.get("post_as") == "company"


def store_web(s: dict | None = None) -> str:
    s = s or settings()
    w = (s.get("store_web") or "").strip()
    if not w:
        m = re.match(r"https?://(?:www\.)?([^/]+)", getattr(config, "INVENTORY_URL", "") or "")
        w = m.group(1) if m else ""
    return re.sub(r"^https?://(?:www\.)?", "", w).rstrip("/")


def contact_line(s: dict | None = None) -> str:
    """The 'how to reach us' line on the pictures."""
    s = s or settings()
    if company(s):
        ph = (s.get("store_phone") or "").strip()
        return f"Call {ph} or stop by today" if ph else (
            f"Visit {store_web(s)} or stop by today" if store_web(s) else "Stop by today")
    who = s["name"] or config.SELLER_NAME or ""
    return (f"Call or text {who + ' · ' if who else ''}{config.DEALER_PHONE}" if config.DEALER_PHONE
            else (s["cta"] or "Message me for details"))


# ------------------------------------------------------------ the facts
def _num(v):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return 0


def facts(rec: dict) -> dict:
    """Only what the website says, in the form the pictures and captions use."""
    import track
    price = track.post_price(rec)
    sale = track.price_of(rec)
    save = 0
    if track.has_markdown(rec):
        save = _num(rec.get("savings")) or (_num(rec.get("retail_price")) - sale)
    name = " ".join(str(rec.get(k) or "") for k in ("year", "make", "model", "trim")).split()
    name = " ".join(name)
    miles = _num(rec.get("mileage"))
    return {
        "stock": rec.get("stock", ""), "name": name,
        "year": str(rec.get("year") or ""), "make": str(rec.get("make") or ""),
        "model": str(rec.get("model") or ""), "trim": str(rec.get("trim") or ""),
        "price": sale or price, "save": save if save > 0 else 0,
        "retail": _num(rec.get("retail_price")),
        "miles": miles, "one_owner": bool(rec.get("one_owner")),
        "doc_fee": _num(rec.get("doc_fee")),
        "drive": str(rec.get("drivetrain") or ""), "color": str(rec.get("exterior_color") or ""),
        "body": str(rec.get("body_style") or ""), "fuel": str(rec.get("fuel_type") or ""),
        "mpg": _num(rec.get("mpg_hwy")),
    }


def money(n) -> str:
    return f"${int(n):,}" if n else ""


def price_note(f: dict) -> str:
    """The fine print: on stores whose price includes the doc fee, say so."""
    if f.get("doc_fee") and f.get("price"):
        return f"Price includes ${f['doc_fee']:,} doc fee. Tax, title and tags extra."
    return "Plus tax, title and tags."


def features(rec: dict, n: int = 5) -> list[str]:
    try:
        import walkaround
        skip = {str(rec.get("exterior_color") or "").lower(), "one owner",
                str(rec.get("drivetrain") or "").lower()}
        out = [c for c in walkaround.ai_choices(rec)
               if not re.search(r"\bmiles\b|^\$|\binterior\b", c, re.I)
               and c.lower() not in skip and " · " not in c]
        return out[:n]
    except Exception:
        return []


# ------------------------------------------------------------ hashtags
def _tag(s: str) -> str:
    s = re.sub(r"[^A-Za-z0-9 ]", "", str(s or ""))
    return "#" + "".join(w[:1].upper() + w[1:] for w in s.split()) if s.strip() else ""


def hashtags(f: dict, platform: str) -> list[str]:
    s = settings()
    src = ((s.get("co_tags") or s["tags"]) if company(s) else
           (s.get("mp_tags") or s["tags"]) if mypage(s) else s["tags"])
    mine = [t if t.startswith("#") else _tag(t)
            for t in re.split(r"[,\s]+", src) if t.strip()]
    city = getattr(config, "DEALER_CITY", "") or ""
    local = [_tag(city + " WV") if city else "", _tag(config.STORE_FULL)]
    car = [_tag(f["make"]), _tag(f["make"] + f["model"]), _tag(f["model"] + f["trim"]) if f["trim"] else ""]
    kind = []
    body = (f["body"] + " " + f["model"]).lower()
    if "truck" in body or "cab" in body:
        kind += ["#Trucks", "#TruckLife"]
    elif "suv" in body or "utility" in body:
        kind += ["#SUV"]
    if "4wd" in f["drive"].lower() or "awd" in f["drive"].lower() or "4x4" in f["trim"].lower():
        kind.append("#4x4")
    if "electric" in f["fuel"].lower() or "hybrid" in f["fuel"].lower():
        kind.append("#Hybrid")
    deal = ["#CarsForSale", "#UsedCars"] + (["#PriceDrop"] if f["save"] else [])
    want = {"facebook": 4, "instagram": 14, "tiktok": 5, "youtube": 3}.get(platform, 4)
    if platform == "tiktok":
        order = mine + car[:2] + ["#CarTok"] + (["#TruckTok"] if "#Trucks" in kind else []) + local[:1]
    elif platform == "youtube":
        order = ["#Shorts"] + car[1:2] + local[:1]
    elif platform == "facebook":
        order = mine + local[:1] + car[1:2] + local[2:3]
    else:
        order = mine + local + car + kind + deal
    out = []
    for t in order:
        if t and len(t) > 2 and t.lower() not in {x.lower() for x in out}:
            out.append(t)
    return out[:want]


# ------------------------------------------------------------ captions
def captions(rec: dict) -> dict:
    """One caption per platform, written from the listing alone."""
    f = facts(rec)
    s = settings()
    who = s["name"] or config.SELLER_NAME or ""
    phone = config.DEALER_PHONE or ""
    store = config.STORE_FULL or ""
    feats = features(rec, 5)
    price = money(f["price"])
    bits = []
    if f["miles"]:
        bits.append(f"{f['miles']:,} miles")
    if f["one_owner"]:
        bits.append("one owner")
    if f["drive"]:
        bits.append(f["drive"].replace("4WD/AWD", "4WD"))
    if f["color"]:
        bits.append(f["color"])
    facts_line = " · ".join(bits)
    save_line = f"Save {money(f['save'])} off retail. " if f["save"] else ""
    contact = f"Call or text {who + ' ' if who else ''}at {phone}." if phone else "Send me a message."
    dm = "DM me or "
    co = company(s)
    if co:
        ph = (s.get("store_phone") or "").strip()
        web = store_web(s)
        contact = (f"Call us at {ph} or stop by today!" if ph else "Message us or stop by today!") + \
                  (f"\n🌐 {web}" if web else "")
        dm = "DM us or "
    note = price_note(f)

    def tags(p):
        return " ".join(hashtags(f, p))
    fb = (f"🚗 {f['name']}\n💲 {price}{' · ' + save_line.strip() if save_line else ''}\n"
          f"{facts_line}\n\n" + ("✅ " + "\n✅ ".join(feats) + "\n\n" if feats else "") +
          f"{contact}\n{store}\n{note}\n\n{tags('facebook')}").strip()
    ig = (f"{f['name']} 🔥\n{price}{' — ' + save_line.strip() if save_line else ''}\n"
          f"{facts_line}\n" + ("\n".join("• " + x for x in feats) + "\n" if feats else "") +
          f"\n{dm}{contact[0].lower() + contact[1:]}\n📍 {store}\n{note}\n.\n.\n{tags('instagram')}").strip()
    hook = (f"This {f['year']} {f['make']} {f['model']} is {money(f['save'])} off retail 👀" if f["save"]
            else f"Check out this {f['year']} {f['make']} {f['model']} 👀")
    tt = (f"{hook}\n{price} · {facts_line}\n{contact}\n{tags('tiktok')}").strip()
    yt_title = (f"{f['name']} | {price} | {f['miles']:,} miles" if f["miles"] else f"{f['name']} | {price}")[:95]
    yt = (f"{yt_title}\n\n{f['name']} for {price} at {store}.\n{facts_line}\n" +
          ("\n".join("- " + x for x in feats) + "\n" if feats else "") +
          f"\n{contact}\n{note}\n\n{tags('youtube')}").strip()
    # Craigslist and OfferUp: plain words, no hashtags or emoji -- they look
    # like spam there. Craigslist wants a title of its own.
    plain_contact = re.sub(r"[^\x20-\x7E\n]", "", contact).replace("\n", " ").strip()
    cl_title = (f"{f['name']} - {price}" + (f" - {f['miles']:,} miles" if f["miles"] else ""))[:70]
    cl = (f"{f['name']}\n{price}" + (f" (save {money(f['save'])} off retail)" if f["save"] else "") +
          (f"\n{facts_line}" if facts_line else "") + "\n\n" +
          ("".join(f"- {x}\n" for x in feats) + "\n" if feats else "") +
          f"{plain_contact}\n{store}\n{note}").strip()
    ou = (f"{f['name']} - {price}" + (f" (save {money(f['save'])} off retail)" if f["save"] else "") +
          (f"\n{facts_line}" if facts_line else "") +
          ("\n" + ", ".join(feats[:4]) if feats else "") +
          f"\n\nAt {store}. {plain_contact}\n{note}").strip()
    return {"facebook": fb, "instagram": ig, "tiktok": tt, "youtube": yt,
            "youtube_title": yt_title, "craigslist": cl, "craigslist_title": cl_title,
            "offerup": ou}


AI_RULES = (
    "Rewrite this social media caption for a car salesperson so it sounds natural, upbeat "
    "and local, for the platform named. RULES: use ONLY the facts in the caption -- do not "
    "add features, history, condition, financing, warranties, or any number that is not "
    "already in it. Keep the price, savings, phone number and the fine-print line exactly "
    "as written. Keep the hashtags at the end exactly as they are. No ALL CAPS sentences. "
    "Return only the caption.")


def _numbers(t: str) -> set[str]:
    return {re.sub(r"[,$]", "", n) for n in re.findall(r"\$?\d[\d,]*", t)}


def ai_rewrite(text: str, platform: str) -> dict:
    """The AI he chose rewrites a caption. If it adds any number that
    wasn't in the original, its version is thrown away."""
    import ai_engine
    if not ai_engine.on():
        return {"ok": False, "message": "Turn on AI first (Integrations → AI settings)."}
    try:
        out = ai_engine.ask([f"{AI_RULES}\n\nPLATFORM: {platform}\n\nCAPTION:\n{text}"],
                            temperature=0.7).strip()
    except ai_engine.AIFail as e:
        return {"ok": False, "message": str(e)}
    extra = _numbers(out) - _numbers(text)
    if extra:
        return {"ok": False, "message": "The AI added something that isn't in the listing ("
                + ", ".join(sorted(extra))[:60] + "), so its version wasn't used. Try again."}
    return {"ok": True, "text": out}


# ------------------------------------------------------------ drawing helpers
FONT_DIRS = [Path("C:/Windows/Fonts"), Path("/usr/share/fonts/truetype/dejavu"),
             Path("/Library/Fonts"), Path("/System/Library/Fonts/Supplemental")]
FONTS = {
    "head": ["impact.ttf", "ariblk.ttf", "DejaVuSansCondensed-Bold.ttf"],
    "bold": ["segoeuib.ttf", "arialbd.ttf", "DejaVuSans-Bold.ttf"],
    "body": ["segoeui.ttf", "arial.ttf", "DejaVuSans.ttf"],
    "script": ["segoescb.ttf", "Inkfree.ttf", "segoepr.ttf", "DejaVuSerif-BoldItalic.ttf"],
}


def font(kind: str, size: int):
    from PIL import ImageFont
    for n in FONTS[kind]:
        for d in FONT_DIRS:
            if (d / n).exists():
                return ImageFont.truetype(str(d / n), size)
    return ImageFont.load_default()


def fit_font(draw, text, kind, width, start, least=18):
    size = start
    while size > least:
        f = font(kind, size)
        if draw.textlength(text, font=f) <= width:
            return f
        size -= 2
    return font(kind, least)


def cover(im, size, top_bias: float = 0.45):
    """Fill the frame, cropping the overflow (centered a little high)."""
    from PIL import Image
    w, h = size
    s = max(w / im.width, h / im.height)
    im = im.resize((max(1, int(im.width * s + 0.5)), max(1, int(im.height * s + 0.5))), Image.LANCZOS)
    left = (im.width - w) // 2
    top = int((im.height - h) * top_bias)
    return im.crop((left, top, left + w, top + h))


def contain(im, box):
    from PIL import Image
    w, h = box
    s = min(w / im.width, h / im.height)
    return im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))), Image.LANCZOS)


def shade(img, top=0.0, bottom=0.0, top_h=0.35, bottom_h=0.45):
    """Darken the top and bottom so the words read on any photo."""
    import numpy as np
    from PIL import Image
    a = np.asarray(img, np.float32)
    h = a.shape[0]
    y = np.arange(h)[:, None, None] / h
    k = np.zeros_like(y)
    if top:
        k = np.maximum(k, top * np.clip(1 - y / top_h, 0, 1) ** 1.5)
    if bottom:
        k = np.maximum(k, bottom * np.clip((y - (1 - bottom_h)) / bottom_h, 0, 1) ** 1.3)
    return Image.fromarray(np.clip(a * (1 - k), 0, 255).astype(np.uint8))


def text_fx(img, xy, text, f, fill=WHITE, stroke=8, stroke_fill=INK, shadow=8, angle=0,
            anchor="la"):
    """Bold poster lettering: thick outline and a drop shadow, optionally tilted."""
    from PIL import Image, ImageDraw, ImageFilter
    d0 = ImageDraw.Draw(img)
    l, t, r, b = d0.textbbox((0, 0), text, font=f, stroke_width=stroke)
    pad = stroke + shadow + 10
    tw, th = r - l + pad * 2, b - t + pad * 2
    layer = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
    sh = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
    ImageDraw.Draw(sh).text((pad - l + shadow, pad - t + shadow), text, font=f,
                            fill=(0, 0, 0, 150), stroke_width=stroke, stroke_fill=(0, 0, 0, 150))
    sh = sh.filter(ImageFilter.GaussianBlur(shadow / 2))
    layer = Image.alpha_composite(layer, sh)
    ImageDraw.Draw(layer).text((pad - l, pad - t), text, font=f, fill=fill,
                               stroke_width=stroke, stroke_fill=stroke_fill)
    if angle:
        layer = layer.rotate(angle, resample=Image.BICUBIC, expand=True)
    x, y = xy
    if anchor[0] == "m":
        x -= layer.width // 2
    elif anchor[0] == "r":
        x -= layer.width
    if anchor[1] == "m":
        y -= layer.height // 2
    elif anchor[1] in ("d", "s"):
        y -= layer.height - pad // 2
    img.paste(layer, (int(x), int(y)), layer)
    return layer.size


def badge(img, center, lines, angle=-6, fill=RED, color=YELLOW, size=150):
    """A tilted price tag: '$6,000' over 'OFF RETAIL'."""
    from PIL import Image, ImageDraw
    big = font("head", size)
    small = font("head", int(size * 0.42))
    d0 = ImageDraw.Draw(img)
    w = max(d0.textlength(lines[0], font=big), d0.textlength(lines[1], font=small)) + 70
    h = size * 1.05 + size * 0.5 + 40
    tag = Image.new("RGBA", (int(w), int(h)), (0, 0, 0, 0))
    d = ImageDraw.Draw(tag)
    d.rounded_rectangle([0, 0, w - 1, h - 1], radius=26, fill=fill + (255,), outline=WHITE + (255,), width=8)
    d.text((w / 2, 18), lines[0], font=big, fill=color, anchor="mt", stroke_width=3, stroke_fill=INK)
    d.text((w / 2, 18 + size * 1.08), lines[1], font=small, fill=WHITE, anchor="mt")
    tag = tag.rotate(angle, resample=Image.BICUBIC, expand=True)
    x0, y0 = int(center[0] - tag.width / 2), int(center[1] - tag.height / 2)
    img.paste(tag, (x0, y0), tag)
    return (x0, y0, x0 + tag.width, y0 + tag.height)


def chip(img, xy, text, f, fill=YELLOW, color=NAVY, pad=(26, 12), anchor="l"):
    from PIL import ImageDraw
    d = ImageDraw.Draw(img)
    tw = d.textlength(text, font=f)
    l, t, r, b = d.textbbox((0, 0), text, font=f)
    w, h = tw + pad[0] * 2, (b - t) + pad[1] * 2
    x, y = xy
    if anchor == "m":
        x -= w / 2
    elif anchor == "r":
        x -= w
    d.rounded_rectangle([x, y, x + w, y + h], radius=int(h / 2.6), fill=fill)
    d.text((x + pad[0], y + pad[1] - t), text, font=f, fill=color)
    return w, h


def circle(im, d, ring=WHITE, ring_w=10):
    from PIL import Image, ImageDraw
    # a headshot: keep the top of the head -- crop from the bottom instead
    im = cover(im.convert("RGB"), (d, d), top_bias=0.0)
    m = Image.new("L", (d, d), 0)
    ImageDraw.Draw(m).ellipse([0, 0, d - 1, d - 1], fill=255)
    out = Image.new("RGBA", (d + ring_w * 2, d + ring_w * 2), (0, 0, 0, 0))
    ImageDraw.Draw(out).ellipse([0, 0, d + ring_w * 2 - 1, d + ring_w * 2 - 1], fill=ring + (255,))
    out.paste(im, (ring_w, ring_w), m)
    return out


def person_cutout(path: str):
    """Your headshot with its background taken away (when the background
    tool is set up), so you stand in the picture. Your real photo -- not an
    AI version of you."""
    from PIL import Image, ImageOps
    src = Path(path)
    cache = src.with_name(src.stem + " (cut out).png")
    try:
        if cache.exists() and cache.stat().st_mtime >= src.stat().st_mtime:
            return Image.open(cache).convert("RGBA"), True
    except OSError:
        pass
    im = ImageOps.exif_transpose(Image.open(path)).convert("RGB")
    try:
        import backgrounds
        if backgrounds.ready():
            import numpy as np
            a = backgrounds._run_model(im)
            a = backgrounds._guided(np.asarray(im.convert("L"), np.float32) / 255, a, 9, 1e-3)
            a = np.clip((a - 0.1) / 0.8, 0, 1)
            if (a > 0.5).mean() > 0.05:
                out = im.convert("RGBA")
                out.putalpha(Image.fromarray((a * 255).astype(np.uint8)))
                bb = out.getbbox()
                out = out.crop(bb) if bb else out
                try:
                    out.save(cache, "PNG")      # once per photo -- the cut-out takes a few seconds
                except OSError:
                    pass
                return out, True
    except Exception:
        pass
    return im.convert("RGBA"), False


def head_room(path: str) -> str:
    """'' if the photo has room above the head; a warning if the head
    touches the top edge (it would look cut off on every ad)."""
    try:
        import backgrounds
        if not backgrounds.ready():
            return ""
        from PIL import Image, ImageOps
        import numpy as np
        im = ImageOps.exif_transpose(Image.open(path)).convert("RGB")
        a = backgrounds._run_model(im) > 0.5
        top = a[: max(2, a.shape[0] // 60)].mean()
        if top > 0.04:
            return ("The top of your head touches the top of this photo, so it will look cut off "
                    "on the ads. Use one with some room above your head.")
    except Exception:
        pass
    return ""


def plate(lg):
    """A logo on a soft white card, so a dark logo still reads on a dark photo."""
    from PIL import Image, ImageDraw
    pad = max(8, lg.height // 8)
    card = Image.new("RGBA", (lg.width + pad * 2, lg.height + pad * 2), (0, 0, 0, 0))
    ImageDraw.Draw(card).rounded_rectangle([0, 0, card.width - 1, card.height - 1],
                                           radius=pad, fill=(255, 255, 255, 225))
    card.alpha_composite(lg, (pad, pad))
    return card


def logo_img():
    from PIL import Image
    s = settings()
    if s.get("use_logo") == "no":
        return None              # kept, just not used right now
    p = s["logo"]
    if p and Path(p).exists():
        try:
            return Image.open(p).convert("RGBA")
        except Exception:
            return None
    return None


# ------------------------------------------------------------ the car's photo
def best_photo(stock: str, prefer_bg: bool = True) -> Path | None:
    folder = Path(config.PHOTO_DROP) / str(stock)
    if not folder.is_dir():
        return None
    if prefer_bg:
        bgs = sorted(folder.glob("bg_*.jpg"))
        if bgs:
            return bgs[0]
    webs = sorted(p for p in folder.glob("web_*") if p.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp"))
    if webs:
        return webs[0]
    pics = sorted(p for p in folder.iterdir() if p.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp")
                  and not p.name.startswith((".", "bg_")))
    return pics[0] if pics else None


def photos_of(stock: str, n: int = 6, prefer_bg: bool = True) -> list[Path]:
    folder = Path(config.PHOTO_DROP) / str(stock)
    if not folder.is_dir():
        return []
    import walkaround
    pics = walkaround.photos_for(folder)
    out = []
    for p in pics:
        b = folder / ("bg_" + (p.stem[4:] if p.stem.lower().startswith("web_") else p.stem) + ".jpg")
        out.append(b if prefer_bg and b.exists() else p)
    return out[:n]


# ------------------------------------------------------------ the styles
def season_word(today: date | None = None) -> tuple[str, str]:
    t = today or date.today()
    if t.month == 10:
        return "SCARY GOOD DEAL!", "fall"
    if t.month == 11:
        return "FALL INTO SAVINGS!", "fall"
    if t.month == 12:
        return "HOLIDAY DEAL!", "winter"
    if t.month in (1, 2):
        return "WINTER READY!", "winter"
    if t.month in (3, 4, 5):
        return "SPRING INTO SAVINGS!", "spring"
    return "SUMMER DEAL!", "summer"


STYLES = {
    "price": "Savings",
    "arrival": "Just arrived",
    "listed": "For sale",
    "season": "Seasonal",
    "weekend": "Weekend special",
}


def style_ok(style: str, f: dict) -> tuple[bool, str]:
    if style == "price" and not f["save"]:
        return False, "The website shows no savings on this car."
    if not f["price"]:
        return False, "This car has no price on the website yet."
    return True, ""


def _leaves(img, count=26, seed=3):
    """A few drawn fall leaves drifting at the edges (drawn here, nothing to license)."""
    import random
    from PIL import Image, ImageDraw
    rnd = random.Random(seed)
    w, h = img.size
    cols = [(214, 96, 32), (230, 140, 40), (196, 54, 34), (238, 178, 56), (170, 70, 30)]
    for _ in range(count):
        s = rnd.randint(int(w * 0.018), int(w * 0.04))
        leaf = Image.new("RGBA", (s * 2, s * 2), (0, 0, 0, 0))
        d = ImageDraw.Draw(leaf)
        c = rnd.choice(cols)
        pts = []
        for k in range(32):
            t = k / 32 * 2 * math.pi
            wob = 1 + 0.10 * math.sin(7 * t)            # a slightly ragged edge
            pts.append((s + s * 0.55 * math.sin(t) * wob, s - s * 0.92 * math.cos(t)))
        d.polygon(pts, fill=c + (235,))
        d.line([(s, s * 0.12), (s, s * 1.95)], fill=(120, 60, 25, 220), width=max(1, s // 10))
        leaf = leaf.rotate(rnd.randint(0, 360), resample=Image.BICUBIC, expand=True)
        edge = rnd.random()
        if edge < 0.45:
            x, y = rnd.randint(0, int(w * 0.16)), rnd.randint(0, h)
        elif edge < 0.9:
            x, y = rnd.randint(int(w * 0.84), w), rnd.randint(0, h)
        else:
            x, y = rnd.randint(0, w), rnd.randint(0, int(h * 0.08))
        img.paste(leaf, (x - leaf.width // 2, y - leaf.height // 2), leaf)


def _snow(img, count=160, seed=5):
    import random
    from PIL import ImageDraw
    rnd = random.Random(seed)
    d = ImageDraw.Draw(img, "RGBA")
    w, h = img.size
    for _ in range(count):
        r = rnd.randint(2, 7)
        x, y = rnd.randint(0, w), rnd.randint(0, int(h * 0.8))
        d.ellipse([x - r, y - r, x + r, y + r], fill=(255, 255, 255, rnd.randint(120, 230)))


def ad_picture(rec: dict, style: str, size: str = "square", me: bool = False,
               prefer_bg: bool = True, out: Path | None = None, main: str = "") -> Path:
    """One ad picture for one car."""
    from PIL import Image, ImageDraw
    f = facts(rec)
    ok, why = style_ok(style, f)
    if not ok:
        raise ValueError(why)
    src = best_photo(f["stock"], prefer_bg)
    if main:      # the photo he picked -- its background version when there is one
        folder = Path(config.PHOTO_DROP) / f["stock"]
        m = folder / Path(main).name
        b = folder / ("bg_" + (m.stem[4:] if m.stem.lower().startswith("web_") else m.stem) + ".jpg")
        src = b if prefer_bg and b.exists() else (m if m.exists() else src)
    if not src:
        raise ValueError("This car has no photos in its folder yet.")
    W, H = SIZES[size]
    s = settings()
    if company(s):
        me = False                      # the store's page: never his photo
    img = cover(Image.open(src).convert("RGB"), (W, H))
    img = shade(img, top=0.55, bottom=0.7, top_h=0.38 if size != "story" else 0.28,
                bottom_h=0.42 if size != "wide" else 0.5)
    img = img.convert("RGBA")
    d = ImageDraw.Draw(img)
    unit = min(W, H)
    head = {"price": "PRICE DROP!" if f["save"] else "GREAT PRICE!",
            "arrival": "JUST ARRIVED!", "listed": "MUST SEE!",
            "season": season_word()[0], "weekend": "WEEKEND SPECIAL!"}[style]
    if style == "season":
        sea = season_word()[1]
        if sea == "fall":
            _leaves(img)
        elif sea == "winter":
            _snow(img)
    hcol = {"price": (255, 255, 255), "season": (255, 140, 30) if season_word()[1] == "fall" else WHITE}.get(style, YELLOW)
    hf = fit_font(d, head, "head", W * (0.9 if size != "wide" else 0.62), int(unit * 0.16))
    top_y = int(H * (0.035 if size != "story" else 0.06))
    hx = W // 2 if size != "wide" else int(W * 0.04)
    text_fx(img, (hx, top_y), head, hf, fill=hcol, stroke=max(4, unit // 120), angle=2 if size != "wide" else 0,
            anchor="ma" if size != "wide" else "la")

    # the savings tag
    tag_box = None
    if f["save"] and style in ("price", "season", "weekend"):
        bx = W * (0.80 if size != "wide" else (0.60 if me else 0.86))
        by = H * (0.30 if size == "square" else 0.24 if size == "story" else 0.42)
        tag_box = badge(img, (bx, by), [money(f["save"]), "OFF RETAIL"],
                        size=int(unit * (0.085 if size != "wide" else 0.12)))

    lg = logo_img()
    person_top = None
    # the bottom: name, price, contact
    left = int(W * 0.05)
    width = int(W * (0.9 if not me else 0.58)) if size != "wide" else int(W * 0.58)
    yb = H - int(unit * 0.05)
    note_f = font("body", max(16, int(unit * 0.022)))
    note = price_note(f)
    d.text((left, yb), note, font=note_f, fill=(225, 230, 238), anchor="ls")
    yb -= int(unit * 0.045)
    who = s["name"] or config.SELLER_NAME or ""
    contact = contact_line(s)
    cf = fit_font(d, contact, "bold", width, int(unit * 0.042))
    d.text((left, yb), contact, font=cf, fill=WHITE, anchor="ls", stroke_width=2, stroke_fill=INK)
    yb -= int(unit * 0.075)
    pf = font("head", int(unit * 0.075))
    line = money(f["price"])
    extra = []
    if f["miles"]:
        extra.append(f"{f['miles']:,} miles")
    if f["one_owner"]:
        extra.append("1 owner")
    pw, ph = chip(img, (left, yb - int(unit * 0.075)), line, pf)
    room = width - pw - 20
    while extra and d.textlength(" · ".join(extra), font=font("bold", int(unit * 0.036))) > room:
        extra.pop()
    if extra:
        ef = font("bold", int(unit * 0.036))
        d.text((left + pw + 20, yb - int(unit * 0.075) + ph / 2), " · ".join(extra), font=ef,
               fill=WHITE, anchor="lm", stroke_width=2, stroke_fill=INK)
    yb -= int(unit * 0.075) + int(unit * 0.02)
    nf = fit_font(d, f["name"], "head", width, int(unit * 0.07))
    text_fx(img, (left, yb), f["name"], nf, fill=WHITE, stroke=max(3, unit // 200), shadow=6, anchor="ld")

    if me and s["headshot"] and Path(s["headshot"]).exists():
        p, cut = person_cutout(s["headshot"])
        if cut:
            ph_h = int(H * (0.44 if size == "square" else 0.32 if size == "story" else 0.78))
            pim = contain(p, (int(W * (0.34 if size != "wide" else 0.26)), ph_h))
            img.alpha_composite(pim, (W - pim.width - int(W * 0.01), H - pim.height))
            person_top = H - pim.height
        else:
            c = circle(p, int(unit * 0.26))
            img.alpha_composite(c, (W - c.width - int(W * 0.04), H - c.height - int(unit * 0.13)))
            person_top = H - c.height - int(unit * 0.13)
        tf = font("script", int(unit * 0.04))
        if who:
            d.text((W - int(W * 0.04), H - int(unit * 0.012)), f"– {who}", font=tf, fill=YELLOW,
                   anchor="rs", stroke_width=2, stroke_fill=INK)

    # the store's logo: right under the price tag (or where the tag would
    # be), whole, and never under you
    if lg:
        bb = lg.getbbox()
        if bb:
            lg = lg.crop(bb)                  # no empty margins to throw the size off
        if size == "wide":
            lg = plate(contain(lg, (int(W * 0.22), int(unit * 0.13))))
            xy = (W - lg.width - 24, 20)
        else:
            lg = plate(contain(lg, (int(W * 0.26), int(unit * 0.12))))
            gap = int(unit * 0.02)
            if tag_box:
                cx, top = (tag_box[0] + tag_box[2]) / 2, tag_box[3] + gap
            else:
                cx, top = W * 0.80, H * (0.24 if size == "square" else 0.18)
            room = (person_top - gap) if person_top is not None else H - int(H * 0.03)
            if top + lg.height > room:       # tight: make it smaller rather than cover it
                lg = plate(contain(logo_img().crop(bb) if bb else logo_img(),
                                   (int(W * 0.26), max(40, int(room - top) - 24))))
            x = int(min(max(cx - lg.width / 2, W * 0.02), W - lg.width - W * 0.02))
            y = int(min(top, H - lg.height - H * 0.02))
            xy = (x, y)
        img.alpha_composite(lg, xy)

    out = out or (Path(config.PHOTO_DROP) / f["stock"] / "social" /
                  f"{f['stock']} {style} {size}{' company' if company(s) else ''}.jpg")
    out.parent.mkdir(parents=True, exist_ok=True)
    img.convert("RGB").save(out, "JPEG", quality=92)
    return out


def carousel(rec: dict, prefer_bg: bool = True, n: int = 6) -> list[Path]:
    """Instagram / Facebook carousel: a cover, the best photos with a caption
    each (from the listing), and a last slide with the price and how to reach you."""
    from PIL import Image, ImageDraw
    import walkaround
    f = facts(rec)
    folder = Path(config.PHOTO_DROP) / f["stock"] / "social" / ("carousel company" if company() else "carousel")
    folder.mkdir(parents=True, exist_ok=True)
    for old in folder.glob("*.jpg"):
        old.unlink(missing_ok=True)
    outs = [ad_picture(rec, "price" if f["save"] else "listed", "square", False, prefer_bg,
                       folder / "01 cover.jpg")]
    pics = photos_of(f["stock"], n + 1, prefer_bg)[1:n + 1]
    caps = walkaround.suggest(rec, len(pics) + 1)[1:]
    W = H = 1080
    for i, p in enumerate(pics):
        img = cover(Image.open(p).convert("RGB"), (W, H))
        cap = caps[i] if i < len(caps) else ""
        if cap:
            img = shade(img, bottom=0.65, bottom_h=0.3)
            d = ImageDraw.Draw(img)
            cf = fit_font(d, cap, "head", W * 0.9, 74)
            text_fx(img, (W // 2, H - 60), cap, cf, fill=WHITE, stroke=4, shadow=6, anchor="md")
        dst = folder / f"{i + 2:02d}.jpg"
        img.save(dst, "JPEG", quality=92)
        outs.append(dst)
    # last slide
    img = Image.new("RGB", (W, H), NAVY)
    d = ImageDraw.Draw(img)
    s = settings()
    who = s["name"] or config.SELLER_NAME or ""
    y = 150
    nf = fit_font(d, f["name"], "head", W * 0.88, 84)
    text_fx(img, (W // 2, y), f["name"], nf, fill=WHITE, stroke=3, shadow=4, anchor="ma")
    y += 150
    chip(img, (W // 2, y), money(f["price"]), font("head", 110), anchor="m")
    y += 190
    if f["save"]:
        d.text((W // 2, y), f"Save {money(f['save'])} off retail", font=font("bold", 48), fill=YELLOW, anchor="ma")
        y += 80
    for line in features(rec, 4):
        d.text((W // 2, y), "• " + line, font=fit_font(d, line, "body", W * 0.8, 38),
               fill=(220, 228, 240), anchor="ma")
        y += 56
    y = max(y + 40, 820)
    if company(s):
        ph = (s.get("store_phone") or "").strip()
        d.text((W // 2, y), "Call us or stop by" if ph else "Stop by today", font=font("bold", 46), fill=WHITE, anchor="ma")
        big = ph or store_web(s) or (config.STORE_FULL or "")
        d.text((W // 2, y + 60), big, font=fit_font(d, big, "head", W * 0.9, 76), fill=YELLOW, anchor="ma")
    elif config.DEALER_PHONE:
        d.text((W // 2, y), f"Call or text {who}".strip(), font=font("bold", 46), fill=WHITE, anchor="ma")
        d.text((W // 2, y + 60), config.DEALER_PHONE, font=font("head", 76), fill=YELLOW, anchor="ma")
    d.text((W // 2, H - 40), price_note(f), font=font("body", 24), fill=(190, 200, 215), anchor="ms")
    dst = folder / f"{len(outs) + 1:02d} contact.jpg"
    img.save(dst, "JPEG", quality=92)
    outs.append(dst)
    return outs


def _out_dir() -> Path:
    s = settings()
    p = Path(config.OUT) / "social" / ("company page" if company(s) else "my page" if mypage(s) else "")
    p.mkdir(parents=True, exist_ok=True)
    return p


def deals_picture(recs: list[dict], size: str = "square", count: int = 4,
                  prefer_bg: bool = True) -> Path:
    """Today's best savings, 4 cars in one picture -- from today's website prices."""
    from PIL import Image, ImageDraw
    cars = []
    for r in recs:
        f = facts(r)
        if f["save"] and f["price"] and best_photo(f["stock"], prefer_bg):
            cars.append((f["save"], r, f))
    cars.sort(key=lambda x: -x[0])
    cars = cars[:count]
    if not cars:
        raise ValueError("No cars with savings and photos today.")
    W, H = SIZES[size]
    img = Image.new("RGB", (W, H), NAVY)
    d = ImageDraw.Draw(img)
    head = "TODAY'S DEALS"
    hf = fit_font(d, head, "head", W * 0.86, int(min(W, H) * 0.12))
    text_fx(img, (W // 2, int(H * 0.025)), head, hf, fill=YELLOW, stroke=5, shadow=6, anchor="ma")
    sub = config.STORE_FULL or ""
    sf = fit_font(d, sub, "bold", W * 0.9, int(min(W, H) * 0.036)) if sub else None
    sub_y = int(H * 0.025) + int(hf.size * 1.12)
    if sub:
        d.text((W // 2, sub_y), sub, font=sf, fill=WHITE, anchor="ma")
    top = int(H * (0.2 if size != "story" else 0.14))
    if sub:   # the store's name must never sit under the pictures
        top = max(top, sub_y + int(sf.size * 1.25) + 12)
    bottom = H - int(H * (0.1 if size == "square" else 0.08 if size == "story" else 0.17))
    cols = 2 if size != "wide" else min(4, len(cars))
    rows = math.ceil(len(cars) / cols) if size != "story" else len(cars)
    if size == "story":
        cols = 1
    gap = 16
    cw = (W - gap * (cols + 1)) // cols
    ch = (bottom - top - gap * (rows - 1)) // rows
    for i, (_, r, f) in enumerate(cars):
        x = gap + (i % cols) * (cw + gap)
        y = top + (i // cols) * (ch + gap)
        tile = cover(Image.open(best_photo(f["stock"], prefer_bg)).convert("RGB"), (cw, ch))
        tile = shade(tile, bottom=0.8, bottom_h=0.55).convert("RGBA")
        td = ImageDraw.Draw(tile)
        u = min(cw, ch)
        nf = fit_font(td, f["name"], "bold", cw - 30, int(u * 0.1))
        td.text((15, ch - 15), f["name"], font=nf, fill=WHITE, anchor="ld")
        pf = font("head", int(u * 0.13))
        chip(tile, (15, ch - 30 - nf.size - int(u * 0.13) - 20), money(f["price"]), pf, pad=(16, 8))
        badge(tile, (cw - u * 0.2, u * 0.16), [money(f["save"]), "OFF RETAIL"], size=int(u * 0.08), angle=-5)
        mask = Image.new("L", (cw, ch), 0)
        ImageDraw.Draw(mask).rounded_rectangle([0, 0, cw - 1, ch - 1], radius=18, fill=255)
        img.paste(tile.convert("RGB"), (x, y), mask)
    s = settings()
    line = contact_line(s)
    cy = bottom + (H - 28 - bottom) // 2
    d.text((W // 2, cy), line, font=fit_font(d, line, "bold", W * 0.9, min(int(min(W, H) * 0.045), (H - 28 - bottom) - 14)),
           fill=WHITE, anchor="mm")
    d.text((W // 2, H - 14), "Savings off the website's retail price, as of " + date.today().strftime("%b %d") +
           ". " + price_note(cars[0][2]), font=font("body", 18), fill=(180, 192, 210), anchor="ms")
    out = _out_dir() / f"Todays deals {date.today().isoformat()} {size}.jpg"
    img.save(out, "JPEG", quality=92)
    return out


def brand_picture(recs: list[dict], size: str = "square", prefer_bg: bool = True) -> Path:
    """'Looking for your next vehicle? More than likely, I've got it!' --
    you, a row of real cars from today's lot, and the real count."""
    from PIL import Image, ImageDraw
    s = settings()
    co = company(s)
    if not co and not (s["headshot"] and Path(s["headshot"]).exists()):
        raise ValueError("Add your headshot first (Social → My photo).")
    W, H = SIZES[size]
    with_photos = [r for r in recs if best_photo(r.get("stock", ""), prefer_bg)]
    hero = with_photos[0] if with_photos else None
    if hero:
        bgimg = cover(Image.open(best_photo(hero["stock"], prefer_bg)).convert("RGB"), (W, H))
        from PIL import ImageFilter
        bgimg = bgimg.filter(ImageFilter.GaussianBlur(14))
        bgimg = shade(bgimg, top=0.55, bottom=0.75)
    else:
        bgimg = Image.new("RGB", (W, H), NAVY)
    img = bgimg.convert("RGBA")
    d = ImageDraw.Draw(img)
    u = min(W, H)
    l1 = "LOOKING FOR YOUR"
    l2 = "NEXT VEHICLE?"
    tx = int(W * 0.04)
    col = W * (0.56 if not co else 0.66)
    f1 = fit_font(d, l1, "head", col, int(u * 0.085))
    f2 = fit_font(d, l2, "head", col, int(u * 0.12))
    y = int(H * 0.04)
    text_fx(img, (tx, y), l1, f1, fill=WHITE, stroke=5, anchor="la")
    y += int(f1.size * 1.15)
    text_fx(img, (tx, y), l2, f2, fill=YELLOW, stroke=6, anchor="la")
    y += int(f2.size * 1.2)
    got = "More than likely, we've got it!" if co else "More than likely, I've got it!"
    f3 = fit_font(d, got, "script", col, int(u * 0.06))
    text_fx(img, (tx + 10, y), got, f3, fill=WHITE, stroke=3, shadow=5,
            angle=3, anchor="la")
    y += int(f3.size * 2.3)
    n = len(recs)
    drops = sum(1 for r in recs if facts(r)["save"])
    bullets = [f"Over {n - n % 10 if n >= 20 else n} vehicles on the lot today"]
    if drops:
        bullets.append(f"{drops} with savings off retail right now")
    bullets.append("Tell us what you're looking for -- we'll find it" if co
                   else "Tell me what you're looking for -- I'll find it")
    bf = min((fit_font(d, b, "bold", col - 40, int(u * 0.05)) for b in bullets), key=lambda x: x.size)
    for b in bullets:
        w_, h_ = chip(img, (tx, y), b, bf, fill=(255, 255, 255), color=NAVY, pad=(18, 10))
        y += h_ + 16
    # a row of real cars along the bottom
    row = [r for r in with_photos[:4]]
    if row and size != "wide":
        cw = (W - 16 * (len(row) + 1)) // len(row)
        ch = int(H * 0.2)
        yy = H - ch - int(H * 0.11)
        for i, r in enumerate(row):
            t = cover(Image.open(best_photo(r["stock"], prefer_bg)).convert("RGB"), (cw, ch))
            m = Image.new("L", (cw, ch), 0)
            ImageDraw.Draw(m).rounded_rectangle([0, 0, cw - 1, ch - 1], radius=16, fill=255)
            img.paste(t, (16 + i * (cw + 16), yy), m)
    p, cut = person_cutout(s["headshot"]) if not co else (None, False)
    if co:
        pass
    elif cut:
        pim = contain(p, (int(W * 0.40), int(H * (0.58 if size != "wide" else 0.95))))
        img.alpha_composite(pim, (W - pim.width - int(W * 0.01),
                                  (H - int(H * 0.33) - pim.height) if size != "wide" else H - pim.height))
    else:
        c = circle(p, int(u * 0.36))
        img.alpha_composite(c, (W - c.width - int(W * 0.05), int(H * 0.2)))
    lg = logo_img()
    if lg:
        lg = contain(lg, (int(W * 0.26), int(u * 0.12)))
        img.alpha_composite(lg, (W - lg.width - int(W * 0.03), int(H * 0.03)))
    line = contact_line(s)
    band_h = int(H * 0.09)
    d.rectangle([0, H - band_h, W, H], fill=NAVY + (255,))
    d.text((W // 2, H - band_h // 2), line, font=fit_font(d, line, "bold", W * 0.92, int(u * 0.045)),
           fill=WHITE, anchor="mm")
    out = _out_dir() / f"{'Weve' if co else 'Ive'} got it {size}.jpg"
    img.convert("RGB").save(out, "JPEG", quality=92)
    return out


def _pair(recs: list[dict], prefer_bg: bool = True, today: date | None = None) -> tuple[dict, dict]:
    """Two cars people would argue about: same kind of vehicle, close in price.
    A different pair every day."""
    import random
    cars = []
    for r in recs:
        f = facts(r)
        if f["price"] and best_photo(f["stock"], prefer_bg):
            cars.append((r, f))
    if len(cars) < 2:
        raise ValueError("Need at least two cars with photos and prices.")
    rnd = random.Random((today or date.today()).toordinal())
    rnd.shuffle(cars)

    def kind(f):
        b = (f["body"] + " " + f["model"]).lower()
        return ("truck" if "truck" in b or "cab" in b else "suv" if "suv" in b or "utility" in b
                else "car")
    a, fa = cars[0]
    best = None
    for r, f in cars[1:]:
        if f["stock"] == fa["stock"]:
            continue
        score = (kind(f) == kind(fa)) * 2 + (abs(f["price"] - fa["price"]) <= fa["price"] * 0.25)
        if best is None or score > best[0]:
            best = (score, r)
        if score == 3:
            break
    return a, best[1]


def this_or_that(recs: list[dict], size: str = "square", prefer_bg: bool = True) -> Path:
    """'This or that?' -- two cars from today's lot, comment A or B. Gets people talking."""
    from PIL import Image, ImageDraw
    a, b = _pair(recs, prefer_bg)
    W, H = SIZES[size]
    u = min(W, H)
    img = Image.new("RGB", (W, H), NAVY).convert("RGBA")
    d = ImageDraw.Draw(img)
    head = "THIS OR THAT?"
    hf = fit_font(d, head, "head", W * 0.8, int(u * 0.11))
    top = int(H * 0.025)
    text_fx(img, (W // 2, top), head, hf, fill=YELLOW, stroke=5, shadow=6, anchor="ma")
    foot_h = int(u * 0.12)
    y0 = top + int(hf.size * 1.25)
    gap = 14
    side = size == "wide"
    if side:
        cw, ch = (W - gap * 3) // 2, H - y0 - foot_h - gap
        boxes = [(gap, y0), (gap * 2 + cw, y0)]
    else:
        cw, ch = W - gap * 2, (H - y0 - foot_h - gap * 2) // 2
        boxes = [(gap, y0), (gap, y0 + ch + gap)]
    for (x, y), r, letter in zip(boxes, (a, b), ("A", "B")):
        f = facts(r)
        t = shade(cover(Image.open(best_photo(f["stock"], prefer_bg)).convert("RGB"), (cw, ch)),
                  bottom=0.8, bottom_h=0.45).convert("RGBA")
        td = ImageDraw.Draw(t)
        tu = min(cw, ch)
        r0 = int(tu * 0.13)
        td.ellipse([16, 16, 16 + 2 * r0, 16 + 2 * r0], fill=YELLOW + (255,), outline=WHITE, width=5)
        td.text((16 + r0, 16 + r0), letter, font=font("head", int(r0 * 1.3)), fill=NAVY, anchor="mm")
        nf = fit_font(td, f["name"], "bold", cw - 40, int(tu * 0.1))
        td.text((20, ch - 18), f["name"], font=nf, fill=WHITE, anchor="ld", stroke_width=2, stroke_fill=INK)
        chip(t, (20, ch - 30 - nf.size - int(tu * 0.12) - 14), money(f["price"]), font("head", int(tu * 0.12)), pad=(16, 8))
        m = Image.new("L", (cw, ch), 0)
        ImageDraw.Draw(m).rounded_rectangle([0, 0, cw - 1, ch - 1], radius=18, fill=255)
        img.paste(t.convert("RGB"), (x, y), m)
    lg = logo_img()
    if lg:
        bb = lg.getbbox()
        lg = plate(contain(lg.crop(bb) if bb else lg, (int(W * 0.2), int(u * 0.09))))
        img.alpha_composite(lg, (W - lg.width - 14, H - foot_h + (foot_h - lg.height) // 2 - 6))
    line = "COMMENT A OR B BELOW"
    d.text((int(W * 0.04), H - foot_h // 2 - 8), line, font=fit_font(d, line, "head", W * 0.6, int(u * 0.06)),
           fill=WHITE, anchor="lm")
    d.text((int(W * 0.04), H - 12), price_note(facts(a)), font=font("body", max(14, int(u * 0.018))),
           fill=(180, 192, 210), anchor="ls")
    out = _out_dir() / f"This or that {date.today().isoformat()} {size}.jpg"
    img.convert("RGB").save(out, "JPEG", quality=92)
    return out


def this_or_that_caption(recs: list[dict], prefer_bg: bool = True) -> str:
    a, b = _pair(recs, prefer_bg)
    fa, fb = facts(a), facts(b)
    s = settings()
    tags = " ".join(hashtags({"make": "", "model": "", "trim": "", "body": "", "drive": "",
                              "fuel": "", "save": 0}, "facebook"))
    ask = "Comment A or B below 👇" 
    end = contact_line(s) + "."
    return (f"This or that? 🤔\n\n🅰️ {fa['name']} · {money(fa['price'])}\n🅱️ {fb['name']} · {money(fb['price'])}\n\n"
            f"{ask}\n{end}\n{price_note(fa)}\n\n{tags} #ThisOrThat").strip()


def store_caption(kind: str, recs: list[dict]) -> str:
    """A caption for the store pictures (today's deals, we've/I've got it)."""
    s = settings()
    co = company(s)
    tags = " ".join(hashtags({"make": "", "model": "", "trim": "", "body": "", "drive": "",
                              "fuel": "", "save": 0}, "facebook"))
    end = contact_line(s) + "."
    if kind == "deals":
        cars = sorted(((facts(r)) for r in recs), key=lambda f: -f["save"])
        cars = [f for f in cars if f["save"]][:4]
        lines = "\n".join(f"🔥 {f['name']} · {money(f['price'])} · save {money(f['save'])}" for f in cars)
        return (f"Today's best deals at {config.STORE_FULL or 'our store'} 👇\n\n{lines}\n\n{end}\n"
                f"Savings off the website's retail price, as of {date.today().strftime('%b %d')}.\n\n{tags} #Deals").strip()
    if kind == "tot":
        return this_or_that_caption(recs)
    n = len(recs)
    who = "we've" if co else "I've"
    return (f"Looking for your next vehicle? More than likely, {who} got it! 🚗\n"
            f"Over {n - n % 10 if n >= 20 else n} vehicles on the lot today.\n\n{end}\n\n{tags}").strip()


def sold_picture(photo: str, first_name: str, rec: dict | None, vehicle: str = "",
                 size: str = "square") -> Path:
    """'Congratulations, Sarah!' -- only after the customer signed the photo release."""
    from PIL import Image, ImageDraw, ImageOps
    W, H = SIZES[size]
    im = ImageOps.exif_transpose(Image.open(photo)).convert("RGB")
    # people in the photo: keep their heads -- crop from the bottom first
    img = shade(cover(im, (W, H), top_bias=0.12), top=0.5, bottom=0.75, top_h=0.3).convert("RGBA")
    d = ImageDraw.Draw(img)
    u = min(W, H)
    name = re.sub(r"[^A-Za-z' -]", "", first_name or "").strip().title()
    head = f"CONGRATULATIONS{', ' + name.upper() if name else ''}!"
    hf = fit_font(d, head, "head", W * 0.92, int(u * 0.1))
    text_fx(img, (W // 2, int(H * 0.04)), head, hf, fill=YELLOW, stroke=5, anchor="ma")
    car = vehicle or (facts(rec)["name"] if rec else "")
    if car:
        sub = f"on your {car}!"
        text_fx(img, (W // 2, int(H * 0.04) + int(hf.size * 1.3)), sub,
                fit_font(d, sub, "script", W * 0.9, int(u * 0.06)), fill=WHITE, stroke=3, shadow=4, anchor="ma")
    s = settings()
    who = s["name"] or config.SELLER_NAME or ""
    line1 = f"Thank you for choosing {config.STORE_FULL}" if config.STORE_FULL else "Thank you!"
    d.text((W // 2, H - int(u * 0.11)), line1, font=fit_font(d, line1, "bold", W * 0.92, int(u * 0.042)),
           fill=WHITE, anchor="mm", stroke_width=2, stroke_fill=INK)
    if company(s):
        ph = (s.get("store_phone") or "").strip()
        if ph:
            d.text((W // 2, H - int(u * 0.05)), ph, font=font("bold", int(u * 0.045)),
                   fill=YELLOW, anchor="mm", stroke_width=2, stroke_fill=INK)
    elif who:
        line2 = f"– {who}" + (f" · {config.DEALER_PHONE}" if config.DEALER_PHONE else "")
        d.text((W // 2, H - int(u * 0.05)), line2, font=fit_font(d, line2, "script", W * 0.9, int(u * 0.045)),
               fill=YELLOW, anchor="mm", stroke_width=2, stroke_fill=INK)
    lg = logo_img()
    if lg:
        lg = contain(lg, (int(W * 0.22), int(u * 0.1)))
        img.alpha_composite(lg, (W - lg.width - 24, int(H * 0.22)))
    stamp = date.today().isoformat()
    out = _out_dir() / f"Sold {name or 'customer'} {stamp} {size}.jpg"
    img.convert("RGB").save(out, "JPEG", quality=92)
    return out


def sold_caption(first_name: str, vehicle: str) -> str:
    s = settings()
    who = s["name"] or config.SELLER_NAME or ""
    name = (first_name or "").strip().title()
    tags = " ".join(hashtags({"make": "", "model": "", "trim": "", "body": "", "drive": "",
                              "fuel": "", "save": 0}, "facebook"))
    if company(s):
        ph = (s.get("store_phone") or "").strip()
        return (f"🎉 Congratulations{', ' + name if name else ''} on your {vehicle}! 🎉\n"
                f"Thank you for choosing {config.STORE_FULL or 'us'} — from all of us, enjoy the new ride!\n\n"
                f"Looking for your next vehicle? Message us{(' or call ' + ph) if ph else ''}."
                f"\n\n{tags} #Sold #HappyCustomer").strip()
    return (f"🎉 Congratulations{', ' + name if name else ''} on your {vehicle}! 🎉\n"
            f"Thank you for choosing {config.STORE_FULL or 'us'} — enjoy the new ride!\n\n"
            f"Looking for your next vehicle? Message me{(' or call/text ' + config.DEALER_PHONE) if config.DEALER_PHONE else ''}."
            f"\n— {who}\n\n{tags} #Sold #HappyCustomer").strip()


# ------------------------------------------------------------ the daily plan
def _log_file() -> Path:
    s = settings()
    return Path(config.STORE_DIR) / ("social_log_company.json" if company(s) else
                                     "social_log_page.json" if mypage(s) else "social_log.json")


def log() -> dict:
    try:
        d = json.loads(_log_file().read_text(encoding="utf-8"))
    except Exception:
        d = {}
    for k in ("made", "renewed"):
        if not isinstance(d.get(k), dict):
            d[k] = {}
    return d


def note(kind: str, stock: str = "") -> None:
    """Remember what was made or done today, so the plan moves on."""
    d = log()
    today = date.today().isoformat()
    if kind in ("made", "renewed") and stock:
        d[kind][str(stock).upper()] = today
    else:
        d[kind] = today
    try:
        _log_file().write_text(json.dumps(d, indent=1), encoding="utf-8")
    except OSError:
        pass


def _ago(s: str | None) -> int | None:
    try:
        return (date.today() - date.fromisoformat(str(s)[:10])).days
    except (TypeError, ValueError):
        return None


def plan(recs: list[dict], today: date | None = None) -> dict:
    """
    What to post today, from what's on the lot and what you've done:
      - Marketplace listings a week old or more: renew them (Marketplace
        shows a "Renew" button), oldest first.
      - One or two cars to feature on Facebook / Instagram / TikTok: the
        biggest savings not featured in the last two weeks.
      - Today's deals on Mondays and Fridays; the "I've got it" ad on
        Wednesdays.
    """
    import track
    t = today or date.today()
    lg = log()
    rows = track.load()
    inv = {str(r.get("stock", "")).upper(): r for r in recs}
    renew = []
    for s, r in rows.items():
        if r.get("Status") == "down" or s.upper() not in inv:
            continue
        last = max([x for x in (r.get("Posted_Date", ""), lg["renewed"].get(s.upper(), "")) if x] or [""])
        age = _ago(last)
        if age is not None and age >= 7:
            renew.append({"stock": s, "name": facts(inv[s.upper()])["name"], "days": age})
    renew.sort(key=lambda x: -x["days"])
    feats = []
    for s, r in inv.items():
        f = facts(r)
        if not f["save"] or not best_photo(f["stock"]):
            continue
        ago = _ago(lg["made"].get(s))
        if ago is not None and ago < 14:
            continue
        feats.append({"stock": f["stock"], "name": f["name"], "save": money(f["save"]),
                      "price": money(f["price"]), "_k": f["save"]})
    feats.sort(key=lambda x: -x["_k"])
    co = company()
    pg = page_plan()
    n = 2 if t.weekday() in (4, 5) else 1           # Friday and Saturday: two
    if pg:
        n = 3 if t.weekday() in (4, 5) else 2       # a page: 2-3 a day
        renew = []                                  # Marketplace renewals aren't the page's
    for x in feats:
        x.pop("_k", None)
    store = []
    if t.weekday() in (0, 4) and lg.get("deals") != t.isoformat():
        store.append({"kind": "deals", "label": "Today's deals picture (Monday and Friday)"})
    if t.weekday() == 2 and lg.get("brand") != t.isoformat() and (co or settings()["headshot"]):
        store.append({"kind": "brand", "label": ("\"We've got it\"" if co else "\"I've got it\"") + " ad (Wednesdays)"})
    if pg and t.weekday() in (1, 3, 5) and lg.get("tot") != t.isoformat():
        store.append({"kind": "tot", "label": "This or that? (comment A or B)"})
    off = False
    try:
        import customers
        off = t.weekday() in set(customers.settings()["days_off"])
    except Exception:
        pass
    return {"company": co, "page": pg and not co, "renew": renew[:10], "renew_more": max(0, len(renew) - 10),
            "feature": feats[:n], "store": store, "day_off": off,
            "made_today": sorted(k for k, v in lg["made"].items() if v == t.isoformat())}
