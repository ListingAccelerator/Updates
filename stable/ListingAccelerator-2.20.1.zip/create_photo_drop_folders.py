"""
create_photo_drop_folders.py -- pre-build a Photo Drop subfolder per vehicle.

Creates an empty folder named for each stock number so they're already waiting
for you; drag each vehicle's photos into its matching folder.

Safe to re-run after every scrape: existing folders and the photos in them are
left alone, only missing ones get created. Folders for vehicles no longer in
inventory are reported, not deleted -- you decide what to do with them.

Usage:
    python create_photo_drop_folders.py
"""
from __future__ import annotations

import csv
import sys

import config


def main() -> None:
    if not config.INVENTORY_CSV.exists():
        print(f"No inventory at {config.INVENTORY_CSV}")
        print("Run: python scrape_inventory.py")
        sys.exit(1)

    # The JSON carries everything the filter looks at (new or used, which
    # store, Certified). The CSV is a trimmed copy for a spreadsheet, and
    # judging from it put a store demo -- a 2026 the store sells as used --
    # outside what he works, so it got photos but no folder of its own.
    rows = []
    if config.INVENTORY_JSON.exists():
        try:
            import json
            rows = json.loads(config.INVENTORY_JSON.read_text(encoding="utf-8"))
        except Exception:
            rows = []
    if not rows:
        with open(config.INVENTORY_CSV, newline="", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))

    # Accept either the scraper's "stock" or a hand-made sheet's "Stock".
    key = "stock" if rows and "stock" in rows[0] else "Stock"

    # A folder only for the cars he works. Two hundred empty folders for a
    # sister store's inventory is just clutter he has to scroll past.
    try:
        import track
        f = track.focus()
        if track.focus_is_on(f):
            rows = [r for r in rows
                    if track.in_focus({"stock": str(r.get(key, "")).strip(),
                                       **r}, f)]
        else:
            rows = [r for r in rows
                    if not track.is_other_store(
                        {"stock": str(r.get(key, "")).strip(), **r})]
    except Exception:
        pass

    stocks = [str(r[key]).strip() for r in rows if str(r.get(key, "")).strip()]

    config.PHOTO_DROP.mkdir(parents=True, exist_ok=True)

    created = existing = 0
    for stock in stocks:
        folder = config.PHOTO_DROP / stock
        if folder.exists():
            existing += 1
            continue
        folder.mkdir(parents=True)
        print(f"Created: Photo Drop/{stock}")
        created += 1

    # Folders with no matching vehicle -- sold, or a stock number typo
    on_disk = {p.name for p in config.PHOTO_DROP.iterdir() if p.is_dir()}
    orphans = sorted(on_disk - set(stocks))

    empty = sorted(
        s for s in stocks
        if (config.PHOTO_DROP / s).exists()
        and not any((config.PHOTO_DROP / s).iterdir())
    )

    print("\n=== Summary ===")
    print(f"{created} new folder(s) created")
    print(f"{existing} already existed (left alone)")
    print(f"Photo Drop: {config.PHOTO_DROP}")

    if empty:
        print(f"\n{len(empty)} vehicle(s) still need photos:")
        print("  " + ", ".join(empty[:20]) + (" ..." if len(empty) > 20 else ""))
    if orphans:
        print(f"\n{len(orphans)} folder(s) with no matching vehicle "
              f"(sold, or a stock-number mismatch):")
        print("  " + ", ".join(orphans))
        print("  Nothing was deleted -- review these yourself.")


if __name__ == "__main__":
    main()
