"""
A small QR code maker (byte mode, error correction M, versions 1-10), so the
"From my phone" screen needs nothing extra installed. Follows the QR standard
(ISO 18004) the same way the well-known qrcodegen library does.

    qr.matrix("http://192.168.1.24:8770/p/AbC123") -> list of rows of bools
    qr.png_data_uri(text, scale=8)                    -> "data:image/png;base64,..."
"""
from __future__ import annotations

# (ECC codewords per block, number of blocks) for level M, versions 1..10
_ECC_M = {1: (10, 1), 2: (16, 1), 3: (26, 1), 4: (18, 2), 5: (24, 2),
          6: (16, 4), 7: (18, 4), 8: (22, 4), 9: (22, 5), 10: (26, 5)}
_ALIGN = {1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34],
          7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50]}


def _raw_modules(ver: int) -> int:
    r = (16 * ver + 128) * ver + 64
    if ver >= 2:
        n = ver // 7 + 2
        r -= (25 * n - 10) * n - 55
        if ver >= 7:
            r -= 36
    return r


def _data_codewords(ver: int) -> int:
    ecc, blocks = _ECC_M[ver]
    return _raw_modules(ver) // 8 - ecc * blocks


# --- Reed-Solomon over GF(256), polynomial 0x11D ------------------------------
def _gf_mul(x: int, y: int) -> int:
    z = 0
    for i in range(7, -1, -1):
        z = (z << 1) ^ ((z >> 7) * 0x11D)
        z ^= ((y >> i) & 1) * x
    return z & 0xFF


def _rs_divisor(degree: int) -> list[int]:
    result = [0] * (degree - 1) + [1]
    root = 1
    for _ in range(degree):
        for j in range(degree):
            result[j] = _gf_mul(result[j], root)
            if j + 1 < degree:
                result[j] ^= result[j + 1]
        root = _gf_mul(root, 0x02)
    return result


def _rs_remainder(data: list[int], divisor: list[int]) -> list[int]:
    result = [0] * len(divisor)
    for b in data:
        factor = b ^ result.pop(0)
        result.append(0)
        for i, coef in enumerate(divisor):
            result[i] ^= _gf_mul(coef, factor)
    return result


# --- encoding -----------------------------------------------------------------
def _codewords(text: str) -> tuple[int, list[int]]:
    data = text.encode("utf-8")
    for ver in range(1, 11):
        cap_bits = _data_codewords(ver) * 8
        count_bits = 8 if ver <= 9 else 16
        if 4 + count_bits + len(data) * 8 <= cap_bits:
            break
    else:
        raise ValueError("Text too long for this QR maker")
    bits: list[int] = []

    def put(val, n):
        bits.extend((val >> i) & 1 for i in range(n - 1, -1, -1))
    put(0b0100, 4)
    put(len(data), count_bits)
    for b in data:
        put(b, 8)
    put(0, min(4, cap_bits - len(bits)))
    put(0, (8 - len(bits) % 8) % 8)
    pad = 0xEC
    while len(bits) < cap_bits:
        put(pad, 8)
        pad ^= 0xEC ^ 0x11
    words = [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]

    # split into blocks, add error correction, interleave
    ecc_len, nblocks = _ECC_M[ver]
    raw = _raw_modules(ver) // 8
    short_len = raw // nblocks
    n_short = nblocks - raw % nblocks
    div = _rs_divisor(ecc_len)
    blocks, k = [], 0
    for i in range(nblocks):
        dlen = short_len - ecc_len + (0 if i < n_short else 1)
        dat = words[k:k + dlen]
        k += dlen
        blk = dat + _rs_remainder(dat, div)
        if i < n_short:
            blk.insert(dlen, None)          # placeholder so columns line up
        blocks.append(blk)
    out = []
    for i in range(len(blocks[0])):
        for j, blk in enumerate(blocks):
            if blk[i] is not None:
                out.append(blk[i])
    return ver, out


def _format_bits(mask: int) -> int:
    data = (0 << 3) | mask                  # level M = 00
    rem = data
    for _ in range(10):
        rem = (rem << 1) ^ ((rem >> 9) * 0x537)
    return ((data << 10) | rem) ^ 0x5412


def _version_bits(ver: int) -> int:
    rem = ver
    for _ in range(12):
        rem = (rem << 1) ^ ((rem >> 11) * 0x1F25)
    return (ver << 12) | rem


def _build(ver: int, words: list[int], mask: int):
    size = ver * 4 + 17
    m = [[False] * size for _ in range(size)]
    fn = [[False] * size for _ in range(size)]

    def setf(x, y, v):
        m[y][x] = v
        fn[y][x] = True

    for i in range(size):                   # timing
        setf(6, i, i % 2 == 0)
        setf(i, 6, i % 2 == 0)
    for cx, cy in ((3, 3), (size - 4, 3), (3, size - 4)):   # finders + separators
        for dy in range(-4, 5):
            for dx in range(-4, 5):
                x, y = cx + dx, cy + dy
                if 0 <= x < size and 0 <= y < size:
                    d = max(abs(dx), abs(dy))
                    setf(x, y, d not in (2, 4))
    al = _ALIGN[ver]
    for i in al:
        for j in al:
            if (i == 6 and j == 6) or (i == 6 and j == al[-1]) or (i == al[-1] and j == 6):
                continue
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    setf(i + dx, j + dy, max(abs(dx), abs(dy)) != 1)

    def draw_format():
        b = _format_bits(mask)
        for i in range(6):
            setf(8, i, (b >> i) & 1 == 1)
        setf(8, 7, (b >> 6) & 1 == 1)
        setf(8, 8, (b >> 7) & 1 == 1)
        setf(7, 8, (b >> 8) & 1 == 1)
        for i in range(9, 15):
            setf(14 - i, 8, (b >> i) & 1 == 1)
        for i in range(8):
            setf(size - 1 - i, 8, (b >> i) & 1 == 1)
        for i in range(8, 15):
            setf(8, size - 15 + i, (b >> i) & 1 == 1)
        setf(8, size - 8, True)             # dark module
    draw_format()
    if ver >= 7:
        vb = _version_bits(ver)
        for i in range(18):
            bit = (vb >> i) & 1 == 1
            a, c = size - 11 + i % 3, i // 3
            setf(a, c, bit)
            setf(c, a, bit)

    # data in the zigzag
    i = 0
    right = size - 1
    while right >= 1:
        if right == 6:
            right = 5
        for vert in range(size):
            for j in range(2):
                x = right - j
                upward = ((right + 1) & 2) == 0
                y = size - 1 - vert if upward else vert
                if not fn[y][x] and i < len(words) * 8:
                    m[y][x] = (words[i >> 3] >> (7 - (i & 7))) & 1 == 1
                    i += 1
        right -= 2

    masks = [lambda x, y: (x + y) % 2 == 0, lambda x, y: y % 2 == 0,
             lambda x, y: x % 3 == 0, lambda x, y: (x + y) % 3 == 0,
             lambda x, y: (x // 3 + y // 2) % 2 == 0, lambda x, y: x * y % 2 + x * y % 3 == 0,
             lambda x, y: (x * y % 2 + x * y % 3) % 2 == 0,
             lambda x, y: ((x + y) % 2 + x * y % 3) % 2 == 0]
    f = masks[mask]
    for y in range(size):
        for x in range(size):
            if not fn[y][x] and f(x, y):
                m[y][x] = not m[y][x]
    return m


def _penalty(m) -> int:
    size = len(m)
    score = 0
    for grid in (m, [list(r) for r in zip(*m)]):
        for row in grid:
            run, prev = 0, None
            for v in row:
                if v == prev:
                    run += 1
                else:
                    if run >= 5:
                        score += run - 2
                    run, prev = 1, v
            if run >= 5:
                score += run - 2
            s = "".join("1" if v else "0" for v in row)
            score += 40 * (s.count("10111010000") + s.count("00001011101"))
    for y in range(size - 1):
        for x in range(size - 1):
            if m[y][x] == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                score += 3
    dark = sum(v for row in m for v in row)
    total = size * size
    score += (abs(dark * 20 - total * 10) // total) * 10
    return score


def matrix(text: str):
    ver, words = _codewords(text)
    best = min(range(8), key=lambda k: _penalty(_build(ver, words, k)))
    return _build(ver, words, best)


def png_data_uri(text: str, scale: int = 8, border: int = 4) -> str:
    import base64
    import io
    from PIL import Image
    m = matrix(text)
    n = len(m)
    img = Image.new("L", (n + 2 * border, n + 2 * border), 255)
    px = img.load()
    for y in range(n):
        for x in range(n):
            if m[y][x]:
                px[x + border, y + border] = 0
    img = img.resize((img.width * scale, img.height * scale), Image.NEAREST)
    b = io.BytesIO()
    img.save(b, "PNG")
    return "data:image/png;base64," + base64.b64encode(b.getvalue()).decode()
