"""
vin_decode.py -- what a trade-in is, from its VIN.

Asks NHTSA's free VIN decoder (vpic.nhtsa.dot.gov, the U.S. government's
public database, no account or key) for the year, make, model, trim, body,
drive, engine and fuel. Only the VIN is sent -- never the customer.

Before asking, the VIN is checked here: 17 characters, no I, O or Q, and the
check digit (9th character) adds up -- which catches most typos. Without
internet the year still comes from the VIN itself (its 10th character).
"""
from __future__ import annotations

import json
import os
import re
import urllib.request

BASE = os.environ.get("LA_VPIC_BASE") or "https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVinValues/"

_VALUES = {**{str(i): i for i in range(10)},
           "A": 1, "B": 2, "C": 3, "D": 4, "E": 5, "F": 6, "G": 7, "H": 8,
           "J": 1, "K": 2, "L": 3, "M": 4, "N": 5, "P": 7, "R": 9,
           "S": 2, "T": 3, "U": 4, "V": 5, "W": 6, "X": 7, "Y": 8, "Z": 9}
_WEIGHTS = [8, 7, 6, 5, 4, 3, 2, 10, 0, 9, 8, 7, 6, 5, 4, 3, 2]
_YEARS = "ABCDEFGHJKLMNPRSTVWXY123456789"          # 1980/2010 ... 2009/2039

# Makes that are written in capitals.
_CAPS = {"BMW", "GMC", "RAM", "MINI", "FIAT", "KIA", "MG", "AMC", "SRT"}


def clean(vin: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", str(vin or "").upper())


def problem(vin: str) -> str:
    """'' when the VIN looks right, else what's wrong with it."""
    v = clean(vin)
    if len(v) != 17:
        return f"A VIN has 17 characters. That one has {len(v)}."
    bad = sorted(set(re.findall(r"[IOQ]", v)))
    if bad:
        return f"A VIN never has {' or '.join(bad)} in it. Check for a 1 or a 0 instead."
    total = sum(_VALUES[ch] * w for ch, w in zip(v, _WEIGHTS))
    want = "X" if total % 11 == 10 else str(total % 11)
    if v[8] != want:
        return "That VIN doesn't add up (its check digit is off), so a character is probably mistyped."
    return ""


def year_of(vin: str) -> int | None:
    """The model year from the 10th character. The 7th tells the 30-year cycle
    on cars and light trucks: a letter there means 2010 or later."""
    v = clean(vin)
    if len(v) != 17 or v[9] not in _YEARS:
        return None
    y = 1980 + _YEARS.index(v[9])
    if v[6].isalpha():
        y += 30
    return y


def _make(s: str) -> str:
    s = str(s or "").strip()
    if s.upper() in _CAPS:
        return s.upper()
    return " ".join("-".join(p.capitalize() for p in w.split("-")) for w in s.lower().split())


def _body(s: str) -> str:
    t = str(s or "").lower()
    for words, name in ((("pickup",), "Truck"), (("minivan",), "Minivan"), (("sport utility", "crossover", "cuv", "suv"), "SUV"),
                        (("sedan", "saloon"), "Sedan"), (("coupe",), "Coupe"), (("convertible", "cabriolet", "roadster"), "Convertible"),
                        (("hatchback", "liftback"), "Hatchback"), (("wagon",), "Wagon"), (("van",), "Van")):
        if any(w in t for w in words):
            return name
    return str(s or "").split("/")[0].strip()


def _drive(s: str) -> str:
    t = str(s or "").lower()
    if "awd" in t or "all-wheel" in t or "all wheel" in t:
        return "AWD"
    if "4wd" in t or "4x4" in t or "4-wheel" in t or "four" in t:
        return "4WD"
    if "fwd" in t or "front" in t:
        return "FWD"
    if "rwd" in t or "rear" in t:
        return "RWD"
    return str(s or "").split("/")[0].strip()


def decode(vin: str, timeout: int = 12) -> dict:
    v = clean(vin)
    p = problem(v)
    warn = ""
    if p and "check digit" in p:
        warn = "Its check digit is off, so double-check the VIN against the title or door sticker."
    elif p:
        return {"ok": False, "vin": v, "message": p}
    try:
        req = urllib.request.Request(f"{BASE}{v}?format=json",
                                     headers={"User-Agent": "Listing Accelerator"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
        res = (data.get("Results") or [{}])[0]
    except Exception:
        y = year_of(v)
        return {"ok": False, "vin": v, "year": str(y) if y else "",
                "message": "Couldn't reach the VIN decoder (no internet?)."
                           + (f" From the VIN itself it's a {y}." if y else "")}
    make = _make(res.get("Make"))
    if not make:
        return {"ok": False, "vin": v,
                "message": "The decoder doesn't know that VIN. Check it against the title or the door sticker."}
    trim = " ".join(x for x in (str(res.get("Trim") or "").strip(), str(res.get("Trim2") or "").strip()) if x) \
        or str(res.get("Series") or "").strip()
    eng = []
    try:
        if res.get("DisplacementL"):
            eng.append(f"{float(res['DisplacementL']):.1f}L")
    except ValueError:
        pass
    if res.get("EngineCylinders"):
        eng.append(f"{res['EngineCylinders']}-cyl")
    fuel = str(res.get("FuelTypePrimary") or "").strip()
    if fuel and fuel.lower() != "gasoline":
        eng.append(fuel.split("/")[0].strip().lower())
    details = " · ".join(x for x in (_body(res.get("BodyClass")), _drive(res.get("DriveType")), " ".join(eng)) if x)
    code = str(res.get("ErrorCode") or "0").split(",")[0].strip()
    return {"ok": True, "vin": v, "year": str(res.get("ModelYear") or year_of(v) or "").strip(),
            "make": make, "model": str(res.get("Model") or "").strip(), "trim": trim, "details": details,
            "note": warn or ("" if code == "0" else "The decoder wasn't fully sure about this VIN. Double-check it against the car.")}
