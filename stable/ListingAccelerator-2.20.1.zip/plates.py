"""
plates.py -- blur license plates on a car's photos.

Some salespeople (and some stores) don't want plates showing -- trade-ins,
consignment, dealer tags. The salesperson draws a box over each plate, or
with AI on lets the AI find them, and presses Blur. The program:
  - keeps the untouched photo in the car's folder under .plates\\ (so Undo
    can put it back),
  - blurs the plate on the photo itself (web_03.jpg), and on its background
    version (bg_03.jpg) if there is one, so every ad, video and posting set
    made afterwards has the plate blurred.

Only the plate area changes. Nothing else about the car is touched.
"""
from __future__ import annotations

import io
import json
import shutil
from pathlib import Path

KEEP = ".plates"


def _folder(stock: str) -> Path:
    import config
    return Path(config.PHOTO_DROP) / str(stock)


def _boxes_file(folder: Path) -> Path:
    return folder / KEEP / "boxes.json"


def saved_boxes(stock: str) -> dict:
    try:
        d = json.loads(_boxes_file(_folder(stock)).read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def blurred(stock: str) -> list[str]:
    f = _folder(stock) / KEEP
    return sorted(p.name for p in f.iterdir() if p.is_file() and p.suffix.lower() in
                  (".jpg", ".jpeg", ".png", ".webp")) if f.is_dir() else []


def _blur_box(im, box, strength: int = 0):
    """box = [x0, y0, x1, y1] as fractions 0..1 of the picture."""
    from PIL import ImageFilter, ImageDraw, Image
    W, H = im.size
    x0, y0, x1, y1 = box
    # a little room around the plate so no edge of a letter shows
    padx, pady = (x1 - x0) * 0.08, (y1 - y0) * 0.12
    x0, y0 = max(0, int((x0 - padx) * W)), max(0, int((y0 - pady) * H))
    x1, y1 = min(W, int((x1 + padx) * W)), min(H, int((y1 + pady) * H))
    if x1 - x0 < 4 or y1 - y0 < 4:
        return im
    region = im.crop((x0, y0, x1, y1))
    # pixelate, then soften: unreadable, and it still looks like a plate area
    small = region.resize((max(1, (x1 - x0) // 14), max(1, (y1 - y0) // 14)), Image.BILINEAR)
    region = small.resize(region.size, Image.NEAREST).filter(
        ImageFilter.GaussianBlur(max(3, (y1 - y0) // 6) + strength))
    mask = Image.new("L", region.size, 0)
    r = max(2, min(region.size) // 6)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, region.size[0] - 1, region.size[1] - 1], r, fill=255)
    mask = mask.filter(ImageFilter.GaussianBlur(2))
    im.paste(region, (x0, y0), mask)
    return im


def _clean(boxes) -> list[list[float]]:
    out = []
    for b in boxes or []:
        try:
            x0, y0, x1, y1 = (float(v) for v in b)
        except Exception:
            continue
        x0, x1 = sorted((min(max(x0, 0), 1), min(max(x1, 0), 1)))
        y0, y1 = sorted((min(max(y0, 0), 1), min(max(y1, 0), 1)))
        if x1 - x0 > 0.005 and y1 - y0 > 0.005:
            out.append([round(x0, 4), round(y0, 4), round(x1, 4), round(y1, 4)])
    return out


def apply(stock: str, boxes_by_photo: dict) -> dict:
    """boxes_by_photo: {"web_03.jpg": [[x0,y0,x1,y1], ...]}. Blurs, keeps originals."""
    from PIL import Image, ImageOps
    import backgrounds
    folder = _folder(stock)
    keep = folder / KEEP
    done, skipped = [], []
    saved = saved_boxes(stock)
    for name, boxes in (boxes_by_photo or {}).items():
        boxes = _clean(boxes)
        src = folder / Path(str(name)).name
        if not boxes or not src.exists():
            continue
        keep.mkdir(parents=True, exist_ok=True)
        orig = keep / src.name
        if not orig.exists():
            shutil.copy2(src, orig)            # the untouched photo, once
        try:
            # always blur from the untouched photo, so blurring twice doesn't stack
            im = ImageOps.exif_transpose(Image.open(orig)).convert("RGB")
            for b in boxes:
                im = _blur_box(im, b)
            im.save(src, "JPEG", quality=92)
            bgp = folder / backgrounds.bg_name(src)
            if bgp.exists():
                bkeep = keep / bgp.name
                if not bkeep.exists():
                    shutil.copy2(bgp, bkeep)
                bim = Image.open(bkeep).convert("RGB")
                for b in boxes:
                    bim = _blur_box(bim, b)
                bim.save(bgp, "JPEG", quality=92)
            saved[src.name] = boxes
            done.append(src.name)
        except Exception as e:
            skipped.append(f"{src.name}: {e}")
    if done:
        _boxes_file(folder).parent.mkdir(parents=True, exist_ok=True)
        _boxes_file(folder).write_text(json.dumps(saved, indent=1), encoding="utf-8")
    return {"done": done, "skipped": skipped}


def undo(stock: str) -> int:
    """Put every untouched photo back."""
    folder = _folder(stock)
    keep = folder / KEEP
    if not keep.is_dir():
        return 0
    n = 0
    for p in keep.iterdir():
        if p.is_file() and p.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp"):
            shutil.copy2(p, folder / p.name)
            p.unlink()
            n += 1
    try:
        _boxes_file(folder).unlink()
    except FileNotFoundError:
        pass
    try:
        keep.rmdir()
    except OSError:
        pass
    return n


AI_ASK = ("Find every vehicle license plate (front or rear, any state, dealer tags too) in "
          "each photo. For each photo, in order, return the plate boxes as "
          "[ymin, xmin, ymax, xmax] on a 0-1000 scale. A photo with no plate gets an "
          "empty list. Return JSON only: {\"photos\": [{\"n\": 1, \"plates\": [[ymin, xmin, ymax, xmax]]}]}")


def ai_find(stock: str, names: list[str]) -> dict:
    """Ask the AI the salesperson chose where the plates are. Boxes come back
    for him to check -- nothing is blurred until he presses Blur."""
    import ai_engine
    from PIL import Image, ImageOps
    if not ai_engine.on():
        return {"ok": False, "message": "Turn on AI first (Integrations → AI settings), or draw the boxes yourself."}
    folder = _folder(stock)
    out = {}
    names = [n for n in names if (folder / n).exists()][:20]
    for start in range(0, len(names), 6):
        chunk = names[start:start + 6]
        parts = [AI_ASK]
        for i, n in enumerate(chunk, 1):
            src = folder / KEEP / n if (folder / KEEP / n).exists() else folder / n
            im = ImageOps.exif_transpose(Image.open(src)).convert("RGB")
            im.thumbnail((1024, 1024))
            buf = io.BytesIO()
            im.save(buf, "JPEG", quality=85)
            parts += [f"Photo {i}:", {"jpeg": buf.getvalue()}]
        try:
            got = ai_engine.json_from(ai_engine.ask(parts, want_json=True, temperature=0.1)).get("photos", [])
        except ai_engine.AIFail as e:
            return {"ok": False, "message": str(e)}
        except Exception:
            return {"ok": False, "message": "The AI's answer couldn't be read. Try again, or draw the boxes yourself."}
        for g in got:
            try:
                k = int(g.get("n")) - 1
            except Exception:
                continue
            if not 0 <= k < len(chunk):
                continue
            boxes = []
            for b in g.get("plates") or []:
                try:
                    ymin, xmin, ymax, xmax = (float(v) / 1000 for v in b)
                except Exception:
                    continue
                boxes.append([xmin, ymin, xmax, ymax])
            boxes = _clean(boxes)
            if boxes:
                out[chunk[k]] = boxes
    return {"ok": True, "boxes": out}
