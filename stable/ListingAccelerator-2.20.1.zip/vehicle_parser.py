"""
vehicle_parser.py -- turns a rendered vehicle card's text into a structured record.

The block parser and the make/model/trim splitter in here were validated against
all 88 vehicles from a live capture of the Teays Valley inventory page, including
the edge cases: "Grand Cherokee L Limited" vs "Grand Cherokee Limited",
"Wrangler 4xe Unlimited Sahara High Altitude", "ProMaster Cargo Van Tradesman",
and a vehicle with no retail price at all.
"""
from __future__ import annotations

import re

MONEY_RE = re.compile(r"^-?\s*\+?\$([\d,]+)")
# The year starts the title -- after "Used", "Pre-Owned" or "Certified" on
# the many sites that put that word first ("Used 2019 Toyota RAV4 LE").
TITLE_RE = re.compile(r"^(?:(?:certified\s+)?(?:pre-?owned|used)\s+|certified\s+|cpo\s+)?((?:19|20)\d{2})\s+(.+?)\s*$", re.I)
MILEAGE_RE = re.compile(r"^([\d,]+)\s*mi\.?$", re.IGNORECASE)
# "Mileage: 32,937" on one line, or the label alone with the number below it
# -- how Dealer Car Search lays it out. Only "N mi" was understood before, so
# every car at Gary's Auto Sales came through with no mileage.
MILEAGE_LABEL_RE = re.compile(
    r"^(?:mileage|miles|odometer)\s*:?\s*([\d,]+)?\s*(?:mi(?:les)?\.?)?$",
    re.IGNORECASE)
CARD_SPEC_FIELDS = {
    "color": "exterior_color", "colour": "exterior_color",
    "exterior": "exterior_color", "exterior color": "exterior_color",
    "ext color": "exterior_color", "ext": "exterior_color",
    "interior": "interior", "int": "interior",
    "interior color": "interior_color", "int color": "interior_color",
    "engine": "engine", "trans": "transmission",
    "transmission": "transmission", "drive": "drivetrain",
    "drivetrain": "drivetrain", "drive type": "drivetrain",
    "fuel": "fuel_type", "fuel type": "fuel_type",
}
# Labels read when they sit ALONE on a line with the value underneath. Only
# full words: Moses' DealerOn cards print a bare "Ext." and "Int." beside the
# colour swatches with the PRICE on the next line, and reading those took
# "$8,162" as the paint colour of every car at the Supercenter.
STACKED_LABELS = {"exterior color", "exterior colour", "interior color",
                  "interior colour", "color", "colour", "engine",
                  "transmission", "drivetrain", "drive type", "fuel type"}


def _spec_value_ok(v: str) -> bool:
    """A colour or spec is words, never a price or a bare number."""
    v = (v or "").strip()
    if not v or v[0] in "$+-":
        return False
    if re.fullmatch(r"[\d,.\s]+", v):
        return False
    if MONEY_RE.match(v):
        return False
    return True


CARD_SPEC_RE = re.compile(
    r"^(colou?r|exterior(?: colou?r)?|ext\.?(?: colou?r)?|interior(?: colou?r)?"
    r"|int\.?(?: colou?r)?|engine|trans(?:mission)?|drive(?:train| type)?"
    r"|fuel(?: type)?)\s*:\s*(.*)$", re.I)
CTA_RE = re.compile(
    r"^(inquiry|inquire|make (an )?offer|value (my|your) trade|start (my|your)"
    r" deal|financing|get financed|apply( now)?|text us|call us|email us|"
    r"contact us|check availability|confirm availability|schedule( a)? test"
    r" drive|test drive|get pre-?approved|view details|more info|details|"
    r"share|print|save|compare|email for price|call for price|"
    r"n/a|unlock price|get (e-?)?price)$", re.I)
# "Retail $27,495" -- a known price label and its amount on one line with no
# colon between them.
LABEL_MONEY_RE = re.compile(r"^([A-Za-z][A-Za-z .'-]*?)\s*:?\s*(\$[\d,]+)\s*$")

# Every dealer website spells the stock-number label its own way:
#   "Stock: 10142A"   "Stock #P2163"   "Stock Number: 12345"   "Stock No. 887"
# A program that only knows the first spelling finds no stock number, and a
# record with no stock number gets thrown away -- so the whole lot reads as
# zero vehicles. These match the LABEL only; the value is what follows.
#
# The lookahead is what keeps prose out: the text after the label has to look
# like a stock number (contain a digit), so a line of ad copy that happens to
# begin "Stock up on savings" is not mistaken for a vehicle.
# The separator between the label and the number is anybody's guess: a colon,
# a hash, a dash, several of them, or nothing at all. Capital Ford writes
# "Stock # - QAA15260B"; Moses writes "Stock: 10142A".
_SEP = r"[\s:#\-–—]*"
STOCK_LABEL = re.compile(
    rf"^stock\b{_SEP}(?:(?:number|no\.?|num){_SEP})?"
    r"(?=[A-Za-z0-9][A-Za-z0-9-]*\d)", re.I)

# Certified Pre-Owned. Deliberately narrow: a bare "certified" also shows up in
# "certified service department" and "certified technicians", which have
# nothing to do with the car. A card badged only "Certified" on its own line is
# handled separately, where a whole line of exactly that word is unambiguous.
CERTIFIED_RE = re.compile(
    r"\bcertified\s+pre[-\s]?owned\b"
    r"|\bcertified\s+used\b"
    r"|\bcertified\s+vehicle\b"
    r"|\bC\.P\.O\.|\bCPO\b"
    # A bare "Certified" badge, which is how plenty of stores mark it -- and
    # which can share a line with another badge ("Certified Manager's
    # Special"), so it cannot be found by matching a whole line. Everything
    # after the badge word is the service drive talking about itself, not the
    # car, so those phrasings are excluded.
    r"|\bcertified\b(?!\s*(?:service|technician|tech\b|dealer|mechanic"
    r"|repair|collision|installer|parts|staff|advisor))", re.I)

# Manager's Special, and the many names stores give the same thing.
MANAGER_SPECIAL_RE = re.compile(
    r"\bmanager'?s?\s+(?:special|pick|choice|madness)\b"
    r"|\bmgr'?s?\s+special\b"
    r"|\bmanager\s+special\b", re.I)

# Two badges sitting side by side in the markup come through with no space
# between them -- "CertifiedManager's Special" -- and a word that is glued to
# the next one matches nothing, so a car wearing BOTH badges would lose both.
# Splitting at a lowercase-to-uppercase join puts the space back. Only ever
# used for spotting badges, never for reading a value out of the card.
_GLUED = re.compile(r"([a-z])([A-Z])")


def unglue(s: str) -> str:
    return _GLUED.sub(r"\1 \2", str(s or ""))
VIN_LABEL = re.compile(
    rf"^vin\b{_SEP}(?:(?:number|no\.?){_SEP})?(?=[A-Za-z0-9]{{6,}})", re.I)

# Multi-word makes first so "Land Rover" isn't read as make "Land".
MAKES = [
    "Alfa Romeo", "Land Rover", "Mercedes-Benz",
    "Acura", "Audi", "BMW", "Buick", "Cadillac", "Chevrolet", "Chrysler",
    "Dodge", "Ford", "GMC", "Genesis", "Honda", "Hyundai", "INFINITI",
    "Jaguar", "Jeep", "Kia", "Lexus", "Lincoln", "Mazda", "MINI",
    "Mitsubishi", "Nissan", "Porsche", "RAM", "Subaru", "Tesla", "Toyota",
    "Volkswagen", "Volvo",
]

# Nameplates that contain spaces, so the trim boundary lands correctly.
MODELS = {
    "Jeep": ["Grand Cherokee L", "Grand Cherokee", "Grand Wagoneer",
             "Wrangler 4xe", "Wrangler", "Wagoneer", "Gladiator", "Compass",
             "Cherokee", "Renegade", "Commander"],
    "Ford": ["Expedition Max", "Bronco Sport", "Explorer Hybrid",
             "Escape Hybrid", "Maverick Hybrid", "Transit Connect",
             "Transit 350", "Transit 250", "Transit 150",
             "F-150 Lightning", "F-150", "F-250", "F-350", "Super Duty",
             "Expedition", "Explorer", "Mustang", "Escape", "Bronco",
             "Edge", "Ranger", "Maverick", "Fusion", "Focus"],
    "Chevrolet": ["Silverado 2500HD", "Silverado 3500HD", "Silverado 1500",
                  "Trailblazer", "Equinox EV", "Equinox", "Traverse",
                  "Suburban", "Corvette", "Colorado", "Camaro", "Blazer",
                  "Tahoe", "Malibu", "Trax", "Bolt EUV", "Bolt"],
    "RAM": ["ProMaster Cargo Van", "ProMaster City", "ProMaster",
            "1500 Classic", "1500", "2500", "3500"],
    "Hyundai": ["Santa Cruz", "Santa Fe Hybrid", "Santa Fe", "Ioniq 5",
                "Ioniq 6", "Palisade", "Elantra", "Tucson Hybrid", "Tucson",
                "Sonata", "Kona", "Venue", "Accent"],
    "Toyota": ["RAV4 Prime", "RAV4 Hybrid", "Highlander Hybrid",
               "Grand Highlander", "Camry Hybrid", "Corolla Cross",
               "4Runner", "Highlander", "Corolla", "Tacoma", "Tundra",
               "Sequoia", "Sienna", "Avalon", "Camry", "RAV4", "Prius"],
    "Honda": ["CR-V Hybrid", "Accord Hybrid", "Odyssey", "Passport",
              "Ridgeline", "Pilot", "Civic", "CR-V", "HR-V", "Insight"],
    "Subaru": ["Crosstrek Hybrid", "Crosstrek", "Forester", "Outback",
               "Ascent", "Legacy", "Impreza", "WRX", "BRZ", "Solterra"],
    "Nissan": ["Rogue Sport", "Pathfinder", "Frontier", "Murano", "Armada",
               "Sentra", "Altima", "Rogue", "Kicks", "Titan", "Versa",
               "Maxima", "Ariya", "LEAF"],
    "Mazda": ["CX-90", "CX-70", "CX-50", "CX-30", "CX-5", "CX-9", "MX-5 Miata",
              "MX-30", "Mazda3", "Mazda6"],
    "Mitsubishi": ["Outlander Sport", "Outlander PHEV", "Eclipse Cross",
                   "Outlander", "Mirage G4", "Mirage"],
    "Kia": ["Sportage Hybrid", "Sorento Hybrid", "Telluride", "Sportage",
            "Carnival", "Sorento", "Seltos", "Forte", "Soul", "Niro",
            "Stinger", "EV6", "EV9", "K5", "Rio"],
    "Dodge": ["Grand Caravan", "Challenger", "Charger", "Durango", "Hornet",
              "Journey"],
    "Chrysler": ["Pacifica Hybrid", "Pacifica", "Voyager", "300"],
    "GMC": ["Sierra 2500HD", "Sierra 3500HD", "Sierra 1500", "Acadia",
            "Canyon", "Terrain", "Yukon XL", "Yukon", "Savana"],
    "Audi": ["SQ5 Sportback", "Q5 Sportback", "e-tron", "SQ5", "Q3", "Q5",
             "Q7", "Q8", "A3", "A4", "A5", "A6", "A7"],
    "INFINITI": ["QX80", "QX60", "QX55", "QX50", "Q50", "Q60"],
    "Volkswagen": ["Atlas Cross Sport", "Golf GTI", "Tiguan", "Atlas",
                   "Jetta", "Taos", "Passat", "ID.4", "Arteon"],
    "Buick": ["Encore GX", "Envision", "Enclave", "Encore", "Envista"],
    "Cadillac": ["Escalade ESV", "Escalade", "XT4", "XT5", "XT6", "CT4",
                 "CT5", "LYRIQ"],
    "Lincoln": ["Navigator L", "Navigator", "Aviator", "Corsair", "Nautilus"],
    "Lexus": ["RX 350", "NX 350", "GX 460", "GX 550", "ES 350", "IS 350",
              "TX 350", "RX", "NX", "GX", "ES", "IS"],
    "Acura": ["MDX", "RDX", "TLX", "ILX", "Integra", "ZDX"],
}


def money(s: str) -> int | None:
    m = MONEY_RE.match(s.strip())
    return int(m.group(1).replace(",", "")) if m else None


# Which label means which field. Compared lowercase with any trailing colon
# removed, so "Retail Price:", "RETAIL PRICE" and "Retail Price" all land here.
PRICE_FIELDS = {
    "moses price": "moses_price",
    "retail price": "retail_price",
    "msrp": "retail_price",
    "savings": "savings",
    "you save": "savings",
    "doc fee": "doc_fee",
    "price": "final_price",
    "sale price": "final_price",
    "internet price": "final_price",
    "our price": "final_price",
    # Every platform brands the asking price differently. A label this program
    # does not recognise means a car with no price on it, which is the single
    # worst way for a run to fail -- so this list stays generous.
    "market price": "final_price",
    "sales price": "final_price",
    "special price": "final_price",
    "dealer price": "final_price",
    "asking price": "final_price",
    "now": "final_price",
    "price now": "final_price",
    "your price": "final_price",
    "e-price": "final_price",
    "eprice": "final_price",
    "discounted price": "final_price",
    "was": "retail_price",
    "list price": "retail_price",
    "original price": "retail_price",
    "total savings": "savings",
    "discount": "savings",
    "documentation fee": "doc_fee",
    "dealer doc fee": "doc_fee",
    # Small-lot platforms (Dealer Car Search) show a single "Retail $27,495".
    # Kept as the retail figure; when it is the ONLY price on the card it
    # becomes the asking price below.
    "retail": "retail_price",
}


def money_at(lines: list[str], idx: int, negative_ok: bool = False) -> int | None:
    """
    The dollar amount on line `idx`, if there is one.

    A leading minus means a discount ("- $3,609"), never a price. Reading one
    of those as the asking price is exactly the bug that put a $1,010 price on
    a $52,886 Lexus, so unless we are deliberately reading the savings line,
    a negative is refused outright.
    """
    if idx < 0 or idx >= len(lines):
        return None
    raw = lines[idx].strip()
    if not negative_ok and raw.startswith("-"):
        return None
    return money(raw)


def split_title(title: str) -> tuple[str, str, str]:
    """'Kia Sportage Nightfall' -> ('Kia', 'Sportage', 'Nightfall')"""
    t = title.strip()
    make = ""
    for cand in MAKES:
        low = cand.lower()
        if (t.lower().startswith(low + " ") or t.lower() == low) and len(cand) > len(make):
            make = cand
    if not make:
        parts = t.split(maxsplit=1)
        return (parts[0] if parts else "", parts[1] if len(parts) > 1 else "", "")

    rest = t[len(make):].strip()

    # Some feeds repeat the make inside the nameplate -- the Teays Valley site
    # emits "Mazda Mazda CX-50" and "Mazda Mazda CX-90". Collapse the repeat,
    # but keep it when the make IS the start of the model name ("Mazda3").
    if rest.lower().startswith(make.lower()):
        tail = rest[len(make):]
        if tail.startswith(" "):
            rest = tail.strip()

    for nameplate in sorted(MODELS.get(make, []), key=len, reverse=True):
        n = len(nameplate)
        # Word-boundary match: "Grand Cherokee L" must not swallow the L of
        # "Grand Cherokee Limited".
        if rest.lower().startswith(nameplate.lower()) and (
            len(rest) == n or rest[n] == " "
        ):
            return (make, nameplate, rest[n:].strip())

    parts = rest.split(maxsplit=1)
    return (make, parts[0] if parts else "", parts[1] if len(parts) > 1 else "")


def tidy(s: str) -> str:
    """Normalize ALL-CAPS runs from the site ('SIENNA MINIVAN') to title case."""
    if not s:
        return s
    out = []
    for w in s.split():
        if w.isupper() and len(w) > 3 and not re.search(r"\d", w) and "-" not in w:
            out.append(w.capitalize())
        else:
            out.append(w)
    return " ".join(out)


def parse_card_text(text: str) -> dict:
    """
    Parse one vehicle card's rendered text.

    Expected shape (features vary, order is stable):
        2022 Kia Sportage Nightfall
        Special Offer / Price Drop
        VIN: ...
        Stock: ...
        Model: ...
        46,427 mi
        <features>
        $20,352
        Moses Price
        Less
        Retail Price:
        $24,999
        Savings:
        - $5,222
        Doc Fee
        +$575
        Price:
        $20,352
    """
    lines = [ln.strip() for ln in text.splitlines()]
    lines = [ln for ln in lines if ln]
    rec: dict = {}
    features: list[str] = []
    used_below: set[int] = set()

    PRICE_LABELS = {"Moses Price", "Less", "Retail Price:", "Savings:",
                    "Doc Fee", "Price:", "Instant PriceLOCKED",
                    "Unlock Instant Price", "View CARFAX report",
                    "Compare Vehicle", "Ext.", "Int.", "Special Offer",
                    "Price Drop", "Unlock Today's Market Price",
                    "I'm Interested", "Get Pre Approved", "Sort", "Grid",
                    "List", "Savings", "MOSES PRICE"}

    for i, ln in enumerate(lines):
        if i in used_below:
            continue                      # value already taken by its label
        # A bare "Stock #:" or "VIN:" with its value on the line below.
        if re.fullmatch(r"stock\s*(?:#|no\.?|number|num)?\s*:?", ln, re.I):
            nxt = lines[i + 1] if i + 1 < len(lines) else ""
            if "stock" not in rec and re.fullmatch(r"[A-Za-z0-9-]*\d[A-Za-z0-9-]*", nxt) \
                    and len(nxt) <= 20:
                rec["stock"] = nxt
                used_below.add(i + 1)
            continue
        if re.fullmatch(r"vin\s*(?:#|no\.?|number)?\s*:?", ln, re.I):
            nxt = lines[i + 1] if i + 1 < len(lines) else ""
            if "vin" not in rec and re.fullmatch(r"[A-HJ-NPR-Z0-9]{11,17}", nxt, re.I):
                rec["vin"] = nxt.upper()
                used_below.add(i + 1)
            continue
        m = VIN_LABEL.match(ln)
        if m:
            rest = ln[m.end():].strip()
            # "VIN:" alone, with the number on the next line.
            if not rest and i + 1 < len(lines) and re.fullmatch(
                    r"[A-HJ-NPR-Z0-9]{11,17}", lines[i + 1], re.I):
                rest = lines[i + 1]
                used_below.add(i + 1)
            rec["vin"] = rest
            continue
        m = STOCK_LABEL.match(ln)
        if m:
            # Take only the stock number itself. Some sites run the next
            # label onto the same line ("Stock #P2163 VIN 1G1...").
            rest = ln[m.end():].strip()
            if not rest and i + 1 < len(lines) and re.fullmatch(
                    r"[A-Za-z0-9-]{2,20}", lines[i + 1]):
                rest = lines[i + 1]
                used_below.add(i + 1)
            rec["stock"] = (rest.split() or [""])[0].strip(",;|")
            continue
        if ln.startswith("Model:"):
            rec["model_code"] = ln.split("Model:", 1)[1].strip()
            continue
        if ln == "Special Offer":
            rec["special_offer"] = True
            continue
        if ln == "Price Drop":
            rec["price_drop"] = True
            continue
        if MANAGER_SPECIAL_RE.search(unglue(ln)):
            # Stores badge these a dozen different ways. They are the cars the
            # house wants gone, so they are usually the ones worth posting
            # first -- which is why they get their own switch.
            rec["managers_special"] = True
            continue

        mm = MILEAGE_RE.match(ln)
        if mm and "mileage" not in rec:
            rec["mileage"] = int(mm.group(1).replace(",", ""))
            continue
        mm = MILEAGE_LABEL_RE.match(ln)
        if mm and "mileage" not in rec:
            num = mm.group(1)
            if not num and i + 1 < len(lines) and re.fullmatch(r"[\d,]+", lines[i + 1]):
                num = lines[i + 1]
            if num:
                rec["mileage"] = int(num.replace(",", ""))
            continue
        if ("mileage" in rec and i > 0 and re.fullmatch(r"[\d,]+", ln)
                and MILEAGE_LABEL_RE.match(lines[i - 1])):
            continue                      # the number under "Mileage:"

        m = TITLE_RE.match(ln)
        if m and "year" not in rec:
            rec["year"] = int(m.group(1))
            rec["model_trim"] = m.group(2).strip()
            # Carsforsale.com puts a style line under the title ("AWD 4dr
            # SUV", "SUPER CAB"). It describes the body, not a feature.
            if i + 1 < len(lines):
                nxt = lines[i + 1]
                if (":" not in nxt and not MONEY_RE.match(nxt)
                        and re.search(r"\b(\dd(oo)?r|suv|sedan|coupe|wagon|van|"
                                      r"cab|crossover|hatchback|convertible|"
                                      r"pickup|truck)\b", nxt, re.I)):
                    rec["style"] = nxt
                    used_below.add(i + 1)
            continue

        # --- price block ----------------------------------------------------
        # The two stores lay this out differently, and getting it wrong is how
        # a $52,886 Lexus came out as a $1,010 Lexus.
        #
        #   Teays Valley           Supercenter
        #   -------------          --------------
        #   $20,352                Savings
        #   Moses Price            - $3,609
        #                          Moses Price
        #                          $15,387
        #
        # Read the line AFTER the label first; fall back to the line before.
        # And never accept a negative number as a price -- a leading minus
        # means it is a discount, not what the customer pays. That single
        # check is what the old code was missing.
        norm = ln.rstrip(":").strip().lower()

        # Label and amount on the SAME line -- "Price: $24,995", "Sale Price
        # $18,400". Some platforms render it this way instead of stacking the
        # label above the number, and reading only the stacked form is how a
        # whole store comes back with no prices on it.
        if norm not in PRICE_FIELDS and ":" in ln:
            head, _, tail = ln.partition(":")
            hkey = head.strip().lower()
            if hkey in PRICE_FIELDS and tail.strip():
                key = PRICE_FIELDS[hkey]
                v = money_at([tail.strip()], 0, key == "savings")
                if v and key not in rec:
                    rec[key] = v
                    continue

        lm = LABEL_MONEY_RE.match(ln)
        if lm and norm not in PRICE_FIELDS:
            hkey = lm.group(1).strip().lower()
            if hkey in PRICE_FIELDS:
                key = PRICE_FIELDS[hkey]
                v = money(lm.group(2))
                if v and key not in rec:
                    rec[key] = v
                continue

        if norm in PRICE_FIELDS:
            key = PRICE_FIELDS[norm]
            negative_ok = key == "savings"
            v = money_at(lines, i + 1, negative_ok)
            if v is None:
                v = money_at(lines, i - 1, negative_ok)
            if v and key not in rec:
                rec[key] = v
            continue

        # Spec labels some platforms print right on the card (Dealer Car
        # Search: "Engine: 3.6L V6", "Trans: Automatic", "Drive: 4WD",
        # "Color: White", "Interior: Cloth"). Read them as the fields they
        # are; before, they landed in the feature list and the ads went out
        # with no colour.
        cm = CARD_SPEC_RE.match(ln)
        if cm:
            label = cm.group(1).lower().replace(".", "").strip()
            val = re.sub(r"^(engine|trans(mission)?)\s*:\s*", "",
                         cm.group(2).strip(), flags=re.I).strip()
            field = CARD_SPEC_FIELDS.get(label)
            if val.strip().lower() in ("n/a", "na", "-", "--", "unknown", "tbd"):
                val = ""
            if field and val and field not in rec and _spec_value_ok(val):
                rec[field] = val
                if field == "interior" and re.search(r"leather", val, re.I):
                    features.append("Leather Seats")
            continue

        # The same labels stacked above their value with no colon
        # (Carsforsale.com: "Exterior Color" on one line, "Gray" below).
        bare = ln.lower().replace(".", "").strip()
        if bare in STACKED_LABELS and i + 1 < len(lines):
            nxt = lines[i + 1]
            nb = nxt.lower().replace(".", "").strip()
            field = CARD_SPEC_FIELDS[bare]
            if nb in ("n/a", "na", "-", "--", "unknown", "tbd"):
                used_below.add(i + 1)
                continue
            if (nb not in CARD_SPEC_FIELDS and not CARD_SPEC_RE.match(nxt)
                    and _spec_value_ok(nxt)
                    and not re.fullmatch(r"[a-z]+(-[a-z]+)+", nxt)
                    and len(nxt) <= 60):
                if field not in rec:
                    rec[field] = nxt
                    if field == "interior" and re.search(r"leather", nxt, re.I):
                        features.append("Leather Seats")
                used_below.add(i + 1)
            continue

        # Buttons that sit on every card ("Make Offer", "Text Us") are not
        # features of the car and must never reach an ad.
        if CTA_RE.match(ln):
            continue
        # Icon names ("exterior-color"), "Call <dealer> about <car>", phone
        # numbers and fuel-economy lines are page furniture, not features.
        if (re.fullmatch(r"[a-z]+(-[a-z]+)+", ln)
                or re.fullmatch(r"[\d,.\s]+", ln)
                or re.match(r"^(call|email|text|chat)\b.*\babout\b", ln, re.I)
                or re.search(r"\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}", ln)
                or re.search(r"\d+\s*city\s*/\s*\d+\s*hwy", ln, re.I)
                or ln.lower() in ("fuel economy", "call", "email", "price",
                                  "mileage", "engine", "transmission",
                                  "drivetrain", "exterior color",
                                  "interior color")):
            continue

        # Everything else that isn't money or a known label is a feature chip
        if ln not in PRICE_LABELS and not MONEY_RE.match(ln) and not ln.startswith("$"):
            if "model_trim" in rec and ln != rec.get("model_trim"):
                if len(ln) < 40 and not ln.startswith("20") and not ln.startswith("19"):
                    features.append(ln)

    if "model_trim" in rec:
        make, model, trim = split_title(rec["model_trim"])
        rec["make"], rec["model"], rec["trim"] = make, tidy(model), tidy(trim)

    # A vehicle with no advertised retail comparison still has a real price.
    if "final_price" not in rec and "moses_price" in rec:
        rec["final_price"] = rec["moses_price"]
    # A card whose only figure is "Retail" is asking that much -- small lots
    # show one price and call it retail. Not done when the card hides its
    # real price behind an "unlock" button, where retail is only the
    # comparison and posting it would overstate the price.
    if ("final_price" not in rec and rec.get("retail_price")
            and "savings" not in rec
            and not re.search(r"unlock|locked|call for|click for",
                              text, re.I)):
        rec["final_price"] = rec["retail_price"]

    # --- check the price against its own arithmetic -------------------------
    # Every card publishes four numbers, and on both stores they reconcile:
    #
    #     retail  -  savings  +  doc fee  =  what the customer pays
    #     $26,999 -  $3,099   +  $575     =  $24,475
    #
    # So we never have to take the price line on faith. A 2022 Outback came
    # through as $244,475 and a Silverado as $418,845 -- a stray digit in the
    # rendered text -- and both were caught by this check, which recomputes the
    # price from the three figures that agreed with each other.
    #
    # Only applied when all three are present, and only when the disagreement
    # is more than a few dollars, since the site's own rounding wanders by a
    # dollar or two.
    retail = rec.get("retail_price")
    savings = rec.get("savings")
    doc = rec.get("doc_fee")
    if retail and savings is not None and doc is not None:
        expected = retail - savings + doc
        if expected > 0:
            for key in ("final_price", "moses_price"):
                v = rec.get(key)
                if v and abs(v - expected) > 5:
                    rec.setdefault("price_as_read", v)
                    rec[key] = expected
                    rec["price_corrected"] = True

    # De-dupe features, preserve order
    seen = set()
    rec["features"] = [f for f in features if not (f in seen or seen.add(f))]

    # Certified is read off the whole card, not line by line: stores put the
    # badge wherever it fits -- its own line, inside the title, or alongside
    # the make ("Chevrolet Certified Pre-Owned").
    unglued = unglue(text)
    if CERTIFIED_RE.search(unglued) or any(
            ln.strip().lower() == "certified" for ln in lines):
        rec["certified"] = True

    # A badge the line-by-line pass missed, usually because it shared a line
    # with another badge.
    if MANAGER_SPECIAL_RE.search(unglued):
        rec["managers_special"] = True

    rec.setdefault("special_offer", False)
    rec.setdefault("price_drop", False)
    rec.setdefault("managers_special", False)
    rec.setdefault("certified", False)
    return rec
