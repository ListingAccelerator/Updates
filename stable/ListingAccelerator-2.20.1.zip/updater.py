"""
updater.py -- the "Update now" button.

How it works
    1. CHECK. Read a small file published next to each release:
           latest.json      {"version": "1.4", "notes": [...], "zip": "...",
                             "sha256": "...", "critical": false}
           latest.json.sig  a signature over latest.json
       The signature is checked against the public key built into this file.
       Only the holder of the matching private key -- the publisher's update
       channel -- can produce one, so nobody else can push an update to a
       customer's computer.
    2. INSTALL. Download the zip, check its SHA-256 against the signed
       latest.json, check every file in it is a program file (no settings,
       no out\\, no Photo Drop, no paths that climb out of the folder),
       back up the current program files, put the new ones in place.
       Anything goes wrong -> the backup is put straight back.
    3. ROLL BACK. The previous version is kept in program\\_backup\\ and can
       be restored from the window.

Nothing about the customer is sent anywhere: the check is a plain download of
latest.json.
"""
from __future__ import annotations

import hashlib
import io
import json
import shutil
import time
import urllib.request
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
VERSION_FILE = HERE / "version.txt"
BACKUP_DIR = HERE / "_backup"
STATE_FILE = HERE / "_backup" / "update_state.json"

# Where updates come from, and the key every update must be signed with.
# The matching private key lives only as a GitHub secret on that channel.
UPDATE_BASE = "https://raw.githubusercontent.com/ListingAccelerator/updates/main/stable"
PUBLIC_KEY_HEX = "3071f25cb599b2a990828cea5e1c3112a06b1c7f390c0c8a362f46179a1e2b89"

UA = "ListingAccelerator-Updater"
ALLOWED = {".py", ".html", ".ico", ".txt", ".css", ".js", ".json", ".png",
           ".pdf", ".bat", ".onnx"}
NEVER = {"settings.json", "config_local.py"}          # the customer's own
KEEP_BACKUPS = 3


# ---------------------------------------------------------------- versions
def current_version() -> str:
    try:
        return VERSION_FILE.read_text(encoding="utf-8").strip() or "1.0"
    except OSError:
        return "1.0"


def _vtuple(v: str):
    out = []
    for part in str(v).strip().split("."):
        try:
            out.append(int(part))
        except ValueError:
            out.append(0)
    return tuple(out + [0] * (4 - len(out)))


def newer(a: str, b: str) -> bool:
    """Is version a newer than version b?"""
    return _vtuple(a) > _vtuple(b)


# ------------------------------------------------------------ ed25519 verify
# RFC 8032 reference arithmetic. Pure Python so nothing extra has to be
# installed on the customer's computer; it only ever checks one signature.
_p = 2 ** 255 - 19
_L = 2 ** 252 + 27742317777372353535851937790883648493
_d = -121665 * pow(121666, _p - 2, _p) % _p
_I = pow(2, (_p - 1) // 4, _p)


def _xrecover(y):
    xx = (y * y - 1) * pow(_d * y * y + 1, _p - 2, _p)
    x = pow(xx, (_p + 3) // 8, _p)
    if (x * x - xx) % _p:
        x = x * _I % _p
    if x % 2:
        x = _p - x
    return x


_By = 4 * pow(5, _p - 2, _p) % _p
_B = (_xrecover(_By), _By, 1, _xrecover(_By) * _By % _p)


def _add(P, Q):
    x1, y1, z1, t1 = P
    x2, y2, z2, t2 = Q
    A = (y1 - x1) * (y2 - x2) % _p
    Bv = (y1 + x1) * (y2 + x2) % _p
    C = t1 * 2 * _d * t2 % _p
    D = z1 * 2 * z2 % _p
    E, F, G, H = Bv - A, D - C, D + C, Bv + A
    return (E * F % _p, G * H % _p, F * G % _p, E * H % _p)


def _mul(P, e):
    Q = (0, 1, 1, 0)
    while e:
        if e & 1:
            Q = _add(Q, P)
        P = _add(P, P)
        e >>= 1
    return Q


def _eq(P, Q):
    return (P[0] * Q[2] - Q[0] * P[2]) % _p == 0 and \
           (P[1] * Q[2] - Q[1] * P[2]) % _p == 0


def _decode_point(s: bytes):
    if len(s) != 32:
        raise ValueError("bad point")
    y = int.from_bytes(s, "little") & ((1 << 255) - 1)
    if y >= _p:
        raise ValueError("bad point")
    x = _xrecover(y)
    if (x & 1) != (s[31] >> 7):
        x = _p - x
    P = (x, y, 1, x * y % _p)
    if (-x * x + y * y - 1 - _d * x * x * y * y) % _p:
        raise ValueError("not on curve")
    return P


def verify(public_key: bytes, message: bytes, signature: bytes) -> bool:
    try:
        if len(signature) != 64:
            return False
        A = _decode_point(public_key)
        R = _decode_point(signature[:32])
        S = int.from_bytes(signature[32:], "little")
        if S >= _L:
            return False
        h = int.from_bytes(hashlib.sha512(signature[:32] + public_key
                                          + message).digest(), "little") % _L
        return _eq(_mul(_B, S), _add(R, _mul(A, h)))
    except Exception:
        return False


# ------------------------------------------------------------------ network
def _get(url: str, timeout: int = 30) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": UA,
                                               "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def enabled() -> bool:
    return bool(UPDATE_BASE and PUBLIC_KEY_HEX)


def check(base: str | None = None, key_hex: str | None = None) -> dict:
    """
    {"available": bool, "current": "1.3", "version": "1.4", "notes": [...],
     "critical": bool, "error": "..."}
    Never raises: a failed check just means "no update shown today".
    """
    base = (base or UPDATE_BASE).rstrip("/")
    key_hex = key_hex or PUBLIC_KEY_HEX
    cur = current_version()
    out = {"available": False, "current": cur}
    if not base or not key_hex:
        out["error"] = "updates not set up"
        return out
    try:
        raw = _get(f"{base}/latest.json")
        sig = _get(f"{base}/latest.json.sig")
        sig = bytes.fromhex(sig.decode("ascii").strip())
    except Exception as e:
        out["error"] = f"couldn't reach the update channel ({type(e).__name__})"
        return out
    if not verify(bytes.fromhex(key_hex), raw, sig):
        out["error"] = "an update was offered that isn't signed by the publisher -- ignored"
        return out
    try:
        info = json.loads(raw.decode("utf-8"))
    except ValueError:
        out["error"] = "update information was unreadable"
        return out
    out.update(version=str(info.get("version", "")),
               notes=list(info.get("notes") or []),
               critical=bool(info.get("critical")),
               _info=info)
    out["available"] = newer(out["version"], cur)
    return out


# ------------------------------------------------------------------ install
def _safe_names(z: zipfile.ZipFile) -> list[str]:
    names = []
    for n in z.namelist():
        if n.endswith("/"):
            continue
        p = Path(n)
        if p.is_absolute() or ".." in p.parts or len(p.parts) > 3:
            raise ValueError(f"unsafe path in update: {n}")
        if p.parts and p.parts[0].lower() in ("out", "photo drop", "_backup",
                                               "stores", "customers", "media"):
            raise ValueError(f"update tried to touch your data: {n}")
        if p.name.lower() in NEVER:
            raise ValueError(f"update tried to replace your settings: {n}")
        if p.suffix.lower() not in ALLOWED:
            raise ValueError(f"unexpected file type in update: {n}")
        names.append(n)
    if "app.py" not in {Path(n).name for n in names}:
        raise ValueError("update is missing the program itself")
    return names


def _backup(names: list[str], version: str) -> Path:
    dest = BACKUP_DIR / f"v{version}-{time.strftime('%Y%m%d-%H%M%S')}"
    dest.mkdir(parents=True, exist_ok=True)
    keep = set(names)
    # everything that is a program file now, plus anything the update will
    # write -- so a rollback restores exactly what was there
    for f in HERE.iterdir():
        if f.is_file() and f.suffix.lower() in ALLOWED \
                and f.name.lower() not in NEVER:
            keep.add(f.name)
    manifest = []
    for n in sorted(keep):
        src = HERE / n
        if src.is_file():
            (dest / n).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dest / n)
            manifest.append({"name": n, "existed": True})
        else:
            manifest.append({"name": n, "existed": False})
    (dest / "_backup_manifest.json").write_text(
        json.dumps({"version": version, "files": manifest}), encoding="utf-8")
    return dest


def _restore(backup: Path) -> None:
    m = json.loads((backup / "_backup_manifest.json").read_text(encoding="utf-8"))
    for f in m["files"]:
        target = HERE / f["name"]
        if f["existed"]:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(backup / f["name"], target)
        elif target.exists():
            target.unlink()
    VERSION_FILE.write_text(m["version"], encoding="utf-8")


def _prune():
    olds = sorted([d for d in BACKUP_DIR.glob("v*") if d.is_dir()],
                  key=lambda d: d.stat().st_mtime, reverse=True)
    for d in olds[KEEP_BACKUPS:]:
        shutil.rmtree(d, ignore_errors=True)


def install(found: dict, progress=print, base: str | None = None) -> dict:
    """found = the dict check() returned. Returns {"ok": bool, "message": str}."""
    info = found.get("_info") or {}
    base = (base or UPDATE_BASE).rstrip("/")
    ver = str(info.get("version", ""))
    zip_url = info.get("zip", "")
    if zip_url and not zip_url.startswith("http"):
        zip_url = f"{base}/{zip_url}"
    want = str(info.get("sha256", "")).lower()
    if not (ver and zip_url and want):
        return {"ok": False, "message": "The update information is incomplete."}

    progress("Downloading")
    try:
        data = _get(zip_url, timeout=120)
    except Exception:
        return {"ok": False, "message": "Couldn't download the update. "
                "Check the internet connection and try again."}
    progress(f"Downloaded ({len(data) / 1e6:.1f} MB)")
    if hashlib.sha256(data).hexdigest() != want:
        return {"ok": False, "message": "The download didn't match the signed "
                "update, so it was not installed. Nothing changed."}
    progress("Checked it really came from the publisher")

    try:
        z = zipfile.ZipFile(io.BytesIO(data))
        names = _safe_names(z)
    except Exception as e:
        return {"ok": False, "message": f"The update was refused: {e}. "
                "Nothing changed."}

    cur = current_version()
    backup = _backup(names, cur)
    progress(f"Saved a backup of version {cur}")

    progress("Putting the new files in place")
    try:
        for n in names:
            target = HERE / n
            target.parent.mkdir(parents=True, exist_ok=True)
            tmp = target.with_name(target.name + ".new")
            tmp.write_bytes(z.read(n))
            tmp.replace(target)
        VERSION_FILE.write_text(ver, encoding="utf-8")
    except Exception as e:
        try:
            _restore(backup)
        except Exception:
            pass
        return {"ok": False, "message": f"The update didn't finish ({type(e).__name__}), "
                f"so version {cur} was put back. Nothing was lost."}

    try:
        STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
        STATE_FILE.write_text(json.dumps({"installed": ver, "previous": cur,
                                          "backup": backup.name,
                                          "when": time.time()}), encoding="utf-8")
    except OSError:
        pass
    _prune()
    progress(f"Updated to version {ver}")
    return {"ok": True, "message": f"Updated to version {ver}.", "version": ver,
            "previous": cur}


def rollback() -> dict:
    try:
        st = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        backup = BACKUP_DIR / st["backup"]
        _restore(backup)
        STATE_FILE.unlink(missing_ok=True)
        return {"ok": True, "message": f"Back on version {st['previous']}."}
    except Exception:
        return {"ok": False, "message": "There's no earlier version to go back to."}


# -------------------------------------------------------------- "Later"
def snoozed(version: str) -> bool:
    try:
        st = json.loads((BACKUP_DIR / "snooze.json").read_text(encoding="utf-8"))
        return st.get("version") == version and time.time() < st.get("until", 0)
    except Exception:
        return False


def snooze(version: str, hours: int = 20) -> None:
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    (BACKUP_DIR / "snooze.json").write_text(
        json.dumps({"version": version, "until": time.time() + hours * 3600}),
        encoding="utf-8")
