"""
First-run setup window.

The program needs two pieces fetched from the internet before it can run, and
a customer should not be watching a black command window scroll past to get
them. This is a small installer window: a bar, a sentence about what is
happening, and a Details panel for anyone who wants it.

It cannot use the program's own window library -- that is one of the things it
is installing -- so it is built with the toolkit that ships inside Python.

MARKETPLACE.bat runs this when the .ready marker is missing. On success it
writes the marker and opens the program.
"""
from __future__ import annotations

import subprocess
import sys
import threading
import queue
from pathlib import Path

import tkinter as tk
from tkinter import font as tkfont
from tkinter import ttk

HERE = Path(__file__).resolve().parent
READY = HERE / ".ready"

NAVY = "#00305F"
NAVY_LT = "#A9C4DD"
PAPER = "#EEF1F4"
CARD = "#FFFFFF"
INK = "#14181D"
MUTED = "#5C6671"
RULE = "#D9DEE5"
BAD = "#B3261E"

STEPS = [
    ("Fetching the program's window library",
     [sys.executable, "-m", "pip", "install", "pywebview", "playwright"]),
    ("Fetching the browser it reads the website with",
     [sys.executable, "-m", "playwright", "install", "chromium"]),
]

NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


class Setup(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Listing Accelerator")
        self.configure(bg=CARD)
        self.resizable(False, False)

        fam = "Segoe UI"
        self.f_h = tkfont.Font(family=fam, size=15, weight="bold")
        self.f_b = tkfont.Font(family=fam, size=10)
        self.f_s = tkfont.Font(family=fam, size=9)
        self.f_m = tkfont.Font(family="Consolas", size=9)

        self.q: queue.Queue = queue.Queue()
        self.failed = False
        self.shown = False

        self._build()
        self._centre(560, 268)
        self.after(400, self.start)
        self.after(120, self._drain)

    def _centre(self, w, h):
        self.update_idletasks()
        x = (self.winfo_screenwidth() - w) // 2
        y = (self.winfo_screenheight() - h) // 3
        self.geometry(f"{w}x{h}+{x}+{y}")

    def _build(self):
        band = tk.Frame(self, bg=NAVY)
        band.pack(fill="x")
        pad = tk.Frame(band, bg=NAVY)
        pad.pack(fill="x", padx=26, pady=18)
        tk.Label(pad, text="Setting up Listing Accelerator", font=self.f_h,
                 bg=NAVY, fg="#FFFFFF", anchor="w").pack(anchor="w")
        tk.Label(pad, text="This happens once. It takes a few minutes.",
                 font=self.f_b, bg=NAVY, fg=NAVY_LT, anchor="w").pack(
                     anchor="w", pady=(4, 0))

        body = tk.Frame(self, bg=CARD)
        body.pack(fill="both", expand=True, padx=26, pady=22)

        self.step = tk.Label(body, text="Starting", font=self.f_b, bg=CARD,
                             fg=INK, anchor="w")
        self.step.pack(fill="x")

        self.bar = ttk.Progressbar(body, mode="indeterminate", length=508)
        self.bar.pack(fill="x", pady=(12, 10))
        self.bar.start(14)

        self.note = tk.Label(body, text="Leave this window open. While you "
                                        "wait, read the instructions — it "
                                        "takes five minutes and covers "
                                        "everything.",
                             font=self.f_s, bg=CARD, fg=MUTED, anchor="w",
                             justify="left", wraplength=508)
        self.note.pack(fill="x")

        # The few minutes of setup is the one moment he is sitting there with
        # nothing to do. Put the instructions in front of him right then.
        self.read = tk.Button(body, text="Read the instructions",
                              font=self.f_b, bg=PAPER, fg=NAVY,
                              activebackground="#E3E9EE", activeforeground=NAVY,
                              relief="flat", bd=0, padx=16, pady=8,
                              cursor="hand2", command=self.open_instructions)
        self.read.pack(anchor="w", pady=(14, 0))

        foot = tk.Frame(self, bg=CARD)
        foot.pack(fill="x", padx=26, pady=(0, 18))

        self.more = tk.Button(foot, text="Details", font=self.f_s, bg=CARD,
                              fg=MUTED, activebackground=PAPER, relief="flat",
                              bd=0, padx=10, pady=6, cursor="hand2",
                              command=self.toggle)
        self.more.pack(side="left")

        self.again = tk.Button(foot, text="Try again", font=self.f_b, bg=NAVY,
                               fg="#FFFFFF", activebackground="#002247",
                               activeforeground="#FFFFFF", relief="flat",
                               bd=0, padx=18, pady=8, cursor="hand2",
                               command=self.retry)

        self.logwrap = tk.Frame(self, bg=CARD)
        tk.Frame(self.logwrap, bg=RULE, height=1).pack(fill="x")
        self.log = tk.Text(self.logwrap, height=10, bg="#FBFCFD", fg=MUTED,
                           font=self.f_m, relief="flat", wrap="word",
                           padx=20, pady=12, highlightthickness=0)
        self.log.pack(fill="both", expand=True)

    def open_instructions(self):
        """Open the printable instructions without Windows asking anything."""
        import webbrowser, subprocess, os
        for name in ("Instructions.html", "Instructions.pdf",
                     "Read me first.txt"):
            f = HERE.parent / name
            if not f.exists():
                continue
            # Windows asks the user to pick a program when no browser is the
            # default. Find one ourselves first.
            cands = [
                r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
                r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe",
                r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
                r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
            ]
            cands = [os.path.expandvars(c) for c in cands]
            cands = [c for c in cands if "%" not in c]
            for exe in cands:
                if os.path.exists(exe):
                    try:
                        subprocess.Popen([exe, f.as_uri()])
                        return
                    except Exception:
                        break
            try:
                webbrowser.open(f.as_uri())
            except Exception:
                pass
            return

    def toggle(self):
        self.shown = not self.shown
        if self.shown:
            self.logwrap.pack(fill="both", expand=True)
            self._centre(560, 540)
            self.more.config(text="Hide details")
        else:
            self.logwrap.pack_forget()
            self._centre(560, 268)
            self.more.config(text="Details")

    # --- running -----------------------------------------------------------
    def start(self):
        self.failed = False
        self.again.pack_forget()
        self.bar.config(mode="indeterminate")
        self.bar.start(14)
        threading.Thread(target=self._worker, daemon=True).start()

    def retry(self):
        self.log.delete("1.0", "end")
        self.note.config(text="Leave this window open.", fg=MUTED)
        self.start()

    def _worker(self):
        for i, (label, cmd) in enumerate(STEPS, start=1):
            self.q.put(("step", f"{label}   ({i} of {len(STEPS)})"))
            self.q.put(("log", f"\n--- {label} ---\n"))
            try:
                proc = subprocess.Popen(
                    cmd, cwd=str(HERE), stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT, text=True, bufsize=1,
                    creationflags=NO_WINDOW)
            except Exception as e:
                self.q.put(("fail", str(e)))
                return
            for line in proc.stdout:
                self.q.put(("log", line))
            if proc.wait() != 0:
                self.q.put(("fail",
                            "That download didn't go through. Check you're "
                            "online and try again.\n\nOn a dealership network "
                            "it may be blocked — a phone hotspot usually "
                            "works."))
                return
        self.q.put(("done", None))

    def _drain(self):
        try:
            while True:
                kind, payload = self.q.get_nowait()
                if kind == "log":
                    self.log.insert("end", payload)
                    self.log.see("end")
                elif kind == "step":
                    self.step.config(text=payload)
                elif kind == "fail":
                    self.failed = True
                    self.bar.stop()
                    self.bar.config(mode="determinate", value=0)
                    self.step.config(text="Setup didn't finish", fg=BAD)
                    self.note.config(text=payload, fg=INK)
                    self.again.pack(side="right")
                elif kind == "done":
                    self.bar.stop()
                    self.bar.config(mode="determinate", maximum=1, value=1)
                    self.step.config(text="Ready")
                    self.note.config(text="Opening Listing Accelerator.")
                    READY.write_text("ready", encoding="utf-8")
                    self.after(900, self.launch)
        except queue.Empty:
            pass
        self.after(120, self._drain)

    def launch(self):
        exe = sys.executable
        if exe.lower().endswith("python.exe"):
            w = Path(exe).with_name("pythonw.exe")
            if w.exists():
                exe = str(w)
        # A brand new copy does not know whose store it is yet, so the setup
        # screen comes before the program itself.
        nxt = "app.py" if (HERE / "settings.json").exists() else "wizard.py"
        try:
            subprocess.Popen([exe, str(HERE / nxt)], cwd=str(HERE),
                             creationflags=NO_WINDOW)
        except Exception:
            pass
        self.destroy()


if __name__ == "__main__":
    Setup().mainloop()
