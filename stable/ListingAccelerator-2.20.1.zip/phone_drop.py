"""
From my phone: photos and videos go straight from a salesperson's phone into
the program over the Wi-Fi, by scanning a QR code. Nothing to install on the
phone (iPhone or Android, its own browser).

How it works: the program opens a small receiving page on this computer, on
the local network only, behind a one-time code that runs out after 15
minutes. The phone opens that page from the QR code, the salesperson picks
photos/videos and presses Send, and each file is saved where the screen that
asked for it wants it (the car's folder, the customer's trade photos, the
headshot). Nothing goes to the internet.
"""
from __future__ import annotations

import html
import json
import re
import secrets
import shutil
import socket
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import config

PORTS = range(8770, 8780)
LIFE = 15 * 60                 # seconds a code works
MAX_BYTES = 3 * 1024 ** 3      # 3 GB per file is plenty for a phone video
PHOTO_EXT = {".jpg", ".jpeg", ".png", ".webp", ".heic", ".heif", ".gif"}
VIDEO_EXT = {".mp4", ".mov", ".m4v", ".3gp", ".webm", ".avi", ".mkv"}

_lock = threading.RLock()
_server = None
_port = 0
_sessions: dict[str, dict] = {}


# --- the computer's address on the Wi-Fi -------------------------------------
def lan_ip() -> str:
    """The address phones on the same Wi-Fi reach this computer at."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))        # no packet is sent
        ip = s.getsockname()[0]
        s.close()
        if not ip.startswith("127."):
            return ip
    except Exception:
        pass
    try:
        for ip in socket.gethostbyname_ex(socket.gethostname())[2]:
            if not ip.startswith("127."):
                return ip
    except Exception:
        pass
    return ""


def _ensure_server() -> int:
    global _server, _port
    with _lock:
        if _server:
            return _port
        last = None
        for p in PORTS:
            try:
                srv = ThreadingHTTPServer(("0.0.0.0", p), _Handler)
                srv.daemon_threads = True
                threading.Thread(target=srv.serve_forever, daemon=True).start()
                _server, _port = srv, p
                return p
            except OSError as e:
                last = e
        raise OSError(f"No free port for the phone page ({last})")


# --- sessions -----------------------------------------------------------------
def start(target: dict) -> dict:
    """
    target: {"kind": "car" | "trade" | "headshot",
             "folder": where files go (car / trade), "stock", "cid",
             "label": shown on the phone, "accept": "both" | "photos" | "video"}
    """
    ip = lan_ip()
    if not ip:
        return {"ok": False, "message": "This computer isn't on a Wi-Fi or network right now. "
                "Connect it to the same Wi-Fi as your phone."}
    try:
        port = _ensure_server()
    except OSError as e:
        return {"ok": False, "message": str(e)}
    tok = secrets.token_urlsafe(6).replace("-", "x").replace("_", "y")
    with _lock:
        for k in [k for k, s in _sessions.items() if s["expires"] < time.time()]:
            _sessions.pop(k, None)
        _sessions[tok] = {"target": dict(target), "expires": time.time() + LIFE,
                          "received": [], "busy": 0}
    url = f"http://{ip}:{port}/p/{tok}"
    import qr
    return {"ok": True, "token": tok, "url": url, "qr": qr.png_data_uri(url, 7),
            "minutes": LIFE // 60}


def status(tok: str) -> dict:
    with _lock:
        s = _sessions.get(tok)
        if not s:
            return {"ok": False, "gone": True}
        return {"ok": True, "received": list(s["received"]), "busy": s["busy"],
                "left": max(0, int(s["expires"] - time.time()))}


def stop(tok: str) -> None:
    with _lock:
        _sessions.pop(tok, None)


def _session(tok: str):
    with _lock:
        s = _sessions.get(tok)
        if s and s["expires"] >= time.time():
            return s
    return None


# --- saving -------------------------------------------------------------------
def _next(folder: Path, stem: str, ext: str) -> Path:
    nums = [int(m.group(1)) for p in folder.glob(f"{stem}_*")
            if (m := re.match(rf"{stem}_(\d+)", p.stem))]
    return folder / f"{stem}_{max(nums or [0]) + 1:02d}{ext}"


def _open_image(path: Path):
    from PIL import Image, ImageOps
    if path.suffix.lower() in (".heic", ".heif"):
        try:
            import pillow_heif
            pillow_heif.register_heif_opener()
        except Exception:
            pass
    return ImageOps.exif_transpose(Image.open(path))


def _thumb(path: Path, is_video: bool) -> str:
    import base64
    import io
    try:
        if is_video:
            try:
                import walkaround
                jpg = walkaround.video_thumb(path, 1.0)
                return "data:image/jpeg;base64," + base64.b64encode(jpg).decode() if jpg else ""
            except Exception:
                return ""
        im = _open_image(path).convert("RGB")
        im.thumbnail((240, 240))
        b = io.BytesIO()
        im.save(b, "JPEG", quality=75)
        return "data:image/jpeg;base64," + base64.b64encode(b.getvalue()).decode()
    except Exception:
        return ""


def _place(tmp: Path, original: str, target: dict) -> dict:
    """Move one received file to where the screen wants it."""
    ext = Path(original).suffix.lower() or ".jpg"
    is_video = ext in VIDEO_EXT
    kind = target.get("kind", "car")
    if kind == "headshot":
        if is_video:
            raise ValueError("A headshot has to be a photo.")
        im = _open_image(tmp)
        im.thumbnail((1600, 1600))
        dest = Path(config.BASE) / "my headshot.jpg"
        im.convert("RGB").save(dest, "JPEG", quality=92)
        try:
            import social
            social.save_settings({"headshot": str(dest)})
        except Exception:
            pass
    else:
        folder = Path(target["folder"])
        folder.mkdir(parents=True, exist_ok=True)
        if is_video:
            dest = _next(folder, "my_video" if kind == "car" else "trade_video", ext)
            shutil.move(str(tmp), dest)
        else:
            im = _open_image(tmp).convert("RGB")
            im.thumbnail((2400, 2400))
            dest = _next(folder, "my" if kind == "car" else "trade", ".jpg")
            im.save(dest, "JPEG", quality=92)
    return {"name": dest.name, "path": str(dest), "video": is_video,
            "uri": _thumb(dest, is_video)}


# --- the page on the phone ---------------------------------------------------
_PAGE = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<title>Send to Listing Accelerator</title><style>
*{box-sizing:border-box}body{margin:0;font-family:-apple-system,"Segoe UI",Roboto,Arial,sans-serif;background:#F2F4F7;color:#14181D}
.h{background:#00305F;color:#fff;padding:16px 18px}.h b{font-size:18px;display:block}.h span{color:#C9D6EA;font-size:14px}
.in{padding:16px;display:flex;flex-direction:column;gap:12px}
label.big{display:block;background:#00305F;color:#fff;border-radius:14px;padding:16px;text-align:center;font-weight:700;font-size:17px}
label.big.l{background:#fff;color:#00305F;border:2px solid #00305F}
input[type=file]{display:none}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}
.t{position:relative;aspect-ratio:1;border-radius:8px;overflow:hidden;background:#DDE2E8}
.t img,.t video{width:100%;height:100%;object-fit:cover}
.t .s{position:absolute;left:0;right:0;bottom:0;height:6px;background:rgba(255,255,255,.6)}
.t .s i{display:block;height:100%;width:0;background:#00305F}
.t .ok{position:absolute;right:5px;top:5px;background:#1E8E5A;color:#fff;border-radius:50%;width:22px;height:22px;text-align:center;line-height:22px;font-weight:700;font-size:13px;display:none}
.t.done .ok{display:block}.t.bad{outline:3px solid #C0392B}
.t .v{position:absolute;left:5px;top:5px;background:rgba(0,0,0,.6);color:#fff;font-size:11px;border-radius:6px;padding:1px 5px}
button{border:0;background:#1E8E5A;color:#fff;border-radius:14px;padding:16px;font-weight:800;font-size:17px;width:100%}
button:disabled{background:#9DB8A9}
.n{font-size:13px;color:#5C6671;text-align:center;line-height:1.45}
.msg{font-weight:700;text-align:center;font-size:16px}
</style></head><body>
<div class="h"><b>Send to Listing Accelerator</b><span>__LABEL__</span></div>
<div class="in">
 <label class="big">📷 Take a photo or video<input id="cam" type="file" accept="__ACCEPT__" capture="environment"></label>
 <label class="big l">🖼 Choose from my photos<input id="pick" type="file" accept="__ACCEPT__" multiple></label>
 <div class="n" id="cnt">Pick as many as you like.</div>
 <div class="grid" id="grid"></div>
 <button id="send" disabled>Send to the computer</button>
 <div class="msg" id="msg"></div>
 <div class="n">Full quality. Nothing is posted anywhere — they only go to your computer.</div>
</div>
<script>
const files = [], grid = document.getElementById("grid"), send = document.getElementById("send");
function add(list){
  for (const f of list){
    const i = files.length; files.push(f);
    const d = document.createElement("div"); d.className = "t"; d.id = "t" + i;
    const url = URL.createObjectURL(f);
    d.innerHTML = (f.type.startsWith("video") ? '<video muted playsinline src="' + url + '#t=0.5"></video><span class="v">video</span>' : '<img src="' + url + '">')
      + '<span class="s"><i></i></span><span class="ok">✓</span>';
    grid.appendChild(d);
  }
  const left = files.filter(f => !f.sent).length;
  document.getElementById("cnt").textContent = left + " picked";
  send.disabled = !left; send.textContent = left ? "Send " + left + " to the computer" : "Send to the computer";
}
document.getElementById("cam").onchange = e => add(e.target.files);
document.getElementById("pick").onchange = e => add(e.target.files);
function up(f, i){
  return new Promise(res => {
    const x = new XMLHttpRequest();
    x.open("POST", location.pathname + "/up?n=" + encodeURIComponent(f.name || ("photo" + i + ".jpg")));
    x.setRequestHeader("Content-Type", "application/octet-stream");
    const bar = document.querySelector("#t" + i + " .s i");
    x.upload.onprogress = e => { if (e.lengthComputable) bar.style.width = (e.loaded / e.total * 100) + "%"; };
    x.onload = () => { let ok = false, m = ""; try { const r = JSON.parse(x.responseText); ok = r.ok; m = r.message || ""; } catch (e) {}
      document.getElementById("t" + i).classList.add(ok ? "done" : "bad"); res({ok, m}); };
    x.onerror = () => { document.getElementById("t" + i).classList.add("bad"); res({ok: false, m: "Lost the connection to the computer."}); };
    x.send(f);
  });
}
send.onclick = async () => {
  send.disabled = true; let good = 0, last = "";
  for (let i = 0; i < files.length; i++){
    if (files[i].sent) continue;
    send.textContent = "Sending " + (i + 1) + " of " + files.length + "…";
    const r = await up(files[i], i);
    if (r.ok){ files[i].sent = true; good++; } else last = r.m;
  }
  const left = files.filter(f => !f.sent).length;
  document.getElementById("msg").textContent = good ? "✓ " + good + " sent to the computer" + (left ? " · " + left + " didn't go — press Send to try again" : "") : (last || "Nothing went through.");
  if (last && good) document.getElementById("msg").textContent += " (" + last + ")";
  send.disabled = !left; send.textContent = left ? "Send " + left + " again" : "Done — pick more if you like";
  document.getElementById("cnt").textContent = left ? left + " still to send" : "All sent ✓";
};
</script></body></html>"""

_GONE = """<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{font-family:-apple-system,Arial,sans-serif;padding:30px;text-align:center;color:#14181D}</style></head>
<body><h2>This code ran out</h2><p>Press <b>📱 From my phone</b> in Listing Accelerator again and scan the new code.</p></body></html>"""


class _Handler(BaseHTTPRequestHandler):
    server_version = "ListingAccelerator"

    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="text/html; charset=utf-8"):
        data = body.encode() if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _json(self, code, obj):
        self._send(code, json.dumps(obj), "application/json")

    def do_GET(self):
        m = re.fullmatch(r"/p/([A-Za-z0-9]{4,20})/?", urllib.parse.urlparse(self.path).path)
        if not m:
            return self._send(404, "Not here.")
        s = _session(m.group(1))
        if not s:
            return self._send(410, _GONE)
        t = s["target"]
        accept = {"photos": "image/*", "video": "video/*"}.get(t.get("accept"), "image/*,video/*")
        page = (_PAGE.replace("__LABEL__", html.escape(t.get("label") or ""))
                     .replace("__ACCEPT__", accept))
        self._send(200, page)

    def do_POST(self):
        u = urllib.parse.urlparse(self.path)
        m = re.fullmatch(r"/p/([A-Za-z0-9]{4,20})/up", u.path)
        if not m:
            return self._json(404, {"ok": False})
        tok = m.group(1)
        s = _session(tok)
        if not s:
            return self._json(410, {"ok": False, "message": "This code ran out. Scan the new one."})
        name = urllib.parse.parse_qs(u.query).get("n", ["photo.jpg"])[0]
        name = re.sub(r"[^\w.\- ]", "_", Path(name).name)[:80] or "photo.jpg"
        ext = Path(name).suffix.lower()
        t = s["target"]
        allowed = PHOTO_EXT | (VIDEO_EXT if t.get("accept") != "photos" else set())
        if t.get("accept") == "video":
            allowed = VIDEO_EXT
        if ext not in allowed:
            return self._json(415, {"ok": False, "message": f"{name} isn't a photo or video the program can use."})
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        if length <= 0 or length > MAX_BYTES:
            return self._json(413, {"ok": False, "message": f"{name} is too big or empty."})
        inbox = Path(config.BASE) / "phone inbox"
        inbox.mkdir(parents=True, exist_ok=True)
        tmp = inbox / f"{tok}-{secrets.token_hex(4)}{ext}"
        with _lock:
            s["busy"] += 1
        try:
            left = length
            with open(tmp, "wb") as f:
                while left > 0:
                    chunk = self.rfile.read(min(1 << 20, left))
                    if not chunk:
                        break
                    f.write(chunk)
                    left -= len(chunk)
            if left > 0:
                raise ValueError("The upload stopped partway.")
            got = _place(tmp, name, t)
            with _lock:
                s["received"].append(got)
            self._json(200, {"ok": True})
        except Exception as e:
            self._json(500, {"ok": False, "message": f"Couldn't save {name}: {e}"})
        finally:
            with _lock:
                s["busy"] -= 1
            try:
                if tmp.exists():
                    tmp.unlink()
            except Exception:
                pass


# --- the other way: a phone folder that syncs through the internet -----------
# OneDrive "Camera upload", iCloud for Windows, or a Google Drive folder put
# the phone's photos in a folder on this computer. When the store's network
# keeps the phone and computer apart, pick from there instead.
def _folder_file() -> Path:
    return Path(config.BASE) / "phone folder.json"


def folder_saved() -> str:
    try:
        return json.loads(_folder_file().read_text(encoding="utf-8")).get("folder", "")
    except Exception:
        return ""


def folder_set(path: str) -> dict:
    p = Path(str(path or ""))
    if path and not p.is_dir():
        return {"ok": False, "message": "That folder isn't there."}
    _folder_file().write_text(json.dumps({"folder": str(p) if path else ""}), encoding="utf-8")
    return {"ok": True}


def folder_candidates() -> list[dict]:
    """Phone-photo folders found on this computer."""
    import os
    home = Path.home()
    roots = [home]
    for k in ("OneDrive", "OneDriveConsumer", "OneDriveCommercial"):
        if os.environ.get(k):
            roots.append(Path(os.environ[k]))
    roots += [p for p in home.glob("OneDrive*") if p.is_dir()]
    found, seen = [], set()

    def add(p: Path, label: str):
        try:
            if p.is_dir() and str(p).lower() not in seen:
                seen.add(str(p).lower())
                found.append({"path": str(p), "label": label})
        except Exception:
            pass
    for r in roots:
        for sub in ("Pictures/Camera Roll", "Pictures/Samsung Gallery/DCIM/Camera", "Pictures/Camera imports",
                    "Bilder/Eigene Aufnahmen"):
            add(r / sub, "OneDrive camera upload" if "onedrive" in str(r).lower() else "Pictures")
    add(home / "Pictures" / "iCloud Photos" / "Photos", "iCloud Photos (iPhone)")
    add(home / "iCloudPhotos" / "Photos", "iCloud Photos (iPhone)")
    for drive in "GHIJ":
        add(Path(f"{drive}:/My Drive"), "Google Drive")
    return found


def folder_recent(path: str = "", hours: int = 72, limit: int = 40) -> list[dict]:
    folder = Path(path or folder_saved())
    if not folder.is_dir():
        return []
    cut = time.time() - hours * 3600
    files = []
    try:
        for p in folder.rglob("*"):
            ext = p.suffix.lower()
            if ext in PHOTO_EXT or ext in VIDEO_EXT:
                try:
                    m = p.stat().st_mtime
                except OSError:
                    continue
                if m >= cut:
                    files.append((m, p))
            if len(files) > 2000:
                break
    except Exception:
        pass
    files.sort(reverse=True)
    out = []
    for m, p in files[:limit]:
        vid = p.suffix.lower() in VIDEO_EXT
        out.append({"path": str(p), "name": p.name, "video": vid,
                    "when": time.strftime("%b %d %I:%M %p", time.localtime(m)).replace(" 0", " "),
                    "uri": "" if vid else _thumb(p, False)})
    return out


def take(target: dict, paths: list[str]) -> dict:
    """Bring picked files from the phone folder in, the same as a phone send."""
    inbox = Path(config.BASE) / "phone inbox"
    inbox.mkdir(parents=True, exist_ok=True)
    got, bad = [], []
    for s in paths or []:
        src = Path(str(s))
        if not src.is_file():
            bad.append(src.name)
            continue
        tmp = inbox / f"f-{secrets.token_hex(4)}{src.suffix.lower()}"
        try:
            shutil.copy2(src, tmp)          # the original stays in OneDrive / iCloud
            got.append(_place(tmp, src.name, target))
        except Exception:
            bad.append(src.name)
        finally:
            try:
                if tmp.exists():
                    tmp.unlink()
            except Exception:
                pass
    return {"ok": bool(got), "received": got, "bad": bad}
