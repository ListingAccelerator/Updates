"""
team.py -- the manager dashboard.

No server and no accounts. Each salesperson's program writes a small
summary file into one shared folder the store already has (a OneDrive,
SharePoint, Google Drive or network folder) after every update, and the
manager's program reads every file in that folder.

What's in a summary: the salesperson's name and store, when it was last
updated, their Marketplace numbers (posted, live, posted this week, sold
and taken down, price drops, days up), what's waiting for them (not posted
yet, price drops due, sold cars still listed), their Accelerator CRM counts
(customers, appointments, shows, sold) and the stock numbers they have
listed. Never a customer's name, phone, email or address.
"""
from __future__ import annotations

import json
import re
from datetime import date, datetime, timedelta
from pathlib import Path

KIND = "listing-accelerator-team"


# ------------------------------------------------------------------ settings
def _file() -> Path:
    import config
    return Path(config.BASE) / "team.json"


def settings() -> dict:
    try:
        d = json.loads(_file().read_text(encoding="utf-8"))
        if isinstance(d, dict):
            return {"share": bool(d.get("share")), "folder": str(d.get("folder") or ""),
                    "watch": str(d.get("watch") or ""), "last_shared": str(d.get("last_shared") or "")}
    except Exception:
        pass
    return {"share": False, "folder": "", "watch": "", "last_shared": ""}


def save_settings(**kw) -> dict:
    s = settings()
    for k in ("share", "folder", "watch", "last_shared"):
        if k in kw and kw[k] is not None:
            s[k] = kw[k]
    _file().write_text(json.dumps(s, indent=1), encoding="utf-8")
    return s


def _safe(t: str) -> str:
    return re.sub(r"[^A-Za-z0-9 ()&.-]+", " ", str(t or "")).strip()[:60] or "Salesperson"


# ------------------------------------------------------------------ one summary
def summary(store_key: str | None = None) -> dict:
    """This salesperson at the store the program is pointed at right now."""
    import config
    import track
    import results
    rows = track.load()
    d = track.todo_data()
    inv = track.inventory()
    today = date.today()
    week = (today - timedelta(days=7)).isoformat()
    month = (today - timedelta(days=30)).isoformat()
    lst = results.listing_results(rows)
    live = []
    for s, r in rows.items():
        if r.get("Status") == "down" or not r.get("Posted_Date"):
            continue
        v = inv.get(s)
        days = None
        try:
            days = (today - date.fromisoformat(r["Posted_Date"][:10])).days
        except ValueError:
            pass
        live.append({"stock": s, "name": r.get("Vehicle") or (track.name_of(inv, s, rows) if v else s),
                     "posted": r.get("Posted_Date", ""), "price": r.get("Posted_Price", ""),
                     "dropped": bool(r.get("Dropped_Date")), "days": days, "on_lot": s in inv})
    crm30 = {"leads": 0, "appts": 0, "shows": 0, "sold": 0}
    try:
        import customers
        for c in customers.load():
            if store_key and c.get("store_key") and c.get("store_key") != store_key:
                continue
            if str(c.get("added") or "")[:10] < month:
                continue
            st = c.get("status") or ""
            crm30["leads"] += 1
            if c.get("appointment") or st in ("Appointment set", "Showed", "Sold"):
                crm30["appts"] += 1
            if st in ("Showed", "Sold"):
                crm30["shows"] += 1
            if st == "Sold":
                crm30["sold"] += 1
    except Exception:
        pass
    read = ""
    try:
        read = datetime.fromtimestamp(Path(config.INVENTORY_JSON).stat().st_mtime).isoformat(timespec="minutes")
    except Exception:
        pass
    try:
        version = (Path(config.BASE) / "version.txt").read_text(encoding="utf-8").strip()
    except Exception:
        version = ""
    return {
        "kind": KIND, "v": 1,
        "salesperson": getattr(config, "SELLER_NAME", "") or "Salesperson",
        "store": getattr(config, "STORE_FULL", "") or "Store",
        "updated": datetime.now().isoformat(timespec="minutes"),
        "lot_read": read, "version": version,
        "lot": len(inv),
        "live": len(live),
        "posted_week": sum(1 for r in rows.values() if str(r.get("Posted_Date") or "") >= week),
        "not_posted": len(d["not_posted"]),
        "drops_due": len(d["drop_today"]) + len(d["mismatched"]),
        "sold_still_listed": [x["stock"] for x in d["take_down"]],
        "sold_taken_down": lst["sold"], "avg_days": lst["avg_days"], "drops_made": lst["drops"],
        "crm30": crm30,
        "listings": sorted(live, key=lambda x: x["posted"]),
        "lot_stocks": [{"stock": s, "name": " ".join(str(v.get(k) or "") for k in ("year", "make", "model")).strip(),
                        "price": track.price_of(v)} for s, v in sorted(inv.items())],
    }


def share(store_key: str | None = None) -> dict:
    """Write this store's summary into the shared folder, if sharing is on."""
    s = settings()
    if not s["share"] or not s["folder"]:
        return {"ok": False, "off": True}
    folder = Path(s["folder"])
    if not folder.is_dir():
        return {"ok": False, "message": f"The shared folder isn't there any more: {folder}"}
    data = summary(store_key)
    name = f"{_safe(data['salesperson'])} - {_safe(data['store'])}.json"
    tmp = folder / (name + ".tmp")
    tmp.write_text(json.dumps(data, indent=1), encoding="utf-8")
    tmp.replace(folder / name)
    save_settings(last_shared=datetime.now().isoformat(timespec="minutes"))
    return {"ok": True, "file": str(folder / name)}


# ------------------------------------------------------------------ the dashboard
def _age_hours(iso: str):
    try:
        return round((datetime.now() - datetime.fromisoformat(iso)).total_seconds() / 3600, 1)
    except Exception:
        return None


def dashboard(folder: str) -> dict:
    f = Path(folder or "")
    if not folder or not f.is_dir():
        return {"ok": False, "message": "Pick the shared folder first."}
    people = []
    for p in sorted(f.glob("*.json")):
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            continue
        if d.get("kind") != KIND:
            continue
        d["age_hours"] = _age_hours(d.get("updated", ""))
        c = d.get("crm30") or {}
        d["closing"] = round(100 * c.get("sold", 0) / c["leads"]) if c.get("leads") else None
        people.append(d)
    # each store: what's on the lot (newest read), and what nobody has listed
    stores = {}
    for d in people:
        k = d.get("store", "").strip().lower()
        st = stores.setdefault(k, {"store": d.get("store", ""), "people": 0, "lot": [], "lot_read": "",
                                   "listed": set()})
        st["people"] += 1
        if d.get("lot_read", "") >= st["lot_read"]:
            st["lot_read"] = d.get("lot_read", "")
            st["lot"] = d.get("lot_stocks") or []
        st["listed"] |= {x["stock"] for x in d.get("listings") or []}
    store_rows = []
    for st in stores.values():
        nobody = [x for x in st["lot"] if x["stock"] not in st["listed"]]
        store_rows.append({"store": st["store"], "people": st["people"], "lot": len(st["lot"]),
                           "listed": len([x for x in st["lot"] if x["stock"] in st["listed"]]),
                           "nobody": sorted(nobody, key=lambda x: x.get("price") or 0)})
    people.sort(key=lambda d: (d.get("store", ""), d.get("salesperson", "")))
    for d in people:
        d.pop("lot_stocks", None)       # the store rows carry the lot
    return {"ok": True, "folder": str(f), "people": people,
            "stores": sorted(store_rows, key=lambda x: x["store"])}
