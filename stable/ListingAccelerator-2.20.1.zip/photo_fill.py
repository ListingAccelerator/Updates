"""
photo_fill.py -- make sure a car ends up with its whole photo set.

Three safety nets, used by scrape_inventory.py when it reads photo galleries:

1. REUSE. If the car's list-card picture is the same picture as last run
   (same address, same timestamp) and last run read its full gallery in the
   last few days, the set has not changed -- use last run's photos and skip
   opening the car's page. Fewer page loads, faster run, and the website is
   less likely to start refusing pages part-way through.

2. KEEP. If a car's page would not load, or loaded without its gallery, keep
   last run's full set instead of dropping to the one list-card thumbnail.

3. NUMBERED. Many dealer sites (DealerOn among them) number a car's pictures
   1.jpg, 2.jpg, 3.jpg... in one folder named for the car's VIN. When all we
   have is picture 1, ask the same site for 2, 3, 4... in the same folder until
   one is missing. Plain picture requests -- the same ones a browser makes.
"""
from __future__ import annotations

import hashlib
import json
import re
import urllib.request
from datetime import date

import config
import photo_watch

REUSE_DAYS = 3
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")
NUMBERED = re.compile(r"^(?P<head>.*/)(?P<n>1)(?P<ext>\.(?:jpe?g|png|webp))(?P<tail>(?:\?.*)?)$",
                      re.I)


def today() -> str:
    return date.today().isoformat()


def previous_photos() -> dict:
    """VIN -> last run's record, for cars that had more than one photo."""
    try:
        old = json.loads(config.INVENTORY_JSON.read_text(encoding="utf-8"))
    except Exception:
        return {}
    out = {}
    for r in old:
        # REAL pictures of this car only -- one real photo plus a stock
        # picture is still a car that needs its gallery read (OW26409)
        if r.get("vin") and len(real(r.get("photos"), r.get("vin"))) > 1 \
                and not needs_more(r.get("photos"), r.get("vin")):
            out[r["vin"]] = r
    return out


def same_set(card_photos, prev_photos) -> bool:
    """Is the list card showing the same first picture as last run's set?"""
    if not card_photos or not prev_photos:
        return False
    return photo_watch._key(card_photos[0]) == photo_watch._key(prev_photos[0])


def fresh(prev: dict) -> bool:
    d = str(prev.get("gallery_checked") or "")
    try:
        return (date.today() - date.fromisoformat(d)).days < REUSE_DAYS
    except ValueError:
        return False


def _get(url: str, timeout: int = 20) -> bytes | None:
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            if getattr(r, "status", 200) != 200:
                return None
            return r.read()
    except Exception:
        return None


def _is_image(data: bytes | None) -> bool:
    if not data or len(data) < 1024:
        return False
    h = data[:16]
    return (h.startswith(b"\xff\xd8\xff") or h.startswith(b"\x89PNG")
            or (h[:4] == b"RIFF" and h[8:12] == b"WEBP"))


def numbered(first_url: str, most: int, get=_get) -> list[str]:
    """
    From ".../<vin>/ip/1.jpg?timestamp=..." try 2.jpg, 3.jpg ... in the same
    folder. Stops at the first one that is missing. Returns the full list
    including picture 1, or [] when the address isn't numbered that way.

    Some sites answer a missing number with a "no photo" picture instead of
    an error, so number 99 is asked for first: if it comes back as a picture,
    that picture is the stand-in, and any number that returns the same bytes
    counts as missing.
    """
    m = NUMBERED.match(first_url or "")
    if not m:
        return []
    head, ext, tail = m.group("head"), m.group("ext"), m.group("tail")

    def at(n: int) -> str:
        return f"{head}{n}{ext}{tail}"

    stand_in = None
    probe = get(at(99))
    if _is_image(probe):
        stand_in = hashlib.sha1(probe).hexdigest()

    seen = set()
    urls = [first_url]
    for n in range(2, max(2, most) + 1):
        data = get(at(n))
        if not _is_image(data):
            break
        h = hashlib.sha1(data).hexdigest()
        if h == stand_in or h in seen:
            break
        seen.add(h)
        urls.append(at(n))
    return urls if len(urls) > 1 else []


def own(photos, vin) -> list[str]:
    """
    The pictures that are really this car's.

    On sites that keep each car's pictures in a folder named for its VIN,
    only those count -- the "similar vehicles" strip and the site-wide
    "photo coming soon" picture live elsewhere. Otherwise, everything that
    isn't filed under some other car's VIN.
    """
    photos = list(photos or [])
    v = str(vin or "").strip().lower()
    if len(v) == 17:
        mine = [u for u in photos if v in u.lower()]
        if mine:
            return mine
    return photo_watch.own_photos(photos, vin)


def first_numbered(photos, vin) -> str:
    """This car's picture number 1, if the site numbers them."""
    for u in real(photos, vin):
        if NUMBERED.match(u):
            return u
    return ""


def real(photos, vin) -> list[str]:
    """This car's own pictures, leaving out the maker's stock pictures."""
    return [u for u in own(photos, vin) if not photo_watch.is_stock(u)]


def needs_more(photos, vin) -> bool:
    """
    Should we go looking for more of this car's real pictures?

    Yes when it has at most one, and yes when stock pictures are mixed in
    with fewer real ones than the photo limit -- the site lists stock
    pictures after the real ones, so a full list can be cut off before all
    the real ones are counted (OW26409 has 33 real photos and 12 stock).
    """
    photos = list(photos or [])
    n = len(real(photos, vin))
    if n <= 1:
        return True
    most = int(getattr(config, "MAX_PHOTOS_PER_VEHICLE", 12) or 12)
    has_stock = any(photo_watch.is_stock(u) for u in photos)
    return has_stock and n < most
