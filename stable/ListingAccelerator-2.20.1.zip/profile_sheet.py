"""
profile_sheet.py -- the customer's deal sheet, one page, to print.

From the customer's Accelerator CRM card: contact and appointment, what they
want, the vehicle (stock, VIN, miles, price), their trade (VIN, miles, payoff,
lienholder, allowance, equity), the deal numbers he filled in (price, doc
fee, tax, tags and fees, rebates, down) with the amount financed, a payment
grid across terms and down payments, his notes, and signature lines.
Boxes he left empty print as blank lines to fill in at the desk.

Written as a page in the store's out\\customer sheets folder and opened in
the browser, which brings up Print by itself.
"""
from __future__ import annotations

import html
import re
from datetime import date, datetime
from pathlib import Path


def _e(s) -> str:
    return html.escape(str(s or ""))


def _money(n) -> str:
    try:
        n = int(n)
    except (TypeError, ValueError):
        return ""
    if not n:
        return ""
    return f"-${-n:,}" if n < 0 else f"${n:,}"


def _when(s: str) -> str:
    s = str(s or "").strip()
    if not s:
        return ""
    for fmt, n, out in (("%Y-%m-%dT%H:%M", 16, "%a %b %d · %I:%M %p"), ("%Y-%m-%d %H:%M", 16, "%b %d, %Y"),
                        ("%Y-%m-%d", 10, "%a %b %d, %Y")):
        try:
            return datetime.strptime(s[:n], fmt).strftime(out).replace(" 0", " ")
        except ValueError:
            continue
    return s


def build(cid: str) -> Path:
    import config
    import customers
    import finder
    c = customers.get(cid)
    if not c:
        raise ValueError("That customer isn't in Accelerator CRM any more.")
    invs = customers.inventories()
    v = customers.view(c, invs)
    d = c.get("deal") or {}
    ti = c.get("trade_info") or {}
    calc = v.get("deal_calc") or customers.deal_calc(c)
    num = customers._money_num

    # ---- vehicle(s)
    cars = []
    for i, car in enumerate(v.get("cars") or []):
        rec = (invs.get(car.get("store_key")) or {}).get("cars", {}).get(str(car.get("stock", "")).upper()) or {}
        color = finder._color(rec)
        cars.append(f"""<tr><td><b>{_e(car.get('name'))}</b>{' <span class="tag">this deal</span>' if i == 0 and len(v['cars']) > 1 else ''}
            <div class="mut">Stock {_e(car.get('stock'))}{' · ' + _e(color) if color else ''}{' · VIN ' + _e(rec.get('vin')) if rec.get('vin') else ''}
            · {_e(car.get('store'))}{'' if car.get('on_lot') is not False else ' · <b>NOT ON THE WEBSITE ANY MORE</b>'}</div></td>
          <td class="n">{f"{int(car['miles']):,} mi" if car.get('miles') else ''}</td>
          <td class="n"><b>{_money(car.get('price'))}</b></td></tr>""")

    # ---- the numbers: what he typed, else blank to fill in
    def box(label, val, strong=False):
        return f"<div class='bx{' st' if strong else ''}'><span>{label}</span><b>{_e(val)}</b></div>"
    other_label = d.get("other_label") or "Other fees"
    eq = calc["equity"]
    numbers = "".join([
        box("Selling price", _money(calc["price"])),
        box("Doc fee", _money(num(d.get("doc_fee")))),
        box("Tax", _money(num(d.get("tax")))),
        box("Tags / title", _money(num(d.get("tags")))),
        box(_e(other_label), _money(num(d.get("other")))),
        box("Rebates", _money(calc["rebate"])),
        box("Trade allowance", _money(num(ti.get("allowance")))),
        box("Trade payoff", _money(num(ti.get("payoff")))),
        box("Net trade", _money(eq) if (ti.get("allowance") or ti.get("payoff")) else ""),
        box("Cash down", _money(calc["down"])),
        box("Rate / term", f"{calc['apr']:g}% · {calc['term']} mo"),
        box("Amount financed", _money(calc["financed"]), True),
    ])

    # ---- payment grid: the same deal at other terms and down payments
    grid = ""
    if calc["price"]:
        base = calc["financed"] + calc["down"]          # financed before any down
        terms = sorted({60, 66, 72, 75, 84, calc["term"]})
        downs = sorted({0, 1000, 2000, 3000, 5000, calc["down"]})
        grid = ("<table class='grid2'><tr><th>Down</th>" + "".join(f"<th>{t} mo</th>" for t in terms) + "</tr>" +
                "".join(f"<tr><th>{_money(dn) or '$0'}</th>" + "".join(
                    f"<td class='{'me' if (t == calc['term'] and dn == calc['down']) else ''}'>"
                    f"{_money(finder.pay_on(max(0, base - dn), calc['apr'], t)) or '$0'}</td>" for t in terms) + "</tr>"
                    for dn in downs) + "</table>")

    notes = list(reversed(c.get("notes") or []))[:4]
    notes_html = "".join(f"<tr><td class='w'>{_e(_when(e.get('when')))}</td><td>{_e(e.get('text'))}</td></tr>" for e in notes)

    seller = getattr(config, "SELLER_NAME", "") or ""
    phone = getattr(config, "DEALER_PHONE", "") or ""
    store = getattr(config, "STORE_FULL", "") or v.get("store") or ""
    tcar = " ".join(str(ti.get(k) or "") for k in ("year", "make", "model", "trim")).strip()

    def tf(label, val):
        return f"<div><span>{label}</span><b>{_e(val)}</b></div>"

    page = f"""<!doctype html><html><head><meta charset="utf-8"><title>{('Deal ' + _e(c.get('deal_no')) + ' · ') if c.get('deal_no') else ''}{_e(c.get('name'))} — deal sheet</title>
<style>
@page{{size:Letter;margin:.4in .45in}}
*{{box-sizing:border-box}}
body{{font-family:"Segoe UI",Arial,sans-serif;color:#15191e;font-size:11.5px;margin:0;padding:16px;background:#fff;line-height:1.3}}
.top{{display:flex;justify-content:space-between;align-items:flex-end;border-bottom:3px solid #00305F;padding-bottom:6px}}
.top h1{{margin:0;font-size:22px}} .top .r{{text-align:right;color:#555;font-size:11px}}
.pill{{display:inline-block;border:1px solid #00305F;color:#00305F;border-radius:10px;padding:0 8px;font-size:11px;font-weight:700;margin-left:8px;vertical-align:middle}}
h2{{font-size:11.5px;text-transform:uppercase;letter-spacing:.06em;color:#00305F;margin:11px 0 4px;border-bottom:1px solid #d5dbe1;padding-bottom:2px}}
.two{{display:grid;grid-template-columns:1fr 1fr;gap:0 26px}}
.kv{{display:grid;grid-template-columns:92px 1fr;gap:2px 8px}} .k{{color:#666}}
.mut{{color:#666;font-size:10.5px}} .tag{{font-size:9.5px;background:#00305F;color:#fff;border-radius:3px;padding:0 4px;margin-left:4px}}
table{{width:100%;border-collapse:collapse}}
.cars td{{border-bottom:1px solid #e3e6ea;padding:4px 4px;vertical-align:top}}
.n{{text-align:right;white-space:nowrap}}
.tr{{display:grid;grid-template-columns:repeat(4,1fr);gap:2px 14px}}
.tr div,.bx{{display:flex;justify-content:space-between;align-items:flex-end;gap:6px;border-bottom:1px solid #999;padding:11px 1px 1px;font-size:10.5px;color:#555;min-height:26px}}
.tr div b,.bx b{{color:#15191e;font-size:12px;text-align:right}}
.nums{{display:grid;grid-template-columns:repeat(4,1fr);gap:0 14px}}
.bx.st{{border-bottom:2px solid #00305F}} .bx.st span{{color:#00305F;font-weight:700}} .bx.st b{{font-size:13.5px}}
.grid2 td,.grid2 th{{border:1px solid #cfd5dc;padding:3px 6px;text-align:center}}
.grid2 th{{background:#F1F4F7;font-size:10.5px}} .grid2 td.me{{background:#FFE9A8;font-weight:700}}
.log td{{padding:2px 4px;border-bottom:1px solid #eef0f3;vertical-align:top}} .log .w{{width:96px;color:#666;white-space:nowrap}}
.line{{border-bottom:1px solid #aaa;height:20px}}
.sig{{display:grid;grid-template-columns:2fr 1fr 2fr 2fr;gap:16px;margin-top:24px}}
.sig div{{border-top:1px solid #333;padding-top:2px;font-size:10.5px;color:#555}}
.noprint{{background:#FFF6DD;border:1px solid #EBD38A;padding:7px 11px;border-radius:6px;margin-bottom:10px;font-size:12px}}
@media print{{body{{padding:0}} .noprint{{display:none}}}}
</style></head><body>
<div class="noprint">The print window opens by itself. If it doesn't, press <b>Ctrl + P</b>.</div>
<div class="top"><div><h1>{_e(c.get('name'))}<span class="pill">{_e(c.get('status'))}</span></h1>
  <div class="mut">{('<b style="color:#00305F;font-size:12px">Deal #' + _e(c.get('deal_no')) + '</b> · ') if c.get('deal_no') else ''}Deal sheet · from {_e(c.get('source') or 'Marketplace')} · added {_e(_when(c.get('added')))}</div></div>
  <div class="r"><b>{_e(store)}</b><br>{_e(seller)}{' · ' + _e(phone) if phone else ''}<br>{date.today().strftime('%b %d, %Y').replace(' 0', ' ')}</div></div>

<div class="two">
 <div><h2>Customer</h2><div class="kv">
  <span class="k">Phone</span><b>{_e(c.get('phone'))}</b>
  <span class="k">Email</span><span>{_e(c.get('email'))}</span>
  <span class="k">Address</span><span>{_e(customers.full_address(c))}</span>
  <span class="k">Appointment</span><b>{_e(_when(c.get('appointment'))) or '—'}</b>
  <span class="k">Dealer CRM</span><span>{'Entered ' + _e(_when(c.get('vin_entered_on'))) if c.get('vin_entered') else 'Not entered yet'}</span></div></div>
 <div><h2>What they want</h2><div class="kv">
  <span class="k">Here for</span><span>{_e(', '.join(c.get('wants') or [])) or '—'}{' · ' + _e(c.get('looking_for')) if c.get('looking_for') else ''}</span>
  <span class="k">Looking for</span><span>{_e(v.get('search_words')) or '—'}</span>
  <span class="k">Language</span><span>{'Spanish' if c.get('lang') == 'es' else 'English'}</span></div></div>
</div>

<h2>Vehicle</h2>
{f'<table class="cars">{"".join(cars)}</table>' if cars else '<div class="line"></div><div class="mut">Year / make / model · stock · VIN · miles</div>'}

<h2>Trade-in{(' · equity ' + _money(eq)) if eq > 0 else (' · upside down ' + _money(-eq)) if eq < 0 else ''}</h2>
<div class="tr">{tf('Year / make / model', tcar or (c.get('trade') or ''))}{tf('VIN', ti.get('vin'))}{tf('Miles', ti.get('miles'))}{tf('Color', ti.get('color'))}
  {tf('Payoff', _money(num(ti.get('payoff'))))}{tf('Lienholder', ti.get('lender'))}{tf('Allowance / ACV', _money(num(ti.get('allowance'))))}{tf('Keys / title', '')}</div>
{('<div class="mut" style="margin-top:3px">' + _e(ti.get('details')) + '</div>') if ti.get('details') else ''}
{('<div class="mut" style="margin-top:3px">Condition: ' + _e(ti.get('condition')) + '</div>') if ti.get('condition') else ''}

<h2>The numbers</h2>
<div class="nums">{numbers}</div>

<h2>Payments at {calc['apr']:g}% APR</h2>
{grid or '<div class="mut">Add a vehicle (or a selling price) to see payments.</div>'}
<div class="mut" style="margin-top:3px">Estimates with approved credit, on the amount financed above at each down payment. Not a contract or an offer of credit. The shaded box is this deal.</div>

<h2>Notes</h2>
{f'<table class="log">{notes_html}</table>' if notes else ''}
<div class="line"></div><div class="line"></div>

<div class="sig"><div>Customer</div><div>Date</div><div>Salesperson</div><div>Sales manager</div></div>
<script>window.addEventListener("load", () => setTimeout(() => window.print(), 400));</script>
</body></html>"""
    out = Path(config.OUT) / "customer sheets"
    out.mkdir(parents=True, exist_ok=True)
    name = re.sub(r"[^A-Za-z0-9 .-]+", " ", c.get("name") or "customer").strip()[:50] or "customer"
    f = out / (f"Deal {c['deal_no']} - {name}.html" if c.get("deal_no") else f"{name} - deal sheet.html")
    f.write_text(page, encoding="utf-8")
    return f
