"""
photo_watch.py -- tell stock pictures from real ones, and notice when the
website's photos for a car change.

When a car first lands on the website it usually shows the manufacturer's
stock pictures (a computer-drawn car on a white background). Days later the
lot shoots the real car and the site swaps them in. Nothing about that is
announced, so without this a salesman keeps posting -- or keeps live -- an ad
full of stock pictures long after the real ones are up.

Three things live here, shared by the downloader, the morning briefing and
the window:

  * is_stock(url)    -- is this a stock picture rather than the real car?
  * summary(urls)    -- how many real, how many stock, and a fingerprint of
                        the real set so a change can be spotted next run
  * the "update photos" list -- cars he has posted whose website photos have
                        changed since, kept until he says he has swapped them
"""
from __future__ import annotations

import hashlib
import json
import re
from datetime import date
from urllib.parse import parse_qs, urlsplit

import config

# Addresses that mean "manufacturer / stock image", not a photo of this car.
# Kept narrow on purpose: calling a real photo "stock" would hide it.
STOCK_RE = re.compile(
    r"/assets/stock/|colormatched|/stock[-_]?photos?/|stockphoto|stock-image"
    r"|evox|chromedata|izmo|/oem[-_]?images?/|/stockimages?/",
    re.I)

PENDING = config.OUT / "photo_updates.json"

# A VIN inside a picture's address. Many dealer sites file each car's photos
# under its VIN (.../inventoryphotos/23936/<vin>/ip/1.jpg), and the car page
# also shows "similar vehicles" with THEIR photos -- which must never end up
# in this car's ad.
VIN_IN_URL = re.compile(r"(?<![a-z0-9])[a-hj-npr-z0-9]{17}(?![a-z0-9])", re.I)

# Bump when the rules for what counts as this car's picture change, so the
# morning briefing does not report the clean-up itself as "photos changed".
RULES = 2


def foreign(url: str, vin: str | None) -> bool:
    """True when the address names a different car's VIN."""
    vin = str(vin or "").strip().lower()
    if len(vin) != 17:
        return False
    for tok in VIN_IN_URL.findall(str(url or "").lower()):
        if any(c.isdigit() for c in tok) and any(c.isalpha() for c in tok) \
                and tok != vin:
            return True
    return False


def own_photos(urls, vin) -> list[str]:
    return [u for u in (urls or []) if not foreign(u, vin)]


def is_stock(url: str) -> bool:
    return bool(STOCK_RE.search(str(url or "")))


def _key(url: str) -> str:
    """
    One entry per real picture.

    The same picture often comes in two sizes (?width=600 / ?width=800), so
    the size is ignored. A reshoot usually changes the picture's timestamp,
    so that is kept -- it is how a retake with the same file name is caught.
    """
    try:
        parts = urlsplit(url)
    except ValueError:
        return url
    stamp = parse_qs(parts.query).get("timestamp", [""])[0]
    return f"{parts.netloc.lower()}{parts.path}|{stamp}"


def summary(urls, vin=None) -> dict:
    real, stock = [], []
    seen = set()
    for u in own_photos(urls, vin):
        k = _key(u)
        if k in seen:
            continue
        seen.add(k)
        (stock if is_stock(u) else real).append(k)
    sig = hashlib.sha1("\n".join(sorted(real)).encode()).hexdigest()[:16]
    return {"real": len(real), "stock": len(stock),
            "sig": sig if real else "", "v": RULES}


# Below this many real photos a car is still waiting on its photo shoot.
FEW = 3


def pick_for_download(urls, limit: int, vin=None) -> tuple[list[str], bool]:
    """
    Which pictures to put in his folder.

    Real photos only, when the site has any -- stock fill-ins on a car that
    has been photographed just pad the ad. When there are no real ones yet,
    the stock ones are better than an empty folder, and the caller is told so.
    """
    urls = own_photos(urls, vin)
    real = [u for u in urls if not is_stock(u)]
    stock = [u for u in urls if is_stock(u)]
    if len(real) >= FEW or (real and not stock):
        return real[:limit], False
    if real:
        # The first one or two real photos have just gone up. One photo
        # makes a thin ad, so lead with the real ones and fill in with the
        # stock pictures until the rest are taken.
        return (real + stock)[:limit], False
    return urls[:limit], bool(urls)


def describe(info: dict) -> str:
    r, s = info.get("real", 0), info.get("stock", 0)
    if not r and s:
        return "stock photos only"
    if r and s:
        return f"{r} real + {s} stock photos"
    if r:
        return f"{r} real photos"
    return "no photos"


# --- cars whose live ad needs new pictures ---------------------------------
def load_pending() -> dict:
    try:
        d = json.loads(PENDING.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def save_pending(d: dict) -> None:
    try:
        config.OUT.mkdir(parents=True, exist_ok=True)
        PENDING.write_text(json.dumps(d, indent=2), encoding="utf-8")
    except OSError:
        pass


def add_pending(stock: str, name: str, what: str) -> None:
    d = load_pending()
    d[stock] = {"name": name, "what": what, "since": date.today().isoformat()}
    save_pending(d)


def clear_pending(stocks) -> None:
    d = load_pending()
    for s in stocks or []:
        d.pop(s, None)
    save_pending(d)
