"""
whats_new.py -- what changed on the lot since the last run.

A scheduled job that silently updates files is useless; you need to know what
moved. This compares today's scrape against the previous one and writes a short
morning briefing: new arrivals, cars that sold, and price changes.

Run automatically at the end of daily_update.bat. The briefing lands in
out\\WHATS_NEW.txt.

Usage:
    python whats_new.py
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from datetime import datetime

import config
import photo_watch
import track

STATE = config.OUT / ".last_run_state.json"
BRIEF = config.OUT / "WHATS_NEW.txt"


def live_listings() -> set[str]:
    """
    Stock numbers you currently have up on Marketplace.

    These stay in the briefing no matter what they cost. A car you have listed
    that just sold, or whose price moved on the website, is something you must
    act on today -- hiding it because it is over the ceiling would be the one
    mistake this filter must never make.
    """
    ledger = config.OUT / "posted.csv"
    if not ledger.exists():
        return set()
    out: set[str] = set()
    try:
        with open(ledger, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                if row.get("Status") != "down" and row.get("Stock"):
                    out.add(row["Stock"].strip().upper())
    except OSError:
        pass
    return out


def _name(r: dict) -> str:
    """Year make model trim, without saying "Transit 250 250"."""
    model = str(r.get("model") or "").strip()
    trim = str(r.get("trim") or "").strip()
    if trim and model.lower().endswith(trim.lower()):
        trim = ""
    return " ".join(str(x) for x in (r.get("year") or "", r.get("make") or "",
                                     model, trim) if str(x).strip())


def snapshot(records: list[dict]) -> dict:
    # year/make/model are kept alongside the name so that a vehicle which has
    # since left the lot can still be judged against the slice he works --
    # otherwise a filtered report could only narrow arrivals, not departures.
    return {
        r["stock"]: {
            "name": _name(r),
            "retail": r.get("retail_price"),
            "price": r.get("final_price") or r.get("moses_price"),
            "miles": r.get("mileage"),
            "year": r.get("year"),
            "make": r.get("make"),
            "model": r.get("model"),
            "trim": r.get("trim"),
            # What the filter needs to tell new from used and his store from
            # a sister store's. Without them every car looked used here, and
            # the briefing asked for photos of 101 new cars he doesn't sell.
            "condition": track.condition_of(r),
            "certified": bool(r.get("certified")),
            "managers_special": bool(r.get("managers_special")),
            "other_store": r.get("other_store"),
            "selling_store": r.get("selling_store"),
            "body_style": r.get("body_style"),
            # real vs stock pictures, and a fingerprint of the real set, so
            # tomorrow can say "the real photos are up" or "photos changed"
            "photos": photo_watch.summary(r.get("photos"), r.get("vin")),
        }
        for r in records if r.get("stock")
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--all", action="store_true",
                    help="report on the whole lot, not just the price slice "
                         "you work")
    # Tolerate being imported and called with no command line (make_report.py).
    args, _ = ap.parse_known_args()
    # "--all" reports the whole lot; otherwise narrow to the slice he works,
    # using the same rules the window and the to-do list use.
    narrowed = not args.all and track.focus_is_on()
    cap = 0 if args.all else track.focus_max()

    if not config.INVENTORY_JSON.exists():
        print("No inventory yet.")
        return 1

    records = json.loads(config.INVENTORY_JSON.read_text(encoding="utf-8"))
    today = snapshot(records)

    previous = {}
    first_run = not STATE.exists()
    if not first_run:
        try:
            previous = json.loads(STATE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            first_run = True

    new_stocks = sorted(set(today) - set(previous))
    gone_stocks = sorted(set(previous) - set(today))
    # A dollar or two is the site's retail / sale / doc-fee figures not
    # reconciling to the penny, not the manager moving a price. Reporting
    # those buries the one real change under six fake ones.
    noise = max(1, getattr(config, "PRICE_CHANGE_MIN", 50) or 1)
    moved = []
    for s in sorted(set(today) & set(previous)):
        was, now = previous[s].get("price"), today[s].get("price")
        if was and now and abs(was - now) >= noise:
            moved.append((s, today[s]["name"], was, now))

    # --- narrow to the slice you actually work ------------------------------
    listed = live_listings()
    hidden_new = hidden_gone = hidden_moved = 0

    def mine(stock: str, price, snap=None) -> bool:
        if not narrowed:
            return True
        if stock.strip().upper() in listed:
            return True          # you have it listed -- always tell him
        if not price:
            return False
        rec = dict(snap or {})
        rec["stock"] = stock
        rec["final_price"] = price
        return track.in_focus(rec)

    if narrowed:
        before = len(new_stocks), len(gone_stocks), len(moved)
        new_stocks = [s for s in new_stocks
                      if mine(s, today[s]["price"], today[s])]
        gone_stocks = [s for s in gone_stocks
                       if mine(s, previous[s]["price"], previous[s])]
        moved = [m for m in moved if mine(m[0], m[3], today.get(m[0]))]
        hidden_new = before[0] - len(new_stocks)
        hidden_gone = before[1] - len(gone_stocks)
        hidden_moved = before[2] - len(moved)

    stamp = datetime.now().strftime("%A %B %d, %Y at %-I:%M %p"
                                    if sys.platform != "win32"
                                    else "%A %B %d, %Y at %I:%M %p")
    L = [f"{config.STORE_FULL.upper()} - WHAT'S NEW", stamp, "=" * 52, ""]
    if narrowed:
        where = track.focus_wording()
        L += [f"Showing {where} -- the ones you work --" if where
              else "Showing the ones you work --",
              "plus anything you currently have listed, at any price.", ""]

    if first_run:
        L += [f"First run. Tracking {len(today)} vehicles from here on.",
              "Tomorrow this will show arrivals, sales and price moves.", ""]
    else:
        L.append(f"{len(today)} vehicles on the lot "
                 f"({len(new_stocks)} new, {len(gone_stocks)} gone)")
        L.append("")

        if new_stocks:
            L.append(f"NEW ARRIVALS ({len(new_stocks)}) -- ads are ready:")
            for s in new_stocks:
                v = today[s]
                price = f"${v['price']:,}" if v["price"] else "no price"
                miles = f"{v['miles']:,} mi" if v["miles"] else ""
                L.append(f"   {s:10s} {v['name']}")
                L.append(f"   {'':10s} {miles}, {price}")
            L.append("")

        if gone_stocks:
            L.append(f"GONE ({len(gone_stocks)}) -- sold or pulled. "
                     f"Take these down off Marketplace:")
            for s in gone_stocks:
                L.append(f"   {s:10s} {previous[s]['name']}")
            L.append("")

        if moved:
            L.append(f"PRICE CHANGES ({len(moved)}):")
            for s, name, was, now in moved:
                arrow = "DOWN" if now < was else "UP"
                L.append(f"   {s:10s} {name}")
                L.append(f"   {'':10s} ${was:,} -> ${now:,}  ({arrow} "
                         f"${abs(now - was):,})")
            L.append("")

        # --- the website's pictures ---------------------------------------
        real_up, changed = [], []
        for s in sorted(set(today) & set(previous)):
            was = previous[s].get("photos")
            now = today[s].get("photos") or {}
            if not isinstance(was, dict) or was.get("v") != now.get("v"):
                continue          # last run read photos by older rules
            if was.get("sig") == now.get("sig"):
                continue
            if not mine(s, today[s]["price"], today[s]):
                continue
            wr, nr = was.get("real", 0), now.get("real", 0)
            few = photo_watch.FEW
            if wr < few and nr < few:
                # a first photo or two going up is not news yet -- the car
                # is listed under "only 1-2 real photos so far" below
                continue
            if wr < few <= nr:
                real_up.append((s, f"{nr} real photos now" +
                                (" (was stock only)" if not wr
                                 else f" (was only {wr})")))
            elif nr > wr:
                changed.append((s, f"{nr - wr} photo(s) added -- {nr} now"))
            elif nr < wr:
                changed.append((s, f"{wr - nr} photo(s) taken off -- "
                                   f"{nr} now" if nr else
                                   "real photos taken off -- stock only now"))
            else:
                changed.append((s, f"photos replaced or retaken -- {nr} now"))

        for s, what in real_up + changed:
            if s.strip().upper() in listed:
                photo_watch.add_pending(s, today[s]["name"], what)

        if real_up:
            L.append(f"REAL PHOTOS ARE UP ({len(real_up)}) -- the website "
                     f"swapped the stock pictures for the real car:")
            for s, what in real_up:
                tag = "  <- LIVE, update its photos" \
                    if s.strip().upper() in listed else ""
                L.append(f"   {s:10s} {today[s]['name']}{tag}")
                L.append(f"   {'':10s} {what}")
            L.append("")

        if changed:
            L.append(f"PHOTOS CHANGED ON THE WEBSITE ({len(changed)}):")
            for s, what in changed:
                tag = "  <- LIVE, check its photos" \
                    if s.strip().upper() in listed else ""
                L.append(f"   {s:10s} {today[s]['name']}{tag}")
                L.append(f"   {'':10s} {what}")
            L.append("")

        if not (new_stocks or gone_stocks or moved or real_up or changed):
            L.append("No changes since the last run.")
            L.append("")

        skipped = hidden_new + hidden_gone + hidden_moved
        if skipped:
            bits = []
            if hidden_new:
                bits.append(f"{hidden_new} new")
            if hidden_gone:
                bits.append(f"{hidden_gone} gone")
            if hidden_moved:
                bits.append(f"{hidden_moved} price change(s)")
            L.append(f"Elsewhere on the lot, outside what you work: "
                     f"{', '.join(bits)}.")
            L.append("Run  python whats_new.py --all  to see those too.")
            L.append("")

    # cars still showing only the manufacturer's stock pictures
    stock_only = [s for s in sorted(today)
                  if mine(s, today[s]["price"], today[s])
                  and (today[s].get("photos") or {}).get("stock")
                  and not (today[s].get("photos") or {}).get("real")]
    if stock_only:
        L.append(f"STILL STOCK PHOTOS ONLY ({len(stock_only)}) -- no real "
                 f"pictures on the website yet:")
        for s in stock_only:
            tag = "  <- live" if s.strip().upper() in listed else ""
            L.append(f"   {s:10s} {today[s]['name']}{tag}")
        L.append("")

    # photographed, but barely -- usually one front shot until the lot
    # finishes the car. Worth watching: the rest tend to arrive later.
    few = [s for s in sorted(today)
           if mine(s, today[s]["price"], today[s])
           and 0 < (today[s].get("photos") or {}).get("real", 0) <= 2]
    if few:
        L.append(f"ONLY 1-2 REAL PHOTOS SO FAR ({len(few)}) -- you will hear "
                 f"here when more are added:")
        for s in few:
            n = today[s]["photos"]["real"]
            tag = "  <- live" if s.strip().upper() in listed else ""
            L.append(f"   {s:10s} {today[s]['name']}  ({n}){tag}")
        L.append("")

    # photo gaps are worth knowing every morning
    missing = []
    if config.PHOTO_DROP.exists():
        for s in today:
            if not mine(s, today[s]["price"], today[s]):
                continue
            f = config.PHOTO_DROP / s
            if not f.exists() or not any(f.iterdir()):
                missing.append(s)
    if missing:
        L += [f"NEEDS PHOTOS ({len(missing)}):",
              "   " + ", ".join(missing[:20])
              + (" ..." if len(missing) > 20 else ""), ""]

    L += ["-" * 52,
          r"Ads:    out\jt_listings\<STOCK>.txt",
          r"Photos: " + str(config.PHOTO_DROP) + r"\<STOCK>\ "]

    text = "\n".join(L)
    config.OUT.mkdir(parents=True, exist_ok=True)
    BRIEF.write_text(text, encoding="utf-8")
    STATE.write_text(json.dumps(today, indent=2), encoding="utf-8")

    print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
