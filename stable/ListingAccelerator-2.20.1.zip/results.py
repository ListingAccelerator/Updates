"""
results.py -- "My results": what the program has done for him.

From his own posting record (out\\posted.csv) and Accelerator CRM:
  - cars he posted, cars that sold after he posted them (gone from the
    website and taken down), and how long they were up,
  - price drops he made,
  - customers, appointments, shows and sales logged in Accelerator CRM.
All counted on this computer. Month by month, newest first.
"""
from __future__ import annotations

import re
from collections import defaultdict
from datetime import date


def _d(s: str):
    try:
        return date.fromisoformat(str(s)[:10])
    except (TypeError, ValueError):
        return None


def _month(d: date) -> str:
    return d.strftime("%Y-%m")


def _down_date(r: dict):
    m = re.search(r"down (\d{4}-\d{2}-\d{2})", r.get("Notes") or "")
    return _d(m.group(1)) if m else None


def listing_results(rows: dict) -> dict:
    months = defaultdict(lambda: {"posted": 0, "sold": 0, "drops": 0, "days": []})
    live = sold = drops = 0
    all_days = []
    for s, r in rows.items():
        p = _d(r.get("Posted_Date"))
        if not p:
            continue
        months[_month(p)]["posted"] += 1
        if r.get("Dropped_Date"):
            dd = _d(r.get("Dropped_Date")) or p
            months[_month(dd)]["drops"] += 1
            drops += 1
        if r.get("Status") == "down":
            sold += 1
            dn = _down_date(r)
            when = dn or p
            months[_month(when)]["sold"] += 1
            if dn and dn >= p:
                days = (dn - p).days
                months[_month(when)]["days"].append(days)
                all_days.append(days)
        else:
            live += 1
    out = []
    for m in sorted(months, reverse=True)[:12]:
        x = months[m]
        out.append({"month": date.fromisoformat(m + "-01").strftime("%B %Y"), "posted": x["posted"],
                    "sold": x["sold"], "drops": x["drops"],
                    "avg_days": round(sum(x["days"]) / len(x["days"])) if x["days"] else None})
    return {"posted": len([1 for r in rows.values() if _d(r.get("Posted_Date"))]), "sold": sold,
            "live": live, "drops": drops,
            "avg_days": round(sum(all_days) / len(all_days)) if all_days else None, "months": out}


def crm_results(store_key: str | None = None) -> dict:
    import customers
    months = defaultdict(lambda: {"leads": 0, "appts": 0, "shows": 0, "sold": 0})
    tot = {"leads": 0, "appts": 0, "shows": 0, "sold": 0}
    for c in customers.load():
        if store_key and c.get("store_key") and c.get("store_key") != store_key:
            continue
        a = _d(c.get("added"))
        if not a:
            continue
        m = months[_month(a)]
        m["leads"] += 1
        tot["leads"] += 1
        st = c.get("status") or ""
        if c.get("appointment") or st in ("Appointment set", "Showed", "Sold"):
            m["appts"] += 1
            tot["appts"] += 1
        if st in ("Showed", "Sold"):
            m["shows"] += 1
            tot["shows"] += 1
        if st == "Sold":
            m["sold"] += 1
            tot["sold"] += 1
    out = [{"month": date.fromisoformat(k + "-01").strftime("%B %Y"), **months[k]}
           for k in sorted(months, reverse=True)[:12]]
    return {**tot, "months": out}
