"""
ai_engine.py -- whichever AI the salesman chose, behind one door.

He picks in AI settings (Integrations -> AI settings):
    copy     Copy for AI: nothing to set up. The program copies the request
             and opens the AI site he already uses (ChatGPT, Claude, Gemini,
             Copilot), signed in to his own plan. Free or paid -- his choice.
    gemini   A Google Gemini key: free (no card), or paid if he turned on
             billing in Google AI Studio.
    openai   His own OpenAI (ChatGPT) API key -- he pays OpenAI.
    claude   His own Anthropic (Claude) API key -- he pays Anthropic.

The Reply helper, "Rewrite with AI" and the walkaround's "Match captions
with AI" all come through ask() here. The background clean-up (windows and
the ground under the car) only works with a Google key, because it uses
Google's image tools -- a Google key can sit alongside an OpenAI or Claude one.

The same privacy rule holds for every one of them: the customer's name,
phone, email and address are taken out before anything leaves the computer
(ai_reply.scrub). Keys are kept in program\\customers\\ai_settings.json.
"""
from __future__ import annotations

import base64
import json
import os
import re
import urllib.error
import urllib.request

PROVIDERS = {
    "gemini": "Google Gemini",
    "openai": "OpenAI (ChatGPT)",
    "claude": "Anthropic (Claude)",
}
OPENAI_API = os.environ.get("LA_OPENAI_API_TEST") or "https://api.openai.com/v1"
CLAUDE_API = os.environ.get("LA_CLAUDE_API_TEST") or "https://api.anthropic.com/v1"
OPENAI_FALLBACK = ["gpt-5-mini", "gpt-4.1-mini", "gpt-4o-mini"]
CLAUDE_FALLBACK = ["claude-sonnet-5-5", "claude-haiku-5-5", "claude-sonnet-4-5"]

# Where "Get a key" and "Open my AI" go. Read fresh from the update site
# (stable/partners.json) when it can be, so a sign-up or partner link can be
# changed there without a new version of the program.
LINKS = {
    "gemini_key": "https://aistudio.google.com/apikey",
    "openai_key": "https://platform.openai.com/api-keys",
    "claude_key": "https://console.anthropic.com/settings/keys",
    "chatgpt": "https://chatgpt.com/",
    "claude": "https://claude.ai/new",
    "gemini": "https://gemini.google.com/app",
    "copilot": "https://copilot.microsoft.com/",
}
CHAT_SITES = [("chatgpt", "ChatGPT"), ("claude", "Claude"), ("gemini", "Gemini"),
              ("copilot", "Copilot")]


class AIFail(Exception):
    """A plain-English reason the AI didn't answer."""


def links() -> dict:
    out = dict(LINKS)
    try:
        import updater
        base = (updater.UPDATE_BASE or "").rstrip("/")
        if base:
            req = urllib.request.Request(base + "/partners.json",
                                         headers={"User-Agent": "ListingAccelerator"})
            with urllib.request.urlopen(req, timeout=6) as r:
                d = json.loads(r.read().decode("utf-8"))
            for k, v in (d or {}).items():
                if k in out and isinstance(v, str) and v.startswith("https://"):
                    out[k] = v
    except Exception:
        pass
    return out


# ------------------------------------------------------------- settings
def settings() -> dict:
    import ai_reply
    return ai_reply.settings()


def key_for(provider: str, s: dict | None = None) -> str:
    s = s or settings()
    return {"gemini": s.get("key"), "openai": s.get("openai_key"),
            "claude": s.get("claude_key")}.get(provider) or ""


def active(s: dict | None = None) -> str:
    """The AI that answers inside the program, or '' (Copy for AI / off)."""
    s = s or settings()
    m = s.get("mode")
    return m if m in PROVIDERS and key_for(m, s) else ""


def on() -> bool:
    return bool(active())


def name() -> str:
    return PROVIDERS.get(active(), "")


# ------------------------------------------------------------- HTTP
def _post(url: str, headers: dict, body: dict | None = None, timeout: int = 60) -> dict:
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, method="POST" if data else "GET",
                                 headers={"Content-Type": "application/json", **headers})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def _why(provider: str, e: Exception) -> str:
    who = {"openai": "OpenAI", "claude": "Anthropic"}.get(provider, provider)
    if isinstance(e, urllib.error.HTTPError):
        try:
            msg = json.loads(e.read().decode("utf-8")).get("error", {})
            msg = msg.get("message", "") if isinstance(msg, dict) else str(msg)
        except Exception:
            msg = ""
        low = msg.lower()
        if e.code in (401, 403):
            return f"{who} didn't accept that key. Copy it again from your {who} account and Paste it here."
        if e.code == 402 or "credit" in low or "billing" in low or "quota" in low or "balance" in low:
            return f"Your {who} account is out of credit. Add credit in your {who} account's billing page."
        if e.code == 429:
            return f"{who} says too many requests right now. Wait a minute and try again."
        if e.code in (500, 502, 503, 529):
            return f"{who} is busy right now. Try again in a minute."
        if e.code == 404:
            return f"That {who} model isn't available to your key."
        return f"{who} said: {msg or e.code}"
    if isinstance(e, urllib.error.URLError):
        return (f"Couldn't reach {who} from this computer. The network may block it "
                "(common on work computers) -- use Copy for AI instead.")
    if isinstance(e, AIFail):
        return str(e)
    return f"Something went wrong: {type(e).__name__}"


def _rank(n: str) -> tuple:
    nums = [int(x) for x in re.findall(r"\d+", n)[:2]] + [0, 0]
    return (nums[0], nums[1])


def _openai_models(key: str) -> list[str]:
    try:
        d = _post(f"{OPENAI_API}/models", {"Authorization": f"Bearer {key}"}, timeout=20)
        names = [m.get("id", "") for m in d.get("data", [])]
        good = [n for n in names if re.fullmatch(r"gpt-\d+(\.\d+)?(-mini)?", n)]
        good.sort(key=lambda n: (_rank(n), n.endswith("-mini")), reverse=True)
        minis = [n for n in good if n.endswith("-mini")]
        return (minis[:1] + [n for n in good if n not in minis[:1]] + OPENAI_FALLBACK)[:5]
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            raise
        return OPENAI_FALLBACK
    except Exception:
        return OPENAI_FALLBACK


def _claude_models(key: str) -> list[str]:
    try:
        d = _post(f"{CLAUDE_API}/models?limit=100",
                  {"x-api-key": key, "anthropic-version": "2023-06-01"}, timeout=20)
        names = [m.get("id", "") for m in d.get("data", [])]
        son = sorted([n for n in names if "sonnet" in n], key=_rank, reverse=True)
        hai = sorted([n for n in names if "haiku" in n], key=_rank, reverse=True)
        return (son[:1] + hai[:1] + CLAUDE_FALLBACK)[:5]
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            raise
        return CLAUDE_FALLBACK
    except Exception:
        return CLAUDE_FALLBACK


def _jpeg_b64(img_bytes: bytes) -> str:
    return base64.b64encode(img_bytes).decode()


# ------------------------------------------------------------- one question
def ask(prompt_parts: list, system: str = "", want_json: bool = False,
        temperature: float = 0.6, provider: str | None = None, key: str | None = None,
        timeout: int = 75) -> str:
    """
    prompt_parts: text strings and/or {"jpeg": bytes} pictures, in order.
    Returns the AI's text. Raises AIFail with a plain-English reason.
    """
    s = settings()
    provider = provider or active(s)
    key = key or key_for(provider, s)
    if not provider or not key:
        raise AIFail("AI isn't turned on. Press Integrations, then AI settings.")
    if provider == "gemini":
        return _ask_gemini(prompt_parts, system, want_json, temperature, key, s, timeout)
    if provider == "openai":
        return _ask_openai(prompt_parts, system, want_json, key, s, timeout)
    if provider == "claude":
        return _ask_claude(prompt_parts, system, want_json, temperature, key, s, timeout)
    raise AIFail("Unknown AI.")


def _ask_gemini(parts_in, system, want_json, temperature, key, s, timeout):
    import ai_reply
    parts = []
    for p in parts_in:
        if isinstance(p, dict) and "jpeg" in p:
            parts.append({"inline_data": {"mime_type": "image/jpeg", "data": _jpeg_b64(p["jpeg"])}})
        else:
            parts.append({"text": str(p)})
    body = {"contents": [{"role": "user", "parts": parts}],
            "generationConfig": {"temperature": temperature}}
    if system:
        body["systemInstruction"] = {"parts": [{"text": system}]}
    if want_json:
        body["generationConfig"]["responseMimeType"] = "application/json"
    models = [s["model"]] if s.get("model") else []
    try:
        models += [m for m in ai_reply.pick_model(key)[:4] if m not in models]
    except Exception as e:
        raise AIFail(ai_reply._why(e))
    last = None
    for m in models:
        try:
            d = ai_reply._post(f"{ai_reply.API}/models/{m}:generateContent", key, body, timeout=timeout)
            out = "".join(x.get("text", "") for x in
                          (((d.get("candidates") or [{}])[0].get("content") or {}).get("parts") or [])).strip()
            if out:
                return out
        except Exception as e:
            last = e
            if ai_reply._slow(e) or getattr(e, "code", 0) in (404, 429, 500, 502, 503, 504):
                continue
            break
    raise AIFail(ai_reply._why(last))


def _ask_openai(parts_in, system, want_json, key, s, timeout):
    content = []
    for p in parts_in:
        if isinstance(p, dict) and "jpeg" in p:
            content.append({"type": "image_url", "image_url": {
                "url": "data:image/jpeg;base64," + _jpeg_b64(p["jpeg"]), "detail": "low"}})
        else:
            content.append({"type": "text", "text": str(p)})
    msgs = ([{"role": "system", "content": system}] if system else []) + \
           [{"role": "user", "content": content}]
    hdr = {"Authorization": f"Bearer {key}"}
    try:
        models = ([s["openai_model"]] if s.get("openai_model") else []) + _openai_models(key)
    except Exception as e:
        raise AIFail(_why("openai", e))
    last = None
    for m in dict.fromkeys(models):
        body = {"model": m, "messages": msgs}
        if want_json:
            body["response_format"] = {"type": "json_object"}
        try:
            d = _post(f"{OPENAI_API}/chat/completions", hdr, body, timeout=timeout)
            out = (((d.get("choices") or [{}])[0].get("message") or {}).get("content") or "").strip()
            if out:
                _remember("openai_model", m)
                return out
        except urllib.error.HTTPError as e:
            last = e
            if e.code in (400, 404):          # this model can't: try the next
                continue
            raise AIFail(_why("openai", e))
        except Exception as e:
            raise AIFail(_why("openai", e))
    raise AIFail(_why("openai", last) if last else "OpenAI didn't answer.")


def _ask_claude(parts_in, system, want_json, temperature, key, s, timeout):
    content = []
    for p in parts_in:
        if isinstance(p, dict) and "jpeg" in p:
            content.append({"type": "image", "source": {"type": "base64", "media_type": "image/jpeg",
                                                         "data": _jpeg_b64(p["jpeg"])}})
        else:
            content.append({"type": "text", "text": str(p)})
    if want_json:
        content.append({"type": "text", "text": "Answer with the JSON only, nothing before or after it."})
    hdr = {"x-api-key": key, "anthropic-version": "2023-06-01"}
    try:
        models = ([s["claude_model"]] if s.get("claude_model") else []) + _claude_models(key)
    except Exception as e:
        raise AIFail(_why("claude", e))
    last = None
    for m in dict.fromkeys(models):
        body = {"model": m, "max_tokens": 3000, "messages": [{"role": "user", "content": content}]}
        if system:
            body["system"] = system
        try:
            d = _post(f"{CLAUDE_API}/messages", hdr, body, timeout=timeout)
            out = "".join(b.get("text", "") for b in d.get("content", []) if b.get("type") == "text").strip()
            if out:
                _remember("claude_model", m)
                return out
        except urllib.error.HTTPError as e:
            last = e
            if e.code in (400, 404):
                continue
            raise AIFail(_why("claude", e))
        except Exception as e:
            raise AIFail(_why("claude", e))
    raise AIFail(_why("claude", last) if last else "Claude didn't answer.")


def _remember(field: str, model: str) -> None:
    import ai_reply
    try:
        s = ai_reply.settings()
        if s.get(field) != model:
            s[field] = model
            ai_reply._write(s)
    except Exception:
        pass


def json_from(text: str) -> dict:
    m = re.search(r"\{.*\}", text or "", re.S)
    return json.loads(m.group(0) if m else text)
