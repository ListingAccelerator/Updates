"""
scrape_inventory.py -- pull the Teays Valley used inventory off the website.

The site is a JavaScript single-page app (Dealer Inspire "spaCosmos"), so
requests + BeautifulSoup gets you empty skeleton loaders. This renders the page
in a real browser first, then reads the cards.

Usage:
    python scrape_inventory.py                  # scrape the live site
    python scrape_inventory.py --no-details     # skip per-vehicle photo galleries
    python scrape_inventory.py --show           # run with a visible browser
    python scrape_inventory.py --from-text FILE # parse a saved page capture instead

Outputs (in out/):
    inventory.json   full records, including photo URLs
    inventory.csv    flat table
    xhr/*.json       any JSON the page fetched -- check these, because if the
                     SPA has a clean inventory endpoint, hitting it directly is
                     far faster and more stable than scraping the DOM.
"""
from __future__ import annotations

import argparse
import csv
import base64
import json
import re
import sys
import time
from pathlib import Path

import config
from vehicle_parser import parse_card_text

# One place that knows what a stock-number label looks like, kept in step with
# vehicle_parser.STOCK_LABEL. Dealer websites spell this label several ways --
# "Stock: 10142A", "Stock #P2163", "Stock Number: 12345" -- and because a
# vehicle card is FOUND by its stock number, a program that only knows the
# first spelling reads a whole dealership as zero cars.
_STOCK_SRC = (r"stock\b\s*(?:(?:number|no\.?|num)\s*)?[:#]*\s*"
              r"(?=[A-Za-z0-9][A-Za-z0-9-]*\d)")
STOCK_JS = f"/{_STOCK_SRC}/i"
STOCK_JS_G = f"/{_STOCK_SRC}/gi"
STOCK_PY = re.compile(_STOCK_SRC, re.I)

# Finds the innermost element that is a whole vehicle card: it mentions a stock
# number and a price label, and no descendant of it does the same.
CARD_JS = r"""
() => {
  // A vehicle card is found by its stock number, then GROWN outward to the
  // largest block that still describes exactly one vehicle. Growing matters:
  // the stock number and the price usually sit in different sub-elements, so
  // the innermost match alone has the stock and no price -- which made every
  // car look unpriced.
  const stockCount = el => ((el.innerText || '').match(__STOCK_G__) || []).length;

  const nodes = Array.from(document.querySelectorAll('div,li,article,section,a'));
  let seeds = nodes.filter(el => {
    const t = el.innerText || '';
    return __STOCK__.test(t) && t.length < 4000 &&
           /(19|20)\d{2}\s+[A-Z]/.test(t);
  });
  // innermost only -- one seed per vehicle
  seeds = seeds.filter(el => !seeds.some(o => o !== el && el.contains(o)));

  const cards = seeds.map(seed => {
    let node = seed;
    while (node.parentElement) {
      const p = node.parentElement;
      const txt = p.innerText || '';
      if (stockCount(p) !== 1 || txt.length > 4000) break;
      node = p;
    }
    return node;
  });

  // growing can land two seeds on the same element
  const uniq = Array.from(new Set(cards));

  return uniq.map(el => {
    const imgs = Array.from(el.querySelectorAll('img'))
      .map(i => i.currentSrc || i.getAttribute('src') || '')
      .filter(s => s && !/skeleton|placeholder|logo|sprite|icon/i.test(s));
    const link = el.matches('a[href]') ? el : el.querySelector('a[href]');
    const cf = Array.from(el.querySelectorAll('a[href]'))
      .find(a => /carfax\.com\/./i.test(a.href) && !/carfax\.com\/?$/i.test(a.href));
    return {
      text: el.innerText,
      images: Array.from(new Set(imgs)),
      href: link ? link.href : '',
      carfax: cf ? cf.href : ''
    };
  });
}
"""

CARD_JS = (CARD_JS.replace("__STOCK_G__", STOCK_JS_G)
                  .replace("__STOCK__", STOCK_JS))

# --- grids that print no stock number -----------------------------------------
# Carsforsale.com (Valley Used Cars) shows year, model, price and miles on the
# grid but no stock number and no VIN, and has no inventory feed to fall back
# on. Every other part of the program finds a car by its stock number, so the
# run saw nothing at all. Here a car is found instead by the link to its own
# page -- link text that starts with a year -- and grown out to the block that
# holds that car alone. Its stock number is read from its own page afterwards.
LINK_CARD_JS = r"""
() => {
  const titleRe = /^\s*(19|20)\d{2}\s+[A-Za-z]/;
  const anchors = Array.from(document.querySelectorAll('a[href]')).filter(a => {
    const t = (a.innerText || '').trim();
    if (!titleRe.test(t) || t.length > 120) return false;
    try {
      const u = new URL(a.href, location.href);
      return u.host === location.host && u.pathname.length > 1;
    } catch (e) { return false; }
  });
  const keyOf = a => { try { return new URL(a.href, location.href).pathname; }
                       catch (e) { return a.href; } };
  const firstFor = new Map();
  anchors.forEach(a => { if (!firstFor.has(keyOf(a))) firstFor.set(keyOf(a), a); });
  const titlesIn = el => new Set(Array.from(el.querySelectorAll('a[href]'))
    .filter(a => anchors.includes(a)).map(keyOf));
  const out = [];
  for (const [key, a] of firstFor) {
    let node = a;
    while (node.parentElement && node.parentElement !== document.body) {
      const p = node.parentElement;
      if (titlesIn(p).size > 1 || (p.innerText || '').length > 4000) break;
      node = p;
    }
    const imgs = Array.from(node.querySelectorAll('img'))
      .map(i => i.currentSrc || i.getAttribute('src') || i.getAttribute('data-src') || '')
      .filter(s => s && !/^data:|skeleton|placeholder|logo|sprite|icon|nophoto/i.test(s));
    out.push({text: node.innerText, images: Array.from(new Set(imgs)),
              href: new URL(a.href, location.href).href});
  }
  // A real grid has several; a lone "2019 Ford" link in a menu is not one.
  return out.length >= 2 ? out : [];
}
"""

NO_STOCK_GRID = False   # this store's grid carries no stock numbers


def read_cards(page) -> list:
    """The vehicle cards on screen, found the way this store needs."""
    if NO_STOCK_GRID:
        return page.evaluate(LINK_CARD_JS)
    return page.evaluate(CARD_JS)


def page_has_cars(page) -> bool:
    try:
        if NO_STOCK_GRID:
            return len(page.evaluate(LINK_CARD_JS)) > 0
        return bool(page.evaluate(
            f"() => {STOCK_JS}.test(document.body.innerText)"))
    except Exception:
        return False


def provisional_key(href: str) -> str:
    """A stand-in id for a car until its own page gives its stock number."""
    import hashlib
    from urllib.parse import urlsplit
    path = urlsplit(href or "").path.rstrip("/")
    nums = re.findall(r"\d{5,}", path)
    if nums:
        return "ID" + nums[-1]
    return "ID" + hashlib.md5(path.encode()).hexdigest()[:8]


DETAIL_ID_JS = r"""
() => {
  const t = document.body ? document.body.innerText : '';
  // "Stock #: 12345" or "Stock: 12345" -- a marker is required, so the
  // words "in stock" next to a model year are never read as one.
  const stock = t.match(/\bstock\s*(?:#|no\.|number|num)\s*:?[ \t]*\n?[ \t]*([A-Za-z0-9-]*\d[A-Za-z0-9-]*)/i)
             || t.match(/\bstock\s*:[ \t]*\n?[ \t]*([A-Za-z0-9-]*\d[A-Za-z0-9-]*)/i);
  const okStock = stock && stock[1].length >= 3 && stock[1].length <= 20;
  const vin = t.match(/\bVIN\b\s*(?:#|no\.?|number)?\s*[:#]?[ \t]*\n?[ \t]*([A-HJ-NPR-Z0-9]{17})\b/i)
           || t.match(/\b([A-HJ-NPR-Z0-9]{17})\b/);
  return {stock: okStock ? stock[1] : '', vin: vin ? vin[1].toUpperCase() : ''};
}
"""


def identify_from_pages(page, records: list[dict]) -> None:
    """
    Read each car's stock number (and VIN) off its own page, for stores whose
    grid shows neither. While the page is open its photo gallery is read too,
    so the gallery step does not have to open it a second time.

    Only the cars he works are opened. The rest keep a stand-in id taken from
    their web address, which stays the same from day to day.
    """
    todo = [r for r in records if r.get("stock_provisional")]
    try:
        import track
        f = track.focus()
        if track.focus_is_on(f):
            todo = [r for r in todo if track.in_focus(r, f)]
    except Exception:
        pass
    if not todo:
        return
    print(f"  this store's list shows no stock numbers -- reading them from "
          f"{len(todo)} vehicle page(s)")
    got = from_vin = 0
    for i, rec in enumerate(todo, 1):
        try:
            page.goto(rec["detail_url"], timeout=config.PAGE_TIMEOUT_MS,
                      wait_until="domcontentloaded")
            page.wait_for_timeout(config.DETAIL_DELAY_MS)
            ids = page.evaluate(DETAIL_ID_JS) or {}
            scroll_through(page)
            shots = page.evaluate(GALLERY_JS)
        except Exception as e:
            print(f"    [{i}/{len(todo)}] {rec['stock']} page failed: {e}")
            continue
        vin = ids.get("vin") or ""
        stock = (ids.get("stock") or "").strip()
        if vin and not rec.get("vin"):
            rec["vin"] = vin
        if not stock and vin:
            stock = vin[-8:]          # the usual dealer fallback
            rec["stock_from_vin"] = True
            from_vin += 1
        if stock:
            rec["stock"] = stock
            rec.pop("stock_provisional", None)
            got += 1
        rec["photos"] = clean_photos(list(rec.get("photos") or [])
                                     + list(shots or []))[
            : getattr(config, "MAX_PHOTOS_PER_VEHICLE", 12)]
        rec["gallery_read"] = True
        if i % 10 == 0 or i == len(todo):
            print(f"    [{i}/{len(todo)}] {rec['stock']} -- "
                  f"{len(rec['photos'])} photos")
    print(f"  stock numbers found for {got} of {len(todo)}"
          + (f" ({from_vin} use the last 8 of the VIN -- the page shows no "
             f"stock number)" if from_vin else ""))


TOTAL_JS = r"""
() => {
  // How many vehicles the website says it has. This number is what stops a
  // half-finished read from being saved and reporting live cars as sold, so
  // it is worth hunting for in more than one place.
  //
  // Plenty of sites never print it in the body at all -- Victory Toyota and
  // Joe Holland both put it only in the page title ("226 Used Cars, Trucks,
  // SUVs in Stock"). Missing it there is how a two-car read passed for a
  // whole store.
  const pats = [
    /showing\s+[\d,]+\s*[-–to]+\s*[\d,]+\s+of\s+([\d,]+)/i,
    // "Results 1 - 24 of 34" (Carsforsale.com)
    /results?\s*:?\s*[\d,]+\s*[-–]\s*[\d,]+\s+of\s+([\d,]+)/i,
    /\b[\d,]+\s*[-–]\s*[\d,]+\s+of\s+([\d,]+)\b/i,
    /of\s+([\d,]+)\s+(?:vehicles?|results?|matches)/i,
    /showing\s+all\s+([\d,]+)\s+vehicles?/i,
    /([\d,]+)\s+(?:vehicles?|results?|matches)\s+found/i,
    /([\d,]+)\s+matching\s+vehicles?/i,
    /([\d,]+)\s+(?:used|new|pre[-\s]?owned|certified)?\s*(?:cars?|trucks?|suvs?|vehicles?)[^.]{0,40}?\bin\s+stock\b/i,
    /\b([\d,]+)\s+(?:vehicles?|results?)\b/i,
  ];
  const meta = document.querySelector('meta[name="description"]');
  const sources = [
    document.body ? document.body.innerText : '',
    document.title || '',
    meta ? (meta.getAttribute('content') || '') : '',
  ];
  for (const pat of pats) {
    for (const txt of sources) {
      const m = (txt || '').match(pat);
      if (m) {
        const n = parseInt(m[1].replace(/,/g, ''), 10);
        // A sane lot size. Guards against matching a phone number, a year,
        // or "0 vehicles" on a page that simply has not loaded yet.
        if (n >= 1 && n <= 100000) return n;
      }
    }
  }
  return null;
}
"""

NEXT_JS = r"""
() => {
  // Find a usable "next page" control, whatever the markup calls it.
  const cands = Array.from(document.querySelectorAll(
    'a,button,[role="button"]'));
  const isNext = el => {
    const t = (el.innerText || '').trim().toLowerCase();
    const aria = (el.getAttribute('aria-label') || '').toLowerCase();
    const rel = (el.getAttribute('rel') || '').toLowerCase();
    const cls = (el.className || '') + ' ' + (el.id || '');
    if (rel === 'next') return true;
    if (/\bnext\b/.test(aria)) return true;
    if (/(^|[^a-z])next([^a-z]|$)|^[>\u203a\u00bb]+$/.test(t)) return true;
    if (/\bnext\b/i.test(cls) && !/prev/i.test(cls)) return true;
    return false;
  };
  const disabled = el =>
    el.hasAttribute('disabled') ||
    el.getAttribute('aria-disabled') === 'true' ||
    /\b(disabled|is-disabled)\b/i.test((el.className || '')) ||
    el.offsetParent === null;

  const hit = cands.find(el => isNext(el) && !disabled(el));
  if (!hit) return null;
  hit.setAttribute('data-claude-next', '1');
  return true;
}
"""

GALLERY_JS = r"""
() => {
  const out = new Set();
  const ok = s => s && !/^data:/i.test(s) &&
    !/skeleton|placeholder|logo|sprite|icon|avatar/i.test(s);
  document.querySelectorAll('img').forEach(i => {
    const s = i.currentSrc || i.getAttribute('src') || '';
    if (ok(s)) out.add(s);
    // Lazy galleries keep the real picture in a data- attribute and show a
    // blank stand-in until it scrolls into view. Dealer Car Search does
    // this, which is why every car at Gary's came back with one photo.
    for (const a of ['data-src', 'data-lazy', 'data-lazy-src', 'data-original',
                     'data-zoom-image', 'data-full', 'data-large', 'data-img']) {
      const v = i.getAttribute(a) || '';
      if (ok(v)) out.add(v);
    }
  });
  // Galleries that link each thumbnail to the full-size picture.
  // Only links whose own path is a picture -- a share button carries the
  // picture in its query ("pinterest.com/pin/create/...&media=x.jpg") and
  // is a web page, not a photo.
  document.querySelectorAll('a[href]').forEach(a => {
    const h = a.getAttribute('href') || '';
    let path = '';
    try { path = new URL(h, location.href).pathname; } catch (e) { return; }
    if (/\.(jpe?g|png|webp)$/i.test(path) && ok(h)) out.add(h);
  });
  document.querySelectorAll('source[srcset]').forEach(s => {
    (s.getAttribute('srcset') || '').split(',').forEach(part => {
      const u = part.trim().split(/\s+/)[0];
      if (u && !/skeleton|placeholder|logo|sprite|icon/i.test(u)) out.add(u);
    });
  });
  return Array.from(out);
}
"""


# Anything that is not a picture of the car. Kept deliberately narrow and
# anchored to file names -- an earlier version matched the word "expand"
# anywhere and threw away Cardinal Chevrolet's whole gallery, which lives
# under /assets/stock/expanded/.
JUNK_IMAGE = re.compile(
    r"\.svg(\?|$)"
    # Share buttons: web pages that carry a picture's address in them.
    r"|no-?photo|no_photo|no-?image|no_image|coming-?soon|newarrivalphoto"
    r"|pinterest\.[a-z.]+/pin/|facebook\.com/sharer|twitter\.com/intent"
    r"|x\.com/intent|linkedin\.com/share|addthis|sharethis"
    r"|valuebadge|partnerstatic|/utilityimages/"
    r"|/(icons?|sprites?|badges?|logos?)/"
    r"|[/_-](logo|sprite|icon|badge|spacer|blank|placeholder|skeleton"
    r"|expand|close|arrow|play|chevron|star)[._-]"
    r"|[/_-](logo|sprite|icon|badge|spacer|blank|placeholder|skeleton)\b",
    re.I)

# A photo's address often carries the size on the end -- the same picture is
# offered at 300, 400, 600, 800 wide. Group by what is left when the size is
# taken off, so one picture counts once and we keep the biggest copy.
SIZE_PATH = re.compile(r"/(\d{2,4})x\d{2,4}/")
SIZE_PARAM = re.compile(r"[?&](width|w|h|height|sz|size)=\d+", re.I)


def clean_photos(urls, site_root: str = "") -> list[str]:
    """
    Turn whatever the page handed us into addresses that will actually load.

    Dealer sites hand back a mess: entries lifted straight out of a srcset
    with the "400w" size descriptor still attached, addresses starting at /
    with no site name on the front, CARFAX badges and little interface icons
    mixed in with the real pictures, and the same photo four times over at
    four different sizes. All of that downloads as nothing.
    """
    root = (site_root or getattr(config, "SITE_ROOT", "") or "").rstrip("/")
    best: dict[str, tuple[int, str]] = {}

    for raw in urls or []:
        if not raw:
            continue
        # "…/pic.png?width=400 400w"  ->  "…/pic.png?width=400"
        u = str(raw).strip().split()[0] if str(raw).strip() else ""
        if not u:
            continue
        if u.startswith("//"):
            u = "https:" + u
        elif u.startswith("/"):
            if not root:
                continue                     # nothing to hang it off
            u = root + u
        elif not u.lower().startswith("http"):
            continue                         # data: URIs and other oddities
        if JUNK_IMAGE.search(u):
            continue

        # Size can also be a folder in the address: Carsforsale.com serves
        # the same picture at /480x360/ and /800x600/. Count it once and keep
        # the bigger one.
        key = SIZE_PATH.sub("/", SIZE_PARAM.sub("", u))
        m = re.search(r"[?&](?:width|w)=(\d+)", u, re.I)
        size = int(m.group(1)) if m else 0
        mp = SIZE_PATH.search(u)
        if mp:
            size = max(size, int(mp.group(1)))
        if key not in best or size > best[key][0]:
            best[key] = (size, u)

    return [u for _, u in best.values()]


def prices_from_feed(blobs) -> dict:
    """
    Pull prices out of the data the website's own page fetched.

    Some dealership sites do not print the price on the card -- Cardinal
    Chevrolet shows "Unlock Cardinal Savings" instead of a number. The price
    is still in the data the page downloaded to build itself; it simply is
    not drawn on screen. This reads it from there.

    The useful field is a run of label:value pairs, base64'd:

        MSRP:8716.0;Internet Price:8716.0;Selling Price:8716.0;
        calc_Dealer Doc Fee:575.0;calc_INTERNET PRICE:9291.0

    which is the same arithmetic every other store publishes openly --
    selling price plus the doc fee is what you ask. Returns a lookup keyed
    by BOTH stock number and VIN, since different sites fill in different
    ones.
    """
    found: dict[str, dict] = {}

    def money(v):
        try:
            n = int(round(float(v)))
            return n if 100 < n < 1_000_000 else None
        except (TypeError, ValueError):
            return None

    def read_card(v: dict) -> None:
        stock = str(v.get("VehicleStockNumber") or "").strip()
        vin = str(v.get("VehicleVin") or "").strip()
        if not stock and not vin:
            return

        lib = v.get("VehiclePriceLibrary") or ""
        parts: dict[str, str] = {}
        if lib:
            try:
                raw = base64.b64decode(lib + "===").decode("utf-8", "replace")
                for chunk in raw.split(";"):
                    if ":" in chunk:
                        k, _, val = chunk.partition(":")
                        parts[k.strip().lower()] = val.strip()
            except Exception:
                pass

        rec: dict = {}

        # The feed also names the car. On a site that renders its cards as
        # pictures and buttons rather than text -- Cardinal Chevrolet does --
        # this is the only place the year, make and model exist at all.
        def text(key):
            t = str(v.get(key) or "").strip()
            return t or None

        try:
            yr = int(v.get("VehicleYear") or 0)
            if 1950 < yr < 2100:
                rec["year"] = yr
        except (TypeError, ValueError):
            pass
        for src, dst in (("VehicleMake", "make"), ("VehicleModel", "model"),
                         ("VehicleTrim", "trim"),
                         # The spec block. Some sites render these as pictures
                         # or leave them off the card entirely, so reading the
                         # feed is often the only way to get them -- Corridor G
                         # was missing the engine on a third of its lot.
                         ("VehicleEngine", "engine"),
                         ("VehicleTransmission", "transmission"),
                         ("VehicleFuelType", "fuel_type"),
                         ("VehicleBodyType", "body_style"),
                         ("VehicleExteriorColor", "exterior_color"),
                         ("VehicleInteriorColor", "interior_color")):
            t = text(src)
            if t:
                rec[dst] = t

        for src, dst in (("VehicleMpgCity", "mpg_city"),
                         ("VehicleMpgHwy", "mpg_hwy")):
            try:
                n = int(v.get(src) or 0)
                if 0 < n < 200:
                    rec[dst] = n
            except (TypeError, ValueError):
                pass

        feats = v.get("Features")
        if isinstance(feats, list):
            clean = [str(f).strip() for f in feats if str(f).strip()]
            if clean:
                rec["features"] = clean
                # Drivetrain is not its own field anywhere in the feed, but
                # four-wheel drive shows up in the feature list. Only set it
                # when it is positively there -- the absence of the word does
                # not prove a truck is two-wheel drive, and guessing wrong on
                # a work truck is worse than leaving it blank.
                joined = " ".join(clean).lower()
                if re.search(r"\b4wd\b|\bawd\b|4x4|four wheel|all wheel", joined):
                    rec["drivetrain"] = "4WD/AWD"

        selling = (money(parts.get("selling price"))
                   or money(parts.get("internet price"))
                   or money(parts.get("msrp"))
                   or money(v.get("VehicleMsrp"))
                   or money(v.get("TaggingPrice")))
        doc = money(parts.get("calc_dealer doc fee"))
        asking = money(parts.get("calc_internet price"))

        if asking:
            rec["final_price"] = asking
        elif selling and doc:
            rec["final_price"] = selling + doc
        elif selling:
            rec["final_price"] = selling
        if doc:
            rec["doc_fee"] = doc
        if selling and rec.get("final_price") and selling != rec["final_price"]:
            rec["retail_price"] = selling

        if rec:
            for key in (stock, vin):
                if key:
                    found[key.upper()] = rec

    def walk(node) -> None:
        if isinstance(node, dict):
            if "VehicleStockNumber" in node or "VehiclePriceLibrary" in node:
                read_card(node)
            for val in node.values():
                walk(val)
        elif isinstance(node, list):
            for val in node:
                walk(val)

    for blob in blobs:
        try:
            walk(blob)
        except Exception:
            continue
    return found


def name_from_url(url: str, vin: str = "") -> dict:
    """
    Work the year, make and model out of a vehicle page's address.

    Dealer platforms nearly all build these the same way:

        /used-Hurricane+WV-2018-GMC-Sierra+1500-SLT-3GTU2NEC1JG538313

    so the year is the first four-digit number that looks like a year, the
    VIN is the tail, and what sits between them is make, model and trim.
    Only used when nothing better is available.
    """
    try:
        tail = str(url).rstrip("/").split("/")[-1]
    except Exception:
        return {}
    tail = tail.replace("+", " ").replace("%20", " ")
    if vin:
        tail = re.sub(re.escape(vin) + r"$", "", tail, flags=re.I).rstrip("-")

    bits = [b.strip() for b in tail.split("-") if b.strip()]
    start = None
    for i, b in enumerate(bits):
        if re.fullmatch(r"(19|20)\d{2}", b) and 1950 < int(b) < 2100:
            start = i
            break
    if start is None or start + 1 >= len(bits):
        return {}

    out: dict = {"year": int(bits[start])}
    rest = bits[start + 1:]
    # A 17-character chunk on the end is the VIN when it was not passed in.
    if rest and re.fullmatch(r"[A-HJ-NPR-Z0-9]{17}", rest[-1], re.I):
        rest = rest[:-1]
    if not rest:
        return {}
    out["make"] = rest[0].title() if rest[0].islower() else rest[0]
    if len(rest) > 1:
        out["model"] = rest[1]
    if len(rest) > 2:
        out["trim"] = " ".join(rest[2:])
    return out


def price_gate_wording(records) -> str:
    """The button a site shows in place of a price, if it shows one."""
    seen: dict[str, int] = {}
    for r in records:
        for o in (r.get("options") or [])[:8]:
            t = str(o).strip()
            if re.search(r"^(unlock|see|get|view|reveal)\b.*\b"
                         r"(price|saving|offer)|call for price", t, re.I):
                seen[t] = seen.get(t, 0) + 1
    if not seen:
        return ""
    return max(seen.items(), key=lambda kv: kv[1])[0]


# Learned from the site's own "page 2" link on the first page: the whole
# second-page address with the page number swapped for {n}. Filled in by
# learn_paging() and used in preference to any configured guess.
PAGE_TEMPLATE: str | None = None

PAGE2_JS = r"""
() => {
  // Find this site's own link to page 2 and hand back its address.
  //
  // Reading it off the page beats guessing the parameter name. Every
  // platform names it differently -- pt= on one, _p= on another, page= on a
  // third -- and some carry filters on the paged address that the plain
  // inventory address does not have. Following the site's own link gets all
  // of that right without the salesman knowing any of it.
  const as = Array.from(document.querySelectorAll('a[href]'));
  const twoIsAParam = href => {
    try {
      const u = new URL(href, location.href);
      for (const [, v] of u.searchParams.entries()) {
        if (v === '2') return true;
      }
    } catch (e) {}
    return false;
  };
  for (const a of as) {
    const t = (a.innerText || '').trim();
    const aria = (a.getAttribute('aria-label') || '').toLowerCase();
    if ((t === '2' || /\bpage\s*2\b/.test(aria)) && twoIsAParam(a.href)) {
      return a.href;
    }
  }
  // On page 1, "next" IS page 2.
  for (const a of as) {
    const rel = (a.getAttribute('rel') || '').toLowerCase();
    const aria = (a.getAttribute('aria-label') || '').toLowerCase();
    if ((rel === 'next' || /\bnext\b/.test(aria)) && twoIsAParam(a.href)) {
      return a.href;
    }
  }
  return '';
}
"""


def learn_paging(page) -> None:
    """Work out how this website pages, by reading its own page-2 link."""
    global PAGE_TEMPLATE
    try:
        href = page.evaluate(PAGE2_JS) or ""
    except Exception:
        return
    if not href:
        return
    from urllib.parse import urlsplit, urlunsplit, parse_qsl, quote

    parts = urlsplit(href)
    pairs = parse_qsl(parts.query, keep_blank_values=True)
    key = next((k for k, v in pairs if v == "2"), "")
    if not key:
        return
    # Rebuild the query by hand: the page number becomes a placeholder, and
    # urlencode would escape the braces we need to substitute into later.
    out, swapped = [], False
    for k, v in pairs:
        if k == key and v == "2" and not swapped:
            out.append(f"{quote(k, safe='[]')}={{n}}")
            swapped = True
        else:
            out.append(f"{quote(k, safe='[]')}={quote(v, safe='[] ')}")
    PAGE_TEMPLATE = urlunsplit(
        (parts.scheme, parts.netloc, parts.path, "&".join(out), ""))
    print(f"  this store pages with {key}= -- following its own page links")


def price_ladder(v) -> dict:
    """
    The price ladder a GM store publishes with each car.

    Joe Holland puts its branded price, its doc fee and the fee-inclusive
    total in oem_fields as a "priceBox" list, while the plain
    dealer_processing_fee field reads zero. Verified on all 20 used cars in
    the Joe Holland feed: dealer_price == pricing.price, and
    dealer_price + dealer_fee == net_price_with_dealer_fees, every time.

    Read by the TYPE on each entry, not by position, so a store that lists
    them in another order still reads correctly.
    """
    want = {"dealer_price": "price", "net_price": "price",
            "dealer_fee": "fee", "total_dealer_fees": "fee",
            "net_price_with_dealer_fees": "net"}
    out: dict = {}

    def walk(node):
        if isinstance(node, dict):
            boxes = node.get("priceBox")
            if isinstance(boxes, list):
                for b in boxes:
                    if not isinstance(b, dict):
                        continue
                    slot = want.get(str(b.get("type") or "").strip().lower())
                    amt = b.get("amount")
                    if slot and isinstance(amt, (int, float)) and amt > 0:
                        out.setdefault(slot, int(amt))
            for val in node.values():
                walk(val)
        elif isinstance(node, list):
            for val in node:
                walk(val)

    walk(v.get("oem_fields") or {})
    return out


FEED_WINS = ("final_price", "price_before_fees", "doc_fee",
             "retail_price", "savings")
FEED_LONGER = ("photos", "features")
FEED_OR = ("certified", "managers_special")


def merge_feed(records: list[dict], feed_recs: list[dict]) -> tuple[int, int]:
    """
    Fold the store's own feed into the cars read off the page, by stock number.

    It used to fill only the BLANK fields, so whatever the card showed won --
    even when the card was worse. On Joe Holland that meant:
      * the card's pre-fee $27,317 beat the feed's fee-inclusive $27,892, so
        one store's ads carried two different price rules
      * the card's single thumbnail beat the feed's thirty photos, which then
        sent the program opening every car's page for pictures -- the very
        thing that sets off the "verifying you are human" screen
      * the card's default "not certified / not a special" beat the feed's
        stated True, so the Certified and Specials filters missed them

    The rule now: prices come from the feed when it has one (it is stated by
    the store's own system, not read off a screen); the longer photo list
    wins; a badge is on if EITHER source says so; everything else fills
    blanks only.

    Returns (vehicles changed, vehicles that gained a price).
    """
    by_stock = {str(r.get("stock", "")): r for r in records}
    enriched = priced = 0
    for fr in feed_recs:
        old = by_stock.get(str(fr.get("stock", "")))
        if not old:
            continue
        # Remember what the CARD said the price was, before the feed replaces
        # it. Comparing the two across the lot is how we learn whether this
        # store's cards show prices before or after its fee.
        if old.get("final_price") and "card_price" not in old:
            old["card_price"] = old["final_price"]
        had_price = bool(old.get("final_price") or old.get("moses_price"))
        touched = False
        for k, v in fr.items():
            if v in (None, "", []):
                continue
            cur = old.get(k)
            if k in FEED_WINS:
                if cur != v:
                    old[k] = v
                    touched = True
            elif k in FEED_LONGER:
                if not isinstance(cur, list) or len(v) > len(cur):
                    old[k] = v
                    touched = True
            elif k in FEED_OR:
                if v and not cur:
                    old[k] = True
                    touched = True
            elif cur in (None, "", []):
                old[k] = v
                touched = True
        enriched += touched
        if not had_price and old.get("final_price"):
            priced += 1
    return enriched, priced


def apply_store_fee(records: list[dict]) -> int:
    """
    Put the store's fee on cars the feed did not cover, so one lot has one
    price rule.

    Joe Holland's page lists cars its feed leaves out. Those keep the price
    from their card -- and the card shows the price BEFORE the $575 fee,
    while every feed car's ad includes it. Two rules on one lot.

    Only done on evidence, never assumed: the cars both sources cover must
    show the card price equal to the feed's before-fee price, nearly every
    time, and the store must charge one flat fee. Otherwise nothing changes.
    Returns how many cars it adjusted.
    """
    both = [r for r in records
            if r.get("card_price") and r.get("price_before_fees")
            and r.get("doc_fee")]
    if len(both) < 5:
        return 0
    pre_fee = sum(1 for r in both if r["card_price"] == r["price_before_fees"])
    fees = {r["doc_fee"] for r in both}
    if pre_fee < len(both) * 0.9 or len(fees) != 1:
        return 0
    fee = fees.pop()

    changed = 0
    for r in records:
        if r.get("price_before_fees") or r.get("doc_fee"):
            continue                          # already priced with its fee
        p = r.get("final_price")
        if not p:
            continue
        r["price_before_fees"] = p
        r["doc_fee"] = fee
        r["final_price"] = p + fee
        changed += 1
    return changed


def _cars_listings(blob) -> list:
    """Pull the vehicle list out of a Cars Commerce search response."""
    if not isinstance(blob, dict):
        return []
    data = blob.get("data")
    if isinstance(data, dict) and isinstance(data.get("listings"), list):
        return data["listings"]
    if isinstance(blob.get("listings"), list):
        return blob["listings"]
    return []


def cars_feed_total(blobs) -> int | None:
    """The vehicle count the Cars Commerce feed reports, if present."""
    for b in blobs or []:
        if not isinstance(b, dict):
            continue
        for d in (b.get("data"), b):
            if isinstance(d, dict):
                n = d.get("total_vehicle_count")
                if isinstance(n, int) and n > 0:
                    return n
    return None


def records_from_cars_feed(blobs) -> list[dict]:
    """
    Build whole records from a Cars Commerce (Dealer Inspire) inventory feed.

    Some Dealer Inspire themes never print a stock number on the inventory
    grid, and the program finds a vehicle BY its stock number -- so Victory
    Toyota's 228 cars came back as two. The feed behind the page has
    everything and more cleanly than the cards ever did: stock, VIN, the
    asking price, the doc fee, the engine, the colours, thirty-odd photos,
    and whether each car is Certified or a special.

    Same lesson as Cardinal Chevrolet: when a site publishes a feed, read the
    feed and stop fighting the markup.
    """
    global FEED_SKIPPED_NEW
    out: dict[str, dict] = {}
    skipped_new: set[str] = set()
    cap = int(getattr(config, "MAX_PHOTOS_PER_VEHICLE", 16) or 16)

    for blob in blobs or []:
        for v in _cars_listings(blob):
            if not isinstance(v, dict):
                continue
            stock = str(v.get("stock") or "").strip()
            if not stock:
                continue

            kind = str(v.get("type") or "").strip()      # Used / Certified / New
            is_new = bool(kind and "new" in kind.lower()
                          and "pre" not in kind.lower())
            want = str(getattr(config, "FOCUS_CONDITION", "used")
                       or "used").lower()
            if is_new and want == "used":
                skipped_new.add(stock)                   # not his to post
                continue

            rec: dict = {"stock": stock}

            def put(key, val):
                if val not in (None, "", []):
                    rec[key] = val

            put("vin", str(v.get("vin") or "").strip() or None)
            put("detail_url", str(v.get("vdp_url") or "").strip() or None)
            try:
                y = int(v.get("year") or 0)
                if 1950 < y < 2100:
                    rec["year"] = y
            except (TypeError, ValueError):
                pass
            put("make", str(v.get("make") or "").strip() or None)
            put("model", str(v.get("model") or "").strip() or None)
            put("trim", str(v.get("trim") or "").strip() or None)
            try:
                mi = int(v.get("mileage") or 0)
                if mi > 0:
                    rec["mileage"] = mi
            except (TypeError, ValueError):
                pass

            pr = v.get("pricing") if isinstance(v.get("pricing"), dict) else {}
            def num(*keys):
                for k in keys:
                    n = pr.get(k)
                    if isinstance(n, (int, float)) and n > 0:
                        return int(n)
                return None
            # The website's own pricing recipe, which is where a store puts
            # its branded price and its doc fee. Victory Toyota's doc fee is
            # $398 in here while the plain dealer_processing_fee field reads
            # zero, and a store that labels its price "Joe Holland Price"
            # names the field holding it here rather than in `price`.
            apd = pr.get("advanced_pricing_detail")
            apd_fee = apd_low = None
            if isinstance(apd, dict):
                for item in apd.get("items") or []:
                    if not isinstance(item, dict):
                        continue
                    kind = str(item.get("type") or "").lower()
                    attr = str(item.get("priceAttribute") or "").strip()
                    expr = str(item.get("expression") or "").strip()
                    money = None
                    if attr and isinstance(pr.get(attr), (int, float)):
                        money = int(pr[attr]) or None
                    elif re.fullmatch(r"\d{2,7}(\.\d+)?", expr):
                        money = int(float(expr)) or None
                    if money is None:
                        continue
                    if kind == "fee" and apd_fee is None:
                        apd_fee = money
                    elif kind in ("low_price", "final_price", "sale_price") \
                            and apd_low is None:
                        apd_low = money

            ladder = price_ladder(v)

            # What goes in the ad is the fee-inclusive figure, so the number a
            # buyer reads on Marketplace is the number on the desk. New cars
            # from this store already include the fee, so used cars matching
            # keeps every ad on the same footing.
            fee = num("dealer_processing_fee") or apd_fee or ladder.get("fee")
            if ladder.get("net"):
                ask = ladder["net"]
                if ladder.get("price"):
                    put("price_before_fees", ladder["price"])
            elif apd_low and fee:
                # The site's own recipe draws "Now $37,799" with the fee as a
                # separate line, so its low price is BEFORE the fee. Add it,
                # or this store's ads come out $398 light while Joe Holland's
                # include their $575 -- two stores, two rules. Victory's feed
                # confirms the sum: our_price 38,197 = 37,799 + 398.
                #
                # But not blindly. A store whose "Now" figure already has the
                # fee in it would be charged twice. When the feed carries its
                # own fee-inclusive figure, let it decide.
                ours = num("our_price")
                if ours and ours == apd_low:
                    ask = apd_low                    # fee already included
                elif ours and ours == apd_low + fee:
                    ask = ours                       # confirmed: add it
                    put("price_before_fees", apd_low)
                else:
                    ask = apd_low + fee
                    put("price_before_fees", apd_low)
            else:
                ask = (apd_low
                       or num("price", "our_price", "internet_price"))
            put("final_price", ask)
            put("retail_price", num("msrp", "original_price"))
            put("savings", num("total_savings", "discounts"))
            put("doc_fee", fee)

            mech = v.get("mechanical") if isinstance(v.get("mechanical"), dict) else {}
            put("engine", str(mech.get("engine") or "").strip() or None)
            put("transmission", str(mech.get("transmission") or "").strip() or None)
            put("fuel_type", str(mech.get("fuel_type") or "").strip() or None)
            put("drivetrain", str(mech.get("drivetrain") or "").strip() or None)
            for src, dst in (("city_mpg", "mpg_city"), ("highway_mpg", "mpg_hwy")):
                n = mech.get(src)
                if isinstance(n, (int, float)) and n > 0:
                    rec[dst] = int(n)

            st = v.get("styles") if isinstance(v.get("styles"), dict) else {}
            put("exterior_color", str(st.get("exterior_color") or "").strip() or None)
            put("interior_color", str(st.get("interior_color") or "").strip() or None)

            bd = v.get("body_details") if isinstance(v.get("body_details"), dict) else {}
            put("body_style", str(bd.get("type")
                                  or bd.get("generic_type") or "").strip() or None)

            feats = v.get("features")
            if isinstance(feats, list):
                clean = [str(f).strip() for f in feats
                         if str(f).strip() and len(str(f).strip()) < 60]
                put("features", clean[:40])
                joined = " ".join(clean).lower()
                if re.search(r"\b4wd\b|\bawd\b|4x4|four wheel|all wheel", joined):
                    rec.setdefault("drivetrain", "4WD/AWD")

            media = v.get("media") if isinstance(v.get("media"), dict) else {}
            imgs = media.get("images")
            if isinstance(imgs, list):
                put("photos", clean_photos(imgs)[:cap])

            # The feed states both of these outright, so there is nothing to
            # guess at from badge text.
            rec["certified"] = "certified" in kind.lower()
            rec["condition"] = "new" if is_new else "used"
            rec["managers_special"] = bool(v.get("is_special"))
            put("date_in_stock", str(v.get("date_in_stock") or "")[:10] or None)

            dealer = v.get("dealer") if isinstance(v.get("dealer"), dict) else {}
            put("selling_store", str(dealer.get("location")
                                     or dealer.get("name") or "").strip() or None)

            out[stock] = rec

    FEED_SKIPPED_NEW = len(skipped_new)
    return list(out.values())


def page_url(n: int) -> str:
    """Page 1 is the plain URL; later pages follow how the site itself pages."""
    if n <= 1:
        return config.INVENTORY_URL
    if PAGE_TEMPLATE:
        return PAGE_TEMPLATE.replace("{n}", str(n))
    param = getattr(config, "PAGE_PARAM", "pt")
    sep = "&" if "?" in config.INVENTORY_URL else "?"
    return f"{config.INVENTORY_URL}{sep}{param}={n}"



def wait_for_cards_stable(page, settle_ms: int = 600, limit_ms: int = 25_000) -> int:
    """
    Wait until the number of vehicle cards stops growing.

    These pages fill in lazily, so reading them too early silently returns 90
    of 96 and looks like a complete page. Scrolling alone is not enough -- the
    card count has to actually stop moving before it is safe to read.
    """
    import time
    count_js = (f"() => (document.body.innerText.match({STOCK_JS_G}) "
                f"|| []).length")
    start = time.time()
    last, stable_since = -1, None
    while (time.time() - start) * 1000 < limit_ms:
        page.mouse.wheel(0, 2500)
        page.wait_for_timeout(250)
        try:
            n = page.evaluate(count_js)
        except Exception:
            break
        if n == last:
            if stable_since is None:
                stable_since = time.time()
            elif (time.time() - stable_since) * 1000 >= settle_ms:
                break
        else:
            last, stable_since = n, None
    page.evaluate("window.scrollTo(0, 0)")
    page.wait_for_timeout(200)
    return max(last, 0)


LOAD_MORE_JS = r"""
() => {
  // Find and click this site's "Load More" control, if it has one.
  //
  // Careful about what counts: a vehicle card has its own "Show more" for the
  // feature list, and clicking that does not load any cars. So anything
  // sitting inside something that already mentions a stock number is ignored,
  // and the control has to actually be on screen.
  // Is this control inside ONE vehicle's card? An ancestor that mentions
  // exactly one stock number is that vehicle's card, so a "show more" in
  // there belongs to its feature list. An ancestor mentioning many is just a
  // container -- and the page body mentions every car on the lot, which is
  // why this must not simply walk to the top.
  const stockCount = el => ((el.innerText || '').match(__STOCK_G__) || []).length;
  const isCard = el => {
    let n = el, hops = 0;
    while (n && n !== document.body && hops++ < 8) {
      // A card is small. The page's search form also says "Stock #" once,
      // and wraps everything -- the page buttons included.
      if (stockCount(n) === 1 && (n.innerText || '').length < 4000) return true;
      n = n.parentElement;
    }
    return false;
  };
  const wanted = /^(load|show|view|see)\s+(\d+\s+)?more(\s+(vehicles?|results?|cars?|inventory))?$|^more\s+(vehicles?|results?)$/i;
  const cands = Array.from(document.querySelectorAll(
    'button,a,[role="button"],input[type="button"],input[type="submit"]'));
  for (const el of cands) {
    const t = ((el.innerText || el.value || '') + '').trim();
    if (!wanted.test(t)) continue;
    if (el.disabled) continue;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) continue;      // hidden
    if (isCard(el)) continue;                        // inside one vehicle
    el.scrollIntoView({block: 'center'});
    el.click();
    return t;
  }
  return '';
}
"""
LOAD_MORE_JS = LOAD_MORE_JS.replace("__STOCK_G__", STOCK_JS_G)


# --- stores that change pages by clicking, not by address -------------------
# Dealer Car Search (Gary's Auto Sales) shows "Page: 1 of 3 (57 vehicles)",
# but its page links carry no page number -- they run a script that swaps the
# cars in place. The address never changes, so there is nothing to follow,
# and the run stopped at the first 24 of 57. Two ways round it, tried in
# order: ask for the biggest page size the store offers, then click through
# its own page buttons like a shopper would.
_CARD_GUARD_JS = r"""
  const stockCount = el => ((el.innerText || '').match(__STOCK_G__) || []).length;
  const isCard = el => {
    let n = el, hops = 0;
    while (n && n !== document.body && hops++ < 8) {
      // A card is small. The page's search form also says "Stock #" once,
      // and wraps everything -- the page buttons included.
      if (stockCount(n) === 1 && (n.innerText || '').length < 4000) return true;
      n = n.parentElement;
    }
    return false;
  };
  const visible = el => {
    const r = el.getBoundingClientRect();
    return r.width > 1 && r.height > 1;
  };
"""

PER_PAGE_JS = r"""
() => {
  __GUARD__
  const near = (el, re, hops) => {
    let n = el;
    for (let i = 0; n && i < hops; i++, n = n.parentElement) {
      if (re.test((n.innerText || '') + ' ' + (n.id || '') + ' ' +
                  (n.getAttribute && (n.getAttribute('name') || '')) + ' ' +
                  (typeof n.className === 'string' ? n.className : ''))) return true;
    }
    return false;
  };
  const sizeWords = /per\s*page|page\s*size|results\s*per|show(ing)?\s*:?\s*$|view\s*:?\s*$|display/i;
  // A drop-down of page sizes.
  for (const sel of document.querySelectorAll('select')) {
    const opts = Array.from(sel.options);
    const nums = opts.map(o => parseInt(((o.textContent || '') + ' ' + o.value).replace(/[^\d]/g, ''), 10));
    if (opts.length < 2 || nums.some(v => !(v > 0 && v <= 1000))) continue;
    if (Math.max(...nums) < 30) continue;
    if (!near(sel, /per\s*page|page\s*size|results|show|view|display|pagesize|perpage/i, 3)) continue;
    const best = nums.indexOf(Math.max(...nums));
    if (sel.selectedIndex === best) return '';
    sel.selectedIndex = best;
    sel.dispatchEvent(new Event('input', {bubbles: true}));
    sel.dispatchEvent(new Event('change', {bubbles: true}));
    return String(nums[best]);
  }
  // A row of clickable sizes: "Per Page: 12 24 48 72 96".
  const cands = Array.from(document.querySelectorAll('a,button,[role="button"],li,span'))
    .filter(el => /^\d{2,3}$/.test((el.innerText || '').trim()) && el.children.length === 0
                  && visible(el) && !isCard(el)
                  && near(el, /per\s*page|page\s*size|results\s*per|pagesize|perpage/i, 3));
  if (cands.length >= 2) {
    const best = cands.reduce((a, b) =>
      parseInt(b.innerText, 10) > parseInt(a.innerText, 10) ? b : a);
    best.scrollIntoView({block: 'center'});
    best.click();
    return best.innerText.trim();
  }
  return '';
}
"""

CLICK_PAGE_JS = r"""
(n) => {
  __GUARD__
  const inSizes = el => {
    let x = el;
    for (let i = 0; x && i < 3; i++, x = x.parentElement)
      if (/per\s*page|page\s*size|results\s*per/i.test(x.innerText || '')) return true;
    return false;
  };
  const els = Array.from(document.querySelectorAll('a,button,[role="button"],li,span'))
    .filter(el => visible(el) && !isCard(el) && !inSizes(el));
  // The button for page n itself -- a bare number, sitting near the button
  // for the page before it so a stray "2" elsewhere is never pressed.
  const want = String(n), prev = String(n - 1);
  let hit = els.find(el => (el.innerText || '').trim() === want &&
    el.children.length === 0 && (() => {
      let p = el.parentElement;
      for (let i = 0; p && i < 3; i++, p = p.parentElement)
        if (new RegExp('(^|\\D)' + prev + '(\\D|$)').test(p.innerText || '')) return true;
      return false;
    })());
  // Otherwise a "Next" control.
  if (!hit) hit = els.find(el => {
    const t = (el.innerText || '').trim().toLowerCase();
    const aria = (el.getAttribute('aria-label') || '').toLowerCase();
    if (el.hasAttribute('disabled') || /\bdisabled\b/.test(
        typeof el.className === 'string' ? el.className : '')) return false;
    return /^next\b|\bnext\s*(page)?\s*[>›»]*$/.test(t) ||
           /^[>›»]$/.test(t) || /\bnext\b/.test(aria);
  });
  if (!hit) return '';
  // A list item or span that holds the real link: press the link, which is
  // what the page listens to (Carsforsale.com's Next sits in an <li>).
  if (!hit.matches('a,button,[role="button"]')) {
    const inner = hit.querySelector('a,button,[role="button"]');
    if (inner) hit = inner;
  }
  hit.scrollIntoView({block: 'center'});
  hit.click();
  return (hit.innerText || hit.getAttribute('aria-label') || 'next').trim();
}
"""
PER_PAGE_JS = PER_PAGE_JS.replace("__GUARD__", _CARD_GUARD_JS).replace(
    "__STOCK_G__", STOCK_JS_G)
CLICK_PAGE_JS = CLICK_PAGE_JS.replace("__GUARD__", _CARD_GUARD_JS).replace(
    "__STOCK_G__", STOCK_JS_G)

# A fingerprint of the cars on screen: each stock label together with what
# follows it. The stock pattern alone matches only the label ("Stock #:"),
# which reads the same on every page, so a page change looked like nothing.
STOCKS_ON_PAGE_JS = r"""
() => {
  const t = document.body.innerText || '';
  const m = t.match(/stock[^\n]{0,4}\s*[:#]?\s*[A-Za-z0-9-]{2,20}/gi) || [];
  // Plus the cars' own links, for grids with no stock numbers (a lone
  // "Stock #" search box would otherwise read the same on every page).
  const links = Array.from(document.querySelectorAll('a[href]'))
    .filter(a => /^\s*(19|20)\d{2}\s+[A-Za-z]/.test(a.innerText || ''))
    .map(a => a.getAttribute('href'));
  if (!m.length && !links.length) return '';
  return m.join('|') + '||' + links.join('|');
}
"""


def _wait_for_new_cards(page, before: str, limit_s: float = 15.0) -> bool:
    """After a click, wait for a different set of cars to be on the page."""
    import time
    stop = time.time() + limit_s
    while time.time() < stop:
        page.wait_for_timeout(400)
        try:
            now = page.evaluate(STOCKS_ON_PAGE_JS)
        except Exception:
            continue                      # mid-navigation
        if now and now != before:
            wait_for_cards_stable(page)
            return True
    return False


def try_bigger_pages(page) -> bool:
    """Pick the store's largest page size, if it offers one. True if it did."""
    try:
        before = page.evaluate(STOCKS_ON_PAGE_JS)
        picked = page.evaluate(PER_PAGE_JS)
    except Exception:
        return False
    if not picked:
        return False
    print(f"  asking the store for {picked} vehicles per page")
    if _wait_for_new_cards(page, before):
        return True
    return False


def click_to_page(page, n: int) -> bool:
    """Press this store's button for page n. True if new cars came up."""
    try:
        before = page.evaluate(STOCKS_ON_PAGE_JS)
        hit = page.evaluate(CLICK_PAGE_JS, n)
    except Exception:
        return False
    if not hit:
        return False
    return _wait_for_new_cards(page, before)


def load_everything(page, total: int | None, patient: bool) -> int:
    """
    Get every vehicle onto the page before reading it.

    Dealer websites do this three different ways and the salesman cannot be
    expected to know which one his store uses:

      1. real pages, with a link to page 2        -- handled by page_url()
      2. endless scroll: everything piles onto one page as you scroll
      3. a "Load More" button that adds a dozen at a time

    Two and three both look like a one-page store that only has twelve cars,
    which is how a hundred-car lot comes back nearly empty. So keep scrolling
    and keep pressing the button until the count reaches what the site says it
    has, or until it genuinely stops growing.

    `patient` is on when no page-2 link was found, meaning this is probably
    one of the scrolling kinds and worth waiting on. On a properly paged site
    there is nothing to wait for, so it stays off and the run keeps its pace.
    """
    import time
    count_js = (f"() => (document.body.innerText.match({STOCK_JS_G}) "
                f"|| []).length")
    budget = float(getattr(config, "LOAD_ALL_SECONDS", 240 if patient else 45))
    quiet_rounds = 6 if patient else 3
    settle = 1100 if patient else 500

    start = time.time()
    seen = 0
    still = 0
    clicks = 0
    announced = False
    while time.time() - start < budget:
        page.mouse.wheel(0, 3000)
        page.wait_for_timeout(settle)
        try:
            n = page.evaluate(count_js)
        except Exception:
            break

        if n > seen:
            if patient and not announced and total and n < total:
                print(f"  this store puts them all on one page -- "
                      f"loading all {total}, this part takes a minute")
                announced = True
            seen, still = n, 0
            if total and n >= total:
                break
            continue

        # Nothing new from scrolling. Try the button before giving up.
        try:
            hit = page.evaluate(LOAD_MORE_JS)
        except Exception:
            hit = ""
        if hit:
            clicks += 1
            if clicks == 1:
                print(f"  pressing the store's \"{hit}\" button to get them all")
            page.wait_for_timeout(settle + 600)
            still = 0
            continue

        still += 1
        if still >= quiet_rounds:
            break

    try:
        page.evaluate("window.scrollTo(0, 0)")
        page.wait_for_timeout(200)
    except Exception:
        pass
    if clicks:
        print(f"  pressed it {clicks} time(s); {seen} vehicles on the page")
    return seen


def scroll_through(page) -> None:
    """Trigger lazy-loaded cards and images by walking down the page."""
    last = 0
    for _ in range(40):
        page.mouse.wheel(0, 2200)
        page.wait_for_timeout(350)
        h = page.evaluate("document.body.scrollHeight")
        if h == last:
            break
        last = h
    page.evaluate("window.scrollTo(0, 0)")
    page.wait_for_timeout(400)


def record_from_card(card: dict) -> dict:
    rec = parse_card_text(card.get("text", ""))
    rec["detail_url"] = card.get("href", "")
    rec["photos"] = clean_photos(card.get("images") or [])
    if card.get("carfax"):
        rec["carfax_url"] = card["carfax"]       # the store's free report link for this car
    if NO_STOCK_GRID and not rec.get("stock") and rec["detail_url"]:
        rec["stock"] = provisional_key(rec["detail_url"])
        rec["stock_provisional"] = True
    return rec


# The vehicle count the website itself reports, so main() can refuse to write
# a run that clearly did not read the whole lot.
SITE_TOTAL: int | None = None

# Set when the store is too big to work through in one sitting and the run was
# stopped to say so. main() reads this to exit with its own code, so the window
# can tell him rather than leaving him watching a bar that never finishes.
CLICK_PAGED = False   # this store changes pages by clicking, not by address
BLOCKED = ""   # name of a bot-check service that turned the run away
TOO_BIG = False

# How many NEW vehicles the inventory feed listed and we left out. A used-car
# page's own count includes them, so the target has to come down by this many
# or a complete run looks short.
FEED_SKIPPED_NEW = 0


def hours_for(cars: int, pages: int = 0) -> float:
    """
    Roughly how long a run takes, end to end.

    Two different costs, and on a dealer-group website they come apart badly:

      * walking the pages, which depends on how many the WEBSITE lists
      * reading detail pages and pulling photos, which only happens for the
        cars he can actually sell

    A Ford store inside a big organisation can list two and a half thousand
    vehicles and stock a hundred and fifty. Charging him for all 2,528 would
    stop a run that was never going to be long.

    The per-car figure is measured, not guessed: 81 vehicles took twenty
    minutes with photos.
    """
    per_car = float(getattr(config, "SECONDS_PER_CAR", 15.0))
    per_page = float(getattr(config, "SECONDS_PER_PAGE", 12.0))
    return (cars * per_car + pages * per_page) / 3600.0


def big_lot_stop(total: int, mine: int | None = None,
                 pages: int = 0) -> bool:
    """
    Stop before a run that would take all day, and explain the choice.

    `mine` is how many of those vehicles look like they are at HIS store,
    estimated from the first page. On a normal store that is all of them. On
    a group feed it can be a small fraction, and then the run is short and
    there is nothing to warn about.
    """
    global TOO_BIG
    hours_limit = float(getattr(config, "BIG_LOT_HOURS", 2.5) or 0)
    mine = total if mine is None else mine
    hours = hours_for(mine, pages)
    if not hours_limit or hours <= hours_limit:
        return False
    if getattr(config, "BIG_LOT_OK", False):
        print(f"  A big one: about {hours:.1f} hours, and you have said to "
              f"read it all.")
        return False

    import track
    narrowed = track.focus_is_on()

    TOO_BIG = True
    print()
    print("  " + "=" * 62)
    if mine < total:
        print(f"  THIS WEBSITE LISTS {total:,} VEHICLES")
        print(f"  (about {mine:,} of them look like they are at your store)")
    else:
        print(f"  THIS STORE HAS {total:,} VEHICLES")
    print("  " + "=" * 62)
    print()
    print(f"  That is roughly {hours:.1f} hours, and most of it is")
    print("  downloading photos of cars you would never post.")
    print()
    if narrowed:
        print(f"  You already work {track.focus_wording()}.")
        print("  It is still too big. Narrow it further, or open Settings")
        print("  and tick \"read this whole store anyway\".")
    else:
        print("  Two ways forward:")
        print()
        print("   1. Open \"What you work\" and narrow it down -- a price")
        print("      range, a few makes, or a body style. The program still")
        print("      reads every car so your sold report stays right, but it")
        print("      only pulls photos for the ones you work.")
        print()
        print("   2. If you really do want all of them, open Settings and")
        print("      tick \"read this whole store anyway\", then start it")
        print("      before you leave for the day.")
    print()
    print("  Nothing was changed. Your last run is still in place.")
    print()
    return True

# Most dealer sites show twelve vehicles per page unless the address carries
# a page-size parameter, so a 400-car store is 34 pages. This is the stop so
# a misbehaving site cannot walk forever; it is not a limit anyone should
# need to think about.
PAGE_CAP = 150


def scrape_live(fetch_details: bool, headless: bool) -> list[dict]:
    from playwright.sync_api import sync_playwright

    xhr_dir = config.OUT / "xhr"
    xhr_dir.mkdir(parents=True, exist_ok=True)
    seen_xhr = 0
    feed_blobs: list = []

    records: list[dict] = []

    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=headless)
        ctx = browser.new_context(
            viewport={"width": 1600, "height": 1000},
            user_agent=("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                        "AppleWebKit/537.36 (KHTML, like Gecko) "
                        "Chrome/124.0 Safari/537.36"),
        )
        page = ctx.new_page()

        def on_response(resp):
            nonlocal seen_xhr
            try:
                ct = (resp.headers or {}).get("content-type", "")
                if "json" not in ct.lower():
                    return
                body = resp.text()
                if len(body) < 200:
                    return

                # Saving files for diagnosis is capped. COLLECTING THE FEED IS
                # NOT -- that cap used to sit above this and swallowed the
                # inventory feed whole. Victory Toyota fires forty JSON calls
                # on page one alone, so pages two onward captured nothing and
                # a 228-car store read as two.
                if seen_xhr < 40:
                    seen_xhr += 1
                    name = re.sub(r"[^a-zA-Z0-9]+", "_", resp.url)[-90:]
                    (xhr_dir / f"{seen_xhr:02d}_{name}.json").write_text(
                        body[:2_000_000], encoding="utf-8"
                    )

                # On a site that hides its prices -- or its stock numbers --
                # the feed is the only place the real data exists.
                if ("VehiclePriceLibrary" in body
                        or "VehicleStockNumber" in body
                        or "total_vehicle_count" in body
                        or '"vdp_url"' in body):
                    try:
                        feed_blobs.append(json.loads(body))
                    except Exception:
                        pass
            except Exception:
                pass

        page.on("response", on_response)

        print(f"Loading {config.INVENTORY_URL}")
        page.goto(config.INVENTORY_URL, timeout=config.PAGE_TIMEOUT_MS,
                  wait_until="domcontentloaded")

        # Wait for the inventory to arrive -- as cards on the screen, OR as
        # the site's own feed.
        #
        # Waiting only for cards is what made Victory Toyota look like a dead
        # end: that theme prints no stock number on the grid, so the wait
        # timed out and the run ended before anyone looked at the feed sitting
        # in hand with all 228 vehicles in it. The feed is a first-class
        # source, not a patch over the markup.
        import time as _t
        deadline = _t.time() + (config.PAGE_TIMEOUT_MS / 1000.0)
        saw_cards = False
        links_since = None
        global NO_STOCK_GRID
        while _t.time() < deadline:
            try:
                saw_cards = bool(page.evaluate(
                    f"() => {STOCK_JS}.test(document.body.innerText)"))
            except Exception:
                saw_cards = False
            if saw_cards or records_from_cars_feed(feed_blobs):
                break
            # No stock numbers yet, but a grid of cars linked to their own
            # pages. Give a feed a few seconds to turn up first -- Victory
            # Toyota has both, and its feed is the better source.
            try:
                if page.evaluate(LINK_CARD_JS):
                    links_since = links_since or _t.time()
                    if _t.time() - links_since > 6:
                        NO_STOCK_GRID = True
                        saw_cards = True
                        print("  no stock numbers on this store's list -- "
                              "finding cars by their links instead")
                        break
            except Exception:
                pass
            # A bot check will never turn into cards, so there is no point
            # sitting out the rest of the timeout waiting for one.
            try:
                if blocked_by(page.content()):
                    break
            except Exception:
                pass
            page.wait_for_timeout(400)

        if not saw_cards and not records_from_cars_feed(feed_blobs):
            try:
                html_now = page.content()
            except Exception:
                html_now = ""
            wall = blocked_by(html_now)
            if wall:
                global BLOCKED
                BLOCKED = wall
                report_blocked(wall)
                (config.OUT / "debug_page.html").write_text(html_now,
                                                            encoding="utf-8")
                browser.close()
                return []
            print("No vehicle cards appeared before timeout.")
            (config.OUT / "debug_page.html").write_text(page.content(),
                                                        encoding="utf-8")
            print(f"Saved page HTML to {config.OUT / 'debug_page.html'}")
            browser.close()
            return []

        # "Stock #" can appear on the page without any car under it -- the
        # search box on Carsforsale.com is labelled that way. If the words
        # are there but no card with a stock number turns up, and the cars
        # are linked to their own pages, read them by their links.
        if saw_cards and not NO_STOCK_GRID and not records_from_cars_feed(feed_blobs):
            stop_at = _t.time() + 8
            while _t.time() < stop_at:
                try:
                    if page.evaluate(CARD_JS):
                        break
                    if page.evaluate(LINK_CARD_JS):
                        NO_STOCK_GRID = True
                        print("  no stock numbers on this store's list -- "
                              "finding cars by their links instead")
                        break
                except Exception:
                    pass
                page.wait_for_timeout(400)

        if not saw_cards:
            print("  This store's pages don't show stock numbers -- "
                  "reading its inventory feed instead.")

        if saw_cards:
            wait_for_cards_stable(page)

        total = page.evaluate(TOTAL_JS)
        if total:
            global SITE_TOTAL
            SITE_TOTAL = total
            print(f"Site reports {total} vehicles")

        # Whether this is too big to work through is decided a moment later,
        # once the first page of cards shows how many of these vehicles are
        # actually at his store. See the "too big" check below.

        # Read how this website pages before asking it for page 2. No page-2
        # link means it is one of the scrolling kinds, so page one holds the
        # whole lot and it is worth waiting for all of it.
        learn_paging(page)
        one_pager = PAGE_TEMPLATE is None
        if one_pager:
            print("  no page links on this store -- "
                  "reading it as one long page")
        load_everything(page, total, patient=one_pager)

        # Walk every page. Big stores run several; Teays Valley fits on one.
        seen_stocks: set[str] = set()
        records = []
        pages_walked = 1
        # How many pages to walk. A salesman types in the web address of his
        # inventory; he cannot be expected to know how many pages his store
        # runs, or to put a page-size parameter on the end of the address.
        #
        # So: start with whatever is configured, then once page 1 has been
        # read, work out how many pages the site total actually needs and
        # walk that many. A lot that fits on one page still stops after one.
        max_pages = getattr(config, "MAX_PAGES", 0) or 0
        auto_pages = max_pages < 1          # 0 means work it out below
        if auto_pages:
            max_pages = PAGE_CAP
        if one_pager:
            # The whole lot is already on this page. Asking for page 2 would
            # just fetch the same page over again and read nothing new.
            max_pages, auto_pages = 1, False
        page_no = 0
        while page_no < max_pages:
            page_no += 1
            feed_before = len(records_from_cars_feed(feed_blobs))
            if page_no > 1:
                url = page_url(page_no)
                try:
                    page.goto(url, timeout=config.PAGE_TIMEOUT_MS,
                              wait_until="domcontentloaded")
                    # Wait for this page to produce something -- cards on the
                    # screen, or more vehicles in the feed. A store whose
                    # grid carries no stock number only ever produces the
                    # second kind, and waiting for cards there would stop the
                    # walk at page one.
                    import time as _t2
                    stop = _t2.time() + 12.0
                    while _t2.time() < stop:
                        try:
                            if page_has_cars(page):
                                break
                        except Exception:
                            pass
                        if len(records_from_cars_feed(feed_blobs)) > feed_before:
                            break
                        page.wait_for_timeout(400)
                    else:
                        raise TimeoutError("nothing on this page")
                except Exception:
                    print(f"  page {page_no} has no vehicles -- that's the end")
                    break
                load_everything(page, None, patient=False)
            cards = read_cards(page)
            fresh = 0
            for c in cards:
                rec = record_from_card(c)
                s = rec.get("stock")
                if s and s not in seen_stocks:
                    seen_stocks.add(s)
                    records.append(rec)
                    fresh += 1

            # Vehicles that arrived in the feed count as progress too, so a
            # store with no stock numbers on its grid still pages through.
            feed_now = len(records_from_cars_feed(feed_blobs))
            feed_gain = feed_now - feed_before
            # Only when the page itself gave nothing readable. Where the cards
            # can be read, the feed cars are the same cars over again, and
            # adding them made the log say "20 cards, 36 new".
            if not cards:
                fresh += max(0, feed_gain)
            if feed_now and not cards:
                print(f"  page {page_no}: {feed_gain} from the feed "
                      f"(running total {feed_now})")
            else:
                print(f"  page {page_no}: {len(cards)} cards, {fresh} new "
                      f"(running total {len(records)})")

            # Decide now, on the first page, whether this is worth hours.
            #
            # The website's own count is not the measure on a dealer-group
            # site: Capital Ford lists 2,528 and stocks a fraction of that.
            # So read what share of this first page is actually his, and
            # judge the run by the work it will really take.
            if page_no == 1 and total and records:
                try:
                    import track
                    here = len(records)
                    # Same rule as the full check below: a different town
                    # on most of the page means the city in setup is spelt
                    # differently from the website, not that the cars are
                    # elsewhere. Only a different website counts here then.
                    whys = [track.other_store(r) for r in records]
                    soft_n = sum(1 for w in whys
                                 if w and not w.startswith("listed on"))
                    if soft_n > len(records) * 0.40:
                        whys = [w if w.startswith("listed on") else ""
                                for w in whys]
                    mine_here = sum(1 for w in whys if not w)
                    share = mine_here / here if here else 1.0
                    est_mine = max(1, round(total * share))
                    est_pages = max(1, -(-total // max(1, len(cards)
                                                       or feed_gain or 20)))
                    if mine_here < here:
                        print(f"  {here - mine_here} of the first {here} are "
                              f"at another store, so this website is showing "
                              f"the group's")
                        print(f"  inventory -- roughly {est_mine:,} of the "
                              f"{total:,} look like yours")
                    if big_lot_stop(total, est_mine, est_pages):
                        browser.close()
                        return []
                except Exception:
                    pass

            pages_walked = page_no
            if fresh == 0 and page_no > 1:
                print("  no new vehicles on this page -- stopping")
                break
            if total and len(records) >= total:
                break

            # After the first page we know the page size, so we know how many
            # pages this store actually needs. One page of 96 at a store with
            # 83 cars is done; twelve per page at the same store needs seven.
            # Page size comes from the cards when the grid is readable, and
            # from the feed when it is not.
            per_page = len(cards) or max(0, feed_gain)
            if auto_pages and page_no == 1 and total and per_page:
                need = -(-total // per_page)         # round up
                if need > 1:
                    want = min(need + 2, PAGE_CAP)   # +2 for a short last page
                    if want > max_pages:
                        max_pages = want
                    print(f"  {len(cards)} per page and {total} vehicles, so "
                          f"this store runs about {need} pages")



        # A store that pages by clicking: no page-2 address was found, and
        # loading everything left us short of the site's own count. Try its
        # biggest page size first, then press its page buttons in turn.
        global CLICK_PAGED
        if one_pager and total and len(records) < total * 0.90:
            def _take(tag: str) -> int:
                got = 0
                for c in read_cards(page):
                    rec = record_from_card(c)
                    st = rec.get("stock")
                    if st and st not in seen_stocks:
                        seen_stocks.add(st)
                        records.append(rec)
                        got += 1
                print(f"  {tag}: {got} new (running total {len(records)})")
                return got

            if try_bigger_pages(page):
                load_everything(page, total, patient=False)
                _take("bigger page")
            n = 2
            if len(records) < total:
                print("  this store changes pages by clicking -- "
                      "pressing its page buttons")
            while len(records) < total and n <= PAGE_CAP:
                if not click_to_page(page, n):
                    break
                CLICK_PAGED = True
                load_everything(page, None, patient=False)
                if _take(f"page {n}") == 0:
                    break
                pages_walked = n
                n += 1

        # Only worth saying if we stopped on the cap with cars still missing.
        if (pages_walked >= max_pages and total
                and len(records) < total * 0.90):
            print(f"\n  !! Stopped after {pages_walked} pages with "
                  f"{len(records)} of {total} read.\n     The site may be "
                  f"paging in a way this doesn't follow.")

        # If the site publishes a feed with more vehicles than the screen gave
        # up, switch to it NOW -- before the recovery pass below. Walking
        # every page a second time to re-read cards that carry no stock
        # number is pure waste, and on Victory Toyota it doubled the run.
        feed_recs = records_from_cars_feed(feed_blobs)
        # Merge what the feed knows into the cars we already have, by stock
        # number, BEFORE deciding whether to swap wholesale. The feed may well
        # be shorter than the page -- Joe Holland's feed is used-only (115)
        # while the page lists 131 -- and the old code threw it away whenever
        # it was shorter, taking every used-car price and doc fee with it.
        # That is why 29 priced cars came back as "no price yet".
        if feed_recs:
            enriched, priced = merge_feed(records, feed_recs)
            if priced:
                print(f"\n  Filled the price on {priced} vehicle(s) from the "
                      f"store's own feed.")
            elif enriched:
                print(f"\n  Filled details on {enriched} vehicle(s) from the "
                      f"store's own feed.")

        if len(feed_recs) > len(records):
            by_stock = {str(r.get("stock", "")): r for r in records}
            for fr in feed_recs:
                old = by_stock.get(fr.get("stock", ""))
                if old:
                    for k, v in old.items():
                        if v not in (None, "", []) and fr.get(k) in (None, "", []):
                            fr[k] = v
            print(f"\n  The page showed {len(records)} vehicle(s); this "
                  f"store's own feed lists {len(feed_recs)}.")
            print("  Reading the feed instead -- it carries the prices, "
                  "specs and photos.")
            records = feed_recs
            ft = cars_feed_total(feed_blobs)
            if ft:
                # The feed counts every vehicle on the page, new ones
                # included. We deliberately left the new ones out, so the
                # target has to come down by that many or the short-read
                # guard would refuse a run that is actually complete.
                total = max(1, ft - FEED_SKIPPED_NEW)
                SITE_TOTAL = total
                if FEED_SKIPPED_NEW:
                    print(f"  ({FEED_SKIPPED_NEW} new vehicles on that feed "
                          f"are not yours to post, so they are left out.)")

        # Second pass. Lazy-loading means a page can hand back 90 of its 96
        # cards and look finished, so if we're short of the site's own count,
        # walk the pages again and pick up whatever was missed.
        # Runs for a one-page store as well. Teays Valley fits on a single
        # page, and skipping the recovery pass there is what let a short
        # read report 36 live cars as sold.
        if total and len(records) < total and CLICK_PAGED:
            # Re-loading by address only ever brings back page one here.
            pass
        elif total and len(records) < total:
            print(f"\n  Short by {total - len(records)}. Re-checking pages...")
            for page_no in range(1, pages_walked + 1):
                if len(records) >= total:
                    break
                try:
                    page.goto(page_url(page_no),
                              timeout=config.PAGE_TIMEOUT_MS,
                              wait_until="domcontentloaded")
                    if NO_STOCK_GRID:
                        page.wait_for_timeout(2500)
                    else:
                        page.wait_for_function(
                            f"() => {STOCK_JS}.test(document.body.innerText)",
                            timeout=12_000)
                except Exception:
                    continue
                # On a one-page store this is the second attempt at loading
                # the whole thing, so be patient with it again.
                load_everything(page, total, patient=one_pager)
                gained = 0
                for c in read_cards(page):
                    rec = record_from_card(c)
                    s = rec.get("stock")
                    if s and s not in seen_stocks:
                        seen_stocks.add(s)
                        records.append(rec)
                        gained += 1
                if gained:
                    print(f"    page {page_no}: picked up {gained} more "
                          f"(total {len(records)})")

        # Cars picked up by the second pass arrived after the feed was folded
        # in above, so they would otherwise go out with only what their card
        # showed -- no feed price, no photos, no Certified flag. Folding the
        # feed in again is harmless for the cars that already have it.
        feed_recs = records_from_cars_feed(feed_blobs)
        if feed_recs:
            merge_feed(records, feed_recs)
            n = apply_store_fee(records)
            if n:
                print(f"\n  {n} vehicle(s) the feed didn't cover showed their "
                      f"price before the store's fee;")
                print("  added it, so every ad on this lot uses the same "
                      "price rule.")

        if NO_STOCK_GRID:
            identify_from_pages(page, records)
        print(f"Parsed {len(records)} records with a stock number")

        # Mark anything that belongs to another store in the group. They stay
        # in the inventory list -- so they are not mistaken for sold cars --
        # but they are kept out of the ads, the photos and the to-do.
        try:
            import track
            flagged = {}
            hits = [(r, track.other_store(r)) for r in records]
            hits = [(r, w) for r, w in hits if w]

            # A different website is proof. A different TOWN is only a hint,
            # and it rests on the city he typed at setup matching the way his
            # own website spells it. If that hint would throw out a large
            # share of the lot, the city is what is wrong, not the cars --
            # so the hint is dropped rather than emptying his inventory.
            soft = [(r, w) for r, w in hits if not w.startswith("listed on")]
            if records and len(soft) > len(records) * 0.40:
                print()
                print(f"  ({len(soft)} vehicles looked like another town, "
                      f"which is too many to believe --")
                print("   keeping them all. Check the city on your setup "
                      "screen.)")
                keep = {id(r) for r, _ in soft}
                hits = [(r, w) for r, w in hits if id(r) not in keep]

            # A different website is strong evidence -- but not when it is
            # EVERY car. A real group feed always holds some of this store's
            # own stock, so "all of them are somewhere else" means the
            # address he typed does not match the one in the store's feed,
            # not that he has no inventory. Emptying his lot over that would
            # be the worst thing this program could do.
            hard = [(r, w) for r, w in hits if w.startswith("listed on")]
            if records and len(hard) >= len(records) * 0.90:
                print()
                print(f"  ({len(hard)} of {len(records)} vehicles point at a "
                      f"different web address than the")
                print("   one you entered -- that is all of them, so the "
                      "address is what is")
                print("   wrong, not the cars. Keeping them all.)")
                drop = {id(r) for r, _ in hard}
                hits = [(r, w) for r, w in hits if id(r) not in drop]

            # Record the verdict on every car, not just the flagged ones, so
            # the later steps use THIS decision instead of re-checking the
            # town on their own. They used to re-check, which undid the
            # "too many to believe -- keeping them all" safeguard: the
            # Supercenter run said it was keeping all 388 and then wrote no
            # ads, because every later step threw them out again.
            for r in records:
                r["other_store"] = ""
                r["store_checked"] = True
            for r, why in hits:
                r["other_store"] = why
                flagged[why] = flagged.get(why, 0) + 1
            if flagged:
                n = sum(flagged.values())
                print()
                print(f"  {n} of these vehicles are not at your store:")
                for why, cnt in sorted(flagged.items(),
                                       key=lambda kv: -kv[1])[:6]:
                    print(f"    {cnt:>4}  {why}")
                print("  They are left out of your ads and photos. If any of")
                print("  these ARE yours to sell, tell Claude.")
                print()
        except Exception:
            pass

        # Some inventory pages cannot be read off the screen at all. Victory
        # Toyota prints no stock number on its cards, and a vehicle is FOUND
        # by its stock number, so 228 cars came back as two.
        #
        # When the site publishes a feed with more vehicles than the screen
        # gave up, the feed is simply the better source -- it carries the
        # price, the doc fee, the engine, the colours, thirty photos and
        # whether the car is Certified, all stated rather than guessed.
        # Some sites draw their cards as pictures and buttons rather than
        # readable text, so reading the screen gets a stock number and little
        # else. Fill any blanks from the page's own data feed, and from the
        # address of the vehicle's page, which usually spells the car out.
        if feed_blobs:
            feed = prices_from_feed(feed_blobs)
            got_price = got_name = got_spec = 0
            for r in records:
                hit = (feed.get(str(r.get("stock", "")).upper())
                       or feed.get(str(r.get("vin", "")).upper()))
                if not hit:
                    continue
                had_price = bool(r.get("final_price") or r.get("moses_price"))
                had_name = bool(r.get("make"))
                had_engine = bool(r.get("engine"))
                for k, v in hit.items():
                    if not r.get(k):
                        r[k] = v
                if not had_price and (r.get("final_price")):
                    r["price_from_feed"] = True
                    got_price += 1
                if not had_name and r.get("make"):
                    got_name += 1
                if not had_engine and r.get("engine"):
                    got_spec += 1
            if got_price:
                print(f"  {got_price} vehicle(s) showed no price on the page; "
                      f"read it from the site's own data instead")
                # Say this every single run, not once at install. A website
                # that hides its prices is making a choice, and the man
                # posting them needs reminding that it was not his choice.
                gate = price_gate_wording(records)
                print()
                print(f"  " + "-" * 58)
                print(f"  THIS STORE DOES NOT ADVERTISE THOSE PRICES")
                print(f"  " + "-" * 58)
                if gate:
                    print(f"  Its listings show \"{gate}\" where the price "
                          f"would go.")
                print(f"  The number was still readable in the page, so the ads")
                print(f"  have it. Whether you advertise a price the store has")
                print(f"  chosen not to publish is your call -- and it may be")
                print(f"  against your dealership's policy. Ask first.")
                print(f"  " + "-" * 58)
            if got_name:
                print(f"  {got_name} vehicle(s) showed no year/make/model; "
                      f"read those from the site's own data too")
            if got_spec:
                print(f"  {got_spec} vehicle(s) showed no engine; read the "
                      f"engine and transmission from the data too")

        # Last resort for the name: the vehicle page's own address, which on
        # most platforms reads like  /used-Hurricane+WV-2018-GMC-Sierra-SLT-VIN
        from_url = 0
        for r in records:
            if r.get("make") or not r.get("detail_url"):
                continue
            bits = name_from_url(r["detail_url"], r.get("vin", ""))
            if bits:
                r.update(bits)
                from_url += 1
        if from_url:
            print(f"  {from_url} vehicle(s) named from the address of their "
                  f"own page")
        if total and len(records) < total:
            short = total - len(records)
            print(f"  NOTE: site says {total}, collected {len(records)} "
                  f"({short} short).")
            print(f"  Often those are units with no price shown yet. "
                  f"If it stays far off, tell Claude.")
        if seen_xhr:
            print(f"Captured {seen_xhr} JSON response(s) to {xhr_dir}")

        if fetch_details:
            want = int(getattr(config, "MAX_PHOTOS_PER_VEHICLE", 16) or 16)
            withurl = [r for r in records if r.get("detail_url")]

            # Two reasons to skip a car here, and together they are the
            # difference between opening 228 vehicle pages one at a time and
            # opening none at all:
            #
            #  * the feed already handed us thirty-odd photos of it, so there
            #    is nothing on its page worth going for
            #  * it is not a car he works, so the photos would never be used
            enough = [r for r in withurl if len(r.get("photos") or []) >= want
                      or r.get("gallery_read")]
            withurl = [r for r in withurl if len(r.get("photos") or []) < want
                       and not r.get("gallery_read")]
            if enough:
                read_already = sum(1 for r in enough if r.get("gallery_read"))
                if read_already == len(enough):
                    print(f"  {len(enough)} vehicle(s) had their photos read "
                          f"with their stock numbers -- not opening those "
                          f"pages again.")
                else:
                    print(f"  {len(enough)} vehicle(s) already have their "
                          f"photos from this store's feed -- not opening "
                          f"those pages.")
            try:
                import track
                f = track.focus()
                before = len(withurl)
                if track.focus_is_on(f):
                    withurl = [r for r in withurl if track.in_focus(r, f)]
                else:
                    withurl = [r for r in withurl
                               if not track.is_other_store(r)]
                if before != len(withurl):
                    print(f"  {before - len(withurl)} vehicle(s) outside what "
                          f"you work -- skipping those too.")
            except Exception:
                pass

            # Same first picture as last run, and that run read the whole
            # gallery in the last few days: the set has not changed, so use
            # it and leave the car's page alone. Fewer page loads means a
            # faster run and a site that is less likely to start refusing
            # pages part-way through -- which is how 36 Teays Valley cars
            # once ended up with only their list thumbnail.
            import photo_fill
            prev_ph = photo_fill.previous_photos()
            reused = []
            for r in withurl:
                p = prev_ph.get(r.get("vin"))
                if p and photo_fill.fresh(p) and \
                        photo_fill.same_set(r.get("photos"), p["photos"]):
                    r["photos"] = list(p["photos"])
                    r["gallery_checked"] = p.get("gallery_checked")
                    reused.append(r)
            if reused:
                ids = {id(r) for r in reused}
                withurl = [r for r in withurl if id(r) not in ids]
                print(f"  {len(reused)} vehicle(s) show the same pictures as "
                      f"last run -- using those, not opening their pages.")

            if not withurl:
                print("Nothing left to fetch galleries for.")
            else:
                print(f"Fetching photo galleries for {len(withurl)} "
                      f"vehicles...")
            failed_gallery = []
            for i, rec in enumerate(withurl, 1):
                try:
                    page.goto(rec["detail_url"],
                              timeout=config.PAGE_TIMEOUT_MS,
                              wait_until="domcontentloaded")
                    page.wait_for_timeout(config.DETAIL_DELAY_MS)
                    scroll_through(page)
                    shots = page.evaluate(GALLERY_JS)
                    merged = clean_photos(list(rec["photos"]) + list(shots))
                    rec["photos"] = merged[: getattr(config, "MAX_PHOTOS_PER_VEHICLE", 12)]
                    rec["gallery_checked"] = (
                        photo_fill.today()
                        if len(photo_fill.real(rec["photos"], rec.get("vin"))) > 1
                        else "")
                except Exception as e:
                    first = str(e).splitlines()[0] if str(e) else "error"
                    print(f"  [{i}/{len(withurl)}] {rec['stock']} page did not "
                          f"load ({first[:60]}) -- will try again at the end")
                    failed_gallery.append(rec)
                    continue
                if i % 10 == 0 or i == len(withurl):
                    print(f"  [{i}/{len(withurl)}] {rec['stock']} "
                          f"-- {len(rec['photos'])} photos")

            # A page that timed out once (the Supercenter's site is slow in
            # the evening) usually loads on a second try. Without this the
            # car went out with only the one photo from its list card.
            if failed_gallery:
                print(f"  trying {len(failed_gallery)} gallery page(s) "
                      f"again...")
                for rec in failed_gallery:
                    try:
                        page.goto(rec["detail_url"],
                                  timeout=config.PAGE_TIMEOUT_MS,
                                  wait_until="domcontentloaded")
                        page.wait_for_timeout(config.DETAIL_DELAY_MS)
                        scroll_through(page)
                        shots = page.evaluate(GALLERY_JS)
                        rec["photos"] = clean_photos(
                            list(rec["photos"]) + list(shots))[
                            : getattr(config, "MAX_PHOTOS_PER_VEHICLE", 12)]
                        rec["gallery_checked"] = (
                            photo_fill.today()
                            if len(photo_fill.real(rec["photos"],
                                                  rec.get("vin"))) > 1
                            else "")
                        print(f"    {rec['stock']} -- "
                              f"{len(rec['photos'])} photos")
                    except Exception:
                        rec["gallery_checked"] = ""
                        print(f"    {rec['stock']} -- still would not load")

            # Anything still down to its one list thumbnail -- the page would
            # not load, or loaded without its gallery -- gets two more tries
            # before we settle for one picture:
            #   * last run's full set, if the first picture is unchanged
            #   * the site's numbered pictures (1.jpg, 2.jpg ...) in the
            #     car's own folder
            # Losing a full set to one bad page load also used to wipe the
            # car's downloaded photos, which is worse than doing nothing.
            most = int(getattr(config, "MAX_PHOTOS_PER_VEHICLE", 12) or 12)
            # Count only the car's OWN pictures. The page's "similar
            # vehicles" strip once made 36 cars look like they had 11
            # photos, when 10 of them were other cars and were thrown out
            # later -- leaving one.
            short = [r for r in withurl
                     if photo_fill.needs_more(r.get("photos"), r.get("vin"))]
            kept = filled = 0
            for rec in short:
                have = len(photo_fill.real(rec.get("photos"), rec.get("vin")))
                p = prev_ph.get(rec.get("vin"))
                if have <= 1 and p and photo_fill.same_set(
                        photo_fill.real(rec.get("photos"), rec.get("vin")),
                        p["photos"]):
                    rec["photos"] = list(p["photos"])
                    kept += 1
                    continue
                first = photo_fill.first_numbered(rec.get("photos"),
                                                  rec.get("vin"))
                got = photo_fill.numbered(first, most) if first else []
                if len(got) > have:
                    # the list thumbnail asks for a small size; ask for the
                    # same size the gallery uses
                    got = [re.sub(r"([?&]width=)\d+", r"\g<1>1400", u)
                           for u in got]
                    rec["photos"] = clean_photos(got)[:most]
                    rec["gallery_checked"] = photo_fill.today()
                    filled += 1
            if short:
                print(f"  {len(short)} vehicle(s) came back with only some of "
                      f"their real photos:")
                if kept:
                    print(f"    kept last run's full photo set on {kept}")
                if filled:
                    print(f"    found the rest of the numbered photos on "
                          f"{filled}")
                left = len(short) - kept - filled
                if left:
                    print(f"    {left} have no more real photos on the website "
                          f"yet")

        browser.close()

    return records


def helper_file() -> Path:
    return config.OUT / "helper_cars.json"


def helper_read() -> list[dict] | None:
    """Cars the Chrome helper read off the store's website in the salesperson's
    own Chrome, finished (Done pressed) and fresh -- else None."""
    f = helper_file()
    try:
        d = json.loads(f.read_text(encoding="utf-8"))
    except Exception:
        return None
    if not d.get("done") or d.get("used"):
        return None
    hours = (time.time() - float(d.get("done_at") or 0)) / 3600
    if hours > float(getattr(config, "HELPER_FRESH_HOURS", 20) or 20):
        return None
    def _norm_u(u):
        u = str(u or "").strip().lower().split("#")[0].split("?")[0]
        return u[:-1] if u.endswith("/") else u
    gal = {_norm_u(k): v for k, v in (d.get("galleries") or {}).items()}
    recs, seen = [], set()
    for c in d.get("cards") or []:
        rec = record_from_card(c)
        if not rec.get("stock") and c.get("href"):
            rec["stock"] = provisional_key(c["href"])
            rec["stock_provisional"] = True
        if not rec.get("stock") or rec["stock"] in seen:
            continue
        seen.add(rec["stock"])
        if rec.get("detail_url") and not (rec.get("year") and rec.get("make")):
            for k, v in name_from_url(rec["detail_url"], rec.get("vin", "")).items():
                rec.setdefault(k, v)
        g = gal.get(_norm_u(rec.get("detail_url"))) if rec.get("detail_url") else None
        if g:
            rec["photos"] = clean_photos(list(g) + list(rec.get("photos") or []))
            rec["gallery_read"] = True
        recs.append(rec)
    try:
        apply_store_fee(recs)
    except Exception:
        pass
    try:
        import track
        for r in recs:
            why = track.other_store(r)
            r["other_store"] = why
            r["store_checked"] = True
    except Exception:
        pass
    # cars he works with only their list picture: the site's numbered
    # pictures (1.jpg, 2.jpg...) when it names them that way
    try:
        import photo_fill
        import track
        f_ = track.focus()
        want = int(getattr(config, "MAX_PHOTOS_PER_VEHICLE", 20) or 20)
        more = 0
        for r in recs:
            if len(r.get("photos") or []) <= 1 and not r.get("gallery_read") and track.in_focus(r, f_):
                first = photo_fill.first_numbered(r.get("photos") or [], r.get("vin"))
                nums = photo_fill.numbered(first, want) if first else []
                if len(nums) > 1:
                    r["photos"] = nums[:want]
                    more += 1
        if more:
            print(f"  found the full photo set for {more} more on the website")
    except Exception:
        pass
    print(f"Read by the Chrome helper: {len(recs)} vehicles from {len(d.get('pages') or [])} page(s)"
          + (f", {len(d.get('galleries') or {})} with their full photo set" if d.get("galleries") else ""))
    return recs


def helper_used() -> None:
    """The helper's read is saved: don't use it again."""
    f = helper_file()
    try:
        d = json.loads(f.read_text(encoding="utf-8"))
        d["used"] = True
        f.write_text(json.dumps(d), encoding="utf-8")
    except Exception:
        pass


def scrape_from_text(path: Path) -> list[dict]:
    """Offline mode: parse a saved copy of the rendered page's text."""
    text = path.read_text(encoding="utf-8", errors="replace")
    chunks = [c for c in text.split("Compare Vehicle")
              if STOCK_PY.search(c)]
    recs = [parse_card_text(c) for c in chunks]
    return [r for r in recs if r.get("stock")]


BLOCKERS = [
    # (what shows up in the page, the service's name)
    (("captcha-delivery.com", "datadome"), "DataDome"),
    (("challenges.cloudflare.com", "cf-chl", "cf_chl_opt"), "Cloudflare"),
    (("_incapsula_resource", "incapsula incident"), "Imperva"),
    (("px-captcha", "perimeterx", "human challenge"), "HUMAN"),
    (("errors.edgesuite.net",), "Akamai"),
]


def blocked_by(html: str) -> str:
    """
    The name of the bot-protection service that answered instead of the
    store, or "".

    Capital Ford of Charlotte sent back a DataDome "prove you are human"
    page and no inventory at all. The run used to say only "no vehicle
    cards appeared", which sends you hunting for a problem with the program
    when the site simply refuses automated visitors. The program does not
    try to get past these checks -- the store has chosen to turn programs
    away, and that is its call to make.
    """
    low = (html or "").lower()
    for needles, name in BLOCKERS:
        if any(n in low for n in needles):
            return name
    return ""


def report_blocked(name: str) -> None:
    print()
    print("  " + "!" * 58)
    print("  THIS WEBSITE TURNS AWAY PROGRAMS")
    print("  " + "!" * 58)
    print(f"\n  Instead of its inventory, the site sent back a {name}")
    print("  \"are you a human?\" check. Some stores pay for this to stop")
    print("  programs from reading their pages, and this program does not")
    print("  try to get around it.")
    print("\n  Nothing is wrong with your setup, and nothing was saved, so")
    print("  your list from the last good run is untouched.")
    print("\n  What to do: get the store's INVENTORY FEED instead. Every")
    print("  dealership already sends its cars to Facebook, Cars.com and")
    print("  CarGurus each day, and can send the same feed to you.")
    print("  Press Integrations along the top (Inventory feed) -- it")
    print("  has a message you can copy and send to your manager, and")
    print("  where to put the link or file once you have it.")


def previous_count() -> int:
    """How many vehicles the last saved run held. 0 when there isn't one."""
    try:
        if not config.INVENTORY_JSON.exists():
            return 0
        old = json.loads(config.INVENTORY_JSON.read_text(encoding="utf-8"))
        return len(old) if isinstance(old, list) else 0
    except Exception:
        return 0


_URL_VIN = re.compile(r"(?<![A-Za-z0-9])([A-HJ-NPR-Za-hj-npr-z0-9]{17})(?![A-Za-z0-9])")


def vin_from_url(url: str) -> str:
    """
    The VIN a car's own web address carries, or "".

    Joe Holland's new cars came back with no VIN on the card, yet every one
    of their addresses ends in it: /new-2026-chevrolet-...-3gcpkkek4tg485466/.
    A VIN has 17 characters, never I, O or Q, and always both letters and
    digits -- that last test keeps a long word in the address from passing.
    """
    tail = str(url or "").rstrip("/").rsplit("/", 1)[-1]
    for m in _URL_VIN.finditer(tail):
        v = m.group(1)
        if re.search(r"[A-Za-z]", v) and re.search(r"\d", v):
            return v.upper()
    return ""


def drop_shared_photos(records: list[dict]) -> int:
    """
    Remove pictures that show up on several different vehicles.

    A picture on three or more cars is not a picture of any of them: it is
    the store's "photos coming soon" stand-in, a banner, or a badge. Gary's
    Auto Sales puts a "new arrival" graphic on every car not yet
    photographed -- 20 of its 57 -- and it was being saved as each car's
    photo. Those cars now show as needing photos, which is the truth.
    """
    seen: dict[str, set] = {}
    for r in records:
        for u in r.get("photos") or []:
            key = SIZE_PATH.sub("/", SIZE_PARAM.sub("", str(u)))
            seen.setdefault(key, set()).add(r.get("stock"))
    shared = {k for k, who in seen.items() if len(who) >= 3}
    if not shared:
        return 0
    hit = 0
    for r in records:
        ph = r.get("photos") or []
        keep = [u for u in ph
                if SIZE_PATH.sub("/", SIZE_PARAM.sub("", str(u))) not in shared]
        if len(keep) != len(ph):
            r["photos"] = keep
            hit += 1
    return hit


def write_outputs(records: list[dict]) -> None:
    config.OUT.mkdir(parents=True, exist_ok=True)
    # Stock numbers are kept in capitals: a site that shows "ow26673" one
    # day and "OW26673" the next is still the same car.
    for r in records:
        if r.get("stock"):
            r["stock"] = str(r["stock"]).strip().upper()
    records.sort(key=lambda r: r.get("stock", ""))
    # A colour or spec that is really a price ("$8,162") came from an older
    # build misreading the Supercenter's "Ext." swatch label. Clear it so it
    # is looked up again rather than carried forward into the ads.
    from vehicle_parser import _spec_value_ok
    for r in records:
        r.pop("gallery_read", None)
        for k in ("exterior_color", "interior_color", "interior", "engine",
                  "transmission", "drivetrain", "fuel_type"):
            if k in r and r[k] not in (None, "") and not _spec_value_ok(str(r[k])):
                r.pop(k, None)
    stand_ins = drop_shared_photos(records)
    # Photos of OTHER cars ("similar vehicles" on the car's page) carry
    # their own VIN in the address on many sites. Never this car's picture.
    try:
        import photo_watch
        for r in records:
            ph = r.get("photos") or []
            keep = photo_watch.own_photos(ph, r.get("vin"))
            if len(keep) != len(ph):
                r["photos"] = keep
    except Exception:
        pass
    if stand_ins:
        print(f"  Left out a stand-in picture (\"photo coming soon\", a "
              f"banner or badge) on {stand_ins} vehicle(s) --")
        print(f"  it appears on several cars, so it isn't a photo of any "
              f"of them.")
    for r in records:
        if not r.get("vin"):
            v = vin_from_url(r.get("detail_url", ""))
            if v:
                r["vin"] = v

    config.INVENTORY_JSON.write_text(json.dumps(records, indent=2),
                                     encoding="utf-8")

    cols = ["stock", "year", "make", "model", "trim", "vin", "model_code",
            "mileage", "retail_price", "moses_price", "savings", "doc_fee",
            "final_price", "price_drop", "special_offer", "detail_url",
            "photo_count", "condition", "features"]
    with open(config.INVENTORY_CSV, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        for r in records:
            row = dict(r)
            row["photo_count"] = len(r.get("photos") or [])
            row["features"] = "; ".join(r.get("features") or [])
            # Fill the column for every car, not just the ones the feed
            # labelled, so a spreadsheet filter on it catches the whole lot.
            if not row.get("condition"):
                try:
                    import track
                    row["condition"] = track.condition_of(r)
                except Exception:
                    pass
            w.writerow(row)

    unpriced = [r for r in records if not (r.get("final_price")
                                           or r.get("moses_price"))]
    if unpriced:
        import csv as _csv
        path = config.OUT / "no_price_yet.csv"
        with open(path, "w", newline="", encoding="utf-8") as f:
            w = _csv.writer(f)
            w.writerow(["Stock", "Year", "Make", "Model", "Trim", "Mileage",
                        "VIN"])
            for r in sorted(unpriced, key=lambda x: x.get("stock", "")):
                w.writerow([r.get("stock", ""), r.get("year", ""),
                            r.get("make", ""), r.get("model", ""),
                            r.get("trim", ""), r.get("mileage", ""),
                            r.get("vin", "")])
        # A few unpriced units is normal -- fresh trades the store has not
        # priced yet. ALL of them unpriced means something else: a website
        # that hides its prices behind an "unlock" or "call for price"
        # button. That is not something more scraping can solve, and the
        # salesman needs telling straight away rather than being left to
        # wonder why he got no ads.
        gated = price_gate_wording(records)
        if len(unpriced) == len(records) and records:
            print(f"\n  " + "!" * 58)
            print(f"  THIS WEBSITE DOES NOT SHOW ITS PRICES")
            print(f"  " + "!" * 58)
            print(f"\n  None of the {len(records)} vehicles has a price on the page.")
            if gated:
                print(f"  Every listing says \"{gated}\" instead of a number.")
            print(f"\n  The price is hidden until somebody clicks for it, so there")
            print(f"  is nothing here to read. Everything else worked -- the cars,")
            print(f"  the photos, the colours and engines are all there.")
            print(f"\n  Ads cannot be written without a price. If you work at this")
            print(f"  store you can put the prices in yourself; otherwise this")
            print(f"  site is not one the program can do much with.")
        else:
            print(f"\n  {len(unpriced)} vehicle(s) on the site with NO PRICE yet.")
            print(f"  Listed in {path.name} -- these can't be posted until the")
            print(f"  store prices them, but now you know they're coming.")

    print(f"\nWrote {config.INVENTORY_JSON}")
    print(f"Wrote {config.INVENTORY_CSV}")
    print(f"  vehicles         : {len(records)}")
    missing_vin = [r["stock"] for r in records if not r.get("vin")]
    missing_price = [r["stock"] for r in records if not r.get("final_price")]
    nophoto = [r["stock"] for r in records if not (r.get("photos") or [])]
    if missing_vin:
        print(f"  missing VIN      : {len(missing_vin)} -> {missing_vin[:12]}"
              + (" ..." if len(missing_vin) > 12 else ""))
    if missing_price:
        print(f"  missing price    : {missing_price}")
    if nophoto:
        print(f"  no photos found  : {len(nophoto)} -> {nophoto[:12]}")

    # --- does the price even make sense? ------------------------------------
    # A parser that latches onto the wrong label will happily report a $52,886
    # Lexus as a $1,010 Lexus, and nothing downstream would question it -- the
    # ads just quote the number they are given. Any asking price under 40% of
    # the store's own retail figure is almost certainly a discount or a payment
    # that got read as a price, so say so loudly rather than publish it.
    suspect = []
    for r in records:
        final = r.get("final_price") or r.get("moses_price")
        retail = r.get("retail_price")
        if not (final and retail):
            continue
        # Too low: a discount or a payment got read as the price. That is the
        # bug that showed a $52,886 Lexus as a $1,010 Lexus.
        too_low = final < retail * 0.40
        # Too high: nobody asks MORE than their own retail figure. A stray
        # digit turns $24,475 into $244,475, which is how a Subaru Outback
        # ended up logged at a quarter of a million dollars.
        too_high = final > retail * 1.10
        if too_low or too_high:
            suspect.append((r.get("stock", "?"), final, retail,
                            f"{r.get('year','')} {r.get('make','')} "
                            f"{r.get('model','')}".strip()))
    if suspect:
        print()
        print("  " + "!" * 58)
        print(f"  {len(suspect)} VEHICLE(S) WITH A PRICE THAT LOOKS WRONG")
        print("  " + "!" * 58)
        for stock, final, retail, name in suspect[:12]:
            print(f"    {stock:11s} ${final:>8,} asking vs ${retail:>8,} "
                  f"retail   {name}")
        if len(suspect) > 12:
            print(f"    ... and {len(suspect) - 12} more")
        print()
        print("  These are probably a discount or a payment read as a price.")
        print("  DO NOT POST these until the number is confirmed against the")
        print("  website. Tell Claude and send this list.")
        print()


# Everything the listing card itself can tell us. These come fresh from the
# website on every run and must always be overwritten -- that is the whole
# point of scraping again.
CARD_FIELDS = {
    "year", "make", "model", "trim", "model_trim", "model_code",
    "stock", "vin", "mileage", "retail_price", "moses_price", "savings",
    "doc_fee", "final_price", "price_drop", "special_offer",
    "features", "detail_url", "photos",
    # Judgements made fresh on every run. Carried forward, a wrong one
    # outlives the bug that made it: Saturday's "at Used" tag would have kept
    # every Certified car at Victory Toyota out of the ads for good, even
    # after the fix. Same for a page that failed once, or a special that
    # has since ended.
    "other_store", "selling_store", "certified", "managers_special",
    "condition",
    "price_before_fees", "card_price", "detail_failed", "detail_error",
    "date_in_stock",
}


def carry_forward_details(records: list[dict]) -> list[dict]:
    """
    Keep the detail-page work when the inventory is scraped again.

    scrape_details.py spends 10-15 minutes opening every vehicle's own page to
    collect paint, interior, engine, transmission and the CARFAX notes. None of
    that is on the listing card, so a plain re-scrape used to throw all of it
    away and every ad went back to placeholders. Matching on VIN, anything the
    card cannot provide is carried over from the previous run.

    Prices, mileage and photos are NOT carried over -- those are exactly what we
    came back to the website for.
    """
    if not config.INVENTORY_JSON.exists():
        return records

    try:
        old = json.loads(config.INVENTORY_JSON.read_text(encoding="utf-8"))
    except Exception:
        return records

    by_vin = {r["vin"]: r for r in old if r.get("vin")}
    if not by_vin:
        return records

    kept = 0
    for rec in records:
        prev = by_vin.get(rec.get("vin"))
        if not prev:
            continue
        added = False
        for k, v in prev.items():
            if k in CARD_FIELDS or k in rec or v in (None, "", [], {}):
                continue
            # A failed page last time says nothing about this time. Carried
            # forward, it held a car out of the ads for good -- even after the
            # feed had filled in its colour and engine, because a car with
            # both is never looked up again, so nothing ever cleared the flag.
            if k in ("detail_failed", "detail_error"):
                continue
            rec[k] = v
            added = True
        if added:
            kept += 1

    if kept:
        print(f"\n  Kept detail-page info (color, engine, CARFAX) on {kept} "
              f"vehicle(s)")
        print(f"  that were already looked up. scrape_details.py will only "
              f"work on the new ones.")
    return records


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-details", action="store_true",
                    help="skip per-vehicle photo galleries (much faster)")
    ap.add_argument("--show", action="store_true",
                    help="run with a visible browser window")
    ap.add_argument("--from-text", metavar="FILE",
                    help="parse a saved page text capture instead of going online")
    args = ap.parse_args()

    helper = helper_read()
    if args.from_text:
        recs = scrape_from_text(Path(args.from_text))
    elif helper is not None:
        recs = helper
    elif getattr(config, "READ_BY_HELPER", False):
        print()
        print("  WAITING FOR THE CHROME HELPER")
        print("  This store's cars are read by the Chrome helper, and there's no")
        print("  fresh read yet. In Chrome, open the store's used inventory page,")
        print("  click the Listing Accelerator button in the toolbar and press")
        print("  Read the cars on this page (every page), then Done.")
        print()
        print("  Nothing was changed. Your last good run is still in place.")
        return 1
    elif getattr(config, "FEED_SOURCE", ""):
        # This store's inventory comes from a feed its website company sends,
        # not from reading the website.
        import feed_import
        print(f"Reading the inventory feed: {config.FEED_SOURCE}")
        try:
            recs, rep = feed_import.records()
        except Exception as e:
            print(f"\n  The feed couldn't be read: {e}")
            print("  Nothing was changed. Your last good run is still in place.")
            return 1
        print(f"  {rep['count']} used vehicles in the feed"
              + (f" ({rep['new_skipped']} new ones left out)" if rep["new_skipped"] else ""))
        print(f"  {rep['priced']} with a price, {rep['photos']} with photos")
        if getattr(config, "FEED_ADD_FEE", 0):
            print(f"  added the ${config.FEED_ADD_FEE:,} doc fee to each price")
    else:
        recs = scrape_live(
            fetch_details=config.FETCH_DETAIL_PHOTOS and not args.no_details,
            headless=config.HEADLESS and not args.show,
        )

    if TOO_BIG:
        # Not a failure. The run stopped on purpose and already said why.
        return 3

    if not recs:
        if BLOCKED:
            return 1
        print("No records scraped.")
        return 1

    # --- refuse a short read ------------------------------------------------
    # Anything missing from this run looks exactly like a car that sold, and
    # the morning to-do will tell you to pull those listings down. Reporting
    # 36 live vehicles as sold is far worse than reporting nothing, so if we
    # are well short of the site's own count, write nothing and say so.
    if SITE_TOTAL and len(recs) < SITE_TOTAL * 0.90:
        print()
        print("  " + "!" * 60)
        print(f"  ONLY READ {len(recs)} OF {SITE_TOTAL} VEHICLES -- NOT SAVING")
        print("  " + "!" * 60)
        print()
        print("  The website did not finish loading, so this run is missing")
        print(f"  about {SITE_TOTAL - len(recs)} vehicles. Saving it would")
        print("  report every one of them as SOLD and tell you to take down")
        print("  listings that are still live.")
        print()
        print("  Nothing was changed. Your last good run is still in place.")
        print("  Check your internet connection and run this again.")
        print()
        return 1

    # --- refuse a run that collapsed against the last one -------------------
    # The check above only works when the website printed its own vehicle
    # count. Plenty of them never do, and then there was nothing standing
    # between a two-car read and it being saved as the whole store -- which
    # is exactly how a hundred live listings get reported as sold.
    #
    # The previous good run is the other yardstick, and it needs no
    # cooperation from the website. A lot does not lose half its cars
    # overnight; a read that says it did is a broken read.
    prev = previous_count()
    floor = float(getattr(config, "COLLAPSE_FLOOR", 0.60) or 0)
    if prev >= 10 and floor and len(recs) < prev * floor:
        print()
        print("  " + "!" * 60)
        print(f"  READ {len(recs)} VEHICLES -- LAST RUN HAD {prev}. NOT SAVING")
        print("  " + "!" * 60)
        print()
        print("  A store does not lose that many cars overnight, so this")
        print("  read did not finish. Saving it would report the missing")
        print("  ones as SOLD and tell you to take down listings that are")
        print("  still live.")
        print()
        print("  Nothing was changed. Your last good run is still in place.")
        print("  Run it again. If it keeps happening, send Claude the log")
        print(f"  and the {config.OUT / 'xhr'} folder.")
        print()
        return 1

    recs = carry_forward_details(recs)
    write_outputs(recs)
    if helper is not None:
        helper_used()
    return 0


if __name__ == "__main__":
    sys.exit(main())
