"""
walkaround.py -- turn a car's photos into a short vertical walkaround video.

    title card (car, price, store) -> each photo with a slow zoom and its
    caption -> end card with the salesperson's own name and number.
    No music, no voice. Vertical 1080x1920, like a phone.

CAPTIONS NEVER CLAIM WHAT THE WEBSITE DOESN'T SAY. Every caption choice
comes from the car's own website listing: its paint, miles, drivetrain,
engine, "One owner" only when the site says so, and its listed features.
The salesman reviews each one before the video is made.

Matching captions to photos:
  - With his Gemini key on (AI replies), the AI looks at each photo and
    picks the matching caption -- from the website list only.
  - Otherwise, by photo order: dealer photos run outside first, then inside.
Either way it is only a suggestion until he presses Make video.

Needs Pillow and ffmpeg (the imageio-ffmpeg package). They are installed
the first time a video is made -- one time, about 30 MB.
"""
from __future__ import annotations

import base64
import io
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

PARTS = ["pillow", "imageio-ffmpeg", "numpy"]
PHOTO_EXT = (".jpg", ".jpeg", ".png", ".webp")
MAX_PHOTOS = 20      # the most Facebook takes on a listing, and about a minute of video
DEFAULT_PHOTOS = 12
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


# ------------------------------------------------------------ the add-ons

def end_lines(car: dict) -> list:
    """The last card: him and his cell -- or, for the company page, the store,
    its phone and website (never his name or cell)."""
    if car.get("company"):
        return [(car.get("store", ""), _font(True, 72), WHITE, 30),
                ("Call or stop by today" if car.get("phone") else "Stop by today", _font(False, 44), SOFT, 10),
                (car.get("phone", ""), _font(True, 96), ACCENT, 50),
                (car.get("web", ""), _font(False, 40), SOFT, 0)]
    return [(car.get("seller", ""), _font(True, 72), WHITE, 30),
            ("Call or Text Me Directly" if car.get("phone") else "", _font(False, 44), SOFT, 10),
            (car.get("phone", ""), _font(True, 96), ACCENT, 50),
            (car.get("store", ""), _font(False, 40), SOFT, 0)]

def ffmpeg_exe() -> str | None:
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return shutil.which("ffmpeg")


def ready() -> bool:
    try:
        import PIL  # noqa: F401
        import numpy  # noqa: F401
    except Exception:
        return False
    return bool(ffmpeg_exe())


def install_parts() -> dict:
    """One time: fetch Pillow and ffmpeg, the same way setup fetched the rest."""
    try:
        r = subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", *PARTS],
                           capture_output=True, text=True, timeout=600,
                           creationflags=NO_WINDOW)
        if r.returncode != 0:
            tail = (r.stderr or r.stdout or "").strip().splitlines()[-1:] or [""]
            return {"ok": False, "message": "Couldn't get the video maker. "
                    "Check the internet connection and try again. " + tail[0][:160]}
    except Exception as e:
        return {"ok": False, "message": f"Couldn't get the video maker: {e}"}
    import importlib
    importlib.invalidate_caches()
    return {"ok": ready(), "message": "Video maker ready." if ready()
            else "Installed, but the video maker still isn't answering. Restart the program."}


# ------------------------------------------------------------ captions
SMALL = {"and", "or", "with", "w/", "of", "for", "in", "on", "to", "the", "a"}


def _title(t: str) -> str:
    out = []
    for i, w in enumerate(t.split()):
        if i and w.lower() in SMALL:
            out.append(w.lower())
        elif w[:1].islower() and not any(ch.isdigit() for ch in w):
            out.append(w[:1].upper() + w[1:])
        else:
            out.append(w)
    return " ".join(out)


def _tidy(s: str) -> str:
    s = str(s or "").replace("®", "").replace("™", "").replace('""', '"')
    s = re.sub(r"\b[Ww]/\s*", "with ", s)
    s = re.sub(r"\s*\((?:[\d.,]+\s*(?:cm|mm|m|kg|l|liters?|km)\b[^)]*)\)", "", s, flags=re.I)
    s = re.sub(r"\s+", " ", s).strip(" -·,")
    # Window-sticker style lists the part first: "Wheels, 18" aluminum,
    # painted". Put it the way people say it -- the website's own words,
    # just in order: "18" Aluminum Painted Wheels".
    parts = [p.strip() for p in s.split(",") if p.strip()]
    if len(parts) >= 2 and len(parts[0].split()) <= 2 and parts[0][:1].isupper() \
            and not re.search(r"\d", parts[0]) and len(s) <= 60:
        s = _title(" ".join(parts[1:]) + " " + parts[0].lower())
    elif s[:1].isupper() and re.search(r" [a-z]", s):
        s = _title(s)
    return s


# what a buyer cares about, best first -- for suggesting, not for limiting.
# Patterns, so every website's wording counts ("Heated driver and front
# passenger seats", "Remote vehicle start", "Rear vision camera").
APPEAL = [r"heated.{0,30}(and|&).{0,15}(ventilated|cooled)", r"(ventilated|cooled).{0,25}seat",
          r"heated.{0,40}seat", r"heated.{0,15}steering", r"remote.{0,15}start",
          r"panoramic", r"sun ?roof|moon ?roof", r"navigation|\bnav\b", r"carplay|android auto",
          r"leather", r"(third|3rd).{0,5}row", r"360|surround.{0,10}(view|vision|camera)",
          r"blind.{0,5}(spot|zone)", r"adaptive.{0,10}cruise", r"lane.{0,10}(keep|departure|centering)",
          r"(rear|back|reverse).{0,15}(view|vision|up)?.{0,10}camera|camera.{0,15}(rear|back)",
          r"tow|hitch|trailer", r"power.{0,20}(lift ?gate|tail ?gate)|hands.?free.{0,10}(lift|tail)gate",
          r"wireless.{0,10}charg", r"bose|harman|jbl|bang|premium.{0,10}(audio|sound)|subwoofer",
          r"keyless|push.?button|proximity", r"led.{0,10}head", r"fog", r"running board|assist step|power.{0,5}step",
          r"bed ?liner|spray.?in", r"sliding.{0,10}window", r"dual.{0,5}zone|tri.?zone|automatic climate",
          r"park.{0,10}assist|parksense|parking.{0,10}sensor", r"memory", r"power.{0,15}(driver|seat)",
          r"heated.{0,15}mirror", r"power.?folding", r"garage.{0,10}(door|opener)|homelink",
          r"(alloy|aluminum|chrome|polished).{0,20}wheel|wheel.{0,20}(alloy|aluminum)",
          r"roof.{0,5}(rail|rack)", r"deep.?tint|privacy glass"]
APPEAL_RX = [re.compile(x, re.I) for x in APPEAL]
# true, but no buyer cares -- offered last, never suggested
DULL = re.compile(r"\btires?\b|wiper|molding|mud ?flap|(?<!privacy )\bglass\b|lamp|mirror(?!.*heated)|"
                  r"seat ?belt|horn|antenna|assist handle|cupholder|cup holder|outlet|"
                  r"floor mat|carpet|headliner|visor|grille|license|fascia|bumper|spoiler|"
                  r"defog|wheel ?well|splash|shift|console|door handle|warning|alert$|"
                  r"galvaniz|steel|panel|exhaust|suspension|spring|strut|torsion|stabilizer|"
                  r"fuel tank|\bgal\.?\b|gallon|axle|alternator|battery|brake|rotor|caliper|"
                  r"steering ratio|turning|wheelbase|ground clearance|curb weight|payload|"
                  r"compression|displacement|valve|camshaft|injection|ignition coil|radiator|"
                  r"underbody|skid|crumple|side.?impact|beam|body.?on|unibody|cargo light|"
                  r"tilt|telescop|reading light|map light|power lock|power window|power door", re.I)
OUTSIDE = re.compile(r"fog|led|headl|lamp|mirror|(?<!steering )wheel|tire|hitch|tow|receiver|"
                     r"trailer|bed|liner|sunroof|moonroof|panoramic|roof|running board|"
                     r"step|tailgate|liftgate|grille|spoiler|chrome|rack|sliding window|"
                     r"bumper|exhaust", re.I)
SKIP = re.compile(r"emission|gvwr|axle ratio|telematics|glove box|sun visor|vanity|"
                  r"dome|courtesy|convex|supplemental|badge|defroster|tether|latch|"
                  r"airbag|air bag|immobilizer|stability|traction|brake assist|"
                  r"abs|tire pressure|tpms|child|owner's|manual|spare", re.I)


def _rank(f: str) -> int:
    for i, rx in enumerate(APPEAL_RX):
        if rx.search(f):
            return i
    return len(APPEAL) + (5 if DULL.search(f) else 1)


def caption_choices(rec: dict) -> dict:
    """Everything a caption may say, all taken from the car's website listing."""
    specs = []
    color = _tidy(rec.get("exterior_color"))
    try:
        from vehicle_parser import _spec_value_ok
        if color and not _spec_value_ok(color):
            color = ""
    except Exception:
        pass
    if color:
        specs.append(color)
    inside = _tidy(rec.get("interior_color"))
    if inside:
        specs.append(_title(f"{inside} Interior" if "interior" not in inside.lower() else inside))
    miles = rec.get("mileage")
    if isinstance(miles, (int, float)) and miles > 0:
        specs.append(f"{int(miles):,} miles")
        if rec.get("one_owner") is True:
            specs.append(f"{int(miles):,} miles · One owner")
    if rec.get("one_owner") is True:
        specs.append("One owner")
    drive = _tidy(rec.get("drivetrain"))
    engine = _tidy(rec.get("engine_full") or rec.get("engine"))
    if drive:
        specs.append(drive)
    if engine and len(engine) <= 40:
        specs.append(engine)
    if drive and engine and len(engine) <= 30:
        specs.append(f"{drive} · {engine}")
    try:
        if rec.get("mpg_hwy"):
            specs.append(f"Up to {int(rec['mpg_hwy'])} MPG highway")
    except Exception:
        pass
    wheels = _tidy(rec.get("wheels"))
    if wheels and len(wheels) <= 40:
        specs.append(wheels if "wheel" in wheels.lower() else f"{wheels} Wheels")

    feats = []
    try:
        from build_jt_listings import clean_options
        opts = clean_options(rec.get("options") or [])
    except Exception:
        opts = [o for o in (rec.get("options") or []) if isinstance(o, str)]
    seen = {s.lower() for s in specs}
    for o in opts:
        t = _tidy(o)
        if not t or len(t) > 48 or "\n" in str(o) or t.lower() in seen:
            continue
        seen.add(t.lower())
        feats.append(t)
    feats.sort(key=lambda f: (SKIP.search(f) is not None, DULL.search(f) is not None
                              and _rank(f) > len(APPEAL), _rank(f)))
    return {"specs": specs, "features": feats}


def suggest(rec: dict, count: int) -> list[str]:
    """Captions by photo order: outside first, then inside. Each used once."""
    ch = caption_choices(rec)
    specs, feats = ch["specs"], [f for f in ch["features"] if not SKIP.search(f)]
    good = [f for f in feats if _rank(f) <= len(APPEAL)]
    outside = [f for f in good if OUTSIDE.search(f)]
    inside = [f for f in good if not OUTSIDE.search(f)]
    color = specs[0] if specs and "mile" not in specs[0].lower() else ""
    drive_engine = next((s for s in specs if " · " in s and "mile" not in s), "") or \
        next((s for s in specs if re.search(r"4wd|awd|4x4|fwd|rwd|cylinder|v6|v8|engine|turbo", s, re.I)), "")
    miles = next((s for s in specs if "One owner" in s), "") or \
        next((s for s in specs if "miles" in s), "")
    mpg = next((x for x in specs if "MPG" in x), "")
    out_seq = [c for c in (color, drive_engine, miles, mpg) if c] + outside
    in_seq = inside
    n_out = max(1, round(count * 0.5))
    caps = []
    for i in range(count):
        seq = out_seq if i < n_out else in_seq
        caps.append(seq.pop(0) if seq else "")
    # anything good left over fills empty slots
    rest = out_seq + in_seq
    # still empty: the strong facts (MPG, interior), then leave it blank --
    # no caption beats a dull one
    extra = [x for x in specs if x not in caps and x not in rest and
             re.search(r"mpg|interior", x, re.I)]
    rest += extra
    caps = [c or (rest.pop(0) if rest else "") for c in caps]
    return caps


def ai_choices(rec: dict) -> list[str]:
    """
    What the AI may pick from: the paint, miles, drivetrain and engine, and
    the features buyers care about. Dull-but-true items (glass, door
    handles, wipers, tire sizes...) stay in the drop-down for him, but the
    AI can't choose them just because they're visible in a photo.
    """
    ch = caption_choices(rec)
    good = [f for f in ch["features"]
            if not SKIP.search(f) and not DULL.search(f) and _rank(f) <= len(APPEAL)]
    return ch["specs"] + good


def all_choices(rec: dict) -> list[str]:
    ch = caption_choices(rec)
    return ch["specs"] + ch["features"]


# ------------------------------------------------------------ photos
def photos_for(folder: Path) -> list[Path]:
    if not folder.is_dir():
        return []
    pics = [p for p in folder.iterdir() if p.suffix.lower() in PHOTO_EXT
            and not p.name.lower().startswith(("thumb", ".", "bg_"))
            and ".tmp." not in p.name]
    return sorted(pics, key=lambda p: (not p.name.lower().startswith("web_"), p.name.lower()))


# ------------------------------------------------------------ AI matching
OUTSIDE_SHOT = re.compile(r"front|side|rear|back|exterior|corner|profile|outside|bed|tailgate|"
                          r"wheel|grille|headl|tail ?light|roof", re.I)


# What each kind of inside photo can honestly be captioned with. A cargo
# photo shows the cargo area -- not Android Auto; a back-seat photo shows
# seats -- not Apple CarPlay. Anything the photo can't show stays off it.
VIEW_FITS = [
    (r"cargo|trunk|hatch|liftgate", r"cargo|liftgate|tailgate|split|fold(ing)?[ -]?(down |flat )?(rear |2nd |3rd |second |third )?(row |seat|bench)|fold.?flat|third row|3rd row|tonneau|organizer|power lift"),
    (r"rear seat|back seat|second row|2nd row|third row|3rd row",
     r"rear seat|second row|2nd row|third row|3rd row|split|fold(ing)?[ -]?(down |flat )?(rear |2nd |3rd |second |third )?(row |seat|bench)|fold.?flat|heated rear|rear climate|rear a/?c|"
     r"rear vent|captain|bench|leather|cloth|seating|interior|rear usb|rear entertainment"),
    (r"front seat|seat|interior|cabin|door",
     r"seat|leather|cloth|heated|ventilated|cooled|memory|lumbar|power driver|power passenger|interior|"
     r"bucket|bench|captain"),
    (r"dash|screen|display|radio|infotainment|console|center stack|touch",
     r"carplay|android|navigation|nav\b|touch ?screen|display|audio|radio|speaker|bluetooth|wireless|"
     r"charging|usb|camera|climate|uconnect|sync|infotainment|screen|premium sound|bose|harman|"
     r"jbl|alpine|sirius|wi-?fi|hotspot|dual.zone|tri.zone|interior"),
    (r"steering|wheel controls", r"steering|heated steering|cruise|paddle|adaptive cruise|lane|"
     r"audio control|leather.wrapped"),
    (r"gauge|cluster|instrument|odometer", r"digital|cluster|gauge|display|miles|heads.up|hud"),
    (r"sunroof|moonroof|roof|headliner", r"sunroof|moonroof|panoramic|roof"),
    (r"engine|motor|under ?hood", r"engine|v6|v8|v-6|v-8|cylinder|turbo|hemi|ecoboost|liter|\dl\b|hybrid|diesel"),
    (r"shifter|gear", r"shift|transmission|automatic|manual|drive mode|4wd|awd|4x4"),
    (r"bed", r"bed|liner|tonneau|tailgate|tie.down|cargo"),
    (r"hitch|tow", r"tow|hitch|trailer|receiver"),
    (r"wheel|tire|rim", r"wheel|tire|alloy|rim"),
]
# Facts true of the whole car: fine on any outside photo.
ANY_OUTSIDE = re.compile(r"miles|one owner|mpg|4wd|awd|4x4|fwd|rwd|2wd|v6|v8|cylinder|turbo|"
                         r"engine|hybrid|electric|diesel", re.I)


def fits_photo(caption: str, shows: str, rec: dict | None = None) -> bool:
    """Can this caption honestly go on a photo that shows this?"""
    c, v = (caption or "").lower(), (shows or "").lower()
    if not c:
        return True
    color = str((rec or {}).get("exterior_color") or "").lower().strip()
    inside_color = str((rec or {}).get("interior_color") or "").lower().strip()
    outside = bool(OUTSIDE_SHOT.search(v)) and not re.search(r"seat|dash|cargo|interior|steering|"
                                                             r"screen|console|gauge|engine", v)
    if outside or not v:
        if color and c == color:
            return True
        if "interior" in c:
            return False
        if ANY_OUTSIDE.search(c):
            return True
        if OUTSIDE.search(c):
            # a front part on a front photo, a back part on a back photo
            front_part = re.search(r"\bfront\b|fog|grille|headl|hood|windshield|bumper guard", c)
            rear_part = re.search(r"\brear\b|tail|hitch|receiver|tow|trailer|bed|liner|liftgate|"
                                  r"sliding window|exhaust|spare", c)
            looks_front = re.search(r"front|grille|headl", v) and not re.search(r"rear|back", v)
            looks_rear = re.search(r"rear|back|tail|bed|hitch", v) and not re.search(r"front", v)
            if front_part and looks_rear:
                return False
            if rear_part and looks_front:
                return False
            return True
        return False
    if color and c == color:
        return False                     # the paint, on an inside photo? no
    if "interior" in c:
        return bool(re.search(r"seat|dash|interior|cabin|door|steering|console", v))
    for view, ok in VIEW_FITS:
        if re.search(view, v):
            return bool(re.search(ok, c))
    return False


def ai_match(rec: dict, photos: list[Path], choices: list[str]) -> dict:
    """Ask Gemini what each photo shows and which listed caption fits."""
    import ai_engine
    if not ai_engine.on():
        return {"ok": False, "off": True}
    try:
        from PIL import Image
    except Exception:
        return {"ok": False, "message": "Get the video maker first."}
    parts = [(
        "These photos are all of the same used vehicle for sale: "
        f"{rec.get('year', '')} {rec.get('make', '')} {rec.get('model', '')} {rec.get('trim', '')}. "
        "For each photo, in order, say what it shows in 1 to 3 words (front, side, rear, "
        "wheel, bed, cargo, dash, steering wheel, front seats, rear seats, screen, gauges, "
        "engine, badge, sunroof...). Then pick ONE caption for it from the CAPTION LIST "
        "that is clearly visible in that photo or directly about what it shows. Use each "
        "caption at most once. Copy captions exactly as written in the list. If nothing "
        "fits, use an empty caption. For the first outside photo, prefer the paint color. "
        "Only caption what the photo actually shows: never put an inside feature (CarPlay, "
        "navigation, remote start, heated seats) on an outside photo, and never put a "
        "feature on a photo where you can't see it (a cargo photo gets a cargo caption or "
        "none). An empty caption is much better than a wrong one. "
        "When more than one caption fits a photo, pick what a car buyer cares about most "
        "(comfort, technology, safety, towing, wheels, looks) over minor parts (tires, "
        "wipers, moldings, glass, lamps). The list is already in that order, best first.\n\n"
        "CAPTION LIST:\n" + "\n".join(f"- {c}" for c in choices) +
        '\n\nReturn JSON only: {"photos": [{"n": 1, "shows": "front", "caption": "..."}]}')]
    for i, p in enumerate(photos, 1):
        try:
            im = Image.open(p).convert("RGB")
            im.thumbnail((640, 640))
            buf = io.BytesIO()
            im.save(buf, "JPEG", quality=80)
            parts.append(f"Photo {i}:")
            parts.append({"jpeg": buf.getvalue()})
        except Exception:
            parts.append(f"Photo {i}: (could not be read)")
    try:
        txt = ai_engine.ask(parts, want_json=True, temperature=0.2)
    except ai_engine.AIFail as e:
        return {"ok": False, "message": str(e)}
    allowed = {c: c for c in choices}
    allowed_low = {c.lower().strip(): c for c in choices}
    try:
        got = ai_engine.json_from(txt).get("photos", [])
    except Exception:
        return {"ok": False, "message": "The AI's answer couldn't be read. Try again."}
    caps, shows, used = [""] * len(photos), [""] * len(photos), set()
    for g in got:
        try:
            k = int(g.get("n")) - 1
        except Exception:
            continue
        if not 0 <= k < len(photos):
            continue
        shows[k] = str(g.get("shows") or "")[:30]
        c = str(g.get("caption") or "")
        c = allowed.get(c) or allowed_low.get(c.lower().strip(), "")
        if c and not fits_photo(c, shows[k], rec):
            c = ""                      # the AI's pick doesn't match what it says it sees
        if c and c not in used:         # only from the website list, once each
            caps[k] = c
            used.add(c)
    # The AI only picks what it can SEE. A side or rear shot shows no
    # "feature", so it came back blank -- fill those with the strong
    # facts from the listing (paint, drivetrain and engine, miles,
    # MPG...), the same ones the photo-order captions use.
    base = suggest(rec, 30)
    pool_out = [c for c in base[:15] if c and c not in used]
    pool_in = [c for c in base[15:] if c and c not in used]
    for k in range(len(photos)):
        if caps[k]:
            continue
        # only something this photo can show; otherwise leave it
        # blank -- no caption beats a wrong one
        for pool in (pool_out, pool_in):
            pick = next((c for c in pool if c not in used and fits_photo(c, shows[k], rec)), "")
            if pick:
                pool.remove(pick)
                caps[k] = pick
                used.add(pick)
                break
    return {"ok": True, "captions": caps, "shows": shows}


# ------------------------------------------------------------ the video
W, H, FPS = 1080, 1920, 30
NAVY = (11, 42, 85)
WHITE = (255, 255, 255)
SOFT = (201, 214, 234)
ACCENT = (255, 196, 64)
PHOTO_SECS, FADE_SECS, TITLE_SECS, END_SECS = 2.3, 0.4, 2.4, 3.2
PHOTO_BOX = (0, 560, W, 560 + 810)


def _font(bold: bool, size: int):
    from PIL import ImageFont
    names = (["segoeuib.ttf", "arialbd.ttf", "DejaVuSans-Bold.ttf"] if bold
             else ["segoeui.ttf", "arial.ttf", "DejaVuSans.ttf"])
    dirs = [Path("C:/Windows/Fonts"), Path("/usr/share/fonts/truetype/dejavu"),
            Path("/Library/Fonts"), Path("/System/Library/Fonts/Supplemental")]
    for n in names:
        for d in dirs:
            if (d / n).exists():
                return ImageFont.truetype(str(d / n), size)
    return ImageFont.load_default()


def _wrap(draw, text, f, width):
    words, lines, cur = str(text).split(), [], ""
    for w in words:
        t = (cur + " " + w).strip()
        if draw.textlength(t, font=f) <= width:
            cur = t
        else:
            if cur:
                lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


def _centered(draw, y, text, f, fill, width=W - 120):
    for line in _wrap(draw, text, f, width):
        tw = draw.textlength(line, font=f)
        draw.text(((W - tw) / 2, y), line, font=f, fill=fill)
        y += int(f.size * 1.22)
    return y


def render(car: dict, items: list[dict], out: Path, progress=lambda f: None,
           audio: Path | None = None, sound_opts: dict | None = None):
    """
    car: title, price, seller, phone, store (and optional title_secs/end_secs).
    items: [{path, caption, secs?}] -- secs lets a photo stay up as long as
    its spoken line. audio: a sound track (music, voice, or both) mixed in.
    """
    from PIL import Image, ImageDraw
    exe = ffmpeg_exe()
    if not exe:
        raise RuntimeError("The video maker isn't installed yet.")
    bw, bh = PHOTO_BOX[2] - PHOTO_BOX[0], PHOTO_BOX[3] - PHOTO_BOX[1]

    def prep(p):
        im = Image.open(p).convert("RGB")
        s = max(bw * 1.12 / im.width, bh * 1.12 / im.height)
        return im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))), Image.LANCZOS)

    photos = [prep(it["path"]) for it in items]

    base = Image.new("RGB", (W, H), NAVY)
    d = ImageDraw.Draw(base)
    y = _centered(d, 150, car["title"], _font(True, 64), WHITE)
    if car.get("price"):
        f = _font(True, 58)
        tw = d.textlength(car["price"], font=f)
        x0 = (W - tw) / 2 - 28
        d.rounded_rectangle([x0, y + 20, x0 + tw + 56, y + 104], radius=18, fill=ACCENT)
        d.text(((W - tw) / 2, y + 28), car["price"], font=f, fill=NAVY)
    if car.get("phone"):
        _centered(d, H - 250, (f"Call {car['phone']}" if car.get("company") else f"Call or Text {car['phone']}"),
                  _font(True, 44), WHITE)
    _centered(d, H - 180, (car.get("web") if car.get("company") and car.get("web") else
                           car.get("seller") or car.get("store") or ""), _font(False, 38), SOFT)

    def card(lines):
        img = Image.new("RGB", (W, H), NAVY)
        dd = ImageDraw.Draw(img)
        total = sum(int(f.size * 1.22) * len(_wrap(dd, t, f, W - 160)) + gap
                    for t, f, c, gap in lines if t)
        yy = (H - total) / 2
        for t, f, c, gap in lines:
            if t:
                yy = _centered(dd, yy, t, f, c, W - 160) + gap
        return img

    # the hook: the first thing seen in the feed (only a real fact -- the
    # website's own savings)
    title = card([(car.get("hook", ""), _font(True, 70), (255, 140, 60), 44),
                  (car["title"], _font(True, 86), WHITE, 40),
                  (car.get("price", ""), _font(True, 96), ACCENT, 40),
                  (car.get("store", ""), _font(False, 40), SOFT, 0)])
    end = card(end_lines(car))

    capf = _font(True, 52)

    def frame(img, t, i, caption, alpha):
        z = 1.0 + 0.08 * t
        cw, ch = img.width / 1.12 / z, img.height / 1.12 / z
        cw, ch = min(cw, img.width), min(ch, img.height)
        dx = (img.width - cw) * (0.5 + (0.25 if i % 2 else -0.25) * (t - 0.5))
        dy = (img.height - ch) * 0.5
        crop = img.crop((int(dx), int(dy), int(dx + cw), int(dy + ch))).resize((bw, bh), Image.BILINEAR)
        fr = base.copy()
        fr.paste(crop, (PHOTO_BOX[0], PHOTO_BOX[1]))
        if caption and alpha > 0:
            layer = Image.new("RGBA", (W, 260), (0, 0, 0, 0))
            dl = ImageDraw.Draw(layer)
            lines = _wrap(dl, caption, capf, W - 140)[:2]
            a = int(255 * alpha)
            yy = 30
            for ln in lines:
                tw = dl.textlength(ln, font=capf)
                dl.rounded_rectangle([(W - tw) / 2 - 30, yy - 12, (W + tw) / 2 + 30, yy + 74],
                                     radius=16, fill=(255, 255, 255, int(a * 0.14)))
                dl.text(((W - tw) / 2, yy), ln, font=capf, fill=(255, 255, 255, a))
                yy += 92
            fr = fr.convert("RGBA")
            fr.alpha_composite(layer, (0, PHOTO_BOX[3] + 20))
            fr = fr.convert("RGB")
        return fr

    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_name(out.stem + ".making.mp4")
    ff = subprocess.Popen(
        [exe, "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24",
         "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
         "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "21", "-preset", "veryfast",
         "-movflags", "+faststart", str(tmp)],
        stdin=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=NO_WINDOW)
    title_secs = float(car.get("title_secs") or TITLE_SECS)
    end_secs = float(car.get("end_secs") or END_SECS)
    lens = [max(1.2, float(it.get("secs") or PHOTO_SECS)) for it in items]

    # ---- the voice: each photo stays up as long as its line takes
    import tempfile
    import sound
    so = sound_opts or {}
    work = Path(tempfile.mkdtemp(prefix="la_wa_"))
    lines_wav = []
    if so.get("voice"):
        first = (car.get("seller") or "").split(" ")[0] or "me"
        hook = car.get("hook", "")
        if car.get("company"):
            bye = (f"Call {sound.sayable(car.get('store', ''))} at {sound.say_phone(car['phone'])}, or stop by today."
                   if car.get("phone") else f"Stop by {sound.sayable(car.get('store', ''))} today.")
        else:
            bye = f"Call or text {first} at {sound.say_phone(car.get('phone', ''))}." if car.get("phone") else ""
        lines = ([(f"{sound.sayable(hook)}! " if hook else "") +
                  f"{car['title']}. {sound.say_price(car.get('price', ''))}."]
                 + [sound.sayable(it.get("caption") or "") for it in items]
                 + [bye])
        lines_wav = sound.speak(lines, so["voice"], work)
        d = [sound.seconds(x) for x in lines_wav]
        if d and d[0]:
            title_secs = max(TITLE_SECS, d[0] + 0.55)
        for i in range(len(items)):
            if d[i + 1]:
                lens[i] = max(PHOTO_SECS, d[i + 1] + 0.45)
        if d and d[-1]:
            end_secs = max(END_SECS, d[-1] + 0.9)
    total = int(title_secs * FPS) + sum(int(x * FPS) + int(FADE_SECS * FPS) for x in lens) + \
        int((FADE_SECS + end_secs) * FPS)
    done = [0]

    def emit(img):
        ff.stdin.write(img.tobytes())
        done[0] += 1
        if done[0] % 15 == 0:
            progress(min(0.99, done[0] / total))

    def hold(img, secs):
        for _ in range(int(secs * FPS)):
            emit(img)

    def fade(a, b, secs):
        k = int(secs * FPS)
        for j in range(k):
            emit(Image.blend(a, b, (j + 1) / k))

    try:
        hold(title, title_secs)
        prev = title
        for i, img in enumerate(photos):
            cap = items[i].get("caption") or ""
            frames = []
            n = int(lens[i] * FPS)
            for k in range(n):
                t = k / (n - 1)
                ca = max(0.0, min(1.0, (t - 0.10) / 0.15, (0.95 - t) / 0.12))
                frames.append(frame(img, t, i, cap, ca))
            fade(prev, frames[0], FADE_SECS)
            for f in frames:
                emit(f)
            prev = frames[-1]
        fade(prev, end, FADE_SECS)
        hold(end, end_secs)
    finally:
        try:
            ff.stdin.close()
        except Exception:
            pass
        err = ff.stderr.read().decode("utf-8", "replace") if ff.stderr else ""
        ff.wait()
    if ff.returncode != 0 or not tmp.exists():
        tmp.unlink(missing_ok=True)
        raise RuntimeError("The video couldn't be written. " + err[-200:])
    # ---- the sound track: voice lines at their photos, music underneath
    if so and not audio:
        voice_at, t = [], title_secs
        if lines_wav:
            if lines_wav[0]:
                voice_at.append((0.25, lines_wav[0]))
            for i, ln in enumerate(lens):
                t += FADE_SECS
                if lines_wav[i + 1]:
                    voice_at.append((t + 0.05, lines_wav[i + 1]))
                t += ln
            t += FADE_SECS
            if lines_wav[-1]:
                voice_at.append((t + 0.15, lines_wav[-1]))
        try:
            music = sound.music_file(so.get("music") or "none", so.get("own") or "")
        except Exception:
            music = None
        audio = sound.mix(exe, total / FPS, voice_at, music, work / "track.m4a")
    if audio and Path(audio).exists():
        dur = total / FPS
        mixed = out.with_name(out.stem + ".sound.mp4")
        r = subprocess.run(
            [exe, "-y", "-loglevel", "error", "-i", str(tmp), "-i", str(audio),
             "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-b:a", "160k",
             "-af", f"apad,atrim=0:{dur:.2f},afade=t=out:st={max(0, dur - 1.5):.2f}:d=1.5",
             "-shortest", "-movflags", "+faststart", str(mixed)],
            capture_output=True, creationflags=NO_WINDOW)
        if r.returncode == 0 and mixed.exists():
            tmp.unlink(missing_ok=True)
            tmp = mixed
        else:
            mixed.unlink(missing_ok=True)
    tmp.replace(out)
    try:
        import shutil as _sh
        _sh.rmtree(work, ignore_errors=True)
    except Exception:
        pass
    progress(1.0)
    return out


# ------------------------------------------------------------ your own video
VIDEO_EXT = (".mp4", ".mov", ".m4v", ".avi", ".wmv", ".mkv", ".3gp", ".webm")


def probe(path: Path) -> dict:
    """How long a video is and whether it has sound."""
    exe = ffmpeg_exe()
    if not exe:
        raise RuntimeError("The video maker isn't installed yet.")
    r = subprocess.run([exe, "-hide_banner", "-i", str(path)], capture_output=True,
                       text=True, errors="replace", creationflags=NO_WINDOW)
    err = r.stderr or ""
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", err)
    secs = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3)) if m else 0.0
    if not secs:
        raise RuntimeError("That file doesn't look like a video the program can read.")
    return {"seconds": round(secs, 1), "audio": bool(re.search(r"Stream #.*Audio:", err))}


def video_thumb(path: Path, at: float = 1.0) -> bytes:
    exe = ffmpeg_exe()
    r = subprocess.run([exe, "-loglevel", "error", "-ss", f"{at:.2f}", "-i", str(path),
                        "-frames:v", "1", "-vf", "scale=360:-2", "-f", "image2", "-c:v", "mjpeg", "-"],
                       capture_output=True, creationflags=NO_WINDOW)
    return r.stdout or b""


def _card(lines):
    """A full-screen navy card with centered lines of text."""
    from PIL import Image, ImageDraw
    img = Image.new("RGB", (W, H), NAVY)
    dd = ImageDraw.Draw(img)
    total = sum(int(f.size * 1.22) * len(_wrap(dd, t, f, W - 160)) + gap
                for t, f, c, gap in lines if t)
    yy = (H - total) / 2
    for t, f, c, gap in lines:
        if t:
            yy = _centered(dd, yy, t, f, c, W - 160) + gap
    return img


def render_own(car: dict, video: Path, out: Path, start: float = 0.0, end: float = 0.0,
               keep_sound: bool = True, music: Path | None = None,
               progress=lambda f: None) -> Path:
    """
    Your own phone video, made ready to post: an opening card (the hook, the
    car and the price, from the website), your video standing tall for
    phones, and a closing card with your name and number. Your own sound is
    kept; music can go quietly underneath.
    """
    import tempfile
    exe = ffmpeg_exe()
    if not exe:
        raise RuntimeError("The video maker isn't installed yet.")
    info = probe(video)
    start = max(0.0, float(start or 0))
    end = float(end or 0)
    if not end or end > info["seconds"]:
        end = info["seconds"]
    if end - start < 1:
        raise RuntimeError("Start and end leave less than a second of video.")
    clip = end - start
    work = Path(tempfile.mkdtemp(prefix="la_own_"))
    title = _card([(car.get("hook", ""), _font(True, 70), (255, 140, 60), 44),
                   (car["title"], _font(True, 86), WHITE, 40),
                   (car.get("price", ""), _font(True, 96), ACCENT, 40),
                   (car.get("store", ""), _font(False, 40), SOFT, 0)])
    endc = _card(end_lines(car))
    title.save(work / "title.png")
    endc.save(work / "end.png")
    T, E = TITLE_SECS + 0.4, END_SECS
    total = T + clip + E
    keep = keep_sound and info["audio"]
    args = [exe, "-y", "-loglevel", "error", "-progress", "pipe:1", "-nostats",
            "-loop", "1", "-t", f"{T:.2f}", "-i", str(work / "title.png"),
            "-ss", f"{start:.2f}", "-t", f"{clip:.2f}", "-i", str(video),
            "-loop", "1", "-t", f"{E:.2f}", "-i", str(work / "end.png"),
            "-f", "lavfi", "-t", f"{total + 1:.2f}", "-i", "anullsrc=r=44100:cl=stereo"]
    if music:
        args += ["-stream_loop", "-1", "-i", str(music)]
    norm = f"fps={FPS},format=yuv420p,setsar=1"
    parts = [
        f"[0:v]scale={W}:{H},{norm},fade=t=out:st={T - 0.35:.2f}:d=0.35[t]",
        # your video, standing tall: a soft blurred copy fills the sides
        f"[1:v]split[a][b];[a]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},"
        f"boxblur=24:4,eq=brightness=-0.12[bg];[b]scale={W}:{H}:force_original_aspect_ratio=decrease[fg];"
        f"[bg][fg]overlay=(W-w)/2:(H-h)/2,{norm},fade=t=in:d=0.3[v]",
        f"[2:v]scale={W}:{H},{norm},fade=t=in:d=0.35[e]",
        "[3:a]asplit=2[s1][s3]" if keep else "[3:a]asplit=3[s1][s2][s3]",
        f"[s1]atrim=0:{T:.2f},asetpts=PTS-STARTPTS[ta]",
        (f"[1:a]aresample=44100,aformat=channel_layouts=stereo,apad,atrim=0:{clip:.2f},asetpts=PTS-STARTPTS[va]"
         if keep else f"[s2]atrim=0:{clip:.2f},asetpts=PTS-STARTPTS[va]"),
        f"[s3]atrim=0:{E:.2f},asetpts=PTS-STARTPTS[ea]",
        "[t][ta][v][va][e][ea]concat=n=3:v=1:a=1[vo][ao]",
    ]
    if music:
        vol = 0.16 if keep else 0.85
        parts.append(f"[4:a]aresample=44100,aformat=channel_layouts=stereo,volume={vol},"
                     f"atrim=0:{total:.2f},afade=t=in:d=0.6,afade=t=out:st={max(0, total - 1.8):.2f}:d=1.8[m]")
        parts.append("[ao][m]amix=inputs=2:normalize=0:duration=first,alimiter=limit=0.95[aout]")
        amap = "[aout]"
    else:
        amap = "[ao]"
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_name(out.stem + ".making.mp4")
    args += ["-filter_complex", ";".join(parts), "-map", "[vo]", "-map", amap,
             "-c:v", "libx264", "-preset", "veryfast", "-crf", "21", "-pix_fmt", "yuv420p",
             "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", "-t", f"{total:.2f}", str(tmp)]
    p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                         errors="replace", creationflags=NO_WINDOW)
    for line in p.stdout:
        if line.startswith("out_time_ms="):
            try:
                progress(min(0.99, int(line.split("=")[1]) / 1e6 / total))
            except ValueError:
                pass
    err = p.stderr.read() if p.stderr else ""
    p.wait()
    try:
        import shutil as _sh
        _sh.rmtree(work, ignore_errors=True)
    except Exception:
        pass
    if p.returncode != 0 or not tmp.exists():
        tmp.unlink(missing_ok=True)
        raise RuntimeError("The video couldn't be made. " + err.strip()[-200:])
    tmp.replace(out)
    progress(1.0)
    return out
