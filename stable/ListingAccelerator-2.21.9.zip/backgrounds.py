"""
backgrounds.py -- put a car's outside photos on a new background.

    python backgrounds.py --auto          (the morning run: new and changed cars)

How it stays honest
-------------------
The car itself is never redrawn. A cut-out tool (a small AI model that runs
on this computer) finds the car, and the car's own pixels are laid on the new
scene. Wheels, badges, trim, paint and any marks stay exactly as the camera
saw them.

How it looks real
-----------------
On this computer, free: the scene is lined up with the car's tires, the car's
light and color are nudged toward the scene's, the scene's light wraps the
edges, and shadows are drawn where the tires touch and under the body.

AI finish (optional, a paid Google key): Google's image AI re-shoots the photo
on location -- real ground shadows, the scene's light on the paint. Then the
car's own pixels are laid back over it, carrying only the AI's light, so no
detail of the car can change.

Files: bg_01.jpg next to web_01.jpg in the car's Photo Drop folder. The
originals are never touched.
"""
from __future__ import annotations

import base64
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import threading
import time
import urllib.request
from datetime import date
from pathlib import Path

import config

BASE = Path(__file__).resolve().parent
MEDIA = BASE / "media"
PIC_DIR = MEDIA / "backgrounds"
MODEL = MEDIA / "models" / "isnet.onnx"
MODEL_URL = ("https://github.com/danielgatis/rembg/releases/download/"
             "v0.0.0/isnet-general-use.onnx")
MODEL_SHA = "60920e99c45464f2ba57bee2ad08c919a52bbf852739e96947fbb4358c0d964a"
MODEL_MB = 179
PARTS = ["onnxruntime", "opencv-python-headless", "numpy", "pillow"]
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def _asset_base() -> str:
    if os.environ.get("LA_ASSET_TEST"):
        return os.environ["LA_ASSET_TEST"]
    try:
        import updater
        return updater.UPDATE_BASE.rstrip("/") + "/assets/backgrounds"
    except Exception:
        return ""


# ------------------------------------------------------------ the choices
# kind: drawn = made here, nothing to download; photo = a picture from the
# one-time download. ground = how far down the picture the parking spot's
# back edge is. x = where across the picture the car sits best.
CATALOG = [
    {"key": "fall-field", "label": "Fall field", "season": "fall", "ground": 0.64},
    {"key": "fall-hillside", "label": "Fall hillside", "season": "fall", "ground": 0.70},
    {"key": "spring-mountain", "label": "Spring mountain", "season": "spring", "ground": 0.74},
    {"key": "spring-road", "label": "Spring road", "season": "spring", "ground": 0.74},
    {"key": "summer-field", "label": "Summer field", "season": "summer", "ground": 0.66},
    {"key": "summer-lake", "label": "Summer lake", "season": "summer", "ground": 0.70},
    {"key": "ocean", "label": "Ocean", "season": "summer", "ground": 0.70},
    {"key": "winter-road", "label": "Winter road", "season": "winter", "ground": 0.72},
    {"key": "winter-town", "label": "Winter town", "season": "winter", "ground": 0.72},
    {"key": "winter-barn", "label": "Winter barn", "season": "winter", "ground": 0.62, "x": 0.4},
    {"key": "concrete-skyline", "label": "Concrete & skyline", "drawn": True},
    {"key": "white-studio", "label": "White studio", "drawn": True, "studio": True},
    {"key": "gray-studio", "label": "Light gray studio", "drawn": True, "studio": True},
    {"key": "charcoal-studio", "label": "Dark charcoal studio", "drawn": True, "studio": True},
    {"key": "blue", "label": "Blue", "drawn": True, "studio": True},
]
BY_KEY = {c["key"]: c for c in CATALOG}
OWN = "own"
OFF = "off"


def season_now(today: date | None = None) -> str:
    m = (today or date.today()).month
    return {12: "winter", 1: "winter", 2: "winter", 3: "spring", 4: "spring",
            5: "spring", 6: "summer", 7: "summer", 8: "summer"}.get(m, "fall")


def choices() -> list[dict]:
    """For the screens: every background, with a small preview if it's here."""
    out = [{"key": OFF, "label": "Original (off)"}]
    for c in CATALOG:
        out.append({"key": c["key"], "label": c["label"], "season": c.get("season", ""),
                    "drawn": bool(c.get("drawn"))})
    out.append({"key": OWN, "label": "Use my own picture"})
    return out


# ------------------------------------------------------------ settings
# Each store keeps its own: Settings -> Photos & videos.
DEFAULTS = {"bg": OFF, "season_auto": True, "which": "picked", "own": "",
            "ai_finish": False, "cars": {}}


def _settings_file() -> Path:
    return Path(config.STORE_DIR) / "backgrounds.json"


def settings() -> dict:
    try:
        d = json.loads(_settings_file().read_text(encoding="utf-8"))
    except Exception:
        d = {}
    out = {**DEFAULTS, **{k: v for k, v in d.items() if k in DEFAULTS}}
    if out["bg"] not in BY_KEY and out["bg"] not in (OFF, OWN):
        out["bg"] = OFF
    if out["which"] not in ("all", "picked"):
        out["which"] = "picked"
    if not isinstance(out["cars"], dict):
        out["cars"] = {}
    return out


def save_settings(d: dict) -> dict:
    s = settings()
    for k in ("bg", "season_auto", "which", "own", "ai_finish"):
        if k in d:
            s[k] = d[k]
    if "car" in d and isinstance(d["car"], dict):      # {stock, bg}
        st = str(d["car"].get("stock", "")).upper()
        if st:
            if d["car"].get("bg") in (None, ""):
                s["cars"].pop(st, None)
            else:
                s["cars"][st] = d["car"]["bg"]
    s["season_auto"] = bool(s["season_auto"])
    s["ai_finish"] = bool(s["ai_finish"])
    try:
        _settings_file().parent.mkdir(parents=True, exist_ok=True)
        _settings_file().write_text(json.dumps(s, indent=1), encoding="utf-8")
    except OSError as e:
        return {"ok": False, "message": f"Couldn't save: {e}"}
    return {"ok": True, **s}


def pick_for(stock: str, s: dict | None = None, today: date | None = None) -> str:
    """Which background this car gets: its own choice, else the store's, with
    the season switched when that is turned on."""
    s = s or settings()
    mine = s["cars"].get(str(stock).upper())
    if mine:
        return mine          # picked by hand for this car: kept as picked, any season
    bg = s["bg"]
    if bg in (OFF, OWN) or bg not in BY_KEY:
        return bg
    c = BY_KEY[bg]
    now = season_now(today)
    if s["season_auto"] and c.get("season") and c["season"] != now:
        same = [x["key"] for x in CATALOG if x.get("season") == now]
        if same:   # a steady pick for each car, so it doesn't change every morning
            h = int(hashlib.md5(str(stock).encode()).hexdigest(), 16)
            return same[h % len(same)]
    return bg


# ------------------------------------------------------------ one-time setup
def missing() -> list[str]:
    need = []
    for mod in ("numpy", "PIL", "onnxruntime", "cv2"):
        try:
            __import__(mod)
        except Exception:
            need.append("parts")
            break
    if not MODEL.exists() or MODEL.stat().st_size < 100_000_000:
        need.append("model")
    if any(not (PIC_DIR / f"{c['key']}.jpg").exists() for c in CATALOG if not c.get("drawn")):
        need.append("pictures")
    return need


def ready() -> bool:
    return not missing()


def _download(url: str, dest: Path, progress=None, sha: str | None = None):
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    h = hashlib.sha256()
    req = urllib.request.Request(url, headers={"User-Agent": "ListingAccelerator"})
    with urllib.request.urlopen(req, timeout=60) as r, open(tmp, "wb") as f:
        total = int(r.headers.get("Content-Length") or 0)
        got = 0
        while True:
            b = r.read(1 << 20)
            if not b:
                break
            f.write(b)
            h.update(b)
            got += len(b)
            if progress and total:
                progress(got / total)
    if sha and h.hexdigest() != sha:
        tmp.unlink(missing_ok=True)
        raise RuntimeError("the download came through damaged -- try again")
    os.replace(tmp, dest)


def setup(progress=lambda frac, msg: None) -> dict:
    """One time on each computer: the cut-out tool and the background pictures."""
    need = missing()
    try:
        if "parts" in need:
            progress(0.02, "Getting the cut-out tool's parts…")
            r = subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", *PARTS],
                               capture_output=True, text=True, timeout=900,
                               creationflags=NO_WINDOW)
            if r.returncode != 0:
                tail = (r.stderr or r.stdout or "").strip().splitlines()[-1:] or [""]
                return {"ok": False, "message": "Couldn't get the cut-out tool. Check the "
                        "internet connection and try again. " + tail[0][:160]}
            import importlib
            importlib.invalidate_caches()
        if "model" in need:
            _download(MODEL_URL, MODEL, lambda f: progress(
                0.15 + 0.6 * f, f"Downloading the cut-out tool ({MODEL_MB} MB, one time)… "
                f"{int(f * 100)}%"), sha=MODEL_SHA)
        if "pictures" in need:
            base = _asset_base()
            try:
                man = json.loads(urllib.request.urlopen(base + "/backgrounds.json",
                                                        timeout=30).read())
            except Exception:
                man = {}
            pics = [c for c in CATALOG if not c.get("drawn")]
            for i, c in enumerate(pics):
                dest = PIC_DIR / f"{c['key']}.jpg"
                if dest.exists():
                    continue
                progress(0.78 + 0.2 * i / len(pics), f"Downloading the pictures… {c['label']}")
                _download(f"{base}/{c['key']}.jpg", dest,
                          sha=(man.get(c["key"]) or {}).get("sha256"))
    except Exception as e:
        return {"ok": False, "message": f"Setup stopped: {e}. Click Set up again to finish."}
    progress(1.0, "Ready.")
    return {"ok": ready(), "message": "Backgrounds are ready." if ready() else
            "Set up, but something still isn't answering. Restart the program."}


# ------------------------------------------------------------ the cut-out
_sess = None
_sess_lock = threading.Lock()


def _run_model(img):
    import numpy as np
    from PIL import Image
    global _sess
    with _sess_lock:
        if _sess is None:
            import onnxruntime as ort
            so = ort.SessionOptions()
            so.log_severity_level = 3
            _sess = ort.InferenceSession(str(MODEL), so, providers=["CPUExecutionProvider"])
        w, h = img.size
        x = np.asarray(img.convert("RGB").resize((1024, 1024), Image.BILINEAR),
                       dtype=np.float32) / 255.0 - 0.5
        out = _sess.run(None, {_sess.get_inputs()[0].name: x.transpose(2, 0, 1)[None]})[0][0, 0]
    out = (out - out.min()) / max(out.max() - out.min(), 1e-6)
    m = Image.fromarray((out * 255).astype(np.uint8)).resize((w, h), Image.BILINEAR)
    a = np.asarray(m, dtype=np.float32) / 255.0
    return np.clip((a - 0.15) / 0.7, 0, 1)


def _has_backdrop(hard) -> bool:
    """A car only narrows going up from body to roof. Narrowing and then
    widening again above means a sign or canopy is standing behind it."""
    import numpy as np
    rows = np.convolve(hard.sum(axis=1).astype(float), np.ones(9) / 9, "same")
    ys = np.where(rows > 0)[0]
    if not len(ys):
        return False
    top, bot = ys.min(), ys.max()
    start = top + (bot - top) // 2
    body = np.percentile(rows[start: bot + 1], 90)
    narrowest = rows[start]
    for y in range(start, top - 1, -1):
        narrowest = min(narrowest, rows[y])
        if narrowest < body * 0.6 and rows[y] > narrowest * 1.3 and rows[y] > body * 0.3:
            return True
    return False


def _keep_vehicle(a):
    """Keep only the blob that stands lowest in the frame -- the car."""
    import cv2
    import numpy as np
    hard = (a > 0.5).astype(np.uint8)
    h, w = hard.shape
    k = max(3, int(min(h, w) * 0.02)) | 1
    opened = cv2.morphologyEx(hard, cv2.MORPH_OPEN,
                              cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
    n, lab, stats, _ = cv2.connectedComponentsWithStats(opened, 8)
    if n <= 2:
        return a
    best, best_key = 0, None
    for i in range(1, n):
        x, y, bw, bh, area = stats[i]
        if area < 0.01 * h * w:
            continue
        key = (y + bh, area)
        if best_key is None or key > best_key:
            best, best_key = i, key
    if not best:
        return a
    keep = (lab == best).astype(np.uint8)
    keep = cv2.dilate(keep, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k + 4, k + 4)))
    return a * keep


def _cut_pillar(a):
    """A post right behind the car joins sign and car: drop it from where the
    outline gets much narrower than the car."""
    import numpy as np
    rows = (a > 0.5).sum(axis=1)
    if rows.max() == 0:
        return a
    widest = int(np.argmax(rows))
    limit = rows.max() * 0.30
    run = 0
    for y in range(widest, -1, -1):
        run = run + 1 if rows[y] < limit else 0
        if run >= 4:
            out = a.copy()
            out[: y + 4] = 0
            return out
    return a


def cutout(img):
    """Soft 0..1 mask of the vehicle."""
    import numpy as np
    w, h = img.size
    full = _keep_vehicle(_run_model(img))
    a = full
    for factor in (0.85, 0.6, 0.45):
        hard = a > 0.5
        if not hard.any() or not _has_backdrop(hard):
            break
        ys = np.where((full > 0.5).any(axis=1))[0]
        top, bot = ys.min(), ys.max()
        lower = (full > 0.5)[top + (bot - top) // 2: bot + 1]
        width = np.percentile(lower.sum(axis=1), 90)
        crop_top = int(bot - width * factor)
        if crop_top <= h * 0.03:
            continue
        part = _run_model(img.crop((0, crop_top, w, h)))
        a = np.zeros((h, w), np.float32)
        a[crop_top:] = part
        a = _keep_vehicle(a)
    a = _cut_pillar(a).astype(np.float32)
    return _refine(img, a)


def _guided(I, p, r, eps):
    import cv2

    def mean(x):
        return cv2.boxFilter(x, -1, (r, r))
    mI, mp = mean(I), mean(p)
    A = (mean(I * p) - mI * mp) / (mean(I * I) - mI * mI + eps)
    b = mp - A * mI
    return mean(A) * I + mean(b)


def _refine(img, a):
    """Sharper edges: look again close up at just the car, then let the
    photo's own edges guide the outline (mirrors, antennas, tires)."""
    import cv2
    import numpy as np
    m = a > 0.5
    if not m.any():
        return a
    h, w = a.shape
    ys, xs = np.where(m)
    pad = int(max(xs.max() - xs.min(), ys.max() - ys.min()) * 0.06)
    x0, y0 = max(0, xs.min() - pad), max(0, ys.min() - pad)
    x1, y1 = min(w, xs.max() + pad), min(h, ys.max() + pad)
    if (x1 - x0) * (y1 - y0) < 0.8 * w * h:
        near = _run_model(img.crop((x0, y0, x1, y1)))
        b = np.zeros_like(a)
        b[y0:y1, x0:x1] = near
        # trust the close look, but only near the first outline
        zone = cv2.dilate(m.astype(np.uint8), np.ones((pad + 1, pad + 1), np.uint8)) > 0
        a = np.where(zone, b, 0).astype(np.float32)
    g = np.asarray(img, np.float32) / 255.0
    r = max(5, int(min(h, w) * 0.006)) | 1
    out = np.zeros_like(a)
    for c in range(3):
        out += _guided(g[..., c], a, r, 2e-3) / 3
    out = np.clip(out, 0, 1)
    # keep the solid inside solid; the guide only moves the edge
    core = cv2.erode((a > 0.9).astype(np.uint8), np.ones((r, r), np.uint8)) > 0
    out[core] = 1.0
    out[a < 0.02] = 0
    out = np.clip((out - 0.08) / 0.84, 0, 1)
    # thin slivers of the building stuck to the roof or bumper: gone
    ch = ys.max() - ys.min()
    k = max(3, int(ch * 0.032)) | 1
    hard = (out > 0.5).astype(np.uint8)
    opened = cv2.morphologyEx(hard, cv2.MORPH_OPEN,
                              cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
    keep = cv2.dilate(opened, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
    return (out * keep).astype(np.float32)


def _ground_shadow(src, a, under=None):
    """The car's real shadow, read from the original photo: how much darker
    the ground is near the car than the open ground around it. That darkness
    is laid on the new ground, so the shadow has the true shape and falls the
    true way. Also finds the ground seen under the car (between the tires),
    which the cut-out tool takes for part of the car.
    Returns (shade 0..1, alpha with the under-car ground taken out)."""
    import cv2
    import numpy as np
    h, w = a.shape
    m = a > 0.5
    ys, xs = np.where(m)
    top, bot, left, right = ys.min(), ys.max(), xs.min(), xs.max()
    car_h, car_w = bot - top, right - left
    lab = cv2.cvtColor(np.clip(src, 0, 255).astype(np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32)
    L, chroma = lab[..., 0], np.hypot(lab[..., 1] - 128, lab[..., 2] - 128)
    # open ground: below the car's lowest point, well to the sides
    y_lo = min(h, bot + max(4, car_h // 20))
    band = np.zeros((h, w), bool)
    band[max(bot - car_h // 4, 0):] = True
    band &= ~cv2.dilate(m.astype(np.uint8), np.ones((15, 15), np.uint8)).astype(bool)
    band &= chroma < 18
    if band.sum() < 400:
        return np.zeros((h, w), np.float32), a
    ref = np.percentile(L[band], 65)          # sunlit ground, not the shadow
    if ref < 40:            # dark ground: no shadow to read
        return np.zeros((h, w), np.float32), a
    ratio = np.clip(L / ref, 0, 1.2)
    ratio = cv2.GaussianBlur(ratio, (0, 0), max(2.5, car_h * 0.014))
    shade = np.clip(1 - ratio, 0, 0.85)
    # only around the car's feet: fade with distance from the car
    near = cv2.dilate(m.astype(np.uint8), cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE, (int(car_w * 0.35) | 1, int(car_h * 0.35) | 1)))
    near = cv2.GaussianBlur(near.astype(np.float32), (0, 0), car_h * 0.08)
    low = np.clip((np.arange(h)[:, None] - (bot - car_h * 0.45)) / (car_h * 0.15), 0, 1)
    shade *= near * low
    a2 = a
    if under is not None:
        # the ground seen under the car (from the AI's look at the photo):
        # it becomes new ground, keeping the real darkness of the shadow there
        u = cv2.GaussianBlur(under.astype(np.float32), (0, 0), 1.5)
        u *= (np.arange(h)[:, None] > top + car_h * 0.45)
        a2 = a * (1 - u)
        shade = np.maximum(shade, np.clip(1 - L / ref, 0.25, 0.85) * u)
    return shade.astype(np.float32), a2.astype(np.float32)


def is_outside_shot(a) -> bool:
    """A whole car standing in the frame. Close-ups and inside shots fail."""
    import numpy as np
    m = a > 0.5
    if m.mean() < 0.08:
        return False
    edges = max(m[0].mean(), m[-1].mean(), m[:, 0].mean(), m[:, -1].mean())
    ys, xs = np.where(m)
    h, w = m.shape
    bh = (ys.max() - ys.min()) / h
    bw = (xs.max() - xs.min()) / w
    wide = (bw * w) / max(1, bh * h)
    return edges < 0.02 and bh <= 0.80 and ys.max() / h <= 0.93 and wide >= 1.1


_VIEW_ASK = ("Look at this car-dealer photo. Answer with ONE word. OUTSIDE if it shows the outside "
             "of a vehicle with most of the vehicle in the picture (front, side, rear or corner view). "
             "INSIDE for anything else: the interior, dashboard, steering wheel, seats, cargo area, "
             "engine, a key or key fob, a close-up of one part (a wheel, a badge, a light), or paperwork.")


def ai_view(src_path: Path):
    """With AI on, ask what the photo shows: True = outside of the whole car,
    False = inside or a close-up, None = couldn't ask. Remembered per photo."""
    try:
        import ai_engine
        if not ai_engine.on():
            return None
    except Exception:
        return None
    import io
    import json as _json
    from PIL import Image, ImageOps
    cache = src_path.parent / ".bgcheck.json"
    try:
        known = _json.loads(cache.read_text(encoding="utf-8"))
    except Exception:
        known = {}
    k = f"{src_path.name}:{int(src_path.stat().st_mtime)}"
    if k in known:
        return known[k]
    try:
        im = ImageOps.exif_transpose(Image.open(src_path)).convert("RGB")
        im.thumbnail((640, 640))
        buf = io.BytesIO()
        im.save(buf, "JPEG", quality=80)
        ans = ai_engine.ask([_VIEW_ASK, {"jpeg": buf.getvalue()}], temperature=0.0, timeout=40)
    except Exception:
        return None
    t = ans.strip().upper()
    v = True if t.startswith("OUTSIDE") else False if t.startswith("INSIDE") else None
    if v is not None:
        known[k] = v
        try:
            cache.write_text(_json.dumps(known), encoding="utf-8")
        except OSError:
            pass
    return v


# ------------------------------------------------------------ the scenes
def _vgrad(size, top, bottom):
    import numpy as np
    from PIL import Image
    w, h = size
    t = np.linspace(0, 1, h)[:, None, None]
    c = np.array(top)[None, None] * (1 - t) + np.array(bottom)[None, None] * t
    return Image.fromarray(np.repeat(c, w, axis=1).astype(np.uint8))


def _noise(h, w, seed, scales=((8, 0.5), (24, 0.3), (80, 0.2))):
    import numpy as np
    from PIL import Image
    rng = np.random.default_rng(seed)
    out = np.zeros((h, w), np.float32)
    for cells, weight in scales:
        g = rng.random((max(2, h * cells // w), cells)).astype(np.float32)
        img = Image.fromarray((g * 255).astype(np.uint8)).resize((w, h), Image.BICUBIC)
        out += np.asarray(img, np.float32) / 255.0 * weight
    return out


def _concrete_skyline(size, floor_y):
    import numpy as np
    from PIL import Image, ImageDraw, ImageFilter
    w, h = size
    hz = max(int(h * 0.25), floor_y)
    t = (np.arange(h) / max(1, hz))[:, None]
    top, low = np.array([52, 112, 196]), np.array([196, 222, 242])
    sky = top * (1 - np.clip(t, 0, 1))[..., None] + low * np.clip(t, 0, 1)[..., None]
    sky = np.repeat(sky, w, axis=1)
    cloud = _noise(h, w, 7, ((4, 0.40), (12, 0.30), (40, 0.18), (120, 0.12)))
    cloud = np.clip((cloud - 0.56) * 2.6, 0, 1) ** 1.4 * np.clip(1.1 - t, 0, 1)
    sky = sky * (1 - cloud[..., None] * 0.75) + 248 * cloud[..., None] * 0.75
    img = Image.fromarray(sky.astype(np.uint8))
    d = ImageDraw.Draw(img)
    rng = np.random.default_rng(11)
    for shade, hmax in (((178, 194, 214), 0.085), ((140, 156, 178), 0.055)):
        x = -int(rng.integers(0, max(1, w // 30)))
        while x < w:
            bw = int(w * rng.uniform(0.025, 0.07))
            bh = int(h * hmax * rng.uniform(0.35, 1.0))
            if rng.random() < 0.08:
                bh = int(h * hmax * 1.45)
            d.rectangle([x, hz - bh, x + bw, hz], fill=shade)
            if rng.random() < 0.3:
                d.rectangle([x + bw // 3, hz - bh - bh // 6, x + 2 * bw // 3, hz - bh], fill=shade)
            x += bw + int(w * rng.uniform(0.0, 0.012))
    img = img.filter(ImageFilter.GaussianBlur(max(1, w // 900)))
    fh = h - hz
    base = np.linspace(168, 208, fh)[:, None]
    tex = _noise(fh, w, 3, ((60, 0.5), (200, 0.5))) - 0.5
    con = np.clip(base + tex * 26, 0, 255)
    conc = Image.fromarray(np.dstack([con, con, con * 0.98]).astype(np.uint8))
    dc = ImageDraw.Draw(conc)
    vx = w * 0.5
    for i in range(-14, 15):
        dc.line([(vx + i * w * 0.004, 0), (vx + i * w * 0.16, fh)], fill=(160, 160, 158),
                width=max(1, w // 900))
    for k in range(1, 9):
        y = int(fh * (k / 9) ** 2.2)
        dc.line([(0, y), (w, y)], fill=(162, 162, 160), width=max(1, w // 900))
    conc = conc.filter(ImageFilter.GaussianBlur(0.8))
    img.paste(conc, (0, hz))
    haze = Image.new("RGB", size, (214, 226, 236))
    ramp = np.exp(-((np.arange(h) - hz) / (h * 0.025)) ** 2)
    alpha = Image.fromarray((np.repeat(ramp[:, None], w, axis=1) * 120).astype(np.uint8))
    return Image.composite(haze, img, alpha)


STUDIO = {"white-studio": ((255, 255, 255), (232, 234, 238), (226, 228, 232)),
          "gray-studio": ((214, 218, 224), (170, 176, 184), (160, 166, 174)),
          "charcoal-studio": ((62, 66, 74), (28, 30, 34), (40, 42, 47)),
          "blue": ((36, 84, 160), (12, 32, 72), (14, 30, 62))}


def _studio(key, size, floor_y):
    """A photo-studio cove: the wall curves into the floor with no seam, and a
    soft pool of light on the floor where the car stands."""
    import numpy as np
    from PIL import Image
    w, h = size
    top, bottom, floor = STUDIO[key]
    img = np.asarray(_vgrad(size, top, bottom), np.float32)
    ramp = np.clip((np.arange(h) - floor_y) / max(1, h * 0.22) + 0.5, 0, 1)
    ramp = ramp * ramp * (3 - 2 * ramp)
    img = img * (1 - ramp[:, None, None]) + np.array(floor, np.float32) * ramp[:, None, None]
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    pool = np.exp(-(((xx - w / 2) / (w * 0.45)) ** 2 + ((yy - h * 0.8) / (h * 0.3)) ** 2))
    vign = 1 - 0.18 * (((xx - w / 2) / (w * 0.7)) ** 2 + ((yy - h * 0.45) / (h * 0.9)) ** 2)
    img = img * (1 + 0.10 * pool[..., None]) * np.clip(vign, 0.7, 1)[..., None]
    return Image.fromarray(np.clip(img, 0, 255).astype(np.uint8))


def _photo_scene(path: Path, size, floor_y: int, ground: float, x_center: float, car_cx: float):
    """A location picture scaled to fill the frame, slid so its parking spot
    sits right behind the car's tires."""
    from PIL import Image
    w, h = size
    bg = Image.open(path).convert("RGB")
    s = max(w / bg.width, h / bg.height)
    need = max(floor_y / max(ground, 1e-3), (h - floor_y) / max(1 - ground, 1e-3)) / bg.height
    s = max(s, need)
    bg = bg.resize((int(bg.width * s + 0.5), int(bg.height * s + 0.5)), Image.LANCZOS)
    top = int(ground * bg.height - floor_y)
    top = min(max(0, top), bg.height - h)
    # the scene's best spot for a car lined up with where the car is
    left = int(x_center * bg.width - car_cx)
    left = min(max(0, left), bg.width - w)
    return bg.crop((left, top, left + w, top + h))


def scene(key: str, size, floor_y: int, car_cx: float, own: str = ""):
    if key == OWN:
        p = Path(own)
        if not p.exists():
            raise RuntimeError("your own background picture isn't there anymore -- pick it again")
        return _photo_scene(p, size, floor_y, 0.62, 0.5, car_cx)
    c = BY_KEY[key]
    if key == "concrete-skyline":
        return _concrete_skyline(size, floor_y)
    if key in STUDIO:
        return _studio(key, size, floor_y)
    return _photo_scene(PIC_DIR / f"{key}.jpg", size, floor_y, c["ground"],
                        c.get("x", 0.5), car_cx)


# ------------------------------------------------------------ putting it together
def _baseline(m):
    """For each column across the car, its lowest point -- where it meets the
    ground. In a three-quarter shot the far tires sit higher than the near."""
    import numpy as np
    ys, xs = np.where(m)
    left, right, bot = xs.min(), xs.max(), ys.max()
    cols = np.arange(left, right + 1)
    has = m[:, left:right + 1]
    low = np.where(has.any(axis=0), m.shape[0] - 1 - np.argmax(has[::-1], axis=0), bot)
    k = max(3, (right - left) // 80)
    smooth = np.convolve(np.pad(low.astype(float), k, mode="edge"),
                         np.ones(2 * k + 1) / (2 * k + 1), "valid")
    return cols, smooth


def _shadows(m, light_dx: float, studio: bool):
    """Shadow strength 0..1: dark and tight where the tires touch, soft under
    the body, and a long soft fall-off away from the light."""
    import cv2
    import numpy as np
    h, w = m.shape
    ys, xs = np.where(m)
    car_h = ys.max() - ys.min()
    car_w = xs.max() - xs.min()
    cols, base = _baseline(m)
    # the tires: where the bottom edge reaches lowest nearby
    win = max(5, car_w // 7)
    env = np.array([base[max(0, i - win): i + win].max() for i in range(len(base))])
    tire = np.exp(-np.clip(env - base, 0, None) / max(2.0, car_h * 0.012))

    contact = np.zeros((h, w), np.float32)
    under = np.zeros((h, w), np.float32)
    reach = max(8, int(car_h * 0.07))
    for x, y, t in zip(cols, base, tire):
        y = int(y)
        y0 = max(0, y - reach // 2)
        under[y0: min(h, y + int(reach * 0.6)), x] = 0.75
        if t > 0.35:
            contact[max(0, y - 2): min(h, y + max(2, reach // 6)), x] = t
    contact = cv2.GaussianBlur(contact, (0, 0), max(1.5, reach / 7))
    under = cv2.GaussianBlur(under, (0, 0), max(4, reach * 0.8))
    # a long soft shadow stretching away from the light, flattened onto the ground
    fall = np.zeros((h, w), np.float32)
    if not studio:
        foot = np.zeros((h, w), np.float32)
        for x, y in zip(cols, base):
            foot[max(0, int(y) - int(car_h * 0.10)): min(h, int(y) + 2), x] = 1
        M = np.float32([[1, 0, -light_dx * car_w * 0.10], [0, 0.5, base.max() * 0.5]])
        fall = cv2.warpAffine(foot, M, (w, h))
        fall = cv2.GaussianBlur(fall, (0, 0), max(6, car_h * 0.05)) * 0.45
    s = np.maximum(np.maximum(contact * 0.95, under), fall)
    return np.clip(s, 0, 1)


def _light_side(bg_arr) -> float:
    """-1 = light from the left, +1 = from the right, from the sky's brightness."""
    import numpy as np
    top = bg_arr[: bg_arr.shape[0] // 3].mean(axis=2)
    l, r = top[:, : top.shape[1] // 2].mean(), top[:, top.shape[1] // 2:].mean()
    d = (r - l) / max(1.0, (r + l) / 2) * 6
    return float(np.clip(d, -1, 1))


def _defringe(img, a):
    """The cut-out's soft edge still holds the old background's color. Pull
    colors from just inside the car out over the edge instead."""
    import cv2
    import numpy as np
    solid = (a > 0.95).astype(np.float32)
    r = max(2, int(min(a.shape) * 0.004))
    num = cv2.GaussianBlur(img * solid[..., None], (0, 0), r)
    den = cv2.GaussianBlur(solid, (0, 0), r)[..., None]
    spread = num / np.maximum(den, 1e-4)
    t = np.clip((0.95 - a) / 0.95, 0, 1)[..., None] * (den > 0.02)
    return img * (1 - t) + spread * t


def _harmonize(car, a, bg, strength=1.0):
    """Nudge the car's light and color toward the scene's -- a little. Paint
    color must stay the paint color, so the tint is held to a small amount."""
    import cv2
    import numpy as np
    m = a > 0.5
    lab_c = cv2.cvtColor(np.clip(car, 0, 255).astype(np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32)
    lab_b = cv2.cvtColor(np.clip(bg, 0, 255).astype(np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32)
    ring = cv2.dilate(m.astype(np.uint8), np.ones((51, 51), np.uint8)).astype(bool) & ~m
    bgm = lab_b[ring] if ring.sum() > 500 else lab_b.reshape(-1, 3)
    cm = lab_c[m]
    dL = np.clip((bgm[:, 0].mean() - cm[:, 0].mean()) * 0.18 * strength, -10, 10)
    dab = np.clip((bgm[:, 1:].mean(0) - 128) * 0.12 * strength, -3, 3)
    lab_c[..., 0] += dL
    lab_c[..., 1:] += dab
    out = cv2.cvtColor(np.clip(lab_c, 0, 255).astype(np.uint8), cv2.COLOR_LAB2RGB).astype(np.float32)
    return out


def _light_wrap(car, a, bg):
    """A little of the scene's light spills over the car's outline, as it does
    in a real photo."""
    import cv2
    import numpy as np
    r = max(3, int(min(a.shape) * 0.008))
    inner = cv2.GaussianBlur(a, (0, 0), r)
    band = np.clip(a - inner, 0, 1) * 2.2
    band = np.clip(band, 0, 0.55)[..., None]
    glow = cv2.GaussianBlur(bg, (0, 0), r * 2)
    return car * (1 - band) + glow * band


def _grain(img, amount):
    import numpy as np
    if amount <= 0.3:
        return img
    rng = np.random.default_rng(5)
    return img + rng.normal(0, amount, img.shape[:2])[..., None]


def _noise_level(arr):
    import cv2
    import numpy as np
    g = cv2.cvtColor(np.clip(arr, 0, 255).astype(np.uint8), cv2.COLOR_RGB2GRAY).astype(np.float32)
    hp = g - cv2.GaussianBlur(g, (0, 0), 1.2)
    return float(np.median(np.abs(hp)) * 1.4826)


def _reflection(out, car, a, cols, base, strength=0.16):
    """On a studio floor: a faint mirror of the car, fading out."""
    import numpy as np
    h, w = a.shape
    ys = np.where(a.any(axis=1))[0]
    car_h = ys.max() - ys.min()
    fade = int(car_h * 0.28)
    res = out.copy()
    for x, y in zip(cols, base):
        y = int(y)
        n = min(fade, h - y - 1, y)
        if n <= 2:
            continue
        src_y = np.arange(y, y - n, -1)
        dst_y = np.arange(y + 1, y + 1 + n)
        k = (1 - np.arange(n) / n) ** 2 * strength * a[src_y, x]
        res[dst_y, x] = res[dst_y, x] * (1 - k[:, None]) + car[src_y, x] * k[:, None]
    return res


def _glass(car, src, bg, glass):
    """Windows still show the old lot (and the dealer's sign mirrored in the
    windshield). Keep what's seen through the glass -- the seats, the real
    tint -- but soften the old reflections and let the new scene's light in."""
    import cv2
    import numpy as np
    g = cv2.GaussianBlur(glass.astype(np.float32), (0, 0), 1.2)[..., None]
    inside = cv2.GaussianBlur(src, (0, 0), 1.6) * 0.82
    sky = cv2.GaussianBlur(bg, (0, 0), max(6, src.shape[1] // 120)) * 0.7
    new = inside * 0.6 + sky * 0.4
    return car * (1 - g) + new * g


def _poly_mask(item, w, h):
    """A mask from one of the AI's answers: a polygon in 0-1000 units (or an
    older-style picture of the mask inside its box)."""
    import cv2
    import numpy as np
    m = np.zeros((h, w), np.uint8)
    box = item.get("box_2d") or [0, 0, 1000, 1000]
    try:
        y0, x0, y1, x1 = [float(v) for v in box]
    except Exception:
        y0, x0, y1, x1 = 0, 0, 1000, 1000
    mk = item.get("mask")
    if isinstance(mk, str) and "base64," in mk:
        from PIL import Image
        pic = Image.open(io.BytesIO(base64.b64decode(mk.split("base64,", 1)[1]))).convert("L")
        X0, Y0 = int(x0 / 1000 * w), int(y0 / 1000 * h)
        X1, Y1 = max(X0 + 1, int(x1 / 1000 * w)), max(Y0 + 1, int(y1 / 1000 * h))
        part = np.asarray(pic.resize((X1 - X0, Y1 - Y0)), np.uint8) > 127
        m[Y0:Y1, X0:X1] = part[: h - Y0, : w - X0]
        return m.astype(bool)
    pts = []
    if isinstance(mk, list):
        for p in mk:
            if isinstance(p, (list, tuple)) and len(p) == 2:
                pts.append((float(p[0]) / 1000 * w, float(p[1]) / 1000 * h))
    # a "polygon" that is just a straight-sided box is a guess, not an outline
    if len(pts) == 4 and len({round(p[0]) for p in pts}) <= 2 and len({round(p[1]) for p in pts}) <= 2:
        pts = []
    if len(pts) >= 3:
        cv2.fillPoly(m, [np.array(pts, np.int32)], 1)
    # Only a box and no outline: a rectangle is never the shape of a window or
    # of the ground under a car -- painting one leaves a gray block on the photo.
    return m.astype(bool)


LOOK_PROMPT = (
    "This is a photo of a vehicle for sale. Give the segmentation masks for: "
    "(1) every window glass of the vehicle -- windshield, side windows, rear window -- "
    "label each \"glass\"; (2) any ground, pavement or background seen under the "
    "vehicle's body between its tires, label \"ground under\". "
    "Output a JSON list of segmentation masks where each entry contains the 2D "
    "bounding box in the key \"box_2d\" as [ymin, xmin, ymax, xmax] normalized to 0-1000, "
    "the segmentation mask polygon in the key \"mask\" as a list of [x, y] points "
    "normalized to 0-1000 over the whole image, and the text label in the key \"label\".")


def ai_look(img, key: str) -> dict:
    """Ask Gemini (the free text model) where the glass is and where ground
    shows under the car. {} when it can't say -- the photo is still made."""
    import ai_reply
    import numpy as np
    w, h = img.size
    small = img.copy()
    small.thumbnail((1024, 1024))
    buf = io.BytesIO()
    small.save(buf, "JPEG", quality=88)
    body = {"contents": [{"role": "user", "parts": [
        {"text": LOOK_PROMPT},
        {"inline_data": {"mime_type": "image/jpeg",
                         "data": base64.b64encode(buf.getvalue()).decode()}}]}],
        "generationConfig": {"temperature": 0.1, "responseMimeType": "application/json",
                             "thinkingConfig": {"thinkingBudget": 0}}}
    try:
        models = ai_reply.pick_model(key)[:3]
    except Exception:
        return {}
    for m in models:
        for b in (body, {**body, "generationConfig": {"temperature": 0.1,
                                                      "responseMimeType": "application/json"}}):
            try:
                d = ai_reply._post(f"{ai_reply.API}/models/{m}:generateContent", key, b, timeout=60)
            except Exception as e:
                if getattr(e, "code", 0) == 400 and b is body:
                    continue
                break
            txt = "".join(x.get("text", "") for x in
                          (((d.get("candidates") or [{}])[0].get("content") or {}).get("parts") or []))
            try:
                mm = re.search(r"\[.*\]", txt, re.S)
                items = json.loads(mm.group(0) if mm else txt)
                if isinstance(items, dict):
                    items = next((v for v in items.values() if isinstance(v, list)), [])
            except Exception:
                break
            glass = np.zeros((h, w), bool)
            under = np.zeros((h, w), bool)
            for it in items if isinstance(items, list) else []:
                if not isinstance(it, dict):
                    continue
                lab = str(it.get("label", "")).lower()
                try:
                    pm = _poly_mask(it, w, h)
                except Exception:
                    continue
                if "glass" in lab or "window" in lab or "windshield" in lab:
                    glass |= pm
                elif "ground" in lab or "under" in lab:
                    under |= pm
            return {"glass": glass if glass.any() else None,
                    "under": under if under.any() else None}
    return {}


def _check_masks(masks: dict, a, src=None) -> dict:
    """The AI's window and under-car outlines, kept only where they make
    sense: glass in the upper part of the car, ground under the body between
    its ends. Anything that covers too much is a wrong answer and is dropped
    (the photo is still made, just without that refinement)."""
    import numpy as np
    car = a > 0.5
    if not car.any():
        return {}
    ys, xs = np.where(car)
    top, bot = ys.min(), ys.max()
    left, right = xs.min(), xs.max()
    area = car.sum()
    out = {}
    g = masks.get("glass")
    if g is not None and g.shape == car.shape:
        g = g & car
        g[int(top + (bot - top) * 0.62):] = False          # windows are never down at the wheels
        ok = 0.01 * area < g.sum() < 0.35 * area
        if ok and src is not None:
            # glass is darker than the paint around it; an outline over the
            # hood or the grille is a wrong answer
            lum = np.asarray(src, np.float32).mean(axis=2) if np.asarray(src).ndim == 3 else np.asarray(src, np.float32)
            body = car & ~g
            if body.any() and np.median(lum[g]) > np.median(lum[body]) * 0.95:
                ok = False
        if ok:
            out["glass"] = g
    u = masks.get("under")
    if u is not None and u.shape == car.shape:
        keep = np.zeros_like(u)
        keep[int(top + (bot - top) * 0.55): bot + 1, left: right + 1] = True
        u = u & keep
        if 0 < u.sum() < 0.25 * area:
            out["under"] = u
    return out


def compose(img, a, key: str, own: str = "", masks: dict | None = None):
    """The on-this-computer version. Returns (result, ground, final mask)."""
    import numpy as np
    from PIL import Image
    m = a > 0.5
    ys, xs = np.where(m)
    top, bot = ys.min(), ys.max()
    car_h = bot - top
    cols, base = _baseline(m)
    studio = key in STUDIO
    if key in STUDIO or key == "concrete-skyline":
        floor_y = int(min(base.min(), bot) - car_h * 0.08)
    else:
        floor_y = int(bot - car_h * 0.40)
    car_cx = float(xs.mean())
    bg = np.asarray(scene(key, img.size, floor_y, car_cx, own), np.float32)
    src = np.asarray(img, np.float32)

    car = _defringe(src, a)
    car = _harmonize(car, a, bg, 0.6 if studio else 1.0)
    car = _light_wrap(car, a, bg)

    masks = _check_masks(masks or {}, a, src)
    real, a = _ground_shadow(src, a, masks.get("under"))
    if masks.get("glass") is not None:
        car = _glass(car, src, bg, masks["glass"] * (a > 0.5))
    m = a > 0.5
    drawn = _shadows(a > 0.5, _light_side(bg), studio)
    dark = {"white-studio": 0.42, "gray-studio": 0.5, "charcoal-studio": 0.6, "blue": 0.6}
    k = dark.get(key, 0.62)
    if real.max() > 0.2:
        # the photo's own shadow, with a touch of drawn contact under the tires
        shade = np.maximum(real * (0.45 if studio else 0.95), drawn * k * (0.9 if studio else 0.6))
    else:
        shade = drawn * k
    ground = bg * (1 - shade[..., None])
    if studio:
        ground = _reflection(ground, src, a, cols, base,
                             0.10 if key == "white-studio" else 0.16)
    # match the scene's grain to the car's so neither looks pasted
    nb, nc = _noise_level(bg), _noise_level(src)
    if nc > nb:
        ground = _grain(ground, (nc * nc - nb * nb) ** 0.5 * 0.8)

    aa = a[..., None]
    out = car * aa + ground * (1 - aa)
    res = Image.fromarray(np.clip(out, 0, 255).astype(np.uint8))
    return res, Image.fromarray(np.clip(ground, 0, 255).astype(np.uint8)), a


# ------------------------------------------------------------ AI finish
AI_PROMPT = (
    "This is a photo of a real vehicle for sale, digitally placed on a new background. "
    "Make it look like a real photograph taken on location: blend the lighting and "
    "color temperature of the scene onto the vehicle, add realistic ground contact "
    "shadows under the tires and the body that match the scene's light, and let the "
    "paint pick up soft reflections of the surroundings. "
    "Do NOT change the vehicle: same shape, size, position, angle, paint color, wheels, "
    "tires, badges, trim, lights, and any marks. Do not move, resize, rotate or crop. "
    "Keep the background scene as it is. Do not add people, animals, text, logos, "
    "watermarks or other vehicles.")


class AIError(Exception):
    pass


def _image_models(key: str) -> list[str]:
    import ai_reply
    try:
        d = ai_reply._post(f"{ai_reply.API}/models?pageSize=200", key, timeout=20)
    except Exception as e:
        raise AIError(ai_reply._why(e))
    names = []
    for m in d.get("models", []):
        n = str(m.get("name", "")).split("/")[-1]
        if "generateContent" not in (m.get("supportedGenerationMethods") or []):
            continue
        if "image" in n and "imagen" not in n and "gemini" in n:
            names.append(n)

    def rank(n):
        nums = [float(x) for x in re.findall(r"\d+(?:\.\d+)?", n)] or [0]
        return ("lite" not in n, "preview" not in n, max(nums))
    return sorted(names, key=rank, reverse=True)


def ai_finish(comp, key: str):
    """Send the composite to Google's image AI and return its picture."""
    import ai_reply
    from PIL import Image
    buf = io.BytesIO()
    small = comp.copy()
    small.thumbnail((1600, 1600))
    small.save(buf, "JPEG", quality=90)
    parts = [{"text": AI_PROMPT},
             {"inline_data": {"mime_type": "image/jpeg",
                              "data": base64.b64encode(buf.getvalue()).decode()}}]
    w, h = comp.size
    ratio = min(["1:1", "4:3", "3:2", "16:9", "3:4", "2:3"],
                key=lambda r: abs(int(r.split(":")[0]) / int(r.split(":")[1]) - w / h))
    models = _image_models(key)
    if not models:
        raise AIError("This Google key doesn't have the image AI. It needs billing "
                      "turned on in Google AI Studio.")
    last = None
    for m in models[:3]:
        for cfg in ({"responseModalities": ["IMAGE"],
                     "imageConfig": {"aspectRatio": ratio, "imageSize": "2K"}},
                    {"responseModalities": ["IMAGE", "TEXT"]}):
            body = {"contents": [{"role": "user", "parts": parts}], "generationConfig": cfg}
            try:
                d = ai_reply._post(f"{ai_reply.API}/models/{m}:generateContent", key,
                                   body, timeout=120)
            except Exception as e:
                last = e
                code = getattr(e, "code", 0)
                if code == 400:
                    continue           # try the plainer request
                if code == 429:
                    try:
                        msg = e.read().decode("utf-8", "replace")
                    except Exception:
                        msg = ""
                    if "free" in msg.lower() or "limit: 0" in msg:
                        raise AIError("The AI finish needs billing turned on for your "
                                      "Google key (Google's image AI has no free tier).")
                break
            for c in d.get("candidates") or []:
                for p in ((c.get("content") or {}).get("parts") or []):
                    data = (p.get("inlineData") or p.get("inline_data") or {}).get("data")
                    if data:
                        return Image.open(io.BytesIO(base64.b64decode(data))).convert("RGB")
            last = AIError("Google answered without a picture")
            break
    raise AIError(ai_reply._why(last) if not isinstance(last, AIError) else str(last))


def _align(ai, comp):
    """The AI's picture, lined up exactly with ours (it may shift or scale a
    little). None if it can't be lined up -- then it isn't used."""
    import cv2
    import numpy as np
    w, h = comp.size
    A = np.asarray(ai.resize((w, h)), np.uint8)
    B = np.asarray(comp, np.uint8)
    ga = cv2.cvtColor(A, cv2.COLOR_RGB2GRAY)
    gb = cv2.cvtColor(B, cv2.COLOR_RGB2GRAY)
    orb = cv2.ORB_create(4000)
    ka, da = orb.detectAndCompute(ga, None)
    kb, db = orb.detectAndCompute(gb, None)
    if da is None or db is None or len(ka) < 30 or len(kb) < 30:
        return None
    matches = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True).match(da, db)
    if len(matches) < 30:
        return None
    pa = np.float32([ka[x.queryIdx].pt for x in matches])
    pb = np.float32([kb[x.trainIdx].pt for x in matches])
    M, inl = cv2.estimateAffinePartial2D(pa, pb, method=cv2.RANSAC, ransacReprojThreshold=4)
    if M is None or inl is None or inl.sum() < 25:
        return None
    scale = (M[0, 0] ** 2 + M[1, 0] ** 2) ** 0.5
    if abs(scale - 1) > 0.15 or abs(M[1, 0]) > 0.05:
        return None
    out = cv2.warpAffine(A, M, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)
    valid = cv2.warpAffine(np.ones((h, w), np.float32), M, (w, h), borderMode=cv2.BORDER_CONSTANT)
    valid = cv2.erode(valid, np.ones((5, 5), np.uint8))[..., None]
    # any edge the AI's picture doesn't reach keeps ours
    return out.astype(np.float32) * valid + B.astype(np.float32) * (1 - valid)


def _restore_car(ai_arr, comp, a, glass=None):
    """Lay the car's own pixels back over the AI's picture, carrying only the
    AI's light (a smooth brightness and a very small tint), so no detail of
    the car changes."""
    import cv2
    import numpy as np
    c = np.asarray(comp, np.float32)
    m = a > 0.5
    r = max(8, int(min(a.shape) * 0.03))
    wgt = cv2.GaussianBlur(m.astype(np.float32), (0, 0), r) + 1e-4

    def smooth(x):
        return cv2.GaussianBlur(x * m[..., None], (0, 0), r) / wgt[..., None]
    gain = (smooth(ai_arr) + 4) / (smooth(c) + 4)
    lum = gain.mean(axis=2, keepdims=True)
    lum = np.clip(lum, 0.75, 1.3)
    tint = np.clip(gain / np.maximum(gain.mean(axis=2, keepdims=True), 1e-3), 0.96, 1.04)
    car = c * lum * tint
    if glass is not None:
        # through the windows the AI's new reflections are kept
        gl = cv2.GaussianBlur((glass & m).astype(np.float32), (0, 0), 1.2)[..., None]
        car = car * (1 - gl) + ai_arr * gl
    # the edge: a narrow blend so the AI's shadows meet the car cleanly
    aa = cv2.GaussianBlur(a, (0, 0), 1.0)[..., None]
    return car * aa + ai_arr * (1 - aa)


# ------------------------------------------------------------ one photo, one car
def make_one(src_path: Path, key: str, dest: Path, own: str = "", ai_key: str = "",
             log=print, look_key: str = "") -> dict:
    """One photo. {'ok', 'skipped', 'ai', 'note'}"""
    import numpy as np
    from PIL import Image, ImageOps
    # With AI on, it says whether this is an outside shot of the whole car --
    # the shape test alone can take a dashboard or a key fob for a car.
    def skip():
        # a background made earlier for an inside shot or close-up goes away
        try:
            if dest.exists():
                dest.unlink()
        except OSError:
            pass
        return {"ok": True, "skipped": True}
    view = ai_view(src_path)
    if view is False:
        return skip()
    img = ImageOps.exif_transpose(Image.open(src_path)).convert("RGB")
    a = cutout(img)
    if not a.any() or not is_outside_shot(a):
        return skip()
    masks = {}
    if look_key:
        try:
            masks = _check_masks(ai_look(img, look_key), a, img)
        except Exception:
            masks = {}
    res, _ground, a = compose(img, a, key, own, masks)
    note, used_ai = "", False
    if ai_key:
        try:
            ai = ai_finish(res, ai_key)
            aligned = _align(ai, res)
            if aligned is None:
                note = "the AI moved the car, so the regular version was kept"
            else:
                out = _restore_car(aligned, res, a, masks.get("glass"))
                res = Image.fromarray(np.clip(out, 0, 255).astype(np.uint8))
                used_ai = True
        except AIError as e:
            note = str(e)
        except Exception as e:
            note = f"AI finish skipped: {e}"
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_name(dest.stem + ".tmp.jpg")
    res.save(tmp, "JPEG", quality=92)
    os.replace(tmp, dest)
    return {"ok": True, "skipped": False, "ai": used_ai, "note": note}


def bg_name(p: Path) -> str:
    stem = p.stem[4:] if p.stem.lower().startswith("web_") else p.stem
    return f"bg_{stem}.jpg"


def originals(folder: Path) -> list[Path]:
    ext = (".jpg", ".jpeg", ".png", ".webp")
    if not folder.is_dir():
        return []
    pics = [p for p in folder.iterdir() if p.suffix.lower() in ext
            and not p.name.lower().startswith(("bg_", "thumb", "."))
            and ".tmp." not in p.name]
    return sorted(pics, key=lambda p: (not p.name.lower().startswith("web_"), p.name.lower()))


def made_for(folder: Path) -> list[Path]:
    return sorted(folder.glob("bg_*.jpg")) if folder.is_dir() else []


def _record(folder: Path) -> Path:
    return folder / ".backgrounds.json"


def make_car(folder: Path, names: list[str] | None, key: str, own: str = "",
             ai_key: str = "", progress=lambda f, msg: None, log=print,
             look_key: str = "") -> dict:
    """Make bg_ photos for one car folder. names=None: every web_ outside shot."""
    pics = originals(folder)
    if names is not None:
        want = set(names)
        pics = [p for p in pics if p.name in want]
    else:
        pics = [p for p in pics if p.name.lower().startswith("web_")]
    made, skipped, notes, ai_used = [], [], [], 0
    inside_run = 0
    for i, p in enumerate(pics):
        progress(i / max(1, len(pics)), f"{p.name} ({i + 1} of {len(pics)})")
        try:
            r = make_one(p, key, folder / bg_name(p), own, ai_key, log, look_key)
        except Exception as e:
            notes.append(f"{p.name}: {e}")
            continue
        if r.get("skipped"):
            skipped.append(p.name)
            inside_run += 1
            # dealer photo sets go outside first, then inside: once a set has
            # turned inside for a while, stop looking (morning run only)
            if names is None and made and inside_run >= 2:
                break
            continue
        inside_run = 0
        made.append(folder / bg_name(p))
        ai_used += r.get("ai", False)
        if r.get("note") and r["note"] not in notes:
            notes.append(r["note"])
    # the photo's bg_ copy goes when its original goes
    keep = {bg_name(p) for p in originals(folder)}
    for old in made_for(folder):
        if old.name not in keep:
            old.unlink(missing_ok=True)
    try:
        sig = json.loads((folder / ".web_photos.json").read_text(encoding="utf-8")).get("sig")
    except Exception:
        sig = None
    try:
        _record(folder).write_text(json.dumps({"bg": key, "sig": sig, "ai": bool(ai_key),
                                               "when": time.strftime("%Y-%m-%d %H:%M")}),
                                   encoding="utf-8")
    except OSError:
        pass
    try:
        if made_for(folder):
            posting_set(folder)
        else:
            import shutil
            shutil.rmtree(folder / "post", ignore_errors=True)
    except OSError:
        pass
    progress(1.0, "Done")
    return {"ok": True, "made": [m.name for m in made], "skipped": skipped,
            "ai": ai_used, "notes": notes}


POST_MAX = 20      # Marketplace takes up to 20 photos


def posting_set(folder: Path) -> list[Path]:
    """
    A ready-to-post set in the car's "post" folder: every photo in order,
    the background version where one was made and the original for the
    rest, numbered 01, 02... -- select them all and drag them into
    Marketplace in one go.
    """
    import shutil
    pics = originals(folder)
    out_dir = folder / "post"
    out_dir.mkdir(exist_ok=True)
    for old in out_dir.iterdir():
        if old.is_file():
            old.unlink(missing_ok=True)
    made = []
    for i, p in enumerate(pics[:POST_MAX], 1):
        b = folder / bg_name(p)
        src = b if b.exists() else p
        dst = out_dir / f"{i:02d}{src.suffix.lower()}"
        shutil.copy2(src, dst)
        made.append(dst)
    return made


def needs_redo(folder: Path, key: str) -> bool:
    try:
        r = json.loads(_record(folder).read_text(encoding="utf-8"))
        sig = json.loads((folder / ".web_photos.json").read_text(encoding="utf-8")).get("sig")
    except Exception:
        return True
    return r.get("bg") != key or r.get("sig") != sig


def ai_key() -> str:
    try:
        import ai_reply
        s = ai_reply.settings()
        # a Google key does the background clean-up even when replies use
        # OpenAI or Claude; "Copy for AI" means no AI inside the program
        return s["key"] if s["mode"] != "copy" and s["key"] else ""
    except Exception:
        return ""


# ------------------------------------------------------------ the morning run
def auto_run(log=print) -> int:
    s = settings()
    if s["which"] != "all" and not s["cars"]:
        log("Backgrounds: off (Settings -> Photos & videos).")
        return 0
    if s["which"] == "all" and s["bg"] == OFF and not s["cars"]:
        log("Backgrounds: off.")
        return 0
    if not ready():
        log("Backgrounds: not set up on this computer yet -- open Backgrounds and click Set up.")
        return 0
    try:
        recs = json.loads(Path(config.INVENTORY_JSON).read_text(encoding="utf-8"))
    except Exception:
        log("Backgrounds: no inventory to work from.")
        return 0
    look = ai_key()
    key_ai = look if s["ai_finish"] else ""
    done = 0
    for r in recs:
        stock = str(r.get("stock") or "").upper()
        if not stock:
            continue
        if s["which"] != "all" and stock not in s["cars"]:
            continue
        folder = Path(config.PHOTO_DROP) / stock
        try:
            man = json.loads((folder / ".web_photos.json").read_text(encoding="utf-8"))
        except Exception:
            continue
        if man.get("stock_only"):
            continue                       # stock pictures: nothing real to place
        bg = pick_for(stock, s)
        if bg == OFF:
            continue
        if not needs_redo(folder, bg):
            continue
        t = time.time()
        res = make_car(folder, None, bg, s["own"], key_ai, look_key=look)
        done += 1
        log(f"  {stock}: {len(res['made'])} bg_ photos on {BY_KEY.get(bg, {}).get('label', bg)}"
            f" ({time.time() - t:.0f}s)" + (f" -- {res['notes'][0]}" if res["notes"] else ""))
    log(f"Backgrounds: {done} car{'s' if done != 1 else ''} done.")
    return done


if __name__ == "__main__":
    if "--auto" in sys.argv:
        auto_run()
