"""
Free background music for the walkaround videos, made right here from
scratch (like Country rock in sound.py): no samples, no recordings, no
melodies borrowed from anyone -- so it is safe to sell with the program and
safe to post anywhere.

    compose("pop", Path("media/pop.wav"))

Styles: pop (upbeat pop), hiphop (hip-hop beat), rock, acoustic (calm
acoustic), holiday. Each is about a minute and loops cleanly.
"""
from __future__ import annotations

import wave
from pathlib import Path

SR = 32000

STYLES = {"pop": "Upbeat pop", "hiphop": "Hip-hop beat", "rock": "Rock",
          "acoustic": "Calm acoustic", "holiday": "Holiday"}


def _np():
    import numpy as np
    return np


def midi(m):
    return 440 * 2 ** ((m - 69) / 12)


class _Mix:
    def __init__(self, seconds):
        np = _np()
        self.a = np.zeros(int(SR * (seconds + 3)))

    def add(self, sig, t, g):
        i = int(t * SR)
        if i >= len(self.a):
            return
        j = min(len(self.a), i + len(sig))
        self.a[i:j] += sig[: j - i] * g


# --- instruments --------------------------------------------------------------
def _t(d):
    return _np().arange(int(SR * d)) / SR


def kick(d=0.35, punch=1.0):
    np = _np()
    t = _t(d)
    f = 120 * np.exp(-t * 22) + 42
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 7) * punch


def snare(rng, d=0.22):
    np = _np()
    t = _t(d)
    return rng.uniform(-1, 1, len(t)) * np.exp(-t * 18) * 0.8 + 0.35 * np.sin(2 * np.pi * 185 * t) * np.exp(-t * 25)


def clap(rng):
    np = _np()
    t = _t(0.2)
    env = np.exp(-t * 30) + 0.6 * np.exp(-((t - 0.012) * 300) ** 2) + 0.5 * np.exp(-((t - 0.024) * 300) ** 2)
    nz = np.diff(np.concatenate([[0], rng.uniform(-1, 1, len(t))]))
    return nz * env * 0.9


def hat(rng, d=0.05, open_=False):
    np = _np()
    t = _t(0.25 if open_ else d)
    nz = np.diff(np.concatenate([[0], rng.uniform(-1, 1, len(t))]))
    return nz * np.exp(-t * (14 if open_ else 80))


def shaker(rng):
    np = _np()
    t = _t(0.09)
    nz = np.diff(np.concatenate([[0], rng.uniform(-1, 1, len(t))]))
    return nz * np.sin(np.pi * t / t[-1]) ** 2 * 0.6


def jingle(rng):
    """Sleigh-bell shake: bright metallic partials over noise."""
    np = _np()
    t = _t(0.22)
    s = sum(np.sin(2 * np.pi * f * t + rng.uniform(0, 6)) for f in (5200, 6900, 8300, 9700))
    nz = np.diff(np.concatenate([[0], rng.uniform(-1, 1, len(t))]))
    return (s * 0.25 + nz * 0.5) * np.exp(-t * 16)


def crash(rng):
    np = _np()
    t = _t(1.4)
    nz = np.diff(np.concatenate([[0], rng.uniform(-1, 1, len(t))]))
    return nz * np.exp(-t * 3.2) * 0.7


def sine_bass(m, d, decay=3.0):
    np = _np()
    t = _t(d)
    f = midi(m)
    return (np.sin(2 * np.pi * f * t) + 0.25 * np.sin(4 * np.pi * f * t)) * np.exp(-t * decay) * np.clip(t * 200, 0, 1)


def saw(f, t, voices=3, detune=0.006):
    np = _np()
    out = 0
    for k in range(voices):
        ff = f * (1 + detune * (k - (voices - 1) / 2))
        ph = (t * ff + k * 0.31) % 1.0
        out = out + (2 * ph - 1)
    return out / voices


def soft(sig, k=6):
    """A gentle low-pass (moving average) to take the fizz off."""
    np = _np()
    return np.convolve(sig, np.ones(k) / k, "same")


def pad(ms, d):
    np = _np()
    t = _t(d)
    env = np.clip(t / 0.25, 0, 1) * np.clip((d - t) / 0.4, 0, 1)
    return soft(sum(saw(midi(m), t) for m in ms) / len(ms), 12) * env


def epiano(m, d, bright=1.0):
    """A soft electric-piano tone (sine with a little bell)."""
    np = _np()
    t = _t(d)
    f = midi(m)
    tone = np.sin(2 * np.pi * f * t) + 0.3 * bright * np.sin(2 * np.pi * 2 * f * t) * np.exp(-t * 6) \
        + 0.15 * bright * np.sin(2 * np.pi * 7.0 * f * t) * np.exp(-t * 14)
    return tone * np.exp(-t * 2.2) * np.clip(t * 400, 0, 1)


def bell(m, d=1.2):
    np = _np()
    t = _t(d)
    f = midi(m)
    return (np.sin(2 * np.pi * f * t) + 0.5 * np.sin(2 * np.pi * 2.76 * f * t) * np.exp(-t * 4)
            + 0.25 * np.sin(2 * np.pi * 5.4 * f * t) * np.exp(-t * 8)) * np.exp(-t * 2.6)


def pluck(rng, m, d, bright=0.5, decay=0.996):
    np = _np()
    n, p = int(SR * d), max(2, int(SR / midi(m)))
    buf = rng.uniform(-1, 1, p) * bright + (1 - bright) * np.sin(np.linspace(0, 2 * np.pi, p, endpoint=False))
    out = np.empty(n)
    k = 0
    while k < n:
        q = min(p, n - k)
        out[k:k + q] = buf[:q]
        buf = decay * 0.5 * (buf + np.roll(buf, -1))
        k += q
    return out


def power(ms, d):
    """A distorted power chord."""
    np = _np()
    t = _t(d)
    s = sum(saw(midi(m), t, 2, 0.004) for m in ms)
    env = np.clip(t * 80, 0, 1) * np.exp(-t * 0.6)
    return soft(np.tanh(soft(s, 14) * 2.5), 10) * env * 0.5


# --- the styles ---------------------------------------------------------------
CHORDS = {   # triads as MIDI notes (around middle C)
    "C": [60, 64, 67], "G": [55, 59, 62], "Am": [57, 60, 64], "F": [53, 57, 60],
    "Dm": [62, 65, 69], "Em": [64, 67, 71], "D": [62, 66, 69], "A": [57, 61, 64],
    "Bm": [59, 62, 66], "E": [64, 68, 71], "Am7": [57, 60, 64, 67], "Dm7": [62, 65, 69, 72],
    "Fmaj7": [53, 57, 60, 64], "Em7": [52, 55, 59, 62],
}
ROOT = {"C": 36, "G": 31, "Am": 33, "F": 29, "Dm": 38, "Em": 28, "D": 38, "A": 33, "Bm": 35,
        "E": 28, "Am7": 33, "Dm7": 38, "Fmaj7": 29, "Em7": 28}


def _pop(m, rng, seconds):
    bpm = 118
    beat = 60 / bpm
    prog = ["C", "G", "Am", "F"]
    bars = int(seconds / (4 * beat))
    k, cl = kick(), clap(rng)
    motif = [0, 2, 1, 2, 0, 1, 2, 1]                      # chord-tone pattern, made here
    for b in range(bars):
        c = prog[b % 4]
        t0 = b * 4 * beat
        for q in range(4):
            m.add(k, t0 + q * beat, 0.9)
            if q in (1, 3):
                m.add(cl, t0 + q * beat, 0.28)
        for e in range(8):
            m.add(hat(rng), t0 + e * beat / 2 + beat / 4, 0.08)
            m.add(sine_bass(ROOT[c] + (12 if e % 2 else 0), beat / 2 * 0.9, 5), t0 + e * beat / 2, 0.42)
        for q in (0.5, 1.5, 2.5, 3.5):                    # off-beat chords
            for n in CHORDS[c]:
                m.add(epiano(n, beat * 0.9), t0 + q * beat, 0.09)
        if b % 8 >= 4:                                     # a little top line in the second half
            for e, idx in enumerate(motif):
                m.add(bell(CHORDS[c][idx] + 12, 0.5), t0 + e * beat / 2, 0.06)
    return bars * 4 * beat


def _hiphop(m, rng, seconds):
    bpm = 88
    beat = 60 / bpm
    swing = 0.06
    prog = ["Am7", "Dm7", "Fmaj7", "Em7"]
    bars = int(seconds / (4 * beat))
    k, sn = kick(0.45, 1.2), snare(rng, 0.18)
    for b in range(bars):
        c = prog[b % 4]
        t0 = b * 4 * beat
        for pos in (0, 1.75, 2.5):                        # boom-bap kick
            m.add(k, t0 + pos * beat, 1.0)
        for pos in (1, 3):
            m.add(sn, t0 + pos * beat, 0.38)
        for s in range(16):
            sw = swing * beat if s % 2 else 0
            m.add(hat(rng, 0.04), t0 + s * beat / 4 + sw, 0.09 if s % 2 else 0.14)
        for n in CHORDS[c]:
            m.add(epiano(n, 4 * beat * 0.95, 0.6), t0, 0.08)
        m.add(sine_bass(ROOT[c] - 12, 1.5 * beat, 1.5), t0, 0.55)
        m.add(sine_bass(ROOT[c] - 12, beat, 2.5), t0 + 2.5 * beat, 0.45)
    return bars * 4 * beat


def _rock(m, rng, seconds):
    bpm = 126
    beat = 60 / bpm
    prog = ["E", "C", "G", "D"]
    pw = {"E": [40, 47, 52], "C": [36, 43, 48], "G": [43, 50, 55], "D": [38, 45, 50]}
    bars = int(seconds / (4 * beat))
    k, sn, cr = kick(0.3, 1.1), snare(rng), crash(rng)
    for b in range(bars):
        c = prog[b % 4]
        t0 = b * 4 * beat
        if b % 4 == 0:
            m.add(cr, t0, 0.35)
        for q in range(4):
            m.add(k if q in (0, 2) else sn, t0 + q * beat, 0.85 if q in (0, 2) else 0.45)
        m.add(k, t0 + 2.5 * beat, 0.6)
        for e in range(8):
            m.add(hat(rng), t0 + e * beat / 2, 0.07)
            m.add(power(pw[c], beat / 2 * 0.95), t0 + e * beat / 2, 0.28)
            m.add(sine_bass(ROOT[c], beat / 2 * 0.9, 4), t0 + e * beat / 2, 0.4)
    return bars * 4 * beat


def _acoustic(m, rng, seconds):
    bpm = 84
    beat = 60 / bpm
    prog = ["D", "A", "Bm", "G"]
    shape = {"D": [50, 57, 62, 66, 69], "A": [45, 52, 57, 61, 64], "Bm": [47, 54, 59, 62, 66],
             "G": [43, 50, 55, 59, 62]}
    order = [0, 2, 3, 4, 3, 2, 1, 3]                       # a fingerpicking pattern
    bars = int(seconds / (4 * beat))
    cache = {}
    for b in range(bars):
        c = prog[b % 4]
        t0 = b * 4 * beat
        for e, idx in enumerate(order):
            n = shape[c][idx]
            if n not in cache:
                cache[n] = pluck(rng, n, 2.0, 0.35, 0.9975)
            m.add(cache[n], t0 + e * beat / 2 + rng.uniform(0, 0.008), 0.22)
        for q in range(4):
            m.add(shaker(rng), t0 + q * beat + beat / 2, 0.08)
        m.add(sine_bass(ROOT[c], 2 * beat, 1.2), t0, 0.3)
        m.add(sine_bass(ROOT[c] + 7, 2 * beat, 1.2), t0 + 2 * beat, 0.22)
    return bars * 4 * beat


def _holiday(m, rng, seconds):
    bpm = 132
    beat = 60 / bpm
    prog = ["G", "Em", "C", "D"]
    gch = {"G": [55, 59, 62], "Em": [52, 55, 59], "C": [48, 52, 55], "D": [50, 54, 57]}
    groot = {"G": 31, "Em": 28, "C": 36, "D": 38}
    # an original little bell line built from chord tones (not any carol)
    line = [2, 1, 0, 1, 2, 2, 1, -1]
    bars = int(seconds / (4 * beat))
    k = kick(0.3, 0.8)
    for b in range(bars):
        c = prog[b % 4]
        t0 = b * 4 * beat
        for q in range(4):
            m.add(k, t0 + q * beat, 0.5 if q in (0, 2) else 0.25)
        for e in range(8):
            m.add(jingle(rng), t0 + e * beat / 2, 0.16 if e % 2 == 0 else 0.1)
        walk = [groot[c], groot[c] + 4, groot[c] + 7, groot[c] + 9]   # walking bass
        for q, n in enumerate(walk):
            m.add(sine_bass(n + 12, beat * 0.9, 4), t0 + q * beat, 0.4)
        for q in (1, 3):
            for n in gch[c]:
                m.add(epiano(n, beat * 0.8), t0 + q * beat, 0.08)
        for e, idx in enumerate(line):
            if idx >= 0 and (b % 2 == 0 or e < 4):
                m.add(bell(gch[c][idx] + 24, 0.9), t0 + e * beat / 2, 0.11)
    return bars * 4 * beat


_MAKERS = {"pop": _pop, "hiphop": _hiphop, "rock": _rock, "acoustic": _acoustic, "holiday": _holiday}


def compose(style: str, out: Path, seconds: float = 62.0, seed: int = 11) -> Path:
    np = _np()
    if style not in _MAKERS:
        raise ValueError(f"Unknown music style: {style}")
    rng = np.random.default_rng(seed + sum(map(ord, style)))
    mx = _Mix(seconds)
    length = _MAKERS[style](mx, rng, seconds)
    a = mx.a[: int(SR * (length + 0.6))]
    fade = int(SR * 0.6)
    a[-fade:] *= np.linspace(1, 0, fade)
    a = np.tanh(a * 1.3)
    a /= max(1e-6, np.abs(a).max()) * 1.12
    pcm = (a * 32767 * 0.9).astype("<i2")
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_suffix(".tmp")
    with wave.open(str(tmp), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())
    tmp.replace(out)
    return out


def preview_uri(path: Path, seconds: float = 14.0) -> str:
    """The first few seconds as a small playable sound for the ▶ button."""
    import base64
    import io
    with wave.open(str(path), "rb") as r:
        n = int(r.getframerate() * seconds)
        frames = r.readframes(n)
        params = r.getparams()
    b = io.BytesIO()
    with wave.open(b, "wb") as w:
        w.setnchannels(params.nchannels)
        w.setsampwidth(params.sampwidth)
        w.setframerate(params.framerate)
        w.writeframes(frames)
    return "data:audio/wav;base64," + base64.b64encode(b.getvalue()).decode()
