"""
Listing Accelerator -- first-run setup.

The one screen a new owner fills in: who he is, where he works, the web
address of his inventory, and the terms. Everything he types lands in
settings.json next to this file, and config.py reads it from there, so the
program he installed is the same program everyone else installed -- only the
notes beside it differ.

Nothing in here is a Python file anybody has to open.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

# Setting up one store of several: its settings live in its own folder.
STORE_DIR = Path(os.environ["LA_STORE_DIR"]) if os.environ.get("LA_STORE_DIR") else HERE
SETTINGS = STORE_DIR / "settings.json"

# Carried over from a previous setup so changing your phone number does not
# reset the photo count or the price ceiling.
KEEP = ("max_photos", "focus_max_price", "emoji_style", "max_pages")


def load() -> dict:
    try:
        with open(SETTINGS, encoding="utf-8") as fh:
            d = json.load(fh)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


class Api:
    def current(self):
        return load()

    def clipboard(self):
        """
        Whatever is on the Windows clipboard.

        A web address is the one thing nobody should ever have to type by
        hand. The browser's own clipboard API needs a permission prompt that
        a local page does not get, so we read it on the Python side and hand
        it to the page. tkinter ships with Python and is already used by the
        installer, so this costs nothing.
        """
        try:
            import tkinter
            root = tkinter.Tk()
            root.withdraw()
            try:
                text = root.clipboard_get()
            finally:
                root.destroy()
            return {"ok": True, "text": str(text).strip()}
        except Exception:
            return {"ok": False, "text": ""}

    def check_url(self, url):
        """
        Open the address the salesman gave us and say what is actually there,
        before he spends half an hour finding out it was wrong.
        """
        url = (url or "").strip()
        if not url:
            return {"ok": False, "message": "Put the web address in first."}
        if not re.match(r"^https?://", url, re.I):
            url = "https://" + url

        try:
            from playwright.sync_api import sync_playwright
        except Exception:
            return {"ok": True, "unchecked": True,
                    "message": "Can't test it from here, but it looks like a "
                               "web address. Save and run the update to find "
                               "out."}

        try:
            with sync_playwright() as p:
                b = p.chromium.launch(headless=True)
                pg = b.new_page()
                pg.goto(url, timeout=45_000, wait_until="domcontentloaded")
                pg.wait_for_timeout(3500)
                final = pg.url
                txt = pg.evaluate("document.body.innerText || ''")[:12000]
                cards = pg.evaluate(
                    "document.querySelectorAll("
                    "'[class*=vehicle-card],[class*=vehicleCard],"
                    "[class*=srp-vehicle],[class*=inventory-listing],"
                    "[data-vin],[class*=vehicle-title]').length")
                b.close()
        except Exception as e:
            return {"ok": False,
                    "message": f"Couldn't open that address. {type(e).__name__}"
                               " — check it opens in your browser."}

        m = (re.search(r"of\s+([\d,]+)\s+(?:vehicles?|results?)", txt, re.I)
             or re.search(r"showing\s+all\s+([\d,]+)\s+vehicles?", txt, re.I)
             or re.search(r"([\d,]+)\s+(?:vehicles?|results?)\s+found", txt, re.I))
        total = int(m.group(1).replace(",", "")) if m else None

        if total:
            msg = f"Found it — the page says {total} vehicles."
            if cards:
                msg += f" {cards} showing on this page."
            return {"ok": True, "total": total, "url": final, "message": msg}
        if cards >= 3:
            return {"ok": True, "total": None, "url": final,
                    "message": f"Found {cards} vehicles on the page, but no "
                               f"total. It should still work."}
        return {"ok": False,
                "message": "That page opened but there are no vehicles on it. "
                           "Make sure it's the page that LISTS the cars — "
                           "click Used or Pre-Owned first, then copy the "
                           "address."}

    def save(self, data):
        if not isinstance(data, dict):
            return {"ok": False, "message": "Nothing to save."}
        if not data.get("accepted_terms"):
            return {"ok": False, "message": "Please tick the box first."}

        # Start from everything already saved -- the slice he works, photo
        # count, store wording -- so re-doing setup only changes what is on
        # the setup screen.
        out = dict(load())
        for k, v in data.items():
            if isinstance(v, str):
                v = v.strip()
            out[k] = v

        try:
            SETTINGS.parent.mkdir(parents=True, exist_ok=True)
            with open(SETTINGS, "w", encoding="utf-8") as fh:
                json.dump(out, fh, indent=2)
        except Exception as e:
            return {"ok": False,
                    "message": f"Could not save your details: {e}"}

        # With every store in one program there is one icon, not one per store.
        make_desktop_shortcut("" if STORE_DIR != HERE else (out.get("store_name") or ""))
        launch_app()
        return {"ok": True}


def _ps(text) -> str:
    """A value safe inside a PowerShell '...' string."""
    return str(text).replace("'", "''")


def _pythonw() -> str | None:
    """
    The windowless Python that runs the program. The desktop icon points at
    this, not at the .bat file -- Windows asks "Do you want to run this
    file?" every time a .bat that came from the internet or OneDrive is
    opened, and a .bat also flashes a black window. Python itself is an
    installed program, so neither happens.
    """
    import shutil
    cands = [str(Path(sys.executable).with_name("pythonw.exe")),
             shutil.which("pythonw")]
    # Python from the Microsoft Store lives in a folder whose name changes
    # with every Python update; its stand-in under AppData doesn't, and is
    # the one an icon must point at.
    alias = Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / \
        "WindowsApps" / "pythonw.exe"
    for cand in cands + [str(alias)]:
        if not cand or "\\program files\\windowsapps\\" in cand.lower():
            continue
        if os.path.lexists(cand):
            return str(Path(cand))
    return None


def _run_ps(ps: str, timeout: int = 25):
    return subprocess.run(
        ["powershell", "-NoProfile", "-NonInteractive",
         "-ExecutionPolicy", "Bypass", "-Command", ps],
        timeout=timeout, capture_output=True, text=True,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))


def make_desktop_shortcut(store: str = "", args: str = ""):
    """
    Put an icon on the Desktop so the program is opened like any other
    program, instead of digging through a folder every morning. One click
    and the window comes up -- no "run this file?" box, no black window.

    Done with PowerShell, which is on every Windows machine, so there is
    nothing extra to install. Harmless if it fails -- the folder still works.
    """
    if sys.platform != "win32":
        return False
    try:
        bat = (HERE.parent / "Start Listing Accelerator.bat").resolve()
        app = (HERE / "app.py").resolve()
        icon = (HERE / "app.ico").resolve()
        py = _pythonw()
        if py:
            target, arguments, style = py, f'"{app}" {args}'.strip(), 1
        else:                       # no pythonw found: the .bat still works
            target, arguments, style = str(bat), args, 7
        # One icon per store, so a second copy of the program (another
        # rooftop) gets its own shortcut instead of taking over the first.
        name = "Listing Accelerator"
        clean = re.sub(r"[^A-Za-z0-9 &.-]+", " ", store).strip()
        clean = re.sub(r"\s+", " ", clean)[:50]
        if clean:
            name += " - " + clean
        name = name.replace("'", "")
        ps = f"""
$ws = New-Object -ComObject WScript.Shell
$desk = $ws.SpecialFolders.Item('Desktop')
$lnk = $ws.CreateShortcut((Join-Path $desk '{name}.lnk'))
$lnk.TargetPath = '{_ps(target)}'
$lnk.Arguments = '{_ps(arguments)}'
$lnk.WorkingDirectory = '{_ps(HERE)}'
$lnk.WindowStyle = {style}
$lnk.Description = '{name}'
if (Test-Path '{_ps(icon)}') {{ $lnk.IconLocation = '{_ps(icon)},0' }}
$lnk.Save()
"""
        _run_ps(ps)
        unblock_files()
        return True
    except Exception:
        return False


def unblock_files():
    """
    Clear the "came from the internet" mark Windows puts on files that were
    unzipped from a download or synced through OneDrive -- the mark is what
    makes Windows ask "Do you want to run this file?". Only the program's
    own files; the photos and ads are left alone.
    """
    if sys.platform != "win32":
        return
    try:
        root = HERE.parent
        _run_ps(f"""
Get-ChildItem -LiteralPath '{_ps(root)}' -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
Get-ChildItem -LiteralPath '{_ps(HERE)}' -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
""", timeout=40)
    except Exception:
        pass


def fix_old_icons():
    """
    Icons made by earlier versions point at the .bat file, which is what
    brings up Windows' "Do you want to run this file?" box every morning.
    Point any of those at the program itself instead, keeping whatever
    store each one opens. Done once; nothing else on the Desktop is touched.
    """
    if sys.platform != "win32":
        return
    mark = HERE / ".icons_v2"
    if mark.exists():
        return
    try:
        py = _pythonw()
        bat = (HERE.parent / "Start Listing Accelerator.bat").resolve()
        app = (HERE / "app.py").resolve()
        if py:
            r = _run_ps(f"""
$ws = New-Object -ComObject WScript.Shell
$desk = $ws.SpecialFolders.Item('Desktop')
$n = 0
Get-ChildItem -LiteralPath $desk -Filter '*.lnk' | ForEach-Object {{
  $l = $ws.CreateShortcut($_.FullName)
  if ($l.TargetPath -ieq '{_ps(bat)}') {{
    $a = $l.Arguments
    $l.TargetPath = '{_ps(py)}'
    $l.Arguments = ('"{_ps(app)}" ' + $a).Trim()
    $l.WorkingDirectory = '{_ps(HERE)}'
    $l.WindowStyle = 1
    $l.Save()
    $n++
  }}
}}
Write-Output $n
""")
            if r.returncode != 0:
                return              # try again next time it opens
        unblock_files()
        mark.write_text(datetime_now(), encoding="utf-8")
    except Exception:
        pass


def datetime_now() -> str:
    from datetime import datetime
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def launch_app():
    """Open the program itself, then let this window go."""
    try:
        exe = sys.executable
        # pythonw keeps a black console window from flashing up behind it.
        if sys.platform == "win32":
            w = Path(exe).with_name("pythonw.exe")
            if w.exists():
                exe = str(w)
        args = [exe, str(HERE / "app.py")]
        if STORE_DIR != HERE:
            args += ["--store", STORE_DIR.name]
        subprocess.Popen(args, cwd=str(HERE),
                         creationflags=getattr(subprocess,
                                               "CREATE_NO_WINDOW", 0))
    except Exception:
        pass
    os._exit(0)


def main() -> int:
    try:
        import webview
    except ImportError:
        print("The window library isn't installed yet.")
        return 1

    api = Api()
    webview.create_window(
        "Set up Listing Accelerator",
        str(HERE / "wizard.html"),
        js_api=api,
        width=880, height=760, min_size=(760, 600),
        background_color="#EEF1F4",
    )
    webview.start()
    return 0


if __name__ == "__main__":
    sys.exit(main())
